<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeliveredInformation extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $fillable = 
    [
        'address', 
        'postcode', 
        'city', 
        'country', 
        'status', 
        'delivery_date', 
        'delivery_time_a', 
        'delivery_time_b'
    ];

    public function driverRouteTruckDelivereds()
    {
        return $this->hasMany(DriverRouteTruckDelivered::class);
    }
}
