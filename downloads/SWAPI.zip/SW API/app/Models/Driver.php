<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Driver extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $fillable =
    [
        'fullname',
        'email',
        'phone',
        'password',
        'role',
    ];

    public function driverRouteTruckDelivereds()
    {
        return $this->hasMany(DriverRouteTruckDelivered::class);
    }
    public function truck()
    {
        return $this->belongsToMany(Truck::class, 'driver_route_truck_delivered', 'driver_id', 'truck_id');
    }
}
