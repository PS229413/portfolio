<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Route extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $fillable =
    [
        'start_time',
        'end_time',
        'optimal_route',
        'real_time_updates',
        'last_updated'
    ];

    public function driverRouteTruckDelivereds()
    {
        return $this->hasMany(DriverRouteTruckDelivered::class);
    }
}
