<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DriverRouteTruckDelivered extends Model
{
    use HasFactory;
    protected $table = 'driver_route_truck_delivered';
    public $timestamps = false;
    protected $fillable =
    [
        'route_id',
        'truck_id',
        'driver_id',
        'delivered_information_id',
        'delivered_orders_id'
    ];

    public function driver()
    {
        return $this->belongsTo(Driver::class);
    }

    public function route()
    {
        return $this->belongsTo(Route::class);
    }

    public function truck()
    {
        return $this->belongsTo(Truck::class);
    }

    public function deliveredInformation()
    {
        return $this->belongsTo(DeliveredInformation::class);
    }

    public function deliveredOrder()
    {
        return $this->belongsTo(DeliveredOrder::class);
    }
}
