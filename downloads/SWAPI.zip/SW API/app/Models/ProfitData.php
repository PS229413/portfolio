<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProfitData extends Model
{
    use HasFactory;

    protected $table = 'profitdata'; // Specify the correct table name

    protected $fillable = ['Date', 'Revenue', 'Cost'];

    protected $appends = ['profit']; // Ensure the profit attribute is appended

    // Define a getter for the profit attribute
    public function getProfitAttribute()
    {
        return $this->Revenue - $this->Cost;
    }
}
