<?php

namespace App\Http\Controllers;

use App\Models\DeliveredInformation;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;

class DeliveredInformationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return DeliveredInformation::all();
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try{
            $request->validate([
                'address' => 'required|max:70',
                'postcode' => 'required|max:10',
                'city' => 'required|max:70',
                'country' => 'required|max:2',
                'delivery_date' => 'required'
            ]);
            $delivered_information = DeliveredInformation::create($request->all());
            return response()->json(['message' => 'Delivered information created!',
                'delivered_information' => $delivered_information], 201);
        }
        catch(QueryException $e){
            return response()->json(['message' => $e->getMessage()], 400);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        return DeliveredInformation::findOrFail($id);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try{
            $delivered_information = DeliveredInformation::findOrFail($id);
            $request->validate([
                'address' => 'required|max:70',
                'postcode' => 'required|max:10',
                'city' => 'required|max:70',
                'country' => 'required|max:2',
                'status' => 'required|max:10',
                'delivery_date' => 'required'
            ]);
            $delivered_information->update($request->all());
            return response()->json(['message' => 'Delievered information ' . $id . ' successfully updated!',
                'delivered_information' => $delivered_information]);
        }
        catch(QueryException $e){
            return response()->json(['message' => $e->getMessage()], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $delivered_information = DeliveredInformation::findOrFail($id);
            $delivered_information->delete();
            return response()->json(['message' => 'Delivered information deleted succesfully']);
        }
        catch (QueryException $e) {
            return response()->json(['message' => $e->getMessage()], 400);
        }
    }
}
