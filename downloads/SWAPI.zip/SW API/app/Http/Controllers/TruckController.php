<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Truck;

class TruckController extends Controller
{
    public function index()
    {
        return Truck::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'height' => 'required|integer',
            'weight' => 'required|integer',
        ]);

        return Truck::create($request->all());
    }

    public function show($id)
    {
        return Truck::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $truck = Truck::findOrFail($id);

        $request->validate([
            'height' => 'required|integer',
            'weight' => 'required|integer',
        ]);

        $truck->update($request->all());

        return $truck;
    }

    public function destroy($id)
    {
        $truck = Truck::findOrFail($id);
        $truck->delete();

        return response()->json(['message' => 'Truck deleted successfully']);
    }
}
