<?php

namespace App\Http\Controllers;

use App\Models\DriverSchedule;
use App\Models\Schedule;
use DateTime;
use Illuminate\Http\Request;

class ScheduleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return Schedule::all();
    }

    public function getSchedulesByDriver(Request $request)
    {
        $schedules = DriverSchedule::join('schedules', 'driver_schedule.scheduleid', '=', 'schedules.id')
            ->where('driver_schedule.driverid', $request->driverid)
            ->select('schedules.*') // Selecteer de velden van de schedules tabel
            ->get();

        return $schedules;
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        return Schedule::create($request->all());
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        return Schedule::find($id);
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $schedule = Schedule::find($id);
        return $schedule->update($request->all());
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        Schedule::destroy($id);
    }
}
