<?php

namespace App\Http\Controllers;

use App\Models\Route;
use Illuminate\Http\Request;

class RouteController extends Controller
{
    public function index()
    {
        return Route::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'start_time' => 'required|date',
            'end_time' => 'required|date',
            'optimal_route' => 'required|string',
            'real_time_updates' => 'nullable|string'
        ]);

        $route = Route::create($request->all());
        return response()->json($route, 201);
    }

    public function show($id)
    {
        return Route::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'start_time' => 'sometimes|date',
            'end_time' => 'sometimes|date',
            'optimal_route' => 'sometimes|string',
            'real_time_updates' => 'nullable|string'
        ]);

        $route = Route::findOrFail($id);
        $route->update($request->all());
        return response()->json($route, 200);
    }

    public function destroy($id)
    {
        $route = Route::findOrFail($id);
        $route->delete();
        return response()->json(null, 204);
    }
}
