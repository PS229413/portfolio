<?php

namespace App\Http\Controllers;

use App\Models\DriverRouteTruckDelivered;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Models\Driver;
use App\Models\Truck;
use Illuminate\Support\Facades\Hash;

class DriverController extends Controller
{
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);
        $driver = Driver::where('email', $request->email)->first();

        if (!$driver || !Hash::check($request->password, $driver->password)) {
            return response()->json(['message' => 'Invalid email or password'], 401);
        }

        return response()->json(['message' => 'Login successful', 'driver' => $driver]);
    }

    public function getRole(Request $request)
{
    $driver = $request->user();
    if (!$driver) {
        return response()->json(['message' => 'Unauthenticated'], 401);
    }

    $role = $driver->role;

    return response()->json(['role' => $role]);
}

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Alle drivers ophalen
        $drivers = Driver::all();
        $truckinfo = [];

        foreach ($drivers as $driver) {
            // Trucks ophalen op basis van driver_id
            $trucks = DriverRouteTruckDelivered::where('driver_id', $driver->id)->get();
            foreach ($trucks as $truck) {
                $truckinfo = Truck::where('id', $truck->truck_id)->get();
            }
            //Trucks toewijzen aan de driver
            $driver->trucks = $truckinfo;
            $truckinfo = [];
        }

        // Teruggeven als JSON
        return response()->json($drivers);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try{
            $validatedData = $request->validate([
                'fullname' => 'required|string|max:70',
                'email' => 'required|email|unique:drivers,email',
                'phone' => 'required|string|max:20|unique:drivers,phone',
                'password' => 'required|string|min:8',
                'role' => 'required'
            ]);

            $validatedData['password'] = bcrypt($validatedData['password']);
            $driver = Driver::create($validatedData);
            return response()->json(['message' => 'Driver created successfully', 'data' => $driver], 201);
        }
        catch(QueryException $e){
            return response()->json(['message' => $e->getMessage()], 400);
        }

    }

    /**
     * Display the specified resource.
     */
    public function show(int $id)
    {
        $driver = Driver::find($id);
        $gekoppeldetrucks = DriverRouteTruckDelivered::where('driver_id', $driver->id)->get();
        $driver->trucks = $gekoppeldetrucks;
        return $driver;

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try{
            $validatedData = $request->validate([
                'fullname' => 'required|string|max:70',
                'email' => 'required|email',
                'phone' => 'required|string|max:20',
                'password' => 'required|string|min:8',
                'role' => 'required'
            ]);

            $validatedData['password'] = bcrypt($validatedData['password']);
            $driver = Driver::find($id);
            $driver->update($validatedData);
            return response()->json(['message' => 'Driver updated successfully', 'data' => $driver], 201);
        }
        catch(QueryException $e){
            return response()->json(['message' => $e->getMessage()], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $driver = Driver::findOrFail($id);
        $driver->delete();

        return response()->json(['message' => 'Driver deleted successfully']);
    }
    public function createDriverTruck(int $driverid, int $truckid)
    {
        $drivertruck = DriverRouteTruckDelivered::create([
            'driver_id' => $driverid,
            'truck_id' => $truckid,
        ]);
        return response()->json(['message' => 'Driver truck created successfully', 'data' => $drivertruck], 201);
    }
    public function deleteDriverTruck(int $driverid)
    {
        DriverRouteTruckDelivered::where('driver_id', $driverid)->delete();
        return response()->json(['message' => 'Driver deleted successfully']);
    }
}
