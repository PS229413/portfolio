<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProfitData;

class ProfitDataController extends Controller
{
    public function index(Request $request)
    {
        $startDate = $request->query('start_date');
        $endDate = $request->query('end_date');

        $profits = ProfitData::whereBetween('Date', [$startDate, $endDate])
            ->orderBy('Date')
            ->get()
            ->map(function ($item) {
                return [
                    'date' => $item->Date,
                    'revenue' => $item->Revenue,
                    'cost' => $item->Cost,
                    'profit' => $item->profit
                ];
            });

        return response()->json($profits);
    }
}
