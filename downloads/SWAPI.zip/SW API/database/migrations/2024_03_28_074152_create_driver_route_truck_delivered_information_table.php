<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('driver_route_truck_delivered', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('route_id');
            $table->unsignedBigInteger('truck_id');
            $table->unsignedBigInteger('driver_id');
            $table->unsignedBigInteger('delivered_information_id');
            $table->unsignedBigInteger('delivered_orders_id');

            // Define foreign keys
            $table->foreign('route_id')->references('id')->on('routes');
            $table->foreign('truck_id')->references('id')->on('trucks');
            $table->foreign('driver_id')->references('id')->on('drivers');
            $table->foreign('delivered_information_id')->references('id')->on('delivered_information');
            $table->foreign('delivered_orders_id')->references('id')->on('delivered_orders');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('driver_route_truck_delivered_information');
    }
};
