<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('delivered_information', function (Blueprint $table) {
            $table->id();
            $table->string('address', 70);
            $table->string('postcode', 10);
            $table->string('city', 70);
            $table->string('country', 2);
            $table->string('status', 10);
            $table->date('delivery_date');
            $table->time('delivery_time_a')->nullable();
            $table->time('delivery_time_b')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('delivered_information');
    }
};
