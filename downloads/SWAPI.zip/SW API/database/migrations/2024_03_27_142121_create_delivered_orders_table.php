<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('delivered_orders', function (Blueprint $table) {
            $table->id();
            $table->date('date');
            $table->string('address', 70);
            $table->string('postcode', 10);
            $table->string('city', 70);
            $table->string('country', 2);
            $table->decimal('price', 7, 2);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('delivered_orders');
    }
};
