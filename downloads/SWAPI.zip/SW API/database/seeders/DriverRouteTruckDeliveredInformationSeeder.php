<?php

namespace Database\Seeders;

use App\Models\DriverRouteTruckDelivered;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\DeliveredInformation;

class DriverRouteTruckDeliveredInformationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DriverRouteTruckDelivered::create([
            'route_id' => 1, // Replace with your route_id
            'truck_id' => 1,
            'driver_id' => 1,
            'delivered_information_id' => 1, // Replace with your delivered_information_id
            'delivered_orders_id' => 1, // Nullable column
        ]);
    }
}
