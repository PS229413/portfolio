<?php

use App\Http\Controllers\DeliveredInformationController;
use App\Http\Controllers\RouteController;
use App\Http\Controllers\ScheduleController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TruckController;
use App\Http\Controllers\DriverController;
use App\Http\Controllers\ProfitDataController;


Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::get('schedules/getbydriver', [ScheduleController::class, 'getSchedulesByDriver']);
Route::resource('schedules', ScheduleController::class);

Route::get('driver/{driverid}/truck/{truckid}', [DriverController::class, 'createDriverTruck']);
Route::delete('driver/deletetrucks/{driverid}', [DriverController::class, 'deleteDriverTruck']);
Route::resource('trucks', TruckController::class);
//Route::middleware(['auth:api', 'driver.role:admin'])->get('/trucks', [TruckController::class, 'index']);
Route::resource('deliveredinformation', DeliveredInformationController::class);
Route::post('login', [DriverController::class, 'login']);
Route::resource('drivers', DriverController::class)->only(['index', 'show', 'create', 'store', 'edit', 'update', 'destroy']);
Route::get('driver/role', [DriverController::class, 'getRole']);
Route::apiResource('/routes', RouteController::class);
Route::get('/profits', [ProfitDataController::class, 'index']);


