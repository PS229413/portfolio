<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return Customer::all();
    }
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
       return Customer::create($request->all());
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        return Customer::find($id);
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
       $customer = Customer::find($id);
       return $customer->update($request->all());
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        return Customer::destroy($id);
    }
}
