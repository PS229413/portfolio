<?php

use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CategoryProductController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ImageController;
use App\Http\Controllers\ImageNewsController;
use App\Http\Controllers\NewsController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\OrderlineController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\StaffRoleController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::get('products/get-first/{amount}', [ProductController::class, 'getFirst']);
Route::get('products/get-after-first/{amount}', [ProductController::class, 'getAfterFirst']);

Route::post('categories/{category}/products/{product}', [CategoryProductController::class, 'addCategoryProduct']);
Route::delete('categories/{category}/products/{product}', [CategoryProductController::class, 'removeCategoryProduct']);

Route::post('newsitems/{news_id}/images/{image_id}', [ImageNewsController::class, 'addImgToItem']);
Route::delete('newsitems/{news_id}/images/{image_id}', [ImageNewsController::class, 'removeImgFromItem']);

Route::post('staff/{staff_id}/role/{role_id}', [StaffRoleController::class, 'addRoleToStaff']);
Route::delete('staff/{staff_id}/role/{role_id}', [StaffRoleController::class, 'removeRoleFromStaff']);

Route::get('products/search', [ProductController::class, 'getProductsByInput']);
Route::put('products/{id}/changemargin', [ProductController::class, 'changeMargin']);
Route::put('products/{id}/changediscount', [ProductController::class, 'changeDiscount']);
Route::put('products/changestock', [ProductController::class, 'changeStock']);

Route::get('orders/{id}', [OrderController::class, 'show']);
Route::put('orders/{id}/complete', [OrderlineController::class, 'completeOrder']);

Route::get('products/id', [ProductController::class, 'getAllIds']);

Route::apiResource('products', ProductController::class);
Route::apiResource('categories', CategoryController::class);
Route::apiResource('customers', CustomerController::class);
Route::apiResource('images', ImageController::class);
Route::apiResource('news', NewsController::class);
Route::apiResource('roles', RoleController::class);
