﻿using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using GV_Desktop.Classes;
using GV_Desktop.Classes.API;
using GV_Desktop.Classes.Database;
using GV_Desktop.Classes.Enums;
using GV_Desktop.Classes.Models;
using HandyControl.Controls;

namespace GV_Desktop.Views
{
    public partial class LoginWindow
    {
        private readonly KassaWindow _kassaWindow;
        
        public LoginWindow()
        {
            InitializeComponent();
            _kassaWindow = new KassaWindow();
        }

        private async void TbCredentials_OnKeyUp(object sender, KeyEventArgs e)
        {
            // Trigger login logic from one of the credentials fields
            if (e.Key != Key.Enter) return;
            
            LoginButton.IsChecked = true;

            if (!await AttemptLogin())
            {
                LoginButton.IsChecked = false;
                return;
            }
            OpenKassaWindow();
        }

        private async Task<bool> AttemptLogin()
        {
            // Try to log in with the given credentials
            var authEmployee = await GvApiClient.LoginAsync(TbUsername.Text, TbPassword.Password);
            Employee? employee = null;
            if (authEmployee is not null)
                employee = await Database.GetEmployeeByTokenAsync(authEmployee.Token);
            if (employee is null)
            {
                Growl.Warning("Het inloggen is mislukt! Controleer de ingevulde gegevens en probeer het opnieuw.", "LoginWindow");
                return false;
            }

            if (employee.Roles.Contains(EmployeeRole.Admin) || employee.Roles.Contains(EmployeeRole.Employee))
            {
                Global.Employee = employee;
                return true;
            }
            
            Growl.Warning($"Medewerker {employee.Name} heeft onvoldoende rechten!", "LoginWindow");
            return false;
        }

        private void OpenKassaWindow()
        {
            // Open checkout window and close this window
            _kassaWindow.Show();
            _kassaWindow.Focus();
            Close();
        }

        private async void LoginButton_OnClick(object sender, RoutedEventArgs e)
        {
            // Trigger login logic from button
            if (!await AttemptLogin())
            {
                LoginButton.IsChecked = false;
                return;
            }
            OpenKassaWindow();
        }
    }
}
