﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using GV_Desktop.Classes.Models;

namespace GV_Desktop.Views
{
    public partial class ProductQuantityDialogWindow
    {
        private OrderLine? _orderLine;
        public OrderLine? DialogOrderLine
        {
            get => _orderLine;
            set
            {
                if (_orderLine == value) return;
                _orderLine = value;
                OnPropertyChanged();
            }
        }
        
        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string? name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        #endregion
        
        public ProductQuantityDialogWindow(ref OrderLine? orderLine)
        {
            InitializeComponent();
            
            DialogOrderLine = orderLine;
            DataContext = DialogOrderLine;
            
            TbAmount.Focus();
        }
        
        private void ProductAmount_OnTextChanged(object sender, TextChangedEventArgs e)
        {
            // Extract all invalid characters (non-numeric) and add valid characters (numeric) back to product quantity textbox
            var result = "";
            var validChars = new[] {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
            for (var i = 0; i < TbAmount.Text.Length; i++)
            {
                var character = TbAmount.Text[i];
                if (Array.IndexOf(validChars, character) != -1)
                    result += character;
            }

            _ = int.TryParse(result, out var amount);
            result = amount switch
            {
                0 => "1",
                > 100 => "100",
                _ => result
            };
            TbAmount.Text = result;
            TbAmount.SelectionStart = TbAmount.Text.Length;
        }

        private void ProductAmount_OnKeyDown(object sender, KeyEventArgs e)
        {
            // Catch enter / escape keys to close dialog
            if (e.Key is not Key.Enter && e.Key is not Key.Escape) return;
            
            Close();
        }

        private void QuantityDialogWindow_OnLoaded(object sender, RoutedEventArgs e)
        {
            TbAmount.SelectAll();
        }
    }
}
