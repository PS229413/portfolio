﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using GV_Desktop.Classes;
using GV_Desktop.Classes.API;
using GV_Desktop.Classes.Database;
using GV_Desktop.Classes.Enums;
using GV_Desktop.Classes.Models;
using GV_Desktop.Helpers;
using HandyControl.Controls;
using HandyControl.Data;
using PdfSharp;
using PdfSharp.Pdf;
using TheArtOfDev.HtmlRenderer.PdfSharp;
using MessageBox = HandyControl.Controls.MessageBox;

namespace GV_Desktop.Views
{
    public partial class KassaWindow: INotifyPropertyChanged
    {
        private readonly AdminWindow _adminWindow;
        private const int MaxOrderLines = 50;
        private Customer defaultCustomer;
        internal bool isClosed = false;
        
        #region Properties
        
        private int OrderId { get; set; }
        private Customer Customer { get; set; }
        
        private ObservableCollection<OrderLine> _orderLines = [];
        public ObservableCollection<OrderLine> OrderLines
        {
            get => _orderLines;
            set
            {
                _orderLines = value;
                OnPropertyChanged();
                UpdateOrderlinePositions();
            }
        }
        
        private OrderLine? _selectedOrderLine;
        public OrderLine? SelectedOrderLine
        {
            get => _selectedOrderLine;
            set
            {
                if (_selectedOrderLine == value) return;
                _selectedOrderLine = value;
                OnPropertyChanged();
            }
        }
        
        private readonly List<OrderLine> _insertedOrderLines = [];

        private ObservableCollection<Product> _products = [];
        public ObservableCollection<Product> Products
        {
            get => _products;
            protected set
            {
                _products = value;
                OnPropertyChanged();
            }
        }
        
        private Product? _selectedProduct;
        public Product? SelectedProduct
        {
            get => _selectedProduct;
            set
            {
                if (_selectedProduct == value) return;
                _selectedProduct = value;
                OnPropertyChanged();
            }
        }
        #endregion
        
        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string? name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private void UpdateOrderlinePositions()
        {
            for (var i = 0; i < OrderLines.Count; i++)
            {
                var item = OrderLines[i];
                OrderLines.Remove(item);
                item.Id = i + 1;
                OrderLines.Insert(i, item);
            }
        }
        #endregion

        public KassaWindow()
        {
            InitializeComponent();
            DataContext = this;
            
            _adminWindow = new AdminWindow(this);
            
            // Encoding 1252 error fix for PDF generating
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            // Close the application
            isClosed = true;
            Application.Current.Shutdown();
        }

        private void DeleteLineButton_OnClick(object sender, RoutedEventArgs e)
        {
            // Remove selected orderline from order
            if (OrderLinesList.SelectedIndex == -1) return;

            var index = OrderLinesList.SelectedIndex - 1;
            OrderLines.RemoveAt(OrderLinesList.SelectedIndex);
            UpdateOrderlinePositions();
            
            OrderLinesList.SelectedIndex = index > 0 ? index : 0;
            OrderLinesList.Focus();
            
            Growl.Success("Orderregel verwijderd!", "KassaWindow");
        }

        private void ProductAmount_OnTextChanged(object sender, TextChangedEventArgs e)
        {
            // Extract all invalid characters (non-numeric) and add valid characters (numeric) back to product quantity textbox
            var result = "";
            var validChars = new[] {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
            for (var i = 0; i < TbProductQuantity.Text.Length; i++)
            {
                var character = TbProductQuantity.Text[i];
                if (Array.IndexOf(validChars, character) != -1)
                    result += character;
            }

            _ = int.TryParse(result, out var amount);
            if (amount > 100)
                result = "100";
            TbProductQuantity.Text = result;
            TbProductQuantity.SelectionStart = TbProductQuantity.Text.Length;
        }

        private void AddButton_OnClick(object sender, RoutedEventArgs e) => AddProductToOrder();

        private void AddProductToOrder()
        {
            // Add a product to the order as an orderline
            
            if (SelectedProduct is null) // Ignore warning as it can be null if there is no product selected in the combobox
            {
                Growl.Warning("Selecteer eerst een product!", "KassaWindow");
                return;
            }
            if (string.IsNullOrEmpty(TbProductQuantity.Text) || TbProductQuantity.Text.StartsWith("0"))
            {
                Growl.Warning("Geef een hoeveelheid aan voor dit product!", "KassaWindow");
                return;
            }
            if (OrderLines.Count == MaxOrderLines)
            {
                Growl.Warning($"Je hebt het maximale aantal orderregels van {MaxOrderLines} bereikt!", "KassaWindow");
                return;
            }

            var quantityToAdd = Convert.ToInt32(TbProductQuantity.Text);
            var quantityAdded = false;

            for (var i = 0; i < OrderLines.Count; i++)
            {
                var orderProduct = OrderLines[i].OrderProduct;
                if (orderProduct is not null && SelectedProduct.KuinId != orderProduct.KuinId) continue;
                var totalQuantity = OrderLines[i].Quantity + quantityToAdd;
                if (totalQuantity <= 100)
                {
                    OrderLines[i].Quantity = totalQuantity;
                    quantityAdded = true;
                    break;
                }

                if (OrderLines[i].Quantity >= 100) continue;
                var availableSpace = 100 - OrderLines[i].Quantity;
                OrderLines[i].Quantity = 100;
                quantityToAdd -= availableSpace;
            }

            if (!quantityAdded)
            {
                while (quantityToAdd > 0)
                {
                    var remainingQuantity = quantityToAdd > 100 ? 100 : quantityToAdd;
                    OrderLines.Add(new OrderLine(OrderLinesList.Items.Count + 1, SelectedProduct, remainingQuantity));
                    quantityToAdd -= remainingQuantity;
                }
            }

            Growl.Success("Het product is toegevoegd aan de order", "KassaWindow");
            CollectionViewSource.GetDefaultView(OrderLines).Refresh();
            
        }

        private async void PrintReceiptButton_OnClick(object sender, RoutedEventArgs e)
        {
            // Print the receipt for the order
            if (_insertedOrderLines.Count is 0 && OrderLines.Count is 0) return;

            var success = await CreateOrderWithOrderLines();
            if (!success)
                return;
            
            var pdf = new PdfDocument();
            var config = new PdfGenerateConfig
            {
                PageSize = PageSize.A4,
                MarginBottom = 0,
                MarginTop = 0,
                MarginLeft = 20,
                MarginRight = 20
            };
            
            var htmlContent = GenerateCompleteHtml();
            PdfGenerator.AddPdfPages(pdf, htmlContent, config);

            var downloadsPath = DirectoryFindingHelper.KnownFolders.GetPath(DirectoryFindingHelper.KnownFolder.Downloads);
            var outputPath = $"{downloadsPath}\\bon{DateTime.Now.ToFileTime()}.pdf";
            
            if (File.Exists(outputPath))
                File.Delete(outputPath);
            pdf.Save(outputPath);
            
            MessageBox.Show(new MessageBoxInfo
            {
                Message = "De bon is succesvol gegenereerd!",
                Caption = "Gelukt!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.SuccessBrush,
                IconKey = ResourceToken.SuccessGeometry,
                StyleKey = "MessageBoxCustom"
            });
            Process.Start("explorer.exe", outputPath);
        }

        private async Task<bool> CreateOrderWithOrderLines()
        {
            // Create order and insert orderlines, check if there is enough stock and then subtract that amount.
            if (OrderId is 0)
                OrderId = await Database.InsertOrderAsync(Global.Employee.CheckoutId, Customer);

            for (var i = 0; i < OrderLines.Count; i++)
            {
                var line = OrderLines[i];
                var row = i + 1;
                if (line.OrderProduct is null) continue;
                
                var checkStock = await Database.CheckSufficientStockForOrderAsync(line.OrderProduct.KuinId, line.Quantity);
                if (!checkStock.isSufficient)
                {
                    MessageBox.Show(new MessageBoxInfo
                    {
                        Message = $"Orderregel {row} heeft niet genoeg voorraad!\n\nDe voorraad is nu {checkStock.stock} stuk(s).\n\nPas het aantal van de orderregel(s) aan en probeer het opnieuw. Als er andere orderregels waren, zijn deze al toegevoegd aan de order.",
                        Caption = "Let op!",
                        ConfirmContent = "OK",
                        Button = MessageBoxButton.OK,
                        IconBrushKey = ResourceToken.AccentBrush,
                        IconKey = ResourceToken.ErrorGeometry,
                        StyleKey = "MessageBoxCustom"
                    });
                    continue;
                }
                
                await Database.SubtractProductStockAsync(line.OrderProduct.KuinId, line.Quantity);
                var orderLineInserted = await Database.InsertOrderLineAsync(OrderId, line, row);
                if (orderLineInserted)
                    _insertedOrderLines.Add(line);
            }

            foreach (var line in _insertedOrderLines)
                OrderLines.Remove(line);

            SelectedProduct = null;
            TbProductQuantity.Text = string.Empty;

            if (OrderLines.Count > 0) return false; // If there is still lines in the orderlines then not all order lines were inserted successfully
            
            OrderId = 0; // Only reset order id if there are no orderlines left to insert
            Customer = defaultCustomer;
            return true;
        }

        private string GenerateCompleteHtml()
        {
            // Dynamically generate html for each orderline and calculate total price for order.
            var htmlStart = EmbeddedResourceHelper.GetEmbeddedResourceContent("GV_Desktop.Resources.bontemplatestart.html");
            if (htmlStart is "")
            {
                MessageBox.Show(new MessageBoxInfo
                {
                    Message = "Het genereren van de bon is mislukt!",
                    Caption = "Er is een fout opgetreden!",
                    ConfirmContent = "OK",
                    Button = MessageBoxButton.OK,
                    IconBrushKey = ResourceToken.AccentBrush,
                    IconKey = ResourceToken.ErrorGeometry,
                    StyleKey = "MessageBoxCustom"
                });
                return "";
            }
            var htmlOrderLines = "";
            for (var i = 0; i < _insertedOrderLines.Count; i++)
            {
                var line = _insertedOrderLines[i];
                if (i is 23 or 50 or 61)
                    htmlOrderLines += $"<tr class=\"table-row\">\n                <td>{i+1}</td>\n                <td>{line.OrderProduct?.Name}</td>\n                <td>{line.Quantity}</td>\n                <td>{line.OrderProduct?.CustomerPrice:C2}</td>\n                <td>{line.OrderProduct?.CustomerPrice * line.Quantity:C2}</td>\n            </tr><tr style=\"padding: -10px;\">\n                <td>\u200b</td>\n                <td>\u200b</td>\n                <td>\u200b</td>\n                <td>\u200b</td>\n                <td>\u200b</td>\n            </tr>";
                else
                    htmlOrderLines += $"<tr class=\"table-row\">\n                <td>{i+1}</td>\n                <td>{line.OrderProduct?.Name}</td>\n                <td>{line.Quantity}</td>\n                <td>{line.OrderProduct?.CustomerPrice:C2}</td>\n                <td>{line.OrderProduct?.CustomerPrice * line.Quantity:C2}</td>\n            </tr>";
            }

            var totalprice = _insertedOrderLines.Sum(t => t.OrderProduct?.CustomerPrice * t.Quantity);
            var htmlEnd = $"</tbody>\n    </table>\n\n    <div class=\"total-price\">\n        <strong>Behandeld door medewerker {Global.Employee.CheckoutId} | Totaalprijs: {totalprice:C2}</strong>\n    </div>\n</body>\n</html>";
            var completeHtml = htmlStart + htmlOrderLines + htmlEnd;
            return completeHtml;
        }

        private async void KassaWindow_OnLoaded(object sender, RoutedEventArgs e)
        {
            Activated += KassaWindow_Activated;
            
            // Load in default checkout client
            Customer = await Database.GetCustomerByIdAsync(900000001);
            defaultCustomer = Customer;
            
            // Check and load new products into the database
            var products = await KuinApiClient.GetProductsAsync();
            for (var i = 0; i < products.Count; i++)
            {
                var product = products[i];
                var exists = await Database.GetProductExistsByKuinIdAsync(product.KuinId);
                if (!exists)
                {
                    await Database.InsertProductAsync(product);
                    continue;
                }
                
                var dbProduct = await Database.GetProductByKuinIdAsync(product.KuinId);
                if (dbProduct is null)
                {
                    await Database.InsertProductAsync(product);
                    continue;
                }
                
                if (JsonSerializer.Serialize(product) == JsonSerializer.Serialize(dbProduct)) continue;
                if (product.Name == dbProduct.Name && product.Description == dbProduct.Description &&
                    product.Image == dbProduct.Image && product.Color == dbProduct.Color &&
                    Math.Abs(product.Height - dbProduct.Height) < 0.1 &&
                    Math.Abs(product.Width - dbProduct.Width) < 0.1 &&
                    Math.Abs(product.Depth - dbProduct.Depth) < 0.1 &&
                    Math.Abs(product.Weight - dbProduct.Weight) < 0.1) continue;

                await Database.UpdateProductAsync(product);
            }
            
            // Load products into combobox
            Products = await Database.GetProductsAsync();
        }
        
        private void KassaWindow_Activated(object? sender, EventArgs e)
        {
            // Set keyboard focus on the scannable textbox
            Keyboard.Focus(TbScannable);
    
            // Unsubscribe from the event to prevent multiple calls
            Activated -= KassaWindow_Activated;
        }

        private async void TbScannable_OnKeyDown(object sender, KeyEventArgs e)
        {
            // Catch enter key
            if (e.Key is not Key.Enter) return;

            var scannable = TbScannable.Text;
            TbScannable.Text = "";
            
            if (scannable.StartsWith("9") && scannable.Length is not 13)
            {
                _ = int.TryParse(scannable, NumberStyles.Integer, CultureInfo.InvariantCulture, out var orderCustomerId);
                var customer = await Database.TryGetCustomerByIdAsync(orderCustomerId);
                if (customer is null)
                {
                    Growl.Warning("Deze klantenpas is ongeldig!\n\nScan een geldige klantenpas of ga door als generieke winkelklant.", "KassaWindow");
                    return;
                }
                
                Customer = customer;

                if (Customer.Id is not 900000001)
                {
                    Growl.Success($"De order is nu gekoppeld aan {Customer.Firstname} {Customer.Lastname}", "KassaWindow");
                    return;
                }
                Growl.Success($"De order is nu gekoppeld aan de generieke winkelklant", "KassaWindow");
                return;
            }
            
            // Add scanned product to order by barcode
            var product = await Database.GetProductByBarcodeAsync(scannable);

            if (product.KuinId is 0)
            {
                Growl.Warning("Ongeldig product!", "KassaWindow");
                return;
            }
            
            var orderLine = new OrderLine(OrderLines.Count + 1, product, 1);
            var dialog = new ProductQuantityDialogWindow(ref orderLine);
            dialog.ShowDialog();

            if (orderLine.Quantity is 0)
            {
                MessageBox.Show(new MessageBoxInfo
                {
                    Message = "Voor een geldige hoeveelheid in!",
                    Caption = "Let op!",
                    ConfirmContent = "OK",
                    Button = MessageBoxButton.OK,
                    IconBrushKey = ResourceToken.AccentBrush,
                    IconKey = ResourceToken.ErrorGeometry,
                    StyleKey = "MessageBoxCustom"
                });
                return;
            }

            var quantityToAdd = orderLine.Quantity;
            var quantityAdded = false;
            
            for (var i = 0; i < OrderLines.Count; i++)
            {
                var orderProduct = OrderLines[i].OrderProduct;
                if (orderProduct is not null && orderLine.OrderProduct.KuinId != orderProduct.KuinId) continue;
                var totalQuantity = OrderLines[i].Quantity + quantityToAdd;
                if (totalQuantity <= 100)
                {
                    OrderLines[i].Quantity = totalQuantity;
                    quantityAdded = true;
                    break;
                }

                if (OrderLines[i].Quantity >= 100) continue;
                var availableSpace = 100 - OrderLines[i].Quantity;
                OrderLines[i].Quantity = 100;
                quantityToAdd -= availableSpace;
            }

            if (!quantityAdded)
            {
                while (quantityToAdd > 0)
                {
                    var remainingQuantity = quantityToAdd > 100 ? 100 : quantityToAdd;
                    OrderLines.Add(new OrderLine(OrderLinesList.Items.Count + 1, product, remainingQuantity));
                    quantityToAdd -= remainingQuantity;
                }
            }

            CollectionViewSource.GetDefaultView(OrderLines).Refresh();
        }

        private void TbScannable_OnTextChanged(object sender, TextChangedEventArgs e)
        {
            // Extract all invalid characters (non-numeric) and add valid characters (numeric) back to product quantity textbox
            var result = "";
            var validChars = new[] {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
            for (var i = 0; i < TbScannable.Text.Length; i++)
            {
                var character = TbScannable.Text[i];
                if (Array.IndexOf(validChars, character) != -1)
                    result += character;
            }
            
            TbScannable.Text = result;
            TbScannable.SelectionStart = TbScannable.Text.Length;
        }

        private void TbProductQuantity_OnKeyUp(object sender, KeyEventArgs e)
        {
            // Enter click to add a product to the order
            if (e.Key != Key.Enter) return;
            
            AddProductToOrder();
        }
        
        private void OrderLinesList_OnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // Double click opens dialog to edit quantity of selected orderline
            if (SelectedOrderLine is null) return;
            
            var selectedOrderLine = SelectedOrderLine;
            var dialog = new ProductQuantityDialogWindow(ref selectedOrderLine);
            dialog.ShowDialog();
        }

        private void OrderLinesList_OnKeyDown(object sender, KeyEventArgs e)
        {
            // Enter click opens dialog to edit quantity of selected orderline
            if (e.Key != Key.Enter || SelectedOrderLine is null) return;

            var selectedOrderLine = SelectedOrderLine;
            var dialog = new ProductQuantityDialogWindow(ref selectedOrderLine);
            dialog.ShowDialog();
        }
        
        #region Misc Events
        private void ClearButton_OnClick(object sender, RoutedEventArgs e)
        {
            Growl.Ask(new GrowlInfo
            {
                Message = "Weet je zeker dat je opnieuw wilt beginnen?",
                Token = "KassaWindow",
                ConfirmStr = "Bevestig",
                CancelStr = "Annuleer",
                StaysOpen = true,
                ActionBeforeClose = isConfirmed =>
                {
                    if (!isConfirmed) return true;
                    
                    Growl.Success("De orderregels zijn verwijderd!", "KassaWindow");
                    OrderLines.Clear();
                    Customer = defaultCustomer;
                    return true;
                }
            });
        }
        private void TbScannable_OnGotFocus(object sender, RoutedEventArgs e) => TbScannable.CaptureMouse();

        private void TbScannable_OnIsMouseCaptureWithinChanged(object sender, DependencyPropertyChangedEventArgs e) => TbScannable.SelectAll();
        #endregion

        private void ShowAdminViewButton_OnClick(object sender, RoutedEventArgs e)
        {
            if (!Global.Employee.Roles.Contains(EmployeeRole.Admin))
            {
                Growl.Warning("Je hebt niet de juiste rechten om deze module te gebruiken!", "KassaWindow");
                return;
            }
            _adminWindow.Show();
            Hide();
        }
    }
}
