﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using BarcodeStandard;
using GV_Desktop.Classes.API;
using GV_Desktop.Classes.Database;
using GV_Desktop.Classes.Enums;
using GV_Desktop.Classes.Models;
using GV_Desktop.Helpers;
using HandyControl.Controls;
using HandyControl.Data;
using Microsoft.VisualBasic.FileIO;
using Microsoft.Win32;
using SkiaSharp;
using MessageBox = HandyControl.Controls.MessageBox;

namespace GV_Desktop.Views
{
    public partial class AdminWindow : INotifyPropertyChanged
    {
        private readonly KassaWindow _kassaWindow;
        private const int MaxOrderLineQuantity = 100;
        private bool _isKuinOrdersUpdating;
        
        private ObservableCollection<OrderLine> _orderLines = [];
        public ObservableCollection<OrderLine> OrderLines
        {
            get => _orderLines;
            set
            {
                _orderLines = value;
                OnPropertyChanged();
                UpdateOrderlinePositions();
            }
        }
        
        private OrderLine? _selectedOrderLine;
        public OrderLine? SelectedOrderLine
        {
            get => _selectedOrderLine;
            set
            {
                if (_selectedOrderLine == value) return;
                _selectedOrderLine = value;
                OnPropertyChanged();
            }
        }

        private ObservableCollection<Product> _products = [];
        public ObservableCollection<Product> Products
        {
            get => _products;
            protected set
            {
                _products = value;
                OnPropertyChanged();
            }
        }
        
        private Product? _selectedProduct;
        public Product? SelectedProduct
        {
            get => _selectedProduct;
            set
            {
                if (_selectedProduct == value) return;
                _selectedProduct = value;
                OnPropertyChanged();
            }
        }
        
        private ObservableCollection<KuinOrder> _kuinOrders = [];
        public ObservableCollection<KuinOrder> KuinOrders
        {
            get => _kuinOrders;
            set
            {
                _kuinOrders = value;
                OnPropertyChanged();
            }
        }
        
        private KuinOrder? _selectedKuinOrder;
        public KuinOrder? SelectedKuinOrder
        {
            get => _selectedKuinOrder;
            set
            {
                if (_selectedKuinOrder == value) return;
                _selectedKuinOrder = value;
                OnPropertyChanged();
            }
        }
        
        public AdminWindow(KassaWindow kassaWindow)
        {
            InitializeComponent();
            DataContext = this;
            _kassaWindow = kassaWindow;

            Task.Run(async () =>
            {
                KuinOrders = await Database.GetKuinOrdersAsync();
            });
        }
        
        protected override void OnClosing(CancelEventArgs e)
        {
            // Close this window and return to kassawindow
            e.Cancel = true;
            Hide();
            if (_kassaWindow.isClosed)
            {
                Application.Current.Shutdown();
                return;
            }
            _kassaWindow.Show();
            _kassaWindow.Focus();
        }
        
        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string? name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private void UpdateOrderlinePositions()
        {
            for (var i = 0; i < OrderLines.Count; i++)
            {
                var item = OrderLines[i];
                OrderLines.Remove(item);
                item.Id = i + 1;
                OrderLines.Insert(i, item);
            }
        }
        #endregion

        private void ClearButton_OnClick(object sender, RoutedEventArgs e) => OrderLines.Clear();
        // Clear all orderlines and restart

        private async Task UpdateKuinOrders()
        {
            // Check and load new kuin orders into the database
            _isKuinOrdersUpdating = true;
            
            var newOrders = 0;
            var orders = await KuinApiClient.GetOrdersAsync();

            for (var i = 0; i < orders.Count; i++)
            {
                var order = orders[i];
                var inserted = false;
                
                var orderExists = await Database.GetKuinOrderExistsAsync(order.KuinId);
                var lines = new ObservableCollection<KuinOrderLine>();
                if (!orderExists)
                {
                    lines = await KuinApiClient.GetOrderLinesByOrderIdAsync(order.KuinId);
                    if (lines.Count > 0)
                    {
                        await Database.InsertKuinOrderAsync(order);
                        inserted = true;
                        newOrders++;
                    }
                }
                
                var databaseStatus = await Database.GetKuinOrderStatusAsync(order.KuinId);
                if ((order.Status == databaseStatus && !inserted) || databaseStatus is OrderStatus.Processed) continue;

                await Database.UpdateKuinOrderStatusAsync(order.KuinId, order.Status);
                
                if (lines.Count < 1) continue;
                
                for (var j = 0; j < lines.Count; j++)
                {
                    var line = lines[j];
                    if (line.OrderProduct is null) continue;
                    
                    var lineExists = await Database.GetKuinOrderLineExistsAsync(order.KuinId, line.OrderProduct.KuinId, line.Amount);
                    if (lineExists) continue;

                    await Database.InsertKuinOrderLineAsync(order.KuinId, line);
                }
            }
            
            KuinOrders = await Database.GetKuinOrdersAsync();
            CollectionViewSource.GetDefaultView(KuinOrders).Refresh();

            if (newOrders <= 0)
            {
                _isKuinOrdersUpdating = false;
                return;
            }

            while (Visibility is not Visibility.Visible && !IsFocused)
                await Task.Delay(200);
            Growl.Success($"Er zijn {newOrders} nieuwe orders van Kuin", "AdminWindow");
            _isKuinOrdersUpdating = false;
        }
        
        private void DeleteLineButton_OnClick(object sender, RoutedEventArgs e)
        {
            // Remove selected orderline from order
            if (OrderLinesList.SelectedIndex == -1) return;

            var index = OrderLinesList.SelectedIndex - 1;
            OrderLines.RemoveAt(OrderLinesList.SelectedIndex);
            UpdateOrderlinePositions();
            
            OrderLinesList.SelectedIndex = index > 0 ? index : 0;
            OrderLinesList.Focus();
        }

        private void ProductAmount_OnTextChanged(object sender, TextChangedEventArgs e)
        {
            // Extract all invalid characters (non-numeric) and add valid characters (numeric) back to product quantity textbox
            var result = "";
            var validChars = new[] {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
            for (var i = 0; i < TbProductQuantity.Text.Length; i++)
            {
                var character = TbProductQuantity.Text[i];
                if (Array.IndexOf(validChars, character) != -1)
                    result += character;
            }

            _ = int.TryParse(result, out var amount);
            if (amount > 100)
                result = "100";
            TbProductQuantity.Text = result;
            TbProductQuantity.SelectionStart = TbProductQuantity.Text.Length;
        }

        private void AddButton_OnClick(object sender, RoutedEventArgs e)
        {
            // Add a product to the kuin order as an orderline
            AddProductToOrder();
        }

        void AddProductToOrder()
        {
            // Add a product to the order as an orderline
            
            if (SelectedProduct is null) // Ignore warning as it can be null if there is no kuin product selected in the combobox
            {
                Growl.Warning("Selecteer eerst een product!", "AdminWindow");
                return;
            }
            if (string.IsNullOrEmpty(TbProductQuantity.Text) || TbProductQuantity.Text.StartsWith("0"))
            {
                Growl.Warning("Geef een hoeveelheid aan voor dit product!", "AdminWindow");
                return;
            }
            
            var quantityToAdd = Convert.ToInt32(TbProductQuantity.Text);
            var quantityAdded = false;

            for (var i = 0; i < OrderLines.Count; i++)
            {
                var orderProduct = OrderLines[i].OrderProduct;
                if (orderProduct is not null && SelectedProduct.KuinId != orderProduct.KuinId) continue;
                var totalQuantity = OrderLines[i].Quantity + quantityToAdd;
                if (totalQuantity <= MaxOrderLineQuantity)
                {
                    OrderLines[i].Quantity = totalQuantity;
                    quantityAdded = true;
                    break;
                }

                if (OrderLines[i].Quantity >= MaxOrderLineQuantity) continue;
                var availableSpace = MaxOrderLineQuantity - OrderLines[i].Quantity;
                OrderLines[i].Quantity = MaxOrderLineQuantity;
                quantityToAdd -= availableSpace;
            }

            if (!quantityAdded)
            {
                while (quantityToAdd > 0)
                {
                    var remainingQuantity = quantityToAdd > MaxOrderLineQuantity ? MaxOrderLineQuantity : quantityToAdd;
                    OrderLines.Add(new OrderLine(OrderLinesList.Items.Count + 1, SelectedProduct, remainingQuantity));
                    quantityToAdd -= remainingQuantity;
                }
            }

            Growl.Success("Het product is toegevoegd aan de order", "AdminWindow");
            CollectionViewSource.GetDefaultView(OrderLines).Refresh();
        }

        private async void AdminWindow_OnLoaded(object sender, RoutedEventArgs e)
        {
            // Load products into combobox
            Products = await Database.GetProductsAsync();
            
            if (_isKuinOrdersUpdating) return;
            await UpdateKuinOrders();
        }

        private async void OrderButton_OnClick(object sender, RoutedEventArgs e)
        {
            // Order added products from Kuin
            if (OrderLines.Count is 0) return;
            
            var initialOrderLine = OrderLines[0];
            if (initialOrderLine.OrderProduct is null) return;
            
            var orderId = await KuinApiClient.OrderProductAsync(initialOrderLine.OrderProduct.KuinId, initialOrderLine.Quantity);

            for (var i = 1; i < OrderLines.Count; i++)
            {
                var orderLine = OrderLines[i];
                if (orderLine.OrderProduct is null) continue;
                
                await KuinApiClient.OrderProductAsync(orderLine.OrderProduct.KuinId, orderLine.Quantity, orderId);
            }
        }

        private async void ImportCSVFile_Click(object sender, RoutedEventArgs e)
        {
            // Import orderlines from user-selected CSV file
            var downloadsPath = DirectoryFindingHelper.KnownFolders.GetPath(DirectoryFindingHelper.KnownFolder.Downloads);
            var dialog = new OpenFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv",
                Title = "Selecteer een CSV bestand.",
                InitialDirectory = downloadsPath
            };
            var result = dialog.ShowDialog();
            if (result.HasValue)
            {
                if (dialog.FileName is "") return;
                
                await ImportOrderLinesFromCsvFile(dialog.FileName);
                return;
            }
            
            Growl.Error("Het geselecteerde CSV bestand is ongeldig!", "AdminWindow");
        }

        private async Task ImportOrderLinesFromCsvFile(string path)
        {
            // Validate and place order lines into order
            var lines = new List<OrderLine>();
            
            using var parser = new TextFieldParser(path);
            parser.CommentTokens = ["#"];
            parser.SetDelimiters(",");
            parser.HasFieldsEnclosedInQuotes = false;
            
            // Skip headers
            parser.ReadLine();

            while (!parser.EndOfData)
            {
                string?[]? fields = parser.ReadFields();
                if (fields?.Length < 2)
                {
                    var lineNumber = parser.LineNumber == -1 ? "laatst" : parser.LineNumber.ToString();
                    MessageBox.Show(new MessageBoxInfo
                    {
                        Message = $"De {lineNumber}e rij mist een of meerdere kolom(men)! Voeg de missende kolom(men) toe en probeer het opnieuw.\n\n Of download de template en begin opnieuw.",
                        Caption = "Let op!",
                        ConfirmContent = "OK",
                        Button = MessageBoxButton.OK,
                        IconBrushKey = ResourceToken.AccentBrush,
                        IconKey = ResourceToken.ErrorGeometry,
                        StyleKey = "MessageBoxCustom"
                    });
                    return;
                }
                
                _ = int.TryParse(fields?[0] ?? "0", out var kuinId);
                _ = int.TryParse(fields?[1] ?? "1", out var quantity);

                var product = await KuinApiClient.GetProductByKuinIdAsync(kuinId);
                if (kuinId is 0 || quantity is 0 || product.KuinId is 0)
                {
                    MessageBox.Show(new MessageBoxInfo
                    {
                        Message = $"Product met id: {kuinId} is ongeldig!",
                        Caption = "Let op!",
                        ConfirmContent = "OK",
                        Button = MessageBoxButton.OK,
                        IconBrushKey = ResourceToken.AccentBrush,
                        IconKey = ResourceToken.WarningGeometry,
                        StyleKey = "MessageBoxCustom"
                    });
                    continue;
                }
                
                var line = new OrderLine(OrderLines.Count + 1, product, quantity);
                lines.Add(line);
                var quantityToAdd = line.Quantity;
                var quantityAdded = false;

                for (var i = 0; i < OrderLines.Count; i++)
                {
                    var orderProduct = OrderLines[i].OrderProduct;
                    if (orderProduct is not null && line?.OrderProduct?.KuinId != orderProduct.KuinId) continue;
                    var totalQuantity = OrderLines[i].Quantity + quantityToAdd;
                    if (totalQuantity <= MaxOrderLineQuantity)
                    {
                        OrderLines[i].Quantity = totalQuantity;
                        quantityAdded = true;
                        break;
                    }

                    if (OrderLines[i].Quantity >= MaxOrderLineQuantity) continue;
                    var availableSpace = MaxOrderLineQuantity - OrderLines[i].Quantity;
                    OrderLines[i].Quantity = MaxOrderLineQuantity;
                    quantityToAdd -= availableSpace;
                }

                if (quantityAdded) continue;
                while (quantityToAdd > 0)
                {
                    var remainingQuantity = quantityToAdd > MaxOrderLineQuantity ? MaxOrderLineQuantity : quantityToAdd;
                    OrderLines.Add(new OrderLine(OrderLinesList.Items.Count + 1, line?.OrderProduct, remainingQuantity));
                    quantityToAdd -= remainingQuantity;
                }
            }

            if (lines.Count < 1)
            {
                Growl.Error("Het geselecteerde CSV bestand is ongeldig of heeft geen geldige orderregels!", "AdminWindow");
                return;
            }
            
            Growl.Success("De orderregel(s) zijn toegevoegd aan de order!", "AdminWindow");
            CollectionViewSource.GetDefaultView(OrderLines).Refresh();
        }

        private void ExcelImage_OnMouseUp(object sender, MouseButtonEventArgs e)
        {
            // Download CSV template to import orderlines
            var downloadsPath = DirectoryFindingHelper.KnownFolders.GetPath(DirectoryFindingHelper.KnownFolder.Downloads);
            var csvTemplatePath = $"{downloadsPath}\\OrderImport.csv";
            using (var resource = EmbeddedResourceHelper.GetEmbeddedResourceFileStream("GV_Desktop.Resources.OrderImport.csv"))
            {
                using var file = new FileStream(csvTemplatePath, FileMode.Create, FileAccess.ReadWrite);
                resource?.CopyTo(file);
            }
            
            Process.Start("explorer.exe", downloadsPath);
        }

        private static async Task PrintProductBarcodes()
        {
            // Export all product EAN barcodes to images

            var downloadsPath = DirectoryFindingHelper.KnownFolders.GetPath(DirectoryFindingHelper.KnownFolder.Downloads);
            var barcodesPath = $"{downloadsPath}\\Groenevingers Barcodes";
            if (!Directory.Exists(barcodesPath))
                Directory.CreateDirectory(barcodesPath);
            
            var products = await Database.GetProductsAsync(true);
            
            foreach (var product in products)
            {
                var b = new Barcode();
                b.IncludeLabel = true;
                var img = b.Encode(BarcodeStandard.Type.Ean13, product.Barcode, SKColors.Black, SKColors.White);
            
                var filePath = $"{barcodesPath}\\{product.Name} {product.Color} {product.Barcode}.jpg";
                using var data = img.Encode(SKEncodedImageFormat.Jpeg, 100);
                await using var stream = File.OpenWrite(filePath);
                data.SaveTo(stream);
            }

            Growl.Success("De barcodes zijn succesvol gegenereerd!");
            Process.Start("explorer.exe", barcodesPath);
        }
        
        private void TbProductQuantity_OnKeyUp(object sender, KeyEventArgs e)
        {
            // Enter click to add a product to the order
            if (e.Key != Key.Enter) return;
            
            AddProductToOrder();
        }
        
        private void OrderLinesList_OnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // Double click opens dialog to edit quantity of selected orderline
            if (SelectedOrderLine is null) return;
            
            var selectedOrderLine = SelectedOrderLine;
            var dialog = new ProductQuantityDialogWindow(ref selectedOrderLine);
            dialog.ShowDialog();
        }

        private void OrderLinesList_OnKeyDown(object sender, KeyEventArgs e)
        {
            // Enter click opens dialog to edit quantity of selected orderline
            if (e.Key != Key.Enter || SelectedOrderLine is null) return;

            var selectedOrderLine = SelectedOrderLine;
            var dialog = new ProductQuantityDialogWindow(ref selectedOrderLine);
            dialog.ShowDialog();
        }

        private async void ProcessButton_OnClick(object sender, RoutedEventArgs e)
        {
            // Set kuin order to processed in database
            if (SelectedKuinOrder?.Status is not OrderStatus.Completed) return;
            
            SelectedKuinOrder.Status = OrderStatus.Processed;
            await Database.UpdateKuinOrderStatusAsync(SelectedKuinOrder.KuinId, OrderStatus.Processed);
            var orderLines = await Database.GetKuinOrderLinesAsync(SelectedKuinOrder.KuinId);
            
            for (var i = 0; i < orderLines.Count; i++)
            {
                var line = orderLines[i];
                if (line.OrderProduct is null) continue;
                
                await Database.AddProductStockAsync(line.OrderProduct.KuinId, line.Amount);
            }
            
            CollectionViewSource.GetDefaultView(KuinOrders).Refresh();
            KuinOrdersDataGrid.Focus();
        }

        private void ToggleOrdersProductsView_OnClick(object sender, RoutedEventArgs e)
        {
            // Toggle between orders and products screen
            if (KuinProductsGrid.Visibility == Visibility.Visible)
            {
                KuinProductsGrid.Visibility = Visibility.Collapsed;
                KuinOrdersGrid.Visibility = Visibility.Visible;
                ToggleOrdersProductsView.Header = "Kuin Producten";
                return;
            }
            
            KuinProductsGrid.Visibility = Visibility.Visible;
            KuinOrdersGrid.Visibility = Visibility.Collapsed;
            ToggleOrdersProductsView.Header = "Kuin Orders";
        }

        private async void ExportBarcodes_OnClick(object sender, RoutedEventArgs e) => await PrintProductBarcodes();
    }
}
