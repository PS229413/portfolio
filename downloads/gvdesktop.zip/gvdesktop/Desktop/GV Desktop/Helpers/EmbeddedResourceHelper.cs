using System.IO;
using System.Reflection;

namespace GV_Desktop.Helpers;

public static class EmbeddedResourceHelper
{
    internal static string GetEmbeddedResourceContent(string resourcePath)
    {
        // Read content of the html file embedded in the application
        var assembly = Assembly.GetExecutingAssembly();
        using var stream = assembly.GetManifestResourceStream(resourcePath);
        if (stream is null) return "";

        using var reader = new StreamReader(stream);
        return reader.ReadToEnd();
    }

    internal static Stream? GetEmbeddedResourceFileStream(string resourcePath)
    {
        // Get stream from embeddedresource
        return Assembly.GetExecutingAssembly().GetManifestResourceStream(resourcePath);
    }
}