namespace GV_Desktop.Classes.Enums;

public enum EmployeeRole
{
    Director = 1,
    Admin = 2,
    Hr = 3,
    Employee = 4,
    Writer = 5,
    Buyer = 6,
    Seller = 7,
    Teamleader = 8,
    Driver = 9,
}