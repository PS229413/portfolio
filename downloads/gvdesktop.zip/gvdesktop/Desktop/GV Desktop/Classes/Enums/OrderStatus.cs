namespace GV_Desktop.Classes.Enums;

public enum OrderStatus
{
    Open = 1,
    Pending = 2,
    Processing = 3,
    Completed = 4,
    Processed = 5,
    Cancelled = 6,
}