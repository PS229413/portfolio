﻿using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Threading.Tasks;
using System.Windows;
using GV_Desktop.Classes.Enums;
using GV_Desktop.Classes.Models;
using HandyControl.Data;
using MySqlConnector;
using MessageBox = HandyControl.Controls.MessageBox;

namespace GV_Desktop.Classes.Database;

internal static class Database
{
    private static async Task OpenConnectionAsync(MySqlConnection connection)
    {
        if (connection.State != ConnectionState.Closed)
            await connection.CloseAsync().ConfigureAwait(false);
        
        await connection.OpenAsync().ConfigureAwait(false);
    }

    private static async Task CloseConnectionAsync(MySqlConnection connection)
    {
        if (connection.State != ConnectionState.Closed)
            await connection.CloseAsync().ConfigureAwait(false);
    }
    
    internal static async Task<bool> GetProductExistsByKuinIdAsync(int id)
    {
        // Check if a product exists with the Kuin product Id
        var result = false;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT id FROM products WHERE kuin_id = @kuin_id";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@kuin_id", MySqlDbType.Int32).Value = id;
            
            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
                result = reader.HasRows;
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return await Task.FromResult(result);
    }
    
    internal static async Task<Product> GetProductByBarcodeAsync(string barcode)
    {
        // Check if a product exists with the Kuin product Id
        var product = new Product();
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT * FROM products WHERE barcode = @barcode";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@barcode", MySqlDbType.VarChar).Value = barcode;
            
            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                var id = reader.GetInt32("id");
                var kuinId = reader.GetInt32("kuin_id");
                var name = reader.GetString("name");
                var description = reader.GetString("description");
                var stock = reader.GetInt32("stock");
                var supplierPrice = reader.GetDecimal("supplier_price");
                var priceMargin = reader.GetDecimal("price_margin");
                var image = reader.GetString("image");
                var color = reader.GetString("color");
                var height = reader.GetFloat("height");
                var width = reader.GetFloat("width");
                var depth = reader.GetFloat("depth");
                var weight = reader.GetFloat("weight");
                
                product = new Product(id, kuinId, name, description, barcode, stock, supplierPrice, priceMargin, image, color, height, width, depth, weight);
            }
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return await Task.FromResult(product);
    }
    
    internal static async Task<Product?> GetProductByKuinIdAsync(int kuinProductId)
    {
        // Check if a product exists with the Kuin product Id
        var product = new Product();
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT * FROM products WHERE kuin_id = @kuinId";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@kuinId", MySqlDbType.Int32).Value = kuinProductId;
            
            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                var id = reader.GetInt32("id");
                var kuinId = reader.GetInt32("kuin_id");
                var name = reader.GetString("name");
                var description = reader.GetString("description");
                var barcode = reader.GetString("barcode");
                var stock = reader.GetInt32("stock");
                var supplierPrice = reader.GetDecimal("supplier_price");
                var priceMargin = reader.GetDecimal("price_margin");
                var image = reader.GetString("image");
                var color = reader.GetString("color");
                var height = reader.GetFloat("height");
                var width = reader.GetFloat("width");
                var depth = reader.GetFloat("depth");
                var weight = reader.GetFloat("weight");
                
                product = new Product(id, kuinId, name, description, barcode, stock, supplierPrice, priceMargin, image, color, height, width, depth, weight);
            }
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return await Task.FromResult(product);
    }

    internal static async Task<ObservableCollection<Product>> GetProductsAsync(bool includeInactive = false)
    {
        // Get all products from GV database
        var products = new ObservableCollection<Product>();
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT * FROM products WHERE active = 1 OR active =@active";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@active", DbType.Boolean).Value = !includeInactive;
            
            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                var id = reader.GetInt32("id");
                var kuinId = reader.GetInt32("kuin_id");
                var name = reader.GetString("name");
                var description = reader.GetString("description");
                var barcode = reader.GetString("barcode");
                var stock = reader.GetInt32("stock");
                var supplierPrice = reader.GetDecimal("supplier_price");
                var priceMargin = reader.GetDecimal("price_margin");
                var image = reader.GetString("image");
                var color = reader.GetString("color");
                var height = reader.GetFloat("height");
                var width = reader.GetFloat("width");
                var depth = reader.GetFloat("depth");
                var weight = reader.GetFloat("weight");

                var product = new Product(id, kuinId, name, description, barcode, stock, supplierPrice, priceMargin, image, color, height, width, depth, weight);
                products.Add(product);
            }
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return products;
    }

    internal static async Task<bool> InsertProductAsync(Product product)
    {
        // Insert a new product from the Kuin Api into the database
        var result = false;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "INSERT INTO products (kuin_id, name, description, barcode, stock, supplier_price, price_margin, discount, image, color, height, width, depth, weight) VALUES (@kuinId, @name, @description, @barcode, @stock, @supplierPrice, @priceMargin, @discount, @image, @color, @height, @width, @depth, @weight)";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@kuinId", MySqlDbType.Int32).Value = product.KuinId;
            cmd.Parameters.Add("@name", MySqlDbType.VarChar).Value = product.Name;
            cmd.Parameters.Add("@description", MySqlDbType.VarChar).Value = product.Description;
            cmd.Parameters.Add("@barcode", MySqlDbType.VarChar).Value = product.Barcode;
            cmd.Parameters.Add("@stock", MySqlDbType.Int32).Value = product.Stock;
            cmd.Parameters.Add("@supplierPrice", MySqlDbType.Decimal).Value = product.SupplierPrice;
            cmd.Parameters.Add("@priceMargin", MySqlDbType.Decimal).Value = product.PriceMargin;
            cmd.Parameters.Add("@discount", MySqlDbType.Decimal).Value = 0.00m;
            cmd.Parameters.Add("@image", MySqlDbType.VarChar).Value = product.Image;
            cmd.Parameters.Add("@color", MySqlDbType.VarChar).Value = product.Color;
            cmd.Parameters.Add("@height", MySqlDbType.Float).Value = product.Height;
            cmd.Parameters.Add("@width", MySqlDbType.Float).Value = product.Width;
            cmd.Parameters.Add("@depth", MySqlDbType.Float).Value = product.Depth;
            cmd.Parameters.Add("@weight", MySqlDbType.Float).Value = product.Weight;

            var queryResult = await cmd.ExecuteNonQueryAsync();
            result = queryResult == 1;
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return await Task.FromResult(result);
    }
    
    internal static async Task<bool> UpdateProductAsync(Product product)
    {
        // Update a product from the Kuin Api into the database
        var result = false;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "UPDATE products SET name=@name, description=@description, image=@image, color=@color, height=@height, width=@width, depth=@depth, weight=@weight WHERE kuin_id=@kuinId";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@kuinId", MySqlDbType.Int32).Value = product.KuinId;
            cmd.Parameters.Add("@name", MySqlDbType.VarChar).Value = product.Name;
            cmd.Parameters.Add("@description", MySqlDbType.VarChar).Value = product.Description;
            cmd.Parameters.Add("@image", MySqlDbType.VarChar).Value = product.Image;
            cmd.Parameters.Add("@color", MySqlDbType.VarChar).Value = product.Color;
            cmd.Parameters.Add("@height", MySqlDbType.Float).Value = product.Height;
            cmd.Parameters.Add("@width", MySqlDbType.Float).Value = product.Width;
            cmd.Parameters.Add("@depth", MySqlDbType.Float).Value = product.Depth;
            cmd.Parameters.Add("@weight", MySqlDbType.Float).Value = product.Weight;

            var queryResult = await cmd.ExecuteNonQueryAsync();
            result = queryResult == 1;
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return await Task.FromResult(result);
    }
    
    internal static async Task<(bool isSufficient, int stock)> CheckSufficientStockForOrderAsync(int kuinId, int quantity)
    {
        // Check if there is enough stock to order given amount of the product
        var stock = 0;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT stock FROM products WHERE kuin_id = @kuinId";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@kuinId", MySqlDbType.Int32).Value = kuinId;

            stock = (int)(await cmd.ExecuteScalarAsync() ?? 0);
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);

        var result = stock >= quantity;
        return (result, stock);
    }
    
    internal static async Task<bool> AddProductStockAsync(int kuinId, int stock)
    {
        // Add stock to product
        var result = false;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "UPDATE products SET stock = stock + @stock WHERE kuin_id = @kuinId";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@kuinId", MySqlDbType.Int32).Value = kuinId;
            cmd.Parameters.Add("@stock", MySqlDbType.Int32).Value = stock;

            var queryResult = await cmd.ExecuteNonQueryAsync();
            result = queryResult == 1;
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }

        await CloseConnectionAsync(connection);
        return await Task.FromResult(result);
    }
    
    internal static async Task SubtractProductStockAsync(int kuinId, int quantity)
    {
        // Remove ordered quantity from product stock
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "UPDATE products SET stock = stock - @quantity WHERE kuin_id = @kuinId";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@kuinId", MySqlDbType.Int32).Value = kuinId;
            cmd.Parameters.Add("@quantity", MySqlDbType.Int32).Value = quantity;

            await cmd.ExecuteNonQueryAsync();
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }

        await CloseConnectionAsync(connection);
    }
    
    internal static async Task<int> InsertOrderAsync(int employeeCheckoutId, Customer customer = null)
    {
        // Insert new order placed by checkout system
        var orderId = 0;
        var connection = DatabaseConnectionPool.GetConnection();

        customer ??= await GetCustomerByIdAsync(900000001);
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "INSERT INTO orders (date, customer_id, employee_checkout_id, status, receiver_firstname, receiver_lastname, receiver_address, receiver_postalcode, receiver_city, receiver_country, receiver_email, receiver_phonenumber) VALUES (@date, @customerId, @employeeCheckoutId, @status, @receiver_firstname, @receiver_lastname, @receiver_address, @receiver_postalcode, @receiver_city, @receiver_country, @receiver_email, @receiver_phonenumber); SELECT LAST_INSERT_ID();";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@date", DbType.DateTime).Value = DateTime.Now;
            cmd.Parameters.Add("@customerId", MySqlDbType.Int32).Value = customer.Id;
            cmd.Parameters.Add("@employeeCheckoutId", MySqlDbType.Int32).Value = employeeCheckoutId;
            cmd.Parameters.Add("@status", DbType.Int16).Value = 4;
            cmd.Parameters.Add("@receiver_firstname", MySqlDbType.VarChar).Value = customer.Firstname;
            cmd.Parameters.Add("@receiver_lastname", MySqlDbType.VarChar).Value = customer.Lastname;
            cmd.Parameters.Add("@receiver_address", MySqlDbType.VarChar).Value = customer.Address;
            cmd.Parameters.Add("@receiver_postalcode", MySqlDbType.VarChar).Value = customer.Postcode;
            cmd.Parameters.Add("@receiver_city", MySqlDbType.VarChar).Value = customer.City;
            cmd.Parameters.Add("@receiver_country", MySqlDbType.VarChar).Value = customer.Country;
            cmd.Parameters.Add("@receiver_email", MySqlDbType.VarChar).Value = customer.Email;
            cmd.Parameters.Add("@receiver_phonenumber", MySqlDbType.VarChar).Value = customer.Phone;
            
            var result = await cmd.ExecuteScalarAsync();
            if (result is not null)
                orderId = Convert.ToInt32(result);
        }

        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }

        await CloseConnectionAsync(connection);
        return await Task.FromResult(orderId);
    }
    
    internal static async Task<bool> InsertOrderLineAsync(int orderId, OrderLine orderLine, int row)
    {
        // Add an order line to the given order with id
        if (orderLine.OrderProduct is null)
            return false;
        
        var result = false;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "INSERT INTO order_lines (order_id, order_row, product_id, amount, status, purchase_price) VALUES (@orderId, @orderRow, @productId, @quantity, @status, @purchasePrice)";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@orderId", MySqlDbType.Int32).Value = orderId;
            cmd.Parameters.Add("@orderRow", MySqlDbType.VarChar).Value = row;
            cmd.Parameters.Add("@productId", MySqlDbType.VarChar).Value = orderLine.OrderProduct.Id;
            cmd.Parameters.Add("@quantity", MySqlDbType.VarChar).Value = orderLine.Quantity;
            cmd.Parameters.Add("@status", MySqlDbType.VarChar).Value = 4;
            cmd.Parameters.Add("@purchasePrice", MySqlDbType.VarChar).Value = orderLine.OrderProduct.CustomerPrice;

            var queryResult = await cmd.ExecuteNonQueryAsync();
            result = queryResult == 1;
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return await Task.FromResult(result);
    }
    
    #region Kuin Orders
    
    internal static async Task<int> InsertKuinOrderAsync(KuinOrder order)
    {
        // Insert new kuin order placed by an administrator
        var orderId = 0;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "INSERT INTO kuin_orders (kuin_id, status, date, last_status_change) VALUES (@kuinId, @status, @date, @lastStatusChange); SELECT LAST_INSERT_ID();";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@kuinId", MySqlDbType.Int32).Value = order.KuinId;
            cmd.Parameters.Add("@status", DbType.Int16).Value = order.Status;
            cmd.Parameters.Add("@date", DbType.Int16).Value = order.Date;
            cmd.Parameters.Add("@lastStatusChange", DbType.Int16).Value = order.LastStatusChange;
            
            var result = await cmd.ExecuteScalarAsync();
            if (result is not null)
                orderId = Convert.ToInt32(result);
        }

        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }

        await CloseConnectionAsync(connection);
        return await Task.FromResult(orderId);
    }
    
    internal static async Task<bool> InsertKuinOrderLineAsync(int orderId, KuinOrderLine orderLine)
    {
        // Add an order line to the given kuin order with id
        if (orderLine.OrderProduct is null)
            return false;
        
        var result = false;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "INSERT INTO kuin_order_lines (kuin_order_id, kuin_product_id, amount, purchase_price) VALUES (@orderId, @productId, @amount, @purchasePrice)";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@orderId", MySqlDbType.Int32).Value = orderId;
            cmd.Parameters.Add("@productId", MySqlDbType.VarChar).Value = orderLine.OrderProduct.KuinId;
            cmd.Parameters.Add("@amount", MySqlDbType.VarChar).Value = orderLine.Amount;
            cmd.Parameters.Add("@purchasePrice", MySqlDbType.VarChar).Value = orderLine.OrderProduct.SupplierPrice;

            var queryResult = await cmd.ExecuteNonQueryAsync();
            result = queryResult == 1;
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return await Task.FromResult(result);
    }
    
    internal static async Task UpdateKuinOrderStatusAsync(int id, OrderStatus status)
    {
        // Set kuin order status to processed (5)
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "UPDATE kuin_orders SET status = @status WHERE kuin_id = @kuinId";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@kuinId", MySqlDbType.Int32).Value = id;
            cmd.Parameters.Add("@status", MySqlDbType.Int32).Value = status;

            await cmd.ExecuteNonQueryAsync();
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }

        await CloseConnectionAsync(connection);
    }
    
    internal static async Task<OrderStatus> GetKuinOrderStatusAsync(int kuinId)
    {
        // Check what status the kuin order has
        var status = OrderStatus.Cancelled;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT status FROM kuin_orders WHERE kuin_id = @kuinId";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@kuinId", MySqlDbType.Int32).Value = kuinId;

            var result = await cmd.ExecuteScalarAsync();
            if (result is not null) 
                status = (OrderStatus)result;
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return status;
    }
    
    internal static async Task<bool> GetKuinOrderExistsAsync(int id)
    {
        // Check if a kuin order exists with the Kuin order Id
        var result = false;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT id FROM kuin_orders WHERE kuin_id = @kuin_id";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@kuin_id", MySqlDbType.Int32).Value = id;
            
            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
                result = reader.HasRows;
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return await Task.FromResult(result);
    }
    
    internal static async Task<bool> GetKuinOrderLineExistsAsync(int orderId, int productId, int amount)
    {
        // Check if a kuin order exists with the Kuin order Id
        var result = false;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT id FROM kuin_order_lines WHERE kuin_order_id = @orderId AND kuin_product_id = @productId AND amount = @amount";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@orderId", MySqlDbType.Int32).Value = orderId;
            cmd.Parameters.Add("@productId", MySqlDbType.Int32).Value = productId;
            cmd.Parameters.Add("@amount", MySqlDbType.Int32).Value = amount;
            
            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
                result = reader.HasRows;
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return await Task.FromResult(result);
    }
    
    internal static async Task<ObservableCollection<KuinOrder>> GetKuinOrdersAsync()
    {
        // Get all kuin orders
        var orders = new ObservableCollection<KuinOrder>();
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT * FROM kuin_orders";
            var cmd = new MySqlCommand(query, connection);
            
            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                var id = reader.GetInt32("id");
                var kuinId = reader.GetInt32("kuin_id");
                var status = reader.GetInt32("status");
                var date = reader.GetDateTime("date");
                var lastStatusChange = reader.GetDateTime("last_status_change");

                var order = new KuinOrder(id, kuinId, status, date, lastStatusChange);
                orders.Add(order);
            }
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return orders;
    }
    
    internal static async Task<ObservableCollection<KuinOrderLine>> GetKuinOrderLinesAsync(int kuinId)
    {
        // Get all kuin orders
        var orderLines = new ObservableCollection<KuinOrderLine>();
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT * FROM kuin_order_lines where kuin_order_id = @kuinOrderId";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@kuinOrderId", DbType.Int32).Value = kuinId;
            
            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                var kuinProductId = reader.GetInt32("kuin_product_id");
                var amount = reader.GetInt32("amount");
                var purchasePrice = reader.GetDecimal("purchase_price");

                var orderLine = new KuinOrderLine(new Product(kuinProductId), amount, purchasePrice);
                orderLines.Add(orderLine);
            }
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return orderLines;
    }
    
    #endregion
    
    #region Employees / Staff

    internal static async Task<Employee?> GetEmployeeByTokenAsync(string token)
    {
        // Get employee by token
        Employee? employee = null;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT * FROM staff s INNER JOIN staff_roles sr on s.id = sr.staff_id WHERE s.api_token=@token";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@token", MySqlDbType.VarChar).Value = token;
            
            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                if (employee == null)
                {
                    var id = reader.GetInt32("id");
                    var name = reader.GetString("name");
                    var email = reader.GetString("email");
                    var api_token = reader.GetString("api_token");
                    var checkout_id = reader.GetInt32("checkout_id");
                    employee = new Employee(id, name, email, api_token, checkout_id);
                }
    
                var roleId = reader.GetInt32("role_id");
                employee.Roles.Add((EmployeeRole)roleId);
            }
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return (await Task.FromResult(employee));
    }
    
    internal static async Task<string> GetEmployeeNameByCheckoutIdAsync(int id)
    {
        // Get employee name from checkout id
        var result = "";
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT name FROM staff WHERE checkout_id = @checkoutId";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@checkoutId", MySqlDbType.VarChar).Value = id;
            
            result = (string)(await cmd.ExecuteScalarAsync() ?? "");
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return await Task.FromResult(result);
    }
    
    #endregion
    
    #region Customers
    
    internal static async Task<Customer> GetCustomerByIdAsync(int customerId)
    {
        // Get customer by id
        Customer? customer = null;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT * FROM customers WHERE id = @customerId";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@customerId", MySqlDbType.VarChar).Value = customerId;
            
            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                var id = reader.GetInt32("id");
                var username = reader.GetString("username");
                var email = reader.GetString("email");
                var firstname = reader.GetString("firstname");
                var lastname = reader.GetString("lastname");
                var phone = reader.GetString("phone");
                var birthday = reader.GetDateOnly("birthday");
                var address = reader.GetString("address");
                var city = reader.GetString("city");
                var postcode = reader.GetString("postcode");
                var country = reader.GetString("country");
                customer = new Customer(id, username, email, firstname, lastname, phone, birthday, address, city, postcode, country);
            }
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return (await Task.FromResult(customer))!;
    }
    
    internal static async Task<Customer?> TryGetCustomerByIdAsync(int customerId)
    {
        // Try to get customer by id
        Customer? customer = null;
        var connection = DatabaseConnectionPool.GetConnection();
        
        try
        {
            await OpenConnectionAsync(connection);
            const string query = "SELECT * FROM customers WHERE id = @customerId";
            var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.Add("@customerId", MySqlDbType.VarChar).Value = customerId;
            
            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                var id = reader.GetInt32("id");
                var username = reader.GetString("username");
                var email = reader.GetString("email");
                var firstname = reader.GetString("firstname");
                var lastname = reader.GetString("lastname");
                var phone = reader.GetString("phone");
                var birthday = reader.GetDateOnly("birthday");
                var address = reader.GetString("address");
                var city = reader.GetString("city");
                var postcode = reader.GetString("postcode");
                var country = reader.GetString("country");
                customer = new Customer(id, username, email, firstname, lastname, phone, birthday, address, city, postcode, country);
            }
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(new MessageBoxInfo
            {
                Message = ex.Message,
                Caption = "Er is een fout opgetreden!",
                ConfirmContent = "OK",
                Button = MessageBoxButton.OK,
                IconBrushKey = ResourceToken.AccentBrush,
                IconKey = ResourceToken.ErrorGeometry,
                StyleKey = "MessageBoxCustom"
            });
        }
        await CloseConnectionAsync(connection);
        return (await Task.FromResult(customer));
    }
    
    #endregion
}