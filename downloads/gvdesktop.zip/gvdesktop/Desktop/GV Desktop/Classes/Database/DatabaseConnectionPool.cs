using System.Collections.Generic;
using System.Data;
using MySqlConnector;

namespace GV_Desktop.Classes.Database;

internal struct DatabaseConnectionPool
{
    private const string ConnectionString = "server=csdev.me;uid=groenevingers;pwd=SummaIct2024!;database=projectgroenevingers;Pooling=true;MinimumPoolSize=5;";
    private static readonly List<MySqlConnection> ConnectionPool = [];

    internal static MySqlConnection GetConnection()
    {
        // Return an open and available connection
        
        for (var i = 0; i < ConnectionPool.Count; i++)
        {
            var connection = ConnectionPool[i];
            if (connection.State is ConnectionState.Closed) return connection; // Connection is closed and available

            if (i != ConnectionPool.Count - 1) continue; // Current iteration is not the last in the pool so we check the next connection
            var newConnection = new MySqlConnection(ConnectionString);
            ConnectionPool.Add(newConnection);
            return newConnection;
        }

        var firstConnection = new MySqlConnection(ConnectionString);
        ConnectionPool.Add(firstConnection);
        return firstConnection;
    }
}