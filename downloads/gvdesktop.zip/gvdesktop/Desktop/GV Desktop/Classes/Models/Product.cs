using System;
using System.Threading;

namespace GV_Desktop.Classes.Models;

public class Product
{
    private static int _counter;
    private static readonly Random RandomGenerator = new();
    
    // Product constructor from Kuin Api - missing information like id, sku, stock & price margin
    public Product(int kuinId, string name, string description, decimal supplierPrice, string image, string color, float height, float width, float depth, float weight, bool generateMissingInfo)
    {
        KuinId = kuinId;
        Name = name;
        Description = description;
        SupplierPrice = supplierPrice;
        Image = image;
        Color = color;
        Height = height;
        Width = width;
        Depth = depth;
        Weight = weight;
        
        // Not given
        if (!generateMissingInfo) return;
        Barcode = GenerateUniqueEan13Barcode();
        Stock = 0;
        PriceMargin = 0.00m;
    }
    
    // Product constructor from database - contains all information
    public Product(int id, int kuinId, string name, string description, string barcode, int stock, decimal supplierPrice, decimal priceMargin, string image, string color, float height, float width, float depth, float weight)
    {
        Id = id;
        KuinId = kuinId;
        Name = name;
        Description = description;
        Barcode = barcode;
        Stock = stock;
        SupplierPrice = supplierPrice;
        PriceMargin = priceMargin;
        CustomerPrice = supplierPrice + (supplierPrice * priceMargin);
        Image = image;
        Color = color;
        Height = height;
        Width = width;
        Depth = depth;
        Weight = weight;
    }
    
    public Product(int kuinId)
    {
        KuinId = kuinId;
    }

    public Product()
    {
        
    }

    public int Id { get; set; }
    public int KuinId { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public string Barcode { get; set; }
    public int Stock { get; set; }
    public decimal SupplierPrice { get; set; }
    public decimal CustomerPrice { get; set; }
    public decimal PriceMargin { get; set; }
    public decimal Discount { get; set; }
    public string Image { get; set; }
    public string Color { get; set; }
    public float Height { get; set; }
    public float Width { get; set; }
    public float Depth { get; set; }
    public float Weight { get; set; }

    private static string GenerateUniqueEan13Barcode()
    {
        // Generate unique EAN barcode
        var timestamp = DateTimeOffset.Now.ToUnixTimeMilliseconds();
        var timestampStr = (timestamp % 100000).ToString().PadLeft(5, '0');
        var randomNumber = RandomGenerator.Next(0, 10000);
        var currentCounter = Interlocked.Increment(ref _counter) % 1000;
        var randomNumberStr = randomNumber.ToString("0000"); // 4 digits for random number
        var counterStr = currentCounter.ToString("000"); // 3 digits for counter

        // Combine parts to form the 12-digit base number
        var baseNumber = timestampStr + randomNumberStr + counterStr;

        // Calculate the checksum for the base number
        var checksum = CalculateEan13Checksum(baseNumber);

        // Return complete EAN-13 barcode
        return $"{baseNumber}{checksum}";
    }

    private static string CalculateEan13Checksum(string baseNumber)
    {
        // EAN-13 checksum calculation
        int sum = 0;
        for (int i = 0; i < baseNumber.Length; i++)
        {
            int digit = int.Parse(baseNumber[i].ToString());
            sum += (i % 2 == 0) ? digit : digit * 3;
        }

        int checksumValue = (10 - (sum % 10)) % 10;
        return checksumValue.ToString();
    }
}