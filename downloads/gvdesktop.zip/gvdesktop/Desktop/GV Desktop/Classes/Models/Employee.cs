using System;
using System.Collections.ObjectModel;
using System.Windows.Media.Animation;
using GV_Desktop.Classes.Enums;

namespace GV_Desktop.Classes.Models;

public class Employee(int id, string name, string email, string apiToken, int checkoutId)
{
    public int Id { get; set; } = id;
    public string Name { get; set; } = name;
    public string Email { get; set; } = email;
    public string ApiToken { get; set; } = apiToken;
    public int CheckoutId { get; set; } = checkoutId;
    public ObservableCollection<EmployeeRole> Roles { get; set; } = [];
}