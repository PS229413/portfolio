﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace GV_Desktop.Classes.Models;

public class OrderLine
{
    public OrderLine(int id, Product? product, int quantity)
    {
        Id = id;
        OrderProduct = product;
        Quantity = quantity;
    }

    public int Id { get; set; }
    public Product? OrderProduct { get; set; }
    private int _quantity;
    public int Quantity
    {
        get => _quantity;
        set
        {
            _quantity = value;
            OnPropertyChanged();
        }
    }
    
    #region INotifyPropertyChanged
    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
    #endregion
}