using System;

namespace GV_Desktop.Classes.Models;

public class Customer
{
    public Customer(int id, string username, string email, string firstname, string lastname, string phone, DateOnly birthday, string address, string city, string postcode, string country)
    {
        Id = id;
        Username = username;
        Email = email;
        Firstname = firstname;
        Lastname = lastname;
        Phone = phone;
        Birthday = birthday;
        Address = address;
        City = city;
        Postcode = postcode;
        Country = country;
    }

    public Customer()
    {
        
    }

    public int Id { get; set; }
    public string Username { get; set; }
    public string Email { get; set; }
    public string Firstname { get; set; }
    public string Lastname { get; set; }
    public string Phone { get; set; }
    public DateOnly Birthday { get; set; }
    public string Address { get; set; }
    public string City { get; set; }
    public string Postcode { get; set; }
    public string Country { get; set; }
}