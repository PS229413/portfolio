using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace GV_Desktop.Classes.Models;

public struct KuinOrderLine(Product? product, int amount, decimal purchasePrice)
{
    public Product? OrderProduct { get; set; } = product;
    public int Amount { get; private init; } = amount;
    public decimal PurchasePrice { get; private init; } = purchasePrice;

    #region INotifyPropertyChanged
    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
    #endregion
}