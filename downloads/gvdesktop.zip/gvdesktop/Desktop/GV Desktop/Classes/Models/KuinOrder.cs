using System;
using GV_Desktop.Classes.Enums;

namespace GV_Desktop.Classes.Models;

public class KuinOrder
{
    // Create from order
    public KuinOrder(int kuinId, string? status, DateTime date, DateTime lastStatusChange)
    {
        KuinId = kuinId;
        Status = status switch
        {
            "pending" => OrderStatus.Pending,
            "processing" => OrderStatus.Processing,
            "completed" => OrderStatus.Completed,
            "cancelled" => OrderStatus.Cancelled,
            _ => OrderStatus.Open
        };
        Date = date;
        LastStatusChange = lastStatusChange;
    }
    
    // Create from database
    public KuinOrder(int id, int kuinId, int status, DateTime date, DateTime lastStatusChange)
    {
        Id = id;
        KuinId = kuinId;
        Status = status switch
        {
            2 => OrderStatus.Pending,
            3 => OrderStatus.Processing,
            4 => OrderStatus.Completed,
            5 => OrderStatus.Processed,
            6 => OrderStatus.Cancelled,
            _ => OrderStatus.Open
        };
        Date = date;
        LastStatusChange = lastStatusChange;
    }

    public KuinOrder()
    {
        
    }

    public int Id { get; set; }
    public int KuinId { get; set; }
    public OrderStatus Status { get; set; }
    public DateTime Date { get; set; }
    public DateTime LastStatusChange { get; set; }
}