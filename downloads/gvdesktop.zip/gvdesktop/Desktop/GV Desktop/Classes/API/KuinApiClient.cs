using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using GV_Desktop.Classes.Models;

namespace GV_Desktop.Classes.API;

internal static class KuinApiClient
{
    private static readonly HttpClient Client = new();
    
    #region Products
    public static async Task<Product> GetProductByKuinIdAsync(int kuinId)
    {
        // Get product object by kuin id
        var url = $"{KuinApiCredentials.BaseUrl}/product/{kuinId}";
        
        Client.DefaultRequestHeaders.Accept.Clear();
        Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", KuinApiCredentials.Token);
        
        try
        {
            var response = await Client.GetAsync(url).ConfigureAwait(false);
            var responseBody = await response.Content.ReadAsStringAsync();
            var obj = JsonNode.Parse(responseBody);

            if (obj is null) return new Product();

            var id = obj["id"]?.GetValue<int>() ?? 0;
            var name = obj["name"]?.GetValue<string>() ?? "Onbekend product";
            var description = obj["description"]?.GetValue<string>() ?? "";
            var supplierPriceString = obj["price"]?.GetValue<string>();
            var supplierPrice = decimal.TryParse(supplierPriceString, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal tempPrice) ? tempPrice : 0;
            var image = obj["image"]?.GetValue<string>() ?? $"https://images.placeholders.dev/?width=500&height=500&text={name}&bgColor=%23f7f6f6&textColor=%236d6e71";
            var color = obj["color"]?.GetValue<string>() ?? "Kleurloos";
            var height = (float)(obj["height_cm"] ?? 0);
            var width = (float)(obj["width_cm"] ?? 0);
            var depth = (float)(obj["depth_cm"] ?? 0);
            var weight = (float)(obj["weight_gr"] ?? 0);
                    
            return new Product(id, name, description, supplierPrice, image, color, height, width, depth, weight, false);
        }
        catch (HttpRequestException)
        {
            return new Product();
        }
        catch (JsonException)
        {
            return new Product();
        }
        catch (Exception)
        {
            return new Product();
        }
    }
    
    public static async Task<ObservableCollection<Product>> GetProductsAsync()
    {
        // Get list of product objects by kuin id
        var url = $"{KuinApiCredentials.BaseUrl}/product";
        var products = new ObservableCollection<Product>();
        
        Client.DefaultRequestHeaders.Accept.Clear();
        Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", KuinApiCredentials.Token);
        
        try
        {
            var response = await Client.GetAsync(url).ConfigureAwait(false);
            var responseBody = await response.Content.ReadAsStringAsync();
            var jsonArray = JsonNode.Parse(responseBody)?.AsArray();

            if (jsonArray is null) return products;
            
            foreach (var obj in jsonArray)
            {
                var id = obj?["id"]?.GetValue<int>() ?? 0;
                var name = obj?["name"]?.GetValue<string>() ?? "Onbekend product";
                var description = obj?["description"]?.GetValue<string>() ?? "";
                var supplierPriceString = obj?["price"]?.GetValue<string>();
                var supplierPrice = decimal.TryParse(supplierPriceString, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal tempPrice) ? tempPrice : 0;
                var image = obj?["image"]?.GetValue<string>() ?? $"https://images.placeholders.dev/?width=500&height=500&text={name}&bgColor=%23f7f6f6&textColor=%236d6e71";
                var color = obj?["color"]?.GetValue<string>() ?? "Kleurloos";
                var height = (float)(obj?["height_cm"] ?? 0);
                var width = (float)(obj?["width_cm"] ?? 0);
                var depth = (float)(obj?["depth_cm"] ?? 0);
                var weight = (float)(obj?["weight_gr"] ?? 0);
                    
                var product = new Product(id, name, description, supplierPrice, image, color, height, width, depth, weight, true);
                products.Add(product);
            }
            return products;
        }
        catch (HttpRequestException)
        {
            return products;
        }
        catch (JsonException)
        {
            return products;
        }
        catch (Exception)
        {
            return products;
        }
    }
    
    public static async Task<int> OrderProductAsync(int productId, int quantity, int orderId = 0)
    {
        // Order a product from kuin by Kuin product Id
        var url = $"{KuinApiCredentials.BaseUrl}/orderItem";
        
        Client.DefaultRequestHeaders.Accept.Clear();
        Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", KuinApiCredentials.Token);
        
        try
        {
            var json = $"{{\n    \"product_id\": {productId},\n    \"quantity\": {quantity}";
            if (orderId != 0)
                json += $",\n    \"order_id\": {orderId}";
            json += "\n}";
            
            var response = await Client.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json")).ConfigureAwait(false);
            var responseBody = await response.Content.ReadAsStringAsync();
            var obj = JsonNode.Parse(responseBody);

            if (obj is null) return 0;
            
            return obj["order_id"]?.GetValue<int>() ?? 0;
        }
        catch (HttpRequestException)
        {
            return 0;
        }
        catch (JsonException)
        {
            return 0;
        }
        catch (Exception)
        {
            return 0;
        }
    }
    #endregion
    
    #region Orders
    public static async Task<KuinOrder> GetOrderByIdAsync(int id)
    {
        // Get kuin order object by kuin id
        var url = $"{KuinApiCredentials.BaseUrl}/order/{id}";
        var order = new KuinOrder();
        
        Client.DefaultRequestHeaders.Accept.Clear();
        Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", KuinApiCredentials.Token);
        
        try
        {
            var response = await Client.GetAsync(url).ConfigureAwait(false);
            var responseBody = await response.Content.ReadAsStringAsync();
            var obj = JsonNode.Parse(responseBody);

            if (obj is null) return order;
            
            var kuinId = obj["id"]?.GetValue<int>() ?? 0;
            var status = obj["status"]?.GetValue<string>();
            var createdAtString = obj["created_at"]?.GetValue<string>();
            var createdOffset = DateTimeOffset.Parse(createdAtString!, null, DateTimeStyles.RoundtripKind);
            var createdAt = createdOffset.UtcDateTime;
            var updatedAtString = obj["updated_at"]?.GetValue<string>();
            var updatedOffset = DateTimeOffset.Parse(updatedAtString!, null, DateTimeStyles.RoundtripKind);
            var updatedAt = updatedOffset.UtcDateTime;
                    
            return new KuinOrder(kuinId, status, createdAt, updatedAt);
        }
        catch (HttpRequestException)
        {
            return order;
        }
        catch (JsonException)
        {
            return order;
        }
        catch (Exception)
        {
            return order;
        }
    }
    
    public static async Task<ObservableCollection<KuinOrder>> GetOrdersAsync()
    {
        // Get list of kuin order objects by kuin id
        var url = $"{KuinApiCredentials.BaseUrl}/order";
        var orders = new ObservableCollection<KuinOrder>();
        
        Client.DefaultRequestHeaders.Accept.Clear();
        Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", KuinApiCredentials.Token);
        
        try
        {
            var response = await Client.GetAsync(url).ConfigureAwait(false);
            var responseBody = await response.Content.ReadAsStringAsync();
            var jsonArray = JsonNode.Parse(responseBody)?.AsArray();

            if (jsonArray is null) return orders;
            
            foreach (var obj in jsonArray)
            {
                var kuinId = obj?["id"]?.GetValue<int>() ?? 0;
                var status = obj?["status"]?.GetValue<string>();
                var createdAtString = obj?["created_at"]?.GetValue<string>();
                var createdOffset = DateTimeOffset.Parse(createdAtString!, null, DateTimeStyles.RoundtripKind);
                var createdAt = createdOffset.UtcDateTime;
                var updatedAtString = obj?["updated_at"]?.GetValue<string>();
                var updatedOffset = DateTimeOffset.Parse(updatedAtString!, null, DateTimeStyles.RoundtripKind);
                var updatedAt = updatedOffset.UtcDateTime;
                    
                var order = new KuinOrder(kuinId, status, createdAt, updatedAt);
                orders.Add(order);
            }
            return orders;
        }
        catch (HttpRequestException)
        {
            return orders;
        }
        catch (JsonException)
        {
            return orders;
        }
        catch (Exception)
        {
            return orders;
        }
    }
    
    public static async Task<ObservableCollection<KuinOrderLine>> GetOrderLinesByOrderIdAsync(int id)
    {
        // Get list of kuin order lines objects by order id
        var url = $"{KuinApiCredentials.BaseUrl}/orderItem?order_id={id}";
        var lines = new ObservableCollection<KuinOrderLine>();
        
        Client.DefaultRequestHeaders.Accept.Clear();
        Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", KuinApiCredentials.Token);
        
        try
        {
            var response = await Client.GetAsync(url).ConfigureAwait(false);
            var responseBody = await response.Content.ReadAsStringAsync();
            var jsonArray = JsonNode.Parse(responseBody)?.AsArray();

            if (jsonArray is null) return lines;
            
            foreach (var obj in jsonArray)
            {
                var productId = obj?["product_id"]?.GetValue<int>() ?? 0;
                var amount = obj?["quantity"]?.GetValue<int>() ?? 0;
                var product = await GetProductByKuinIdAsync(productId);
                
                var line = new KuinOrderLine(product, amount, product.SupplierPrice);
                lines.Add(line);
            }
            return lines;
        }
        catch (HttpRequestException)
        {
            return lines;
        }
        catch (JsonException)
        {
            return lines;
        }
        catch (Exception)
        {
            return lines;
        }
    }
    
    #endregion
}