namespace GV_Desktop.Classes.API;

internal struct KuinApiCredentials
{
    internal const string BaseUrl = "https://kuin.summaict.nl/api";
    internal const string Token = "55|gs7Pn0fxYX2YGhDjK7jVHaAv4h7TMyjFPKQtcJpZ";
}