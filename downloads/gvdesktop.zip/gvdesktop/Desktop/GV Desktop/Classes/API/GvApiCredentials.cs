namespace GV_Desktop.Classes.API;

internal struct GvApiCredentials
{
    internal const string BaseUrl = "https://groenevingers.csdev.me";
}