using System.Net.Http;
using System.Threading.Tasks;
using GV_Desktop.Classes.Records;
using RestSharp;

namespace GV_Desktop.Classes.API;

internal static class GvApiClient
{
    #region Authentication / Authorization (DWM RestSharp)

    internal static async Task<AuthEmployee?> LoginAsync(string email, string password)
    {
        try
        {
            var options = new RestClientOptions(GvApiCredentials.BaseUrl);
            using var client = new RestClient(options);
            var request = new RestRequest("/api/login");
            request.AddParameter("email", email);
            request.AddParameter("password", password);
            return await client.PostAsync<AuthEmployee>(request);
        }
        catch (HttpRequestException ex)
        {
            return null;
        }
    }
    
    #endregion
}