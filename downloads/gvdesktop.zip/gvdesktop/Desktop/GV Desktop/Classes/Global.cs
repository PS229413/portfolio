using GV_Desktop.Classes.Models;

namespace GV_Desktop.Classes;

internal struct Global
{
    internal static Employee Employee { get; set; }
}