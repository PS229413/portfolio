using System.Text.Json.Serialization;

namespace GV_Desktop.Classes.Records;

public record AuthEmployee
{
    [JsonPropertyName("token")]
    public string Token { get; init; }
}