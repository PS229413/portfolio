using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using GV_Desktop.Classes.Enums;

namespace GV_Desktop.Classes.Converters;

public class StatusToVisibilityConverter : IMultiValueConverter
{
    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
    {
        if (values.Length < 1 || values[0] is not Enum status)
            return Visibility.Collapsed;
        
        return status.Equals(OrderStatus.Completed) ? Visibility.Visible : Visibility.Collapsed;
    }

    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}