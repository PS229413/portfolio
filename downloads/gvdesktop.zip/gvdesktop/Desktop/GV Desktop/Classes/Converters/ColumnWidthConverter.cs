﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace GV_Desktop.Classes.Converters;

public class ColumnWidthConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        // Calculate width for column by giving a percentage (ex. 0.25) so specified column will use 1/4th of the available room
        if (value is not double actualWidth || !(actualWidth > 0)) return 0;
        double ratio = 1;

        if (parameter is not string param || string.IsNullOrEmpty(param)) return actualWidth * ratio;
        var parts = param.Split(':');
        if (parts.Length > 0 && double.TryParse(parts[0], out double parsedRatio))
            ratio = parsedRatio;

        return (actualWidth * ratio) - 2;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        // Not used
        throw new NotImplementedException();
    }
}