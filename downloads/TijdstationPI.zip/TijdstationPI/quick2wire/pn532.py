from py532lib.i2c import *
from py532lib.frame import *
from py532lib.constants import *
import datetime
import mariadb

# Initialize the NFC reader
pn532 = Pn532_i2c()
pn532.SAMconfigure()

# Read NFC card data
card_data = pn532.read_mifare().get_data()

# Get the current time
current_time = datetime.datetime.now()

# Print the NFC card data and current time
# Convert the `bytearray` to a hexadecimal string
hex_card_data = card_data.hex()

# Print the hexadecimal representation
print("Hex Card Data:", hex_card_data)
print("Time:", current_time)

# Database configuration
db_config = {
    'host': 'localhost',
    'user': 'admin',
    'password': 'Bstation7173',
    'database': 'Tijdstation'
}

conn = None  # Initialize the conn variable outside of the try block

try:
    # Connect to the MariaDB database
    conn = mariadb.connect(**db_config)
    cursor = conn.cursor()

    # Replace '1' with the desired user ID to fetch card data and user information
    user_id = 1

    # Fetch the user's current clock status
    cursor.execute("SELECT clock_out_time FROM clock_records WHERE user_id = %s AND clock_out_time IS NULL", (user_id,))
    current_clock_status = cursor.fetchone()

    if current_clock_status:
        # User is already clocked in, so prompt to clock out
        print("Hey, ", current_clock_status[1], "! You are currently clocked in. Would you like to clock out?")
        # You can add code here to handle clocking out
    else:
        # User is not currently clocked in, so prompt to clock in
        print("Hey, ", current_clock_status[1], "! You are currently clocked out. Would you like to clock in?")
        # You can add code here to handle clocking in

except mariadb.Error as e:
    print(f"Error: {e}")
finally:
    if conn:
        conn.close()
