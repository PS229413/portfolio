# Import necessary libraries
from py532lib.i2c import *
from py532lib.frame import *
from py532lib.constants import *
import datetime
import mariadb
import time

# Function to print styled messages with larger font
def print_message(message, style='info'):
    styles = {
        'info': '\033[94m\033[1m',    # Blue and bold
        'success': '\033[92m\033[1m', # Green and bold
        'warning': '\033[93m\033[1m', # Yellow and bold
        'error': '\033[91m\033[1m'    # Red and bold
    }
    end_color = '\033[0m'
    print(styles.get(style, ''), message, end_color)

# Initialize the NFC reader
pn532 = Pn532_i2c()
pn532.SAMconfigure()

# Database configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Bstation7173',
    'database': 'Tijdstation'
}

# Connect to the MariaDB database
try:
    conn = mariadb.connect(**db_config)
    cursor = conn.cursor()

    # Simulate NFC card data input (replace this with your actual NFC card data)
    simulated_card_data = input("Enter simulated NFC card data (hex format): ")

    # Fetch the user's name and ID based on the simulated card data
    cursor.execute("SELECT id, name FROM users WHERE nfc_card_data = %s", (simulated_card_data,))
    user_info = cursor.fetchone()

    if user_info:
        user_id, user_name = user_info
    else:
        print_message("User not found for the provided NFC card data: " + simulated_card_data, 'error')
        exit()

    # Check if the user is already clocked in
    cursor.execute("SELECT Clock_Out FROM clock WHERE User_id = %s AND Clock_Out IS NULL", (user_id,))
    existing_clock_out = cursor.fetchone()

    current_time = datetime.datetime.now()

    if existing_clock_out:
        # User is already clocked in, so this is a clock-out action
        clock_out_time = current_time
        cursor.execute("UPDATE clock SET Clock_Out = %s WHERE User_id = %s AND Clock_Out IS NULL", (clock_out_time, user_id))
        conn.commit()
        print_message(f"Hey, {user_name}. you have clocked out at {clock_out_time}", 'success')
    else:
        # User is not clocked in, so this is a clock-in action
        clock_in_time = current_time
        cursor.execute("INSERT INTO clock (Date, Clock_In, User_id, Timestamps) VALUES (%s, %s, %s, %s)", (current_time.date(), clock_in_time.time(), user_id, current_time))
        conn.commit()
        print_message(f"Hey, {user_name}. you have clocked in at {clock_in_time}", 'success')

except mariadb.Error as e:
    print_message(f"Database Error: {e}", 'error')
finally:
    if conn:
        conn.close()
