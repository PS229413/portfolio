from py532lib.i2c import *
from py532lib.frame import *
from py532lib.constants import *
import datetime
import mariadb

# Initialize the NFC reader
pn532 = Pn532_i2c()
pn532.SAMconfigure()

# Read NFC card data
card_data = pn532.read_mifare().get_data()

# Get the current time
current_time = datetime.datetime.now()

# Print the NFC card data and current time
# Convert the `bytearray` to a hexadecimal string
hex_card_data = card_data.hex()

# Print the hexadecimal representation
print("Hex Card Data:", hex_card_data)
print("Time:", current_time)

# Database configuration
db_config = {
    'host': 'localhost',
    'user': 'admin',
    'password': 'Bstation7173',
    'database': 'Tijdstation'
}

conn = None  # Initialize the conn variable outside of the try block

try:
    # Connect to the MariaDB database
    conn = mariadb.connect(**db_config)
    cursor = conn.cursor()

    # Replace '1' with the desired user ID to fetch card data and user information
    user_id = 1

    # Fetch the card data and associated user information using a JOIN
    cursor.execute("SELECT nc.card_data, u.username FROM nfc_cards nc JOIN users u ON nc.user_id = u.id WHERE nc.user_id = %s", (user_id,))
    result = cursor.fetchone()

    if result:
        card_data = bytearray(result[0])
        username = result[1]

        print("Card Data:", card_data)
        print("User Name:", username)

        # Check if the user is already clocked in
        cursor.execute("SELECT clock_out_time FROM clock_records WHERE user_id = %s ORDER BY id DESC LIMIT 1", (user_id,))
        last_clock_out = cursor.fetchone()

        if last_clock_out and last_clock_out[0] is None:
            # User is already clocked in, so clock them out
            cursor.execute("UPDATE clock_records SET clock_out_time = %s WHERE user_id = %s AND clock_out_time IS NULL ORDER BY id DESC LIMIT 1", (current_time, user_id))
            print(f"Goodbye, {username}! You have successfully clocked out at {current_time}")
        else:
            # User is not clocked in, so clock them in
            cursor.execute("INSERT INTO clock_records (user_id, nfc_card_id, clock_in_time) VALUES (%s, %s, %s)", (user_id, card_data, current_time))
            print(f"Hello, {username}! You have successfully clocked in at {current_time}")
        
        conn.commit()

    else:
        print(f"User with user_id {user_id} not found in the 'nfc_cards' table.")

except mariadb.Error as e:
    print(f"Error: {e}")
finally:
    if conn:
        conn.close()
