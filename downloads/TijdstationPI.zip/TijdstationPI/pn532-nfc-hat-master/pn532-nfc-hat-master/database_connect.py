import mysql.connector
import RPi.GPIO as GPIO

from pn532 import *

# Replace these values with your actual database credentials
host = "192.168.1.144"
user = "tijdstation"
password = "Bstation7173"
database = "tijdstationdb"

try:
    # Connecting to the MySQL database
    connection = mysql.connector.connect(
        host=host,
        user=user,
        password=password,
        database=database
    )

    if connection.is_connected():
        print("Connected to the MySQL database")
        # You can perform further database operations here
        # ...

except mysql.connector.Error as e:
    print("Error while connecting to the database:", e)

finally:
    if 'connection' in locals():
        connection.close()
        print("Connection closed")
