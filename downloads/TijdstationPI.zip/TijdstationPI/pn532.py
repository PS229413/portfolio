# Import necessary libraries
from py532lib.i2c import *
from py532lib.frame import *
from py532lib.constants import *
import datetime
import mariadb
import time

# Function to print styled messages with larger font
def print_message(message, style='info'):
    styles = {
        'info': '\033[94m\033[1m',    # Blue and bold
        'success': '\033[92m\033[1m', # Green and bold
        'warning': '\033[93m\033[1m', # Yellow and bold
        'error': '\033[91m\033[1m'    # Red and bold
    }
    end_color = '\033[0m'
    print(styles.get(style, ''), message, end_color)

# Initialize the NFC reader
pn532 = Pn532_i2c()
pn532.SAMconfigure()

# Database configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Bstation7173',
    'database': 'Tijdstation'
}

# Connect to the MariaDB database
try:
    conn = mariadb.connect(**db_config)
    cursor = conn.cursor()

    # Main loop to continuously read NFC cards
    while True:
        # Read NFC card data
        card_data = pn532.read_mifare().get_data()

        # Get the current time
        current_time = datetime.datetime.now()

        # Convert the `bytearray` to a hexadecimal string
        hex_card_data = card_data.hex()

        # Print stylish information with larger font
        # print_message("NFC Card Data: " + hex_card_data, 'info')
        # print_message("Time: " + current_time.strftime("%Y-%m-%d %H:%M:%S"), 'info')

        # Fetch the user's name and ID based on the card data from the 'users' table
        cursor.execute("SELECT id, name FROM users WHERE nfc_card_data = %s", (hex_card_data,))
        user_info = cursor.fetchone()

        if user_info:
            user_id, user_name = user_info
            # print_message(f"User found: {user_name} (ID: {user_id})", 'success')
        else:
            print_message("User not found for the provided NFC card data: " + hex_card_data, 'error')
            continue

        # Check if the user is already clocked in
        cursor.execute("SELECT Clock_Out FROM clock WHERE User_id = %s AND Clock_Out IS NULL", (user_id,))
        existing_clock_out = cursor.fetchone()

        if existing_clock_out:
            # User is already clocked in, so this is a clock-out action
            clock_out_time = current_time
            cursor.execute("UPDATE clock SET Clock_Out = %s WHERE User_id = %s AND Clock_Out IS NULL", (clock_out_time, user_id))
            conn.commit()
            print_message(f"Hey, {user_name}. you have clocked out at {clock_out_time}", 'success')
        else:
            # User is not clocked in, so this is a clock-in action
            clock_in_time = current_time
            cursor.execute("INSERT INTO clock (Date, Clock_In, User_id, Timestamps) VALUES (%s, %s, %s, %s)", (current_time.date(), clock_in_time.time(), user_id, current_time))
            conn.commit()
            print_message(f"Hey, {user_name}. you have clocked in at {clock_in_time}", 'success')

        time.sleep(2)

except mariadb.Error as e:
    print_message(f"Database Error: {e}", 'error')
finally:
    if conn:
        conn.close()
