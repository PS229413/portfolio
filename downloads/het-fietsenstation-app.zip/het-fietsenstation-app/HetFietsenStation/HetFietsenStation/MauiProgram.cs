using HetFietsenStation.Services.RepairStep;
using HetFietsenStation.ViewModels;
using HetFietsenStation.Views;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.BikeRepairStep;
using HetFietsenStation.Services.RepairBike;
using HetFietsenStation.Services.BikeType;
using HetFietsenStation.Services.BikeColor;
using HetFietsenStation.Services.BikeCondition;
using HetFietsenStation.Services.BikeStatus;
using HetFietsenStation.Services.BikeSource;
using Syncfusion.Maui.Core.Hosting;
using SampleBrowser.Maui.Base.Hosting;
using HetFietsenStation.Services.User;
using HetFietsenStation.Services.SideProduct;
using HetFietsenStation.Services.Bike;
using HetFietsenStation.Services.SideProductType;
using CommunityToolkit.Maui;
using BarcodeScanner.Mobile;
using HetFietsenStation.Services.Payment;
using HetFietsenStation.Services.PDF;
using HetFietsenStation.Services.PhotoBike;

namespace HetFietsenStation;

public static class MauiProgram
{
	public static MauiApp CreateMauiApp()
	{
		var builder = MauiApp.CreateBuilder();
        // Initialise the toolkit
        builder.UseMauiApp<App>().UseMauiCommunityToolkit();
        builder
			.UseMauiApp<App>()
            .ConfigureSyncfusionCore()
            .ConfigureFonts(fonts =>
			{
				fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
				fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
				fonts.AddFont("hp-simplified.ttf", "HpSimplified");
				fonts.AddFont("rozha-one-regular.ttf", "RozhaOneRegular");
			})
            .ConfigureMauiHandlers(handlers =>
            {
                // Add the handlers
                handlers.AddBarcodeScannerHandler();
            });
        builder.ConfigureSampleBrowserBase();

        //Views
        builder.Services.AddSingleton<RepairView>();
        builder.Services.AddSingleton<RepairCatalogView>();
        builder.Services.AddSingleton<RepairBikeDetailsView>();
        builder.Services.AddSingleton<AddBikeView>();
        builder.Services.AddSingleton<ConcludeRepairView>();
        builder.Services.AddSingleton<LoginView>();
        builder.Services.AddSingleton<ShopCatalogView>();
        builder.Services.AddSingleton<AddProductView>();
        builder.Services.AddSingleton<EditProductView>();
        builder.Services.AddSingleton<CategoryManagementView>();
        builder.Services.AddSingleton<AddCatagoryView>();
        builder.Services.AddSingleton<EditCategoryView>();
        builder.Services.AddSingleton<RemoveCategoryView>();
        builder.Services.AddSingleton<UserView>();
        builder.Services.AddSingleton<AddUserView>();
        builder.Services.AddSingleton<DeleteUserView>();
        builder.Services.AddSingleton<EditUserView>();
        builder.Services.AddSingleton<ProductDetailsView>();
        builder.Services.AddSingleton<PhotographCatalogView>();
        builder.Services.AddSingleton<BikeDetailsView>();
        builder.Services.AddSingleton<EditBikeView>();
        builder.Services.AddSingleton<AdminHomeView>();
        builder.Services.AddSingleton<RoleView>();
        builder.Services.AddSingleton<SettingsView>();
        builder.Services.AddSingleton<ShoppingCartView>();
        builder.Services.AddSingleton<UserView>();
        builder.Services.AddSingleton<ShoppingCartView>();
        builder.Services.AddSingleton<ShopCatalogView>();
        builder.Services.AddSingleton<CheckoutView>();

        //ViewModels
        builder.Services.AddSingleton<RepairCatalogViewModel>();
        builder.Services.AddSingleton<RepairBikeDetailsViewModel>();
        builder.Services.AddSingleton<RepairViewModel>();
        builder.Services.AddSingleton<AddBikeViewModel>();
        builder.Services.AddSingleton<ConcludeRepairViewModel>();
        builder.Services.AddSingleton<LoginViewModel>();
        builder.Services.AddSingleton<ShopCatalogViewModel>();
        builder.Services.AddSingleton<AddProductViewModel>();
        builder.Services.AddSingleton<EditProductViewModel>();
        builder.Services.AddSingleton<AddUserViewModel>();
        builder.Services.AddSingleton<EditUserViewModel>();
        builder.Services.AddSingleton<DeleteUserViewModel>();
        builder.Services.AddSingleton<AddCategoryViewModel>();
        builder.Services.AddSingleton<EditCategoryViewModel>();
        builder.Services.AddSingleton<RemoveCategoryViewModel>();
        builder.Services.AddSingleton<ProductDetailsViewModel>();
        builder.Services.AddSingleton<PhotographCatalogViewModel>();
        builder.Services.AddSingleton<BikeDetailsViewModel>();
        builder.Services.AddSingleton<EditBikeViewModel>();
        builder.Services.AddSingleton<ShoppingCartViewModel>(); 
        builder.Services.AddSingleton<StaticPageViewModel>();

        //Services
        builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
        builder.Services.AddSingleton<INavigationService, NavigationService>();
        builder.Services.AddSingleton<ISettingsService, SettingsService>();
        builder.Services.AddSingleton<IBikeRepairStepService, BikeRepairStepService>();
        builder.Services.AddSingleton<IRepairStepService, RepairStepService>();
        builder.Services.AddSingleton<IRepairBikeService, RepairBikeService>();
        builder.Services.AddSingleton<IBikeTypeService, BikeTypeService>();
        builder.Services.AddSingleton<IBikeColorService, BikeColorService>();
        builder.Services.AddSingleton<IBikeConditionService, BikeConditionService>();
        builder.Services.AddSingleton<IBikeStatusService, BikeStatusService>();
        builder.Services.AddSingleton<IBikeSourceService, BikeSourceService>();
        builder.Services.AddSingleton<IUserService, UserService>();
        builder.Services.AddSingleton<ISideProductService, SideProductService>();
        builder.Services.AddSingleton<IBikeService, BikeService>();
        builder.Services.AddSingleton<ISideProductTypeService, SideProductTypeService>();
        builder.Services.AddSingleton<IPhotoBikeService, PhotoBikeService>();
        builder.Services.AddSingleton<IPDFService, PDFService>();

        return builder.Build();
	}
}