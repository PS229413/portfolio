﻿namespace HetFietsenStation.Validations
{
    class DoesNotContainSpecialCharacters<T> : IValidationRule<T>
    {
        public string ValidationMessage { get; set; }

        string AllowedCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 !?.,";
        public bool Check(T value) =>
            value is string str && str.All(s => AllowedCharacters.Contains(s));
    }
}