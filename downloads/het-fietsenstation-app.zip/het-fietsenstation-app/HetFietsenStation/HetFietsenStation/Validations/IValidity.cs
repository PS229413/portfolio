﻿namespace HetFietsenStation.Validations
{
    public interface IValidity
    {
        bool IsValid { get; }
        bool Validate();
    }
}
