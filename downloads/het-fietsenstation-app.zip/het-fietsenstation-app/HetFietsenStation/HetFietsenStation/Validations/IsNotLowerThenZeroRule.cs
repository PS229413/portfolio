﻿namespace HetFietsenStation.Validations
{
    class IsNotLowerThenZeroRule<T> : IValidationRule<T>
    {
        public string ValidationMessage { get; set; }
        public bool Check(T value) =>
            value is int i && i > -1;
    }
}