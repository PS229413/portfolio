﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace HetFietsenStation.Validations
{
    public class ValidatableObject<T> : ObservableObject, IValidity, INotifyPropertyChanged
    {
        private IEnumerable<string> _errors;
        private bool _isValid;
        private T _value;
        public List<IValidationRule<T>> Validations { get; } = new();
        public IEnumerable<string> Errors
        {
            get => _errors;
            private set => SetProperty(ref _errors, value);
        }
        public bool IsValid
        {
            get => _isValid;
            private set
            {
                SetProperty(ref _isValid, value);
                OnPropertyChanged();
            }
        }
        public T Value
        {
            get => _value;
            set
            {
                SetProperty(ref _value, value);
                OnPropertyChanged();
            }
        }
        public ValidatableObject()
        {
            _isValid = true;
            _errors = Enumerable.Empty<string>();
        }

        public void Clear()
        {
            IsValid = true;
            Errors = Enumerable.Empty<string>();
            Value = default(T);
        }

        public bool Validate()
        {
            Errors = Validations
                ?.Where(v => !v.Check(Value))
                ?.Select(v => v.ValidationMessage)
                ?.ToArray()
                ?? Enumerable.Empty<string>();
            IsValid = !Errors.Any();
            return IsValid;
        }

        public new event PropertyChangedEventHandler PropertyChanged;

        protected new void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
