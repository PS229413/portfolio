﻿using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;

namespace HetFietsenStation.ViewModels
{
    public class StaticPageViewModel : ViewModelBase
    {
        public StaticPageViewModel(ISettingsService settingsService, INavigationService navigationService) : base(navigationService, settingsService) { }

        public void OnNavigatedTo(string viewName)
        {
            switch (viewName)
            {
                case "Admin":
                    Title = "Admin Home";
                    break;
                case "Settings":
                    Title = "Instellingen";
                    break;
                case "User":
                    Title = "Gebruikers";
                    break;
                case "Categories":
                    Title = "Categorieën";
                    break;
                case null:
                    break;
            }
        }
    }
}