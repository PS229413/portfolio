﻿using HetFietsenStation.Models;
using HetFietsenStation.Services.Bike;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.SideProduct;
using HetFietsenStation.Validations;
using Newtonsoft.Json;
using System.Collections.ObjectModel;

namespace HetFietsenStation.ViewModels
{
    public partial class ShoppingCartViewModel : ViewModelBase 
    {
        [ObservableProperty]
        List<ShoppingCartModel> registeredItems;
        [ObservableProperty]
        ObservableCollection<ProductModel> products;
        [ObservableProperty]
        int price;

        List<int> Bikes;
        List<int> Sideproducts;

        private readonly IBikeService _bikeService;
        private readonly ISideProductService _sideProductService;

        public ShoppingCartViewModel(INavigationService navigationService, ISettingsService settingsService, IBikeService bikeService, ISideProductService sideProductService) 
            : base(navigationService, settingsService)
        {
            Title = "Shopping cart";

            Products = new ObservableCollection<ProductModel>();
            RegisteredItems = new List<ShoppingCartModel>();

            Bikes = new List<int>();
            Sideproducts = new List<int>();

            Price = 0;

            _bikeService = bikeService;
            _sideProductService = sideProductService;
        }

        public async Task LoadRegisteredItemsToList()
        {
            var serializedProducts = await SecureStorage.GetAsync("ShoppingCart");
            RegisteredItems = JsonConvert.DeserializeObject<List<ShoppingCartModel>>(serializedProducts);
        }

        public void ClearData()
        {
            RegisteredItems.Clear();
            Products.Clear();

            Price = 0;

            Bikes.Clear();
            Sideproducts.Clear();
        }
        
        public async void OnNavigatedTo()
        {
            ClearData();
            await LoadRegisteredItemsToList();
            ObtainProducts();
        }

        public async void ObtainProducts()
        {
            IEnumerable<BikeModel> bikeModels = await _bikeService.GetRepairedBikes();
            IEnumerable<SideProductModel> sideProductModels = await _sideProductService.GetAllSideProducts();

            foreach (ShoppingCartModel cart in RegisteredItems)
            {
                if (cart.Type == "bike")
                {
                    Bikes.Add(cart.Id);
                }
                else if (cart.Type == "sideproduct")
                {
                    Sideproducts.Add(cart.Id);
                }
            }

            if (bikeModels != null && Bikes.Any())
            {
                foreach (ProductModel product in bikeModels)
                {
                    foreach (int id in Bikes)
                    {
                        if (product.Id == id)
                        {
                          Products.Add(product);
                        }
                    }
                }
            }

            if (sideProductModels != null && Sideproducts.Any())
            {
                foreach (ProductModel product in sideProductModels)
                {
                    foreach (int id in Sideproducts)
                    {
                        if (product.Id == id)
                        {
                            Products.Add(product);
                        }
                    }
                }
            }

            foreach (ProductModel item in Products)
            {
                Price = Price + item.Price;
            }
        }
    }
}