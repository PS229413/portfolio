﻿using System.Collections.ObjectModel;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Validations;

namespace HetFietsenStation.ViewModels
{
    public abstract partial class ViewModelBase : ObservableObject
    {
        [ObservableProperty]
        private bool isInitialized;
        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(IsNotBusy))]
        private bool isBusy;
        [ObservableProperty]
        string title;

        [ObservableProperty]
        bool entryIsEnabled;

        public bool IsNotBusy => !IsBusy;

        public INavigationService _navigationService { get; private set; }
        public ISettingsService _settingService { get; private set; }
        public ViewModelBase(INavigationService navigationService, ISettingsService settingsService)
        {
            _navigationService = navigationService;
            _settingService = settingsService;
        }

        public virtual Task InitializeAsync()
        {
            return Task.CompletedTask;
        }

        public void HideKeyboard()
        {
            EntryIsEnabled = false;

            // Delay the enabling of the entry for a short time to allow the keyboard to fully hide
            Task.Delay(TimeSpan.FromMilliseconds(200)).ContinueWith(_ =>
            {
                EntryIsEnabled = true;
            });
        }

        protected async Task FetchAndSetData<TModel>(Task<IEnumerable<TModel>> task, ObservableCollection<TModel> collection)
        {
            IEnumerable<TModel> data = await task;

            foreach (TModel item in data)
            {
                collection.Add(item);
            }
        }
        
        //Checks if all applied rules from all ValidatableObjects are true and if not returns false
        protected bool Validate(List<IValidity> validations)
        {
            bool valid = true;
            foreach (IValidity validation in validations)
            {
                if (!validation.Validate())
                {
                    valid = false;
                }
            }

            return valid;
        }
        
        [RelayCommand]
        private async Task Logout()
        {
            bool confirmLogout = await Application.Current.MainPage.DisplayAlert("Bevestiging", "Weet u zeker dat u wilt uitloggen?", "Ja", "Nee");
                
            if (confirmLogout)
            {
                SecureStorage.Default.RemoveAll();
                await Shell.Current.GoToAsync("///Login");
            }
        }
    }
}
