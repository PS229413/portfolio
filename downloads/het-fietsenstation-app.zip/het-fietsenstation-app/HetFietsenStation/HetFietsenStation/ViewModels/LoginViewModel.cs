﻿using HetFietsenStation.Dtos.User;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.User;
using HetFietsenStation.Models;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;
using HetFietsenStation.Enums;
using Newtonsoft.Json.Linq;

namespace HetFietsenStation.ViewModels
{
    public partial class LoginViewModel : ViewModelBase
    {
        // Declaration of all ValidatableObject strings
        public ValidatableObject<string> Password { get; private set; }

        // Declaration of all ValidatableObject integers
        public ValidatableObject<int> SelectedUserIndex { get; set; }

        // Declaration of the picker collections
        [ObservableProperty]
        ObservableCollection<UserModel> _users;

        // Declaration of the picker selection
        [ObservableProperty]
        UserModel selectedUser;

        // Declaration of the error handlers
        [ObservableProperty]
        bool wrongInputValues;
        [ObservableProperty]
        bool loginFailed;
        [ObservableProperty]
        bool userRoleExistsNot;

        // Declarations of the services
        private readonly IUserService _userService;

        // Constructor which sets up the ViewModel to be used
        public LoginViewModel(IUserService userService, INavigationService navigationService, 
            ISettingsService settingsService) 
            : base(navigationService, settingsService)
        {
            _userService = userService;

            InitializeData();

            AddValidations();
        }

        // Is fired when navigating to the page, clears all old data and fills the data with up to date data
        public async void OnNavigatedTo()
        {
            await SecureStorage.SetAsync("ShoppingCart", "[]");

            ClearData();

            await GetUsers();
        }

        // Initializes all class fields with default data
        private void InitializeData()
        {
            Title = "Login";

            Users = new ObservableCollection<UserModel>();

            Password = new ValidatableObject<string>();

            SelectedUserIndex = new ValidatableObject<int> { Value = -1 };

            WrongInputValues = false;
            LoginFailed = false;
            UserRoleExistsNot = false;

            EntryIsEnabled = true;
        }

        // Adds the rules to the ValidatableObjects
        private void AddValidations()
        {
            Password.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul het wachtwwoord in!!!!" });
            SelectedUserIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een gebruiker!" });
        }

        // Returns all data of the class fields to a default state
        private void ClearData()
        {
            Password.Clear();

            Users.Clear();

            SelectedUserIndex.Clear();

            SelectedUserIndex.Value = -1;

            WrongInputValues = false;
            LoginFailed = false;
            UserRoleExistsNot = false;
        }

        // Gets the corresponding route based on the user's role ID
        public static string GetRouteByUserRoleId(UserRole roleId)
        {
            return roleId switch
            {
                UserRole.Mechanic => "RepairCatalog",
                UserRole.Admin => "AdminHome",
                UserRole.Photographer => "PhotographCatalog",
                UserRole.SalesPerson => "ShopCatalog",
                _ => null,
            };
        }

        // Gets all Users
        public async Task GetUsers()
        {
            await FetchAndSetData(_userService.GetUsers(), Users);
        }

        // Method which is called on button press and is responsible for the login validation
        [RelayCommand]
        public async Task Login()
        {
            HideKeyboard();

            List<IValidity> validations = new()
            {
                SelectedUserIndex,
                Password
            };

            // Check if the validations pass
            if (Validate(validations))
            {
                WrongInputValues = false;

                var verifyUser = new VerifyUserDto(SelectedUser.Id, SelectedUser.Name, Password.Value);

                string authToken = await _userService.ValidateUser(verifyUser);

                // Check if user authentication is successful
                if (authToken != null)
                {
                    LoginFailed = false;

                    string route = GetRouteByUserRoleId(SelectedUser.UserRoleId);

                    // Check if a route exists for the user role
                    if (route != null) 
                    {
                        UserRoleExistsNot = false;

                        // Extract the token value from the JSON
                        var tokenObject = JObject.Parse(authToken);
                        var token = tokenObject.Value<string>("token");
                        
                        // Store the authentication token and user ID securely
                        await SecureStorage.Default.SetAsync("oauth_token", token);
                        await SecureStorage.Default.SetAsync("user_id", SelectedUser.Id.ToString());

                        await _navigationService.NavigateToAsync(route);
                    }
                    else
                    {
                        UserRoleExistsNot = true;
                    }
                }
                else 
                {
                    LoginFailed = true;
                }
            }
            else 
            {
                WrongInputValues = true;
            }
        }
    }
}
