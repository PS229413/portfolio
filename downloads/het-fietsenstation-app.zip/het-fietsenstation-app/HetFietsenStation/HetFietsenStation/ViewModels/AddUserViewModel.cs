﻿using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;
using HetFietsenStation.Services.User;
using HetFietsenStation.Dtos.User;

namespace HetFietsenStation.ViewModels;

public partial class AddUserViewModel : ViewModelBase
{
    //Declaration of all ValidatableObject strings
    public ValidatableObject<string> NewPassword { get; set; }
    public ValidatableObject<string> NewUser { get; set; }

    //Declaration of all ValidatableObject ints
    public ValidatableObject<int> SelectedRoleIndex { get; set; }

    //Declaration of the picker collections
    [ObservableProperty]
    ObservableCollection<RoleModel> roles;

    //Declaration of the error handler
    [ObservableProperty]
    bool wrongInputValues;
    [ObservableProperty]
    bool incorrectLength;

    //Declaration to show if the label above if user got added
    [ObservableProperty]
    bool addedUserSucces;

    //Delcarations of the services
    IUserService _userService;

    public AddUserViewModel(IUserService userService ,INavigationService navigationService,
    ISettingsService settingsService)
    : base(navigationService, settingsService)
    {
        _userService = userService;

        InitializeData();

        AddValidations();
    }

    //creates the start data when creating this part of the apps
    public void InitializeData()
    {
        //creates all the data to default values
        Title = "Nieuwe Gebruiker";

        NewUser = new ValidatableObject<string>();
        NewPassword = new ValidatableObject<string>();
        Roles = new ObservableCollection<RoleModel>();

        SelectedRoleIndex = new ValidatableObject<int>();

        SelectedRoleIndex.Value = -1;

        WrongInputValues = false;
        IncorrectLength = false;
        AddedUserSucces = false;

        EntryIsEnabled = true;
    }

    //When navigated to add the roles and clear data if it their was already inputted in the lines
    public async void OnNavigatedTo()
    {
        ClearData();

        await GetRoles();
    }

    //Adds the rules to the ValidatableObjects
    private void AddValidations()
    {
        NewPassword.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul het wachtwwoord in!!!!" });
        NewPassword.Validations.Add(new DoesNotContainSpecialCharacters<string> { ValidationMessage = "Gebruik geen speciale tekens!" });
        NewUser.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul een naam in!!!!" });
        NewUser.Validations.Add(new DoesNotContainSpecialCharacters<string> { ValidationMessage = "Gebruik geen speciale tekens!" });
        SelectedRoleIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een rol!" });
    }

    public void ClearData()
    {
        //resets all the data to default values
        NewUser.Clear();
        NewPassword.Clear();

        Roles.Clear();

        SelectedRoleIndex.Clear();

        SelectedRoleIndex.Value = -1;

        WrongInputValues = false;
        IncorrectLength = false ;
        AddedUserSucces = false;
    }

    public async Task GetRoles()
    {
        await FetchAndSetData(_userService.GetRoles(), Roles);
    }

    //use this command to add a user to the database
    [RelayCommand]
    public async Task AddUser()
    {
        //makes an list to check if the given variables are valid
        List<IValidity> validations = new List<IValidity>()
        {
            NewUser,
            NewPassword,
            SelectedRoleIndex
        };

        HideKeyboard();

        if (Validate(validations))
        {
            if (NewPassword.Value.Length == 4)
            {
                //if it goes threw it means that no variables were invalid
                WrongInputValues = false;

                int chosenRole = SelectedRoleIndex.Value + 1;

                //set the dto to the inputed variales
                AddUserDto addUser = new AddUserDto(NewUser.Value, NewPassword.Value, chosenRole);

                //add an user to the database via the api
                await _userService.AddUser(addUser);

                //clear the field in the input
                NewUser.Clear();
                NewPassword.Clear();
                SelectedRoleIndex.Value = -1;
            }
            else
            {
                IncorrectLength = true;
            }
        }
        else
        {
            WrongInputValues = true;
        }

        AddedUserSucces = !WrongInputValues;
    }
}