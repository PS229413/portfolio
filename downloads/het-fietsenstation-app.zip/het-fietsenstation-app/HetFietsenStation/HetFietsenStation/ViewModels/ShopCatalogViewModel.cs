﻿using HetFietsenStation.Models;
using HetFietsenStation.Services.Bike;
using HetFietsenStation.Services.BikeType;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.SideProduct;
using HetFietsenStation.Services.SideProductType;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;

namespace HetFietsenStation.ViewModels
{
    public partial class ShopCatalogViewModel : ViewModelBase
    {
        public ValidatableObject<int?> SearchProductValue { get; set; }

        public ObservableCollection<ProductModel> _allProducts;

        IEnumerable<ProductModel> allProducts;

        [ObservableProperty]
        ObservableCollection<ProductModel> products;
        [ObservableProperty]
        ObservableCollection<SideProductTypeModel> sideTypes;
        [ObservableProperty]
        ObservableCollection<BikeTypeModel> bikeTypes;

        [ObservableProperty]
        BikeTypeModel selectedBikeType;
        [ObservableProperty]
        SideProductTypeModel selectedSideType;

        [ObservableProperty]
        string subType;

        [ObservableProperty]
        string[] filterOptions;
        [ObservableProperty]
        string[] priceOptions;
        [ObservableProperty]
        string[] heightsOptions;
        [ObservableProperty]
        string[] stockOptions;

        [ObservableProperty]
        string selectedFilterOption;
        [ObservableProperty]
        string selectedPriceOption;
        [ObservableProperty]
        string selectedHeightOption;
        [ObservableProperty]
        string selectedStockOption;

        [ObservableProperty]
        bool showBike;

        [ObservableProperty]
        bool showProduct;

        [ObservableProperty]
        int height;
        
        private readonly IBikeService _bikeService;
        private readonly ISideProductService _sideProductService;
        private readonly IBikeTypeService _bikeTypeService;
        private readonly ISideProductTypeService _sideProductTypeService;

        public ShopCatalogViewModel(IBikeService bikeService,INavigationService navigationService, ISettingsService settingsService, ISideProductService sideProductService, IBikeTypeService bikeTypeService, ISideProductTypeService sideProductTypeService) 
            : base(navigationService, settingsService)
        {
            //create the variables to use on the page
            Title = "Catalogus";
            SearchProductValue = new ValidatableObject<int?>();

            Products = new ObservableCollection<ProductModel>();
            EntryIsEnabled = true;
            BikeTypes = new ObservableCollection<BikeTypeModel>();
            SideTypes = new ObservableCollection <SideProductTypeModel>();

            //Create pages for the filter function on the page
            FilterOptions = new string[]
            {
                "Fiets",
                "Side product"
            };
            PriceOptions = new string[]
            {
                "Minder dan 50",
                "50 - 100",
                "100 - 150",
                "150 - 200",
                "Meer dan 200"
            };
            HeightsOptions = new string[]
            {
                "Minder dan 50",
                "50 - 55",
                "55 - 60",
                "60 - 65",
                "Meer dan 65"
            };
            StockOptions = new string[]
            {
                "Minder dan 10",
                "10 - 20",
                "20 - 30",
                "30 - 40"
            };

            ShowProduct = true;
            ShowBike = true;

            Height = 275;

            _bikeService = bikeService;
            _sideProductService = sideProductService;
            _bikeTypeService = bikeTypeService;
            _sideProductTypeService = sideProductTypeService;

            AddValidations();
        }

        public void ClearFilter()
        {
            //reset filter
            SelectedBikeType = null;
            SelectedFilterOption = null;
            SelectedHeightOption = null;
            SelectedPriceOption = null;
            SelectedStockOption = null;
            SelectedSideType = null;
            Height = 275;
        }

        private void AddValidations()
        {
            SearchProductValue.Validations.Add(new IsNotNullOrEmptyIntRule<int?> { ValidationMessage = "Vul het zoek vlak in!" });
        }

        public async Task GetProducts()
        {
            ClearValues();

            // Retrieve bikes and products
            IEnumerable<BikeModel> bikeModels = await _bikeService.GetRepairedBikes();
            IEnumerable<SideProductModel> sideProductModels = await _sideProductService.GetAllSideProducts();
            // Combine bikes and products into a single collection
            allProducts = bikeModels.Cast<ProductModel>().Concat(sideProductModels);

            // Add products to the Products collection if there are any
            if (allProducts.Any())
            {
                // Loop through each product and add it to the Products collection
                foreach (ProductModel product in allProducts)
                {
                    foreach (ImageModel image in product.Images)
                    {
                        ChangeImageToPlacehold(image);
                    }
                    Products.Add(product);
                }
            }
        }

        //check if the image is valid and is indeed a image
        bool IsImageUrl(string currentProduct)
        {
            var extension = Path.GetExtension(currentProduct);
            return !string.IsNullOrEmpty(extension) && (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".gif");
        }

        private void ClearValues()
        {
            Products.Clear();
            SideTypes.Clear();
            BikeTypes.Clear();

            SearchProductValue.Value = null;

            SelectedFilterOption = null;

            Height = 275;

            ShowBike = false;
            ShowProduct = false;
        }

        //this is the part where the products get filtered
        public async Task ProductFilter()
        {
            // Retrieve bikes and products
            IEnumerable<BikeModel> bikeModels = await _bikeService.GetRepairedBikes();
            IEnumerable<SideProductModel> sideProductModels = await _sideProductService.GetAllSideProducts();

            int maxPrice = 1000000;
            int minPrice = 0;
            int maxHeight = 1000000;
            int minHeight = 0;
            int maxStock = 100000;
            int minStock = 0;

            //clear the products 
            Products.Clear();

            //check which option on the filters has been chosen
            switch (SelectedStockOption)
            {
                case "Minder dan 10":
                    maxStock = 11;
                    break;
                case "10 - 20":
                    maxStock = 21;
                    minStock = 10;
                    break;
                case "20 - 30":
                    maxStock = 31;
                    minStock = 20;
                    break;
                case "30 - 40":
                    maxStock = 41;
                    minStock = 30;
                    break;
                case "Meer dan 40":
                    minStock = 40;
                    break;
                default:
                    break;
            }
            switch (SelectedHeightOption)
            {
                case "Minder dan 50":
                    maxHeight = 50;
                    break;
                case "50 - 55":
                    minHeight = 50;
                    maxHeight = 56;
                    break;
                case "55 - 60":
                    minHeight = 55;
                    maxHeight = 61;
                    break;
                case "60 - 65":
                    minHeight = 60;
                    maxHeight = 66;
                    break;
                case "Meer dan 65":
                    minHeight = 65;
                    break;
                default:
                    break;
            }
            switch (SelectedPriceOption)
            {
                case "Minder dan 50":
                    maxPrice = 51;
                    break;
                case "50 - 100":
                    minPrice = 50;
                    maxPrice = 101;
                    break;
                case "100 - 150":
                    minPrice = 100;
                    maxPrice = 151;
                    break;
                case "150 - 200":
                    minPrice = 150;
                    maxPrice = 201;
                    break;
                case "Meer dan 200":
                    minPrice = 200;
                    break;
                default:
                    break;
            }

            // Add products to the Products collection if there are any
            if (SelectedFilterOption == "Fiets")
            {
                foreach (BikeModel bike in bikeModels)
                {
                    foreach (ImageModel image in bike.Images)
                    {
                        ChangeImageToPlacehold(image);
                    }
                    if (SelectedBikeType == null || SelectedBikeType.Name == bike.BikeType.Name)
                    {
                        if (SelectedPriceOption == "" || (minPrice <= bike.Price && bike.Price < maxPrice ))
                        {
                            if (SelectedHeightOption == "" || (minHeight <= bike.FrameHeight && bike.FrameHeight < maxHeight))
                            {
                                Products.Add(bike);
                            }
                        }
                    }
                }
            }
            else if (SelectedFilterOption == "Side product")
            {
                //Go through these filter options if the filter option is a product
                foreach (SideProductModel sideproduct in sideProductModels)
                {
                    foreach (ImageModel image in sideproduct.Images)
                    {
                        ChangeImageToPlacehold(image);
                    }
                    if (SelectedSideType == null || SelectedSideType.Name == sideproduct.SideProductType.Name)
                    {
                        if (SelectedStockOption == "" || (minStock <= sideproduct.Stock && sideproduct.Stock < maxStock))
                        {
                            Products.Add(sideproduct);
                        }
                    }
                }
            }
            else
            {
                //show all products if no filter options were chosen
                foreach (BikeModel bike in bikeModels)
                {
                    Products.Add(bike);
                }
                foreach (SideProductModel sideProduct in sideProductModels)
                {
                    Products.Add(sideProduct);
                }
            }
            SelectedBikeType = null;
            SelectedFilterOption = null;
            SelectedHeightOption = null;
            SelectedPriceOption = null;
            SelectedStockOption = null;
            SelectedSideType = null;
            Height = 275;
        }

        public void CheckSubType()
        {
            //only show the option that are for the selected product type
            if (SelectedFilterOption == "Fiets")
            {
                ShowBike = true;
                ShowProduct = false;
                Height = 400;
            }
            else if (SelectedFilterOption == "Side product")
            {
                ShowProduct = true;
                ShowBike = false;
                Height = 350;
            }
            else
            {
                ShowProduct = false;
                ShowBike = false;
                Height = 275;
            }

        }

        //load all the filter options
        public async void LoadFilterOptions()
        {
            await FetchAndSetData(_bikeTypeService.GetAllBikeTypes(), BikeTypes);
        }

        public void OnSearchTextChanged(string searchText)
        {
            /* If the _allProducts collection has not been initialized, 
               create a copy of the Products collection and assign it to _allProducts */
            _allProducts ??= new ObservableCollection<ProductModel>(Products.ToList());

            // Clear the Products collection from the View
            Products.Clear();

            // Check if the search text is empty or null
            if (string.IsNullOrEmpty(searchText))
            {
                /* If the search text is empty or null, 
                reset the Products collection to its original state */
                foreach (var product in _allProducts)
                {
                    foreach (ImageModel image in product.Images)
                    {
                        ChangeImageToPlacehold(image);
                    }
                    Products.Add(product);
                }

                // Clear SearchBox
                SearchProductValue.Clear();
            }
            else
            {
                // Try to parse the search text as an integer
                if (int.TryParse(searchText, out int searchId))
                {
                    /* If the search text can be parsed as an integer,
                       filter the _allProducts collection based on the product Ids that start with the search text */
                    var products = _allProducts.Where(b => b.Id.ToString().StartsWith(searchText));

                    // Check if any bikes were found
                    if (products != null)
                    {
                        // Add the found products to the Products collection to show in the View
                        foreach (var product in products)
                        {
                            foreach (ImageModel image in product.Images)
                            {
                                ChangeImageToPlacehold(image);
                            }
                            Products.Add(product);
                        }
                    }
                }
            }
        }

        public async Task<BikeModel> OnBarcodeDetected(int bikeId)
        {
            BikeModel bikeResult = await _bikeService.GetBike(bikeId);
            return bikeResult;
        }

        [RelayCommand]
        public async Task SearchProduct()
        {
            HideKeyboard();

            // Validate the SearchBikeValue input
            SearchProductValue.Validate();

            // Clear the Products collection from the View
            Products.Clear();

            // Check if the SearchProductValue input is null or 0
            if (SearchProductValue.Value == null || SearchProductValue.Value == 0)
            {
                // If the SearchProductValue input is null or 0, then get all products
                await GetProducts();
            }
            else
            {
                /* If the SearchProductValue input is not null or 0,
                 get a specific product based on the input value */

                // Retrieve bikes and products
                BikeModel bikeModel = await _bikeService.GetBike((int)SearchProductValue.Value);
                SideProductModel sideProductModel = await _sideProductService.GetSideProduct((int)SearchProductValue.Value);

                // Add the bike and side product to the list if they exist
                if (bikeModel != null)
                {
                    foreach (ImageModel image in bikeModel.Images)
                    {
                        ChangeImageToPlacehold(image);
                    }
                    Products.Add(bikeModel);
                }

                if (sideProductModel != null)
                {
                    foreach (ImageModel image in sideProductModel.Images)
                    {
                        ChangeImageToPlacehold(image);
                    }
                    Products.Add(sideProductModel);
                }
            }
        }

        //check image
        private void ChangeImageToPlacehold(ImageModel image)
        {
            if (image.Url == "")
            {
                image.Url = "bike_placeholder.png";
            }
            else
            {
                if (!IsImageUrl(image.Url))
                {
                    image.Url = "bike_placeholder";
                }
            }
        }

        public void OnSelectedIndexChanged()
        {
            CheckSubType();
        }

        [RelayCommand]
        public async Task ToProductDetails(ProductModel currentProduct)
        {
            HideKeyboard();

            await _navigationService.NavigateToAsync("ProductDetails", new Dictionary<string, object>
            {
                {
                    "Product", currentProduct
                }
            });
        }
        private static async void Winkelmand_Clicked(object sender, EventArgs e)
        {
            await Shell.Current.GoToAsync("ShoppingCart");
        }
    }
}