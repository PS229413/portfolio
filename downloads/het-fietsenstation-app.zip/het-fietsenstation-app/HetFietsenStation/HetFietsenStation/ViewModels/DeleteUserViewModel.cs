using HetFietsenStation.Dtos.User;
using HetFietsenStation.Models;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.User;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;

namespace HetFietsenStation.ViewModels
{
    public partial class DeleteUserViewModel : ViewModelBase
    {
        //Declaration of all ValidatableObject int
        public ValidatableObject<int> SelectedUserIndex { get; set; }

        //Declaration of the picker collection
        [ObservableProperty]
        ObservableCollection<UserModel> users;

        [ObservableProperty]
        bool wrongInputValues;
        [ObservableProperty]
        bool enoughUsers;

        //Declaration of the service
        IUserService _userService;

        public DeleteUserViewModel(IUserService userService, INavigationService navigationService, ISettingsService settingsService) : base(navigationService, settingsService)
        {
            _userService = userService;

            InitializedData();

            AddValidations();
        }

        private void InitializedData()
        {
            Title = "Verwijder Gebruiker";

            Users = new ObservableCollection<UserModel>();
            SelectedUserIndex = new ValidatableObject<int>();

            WrongInputValues = false;
            EnoughUsers = true;
        }

        private void AddValidations()
        {
            SelectedUserIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Selecteer een Gebruiker" });
        }

        private void ClearData()
        {
            Users.Clear();

            SelectedUserIndex.Clear();
            SelectedUserIndex.Value = -1;

            WrongInputValues = false;
            EnoughUsers = true;
        }

        public async void OnNavigatedTo()
        {
            ClearData();

            await GetUsers();
        }

        public async Task GetUsers()
        {
            //obtain the user from the database and put them in a 
            IEnumerable<UserModel> users = await _userService.GetUsers();

            //put all users into the delete entry to delete except for the users that is logged in
            foreach (UserModel user in users)
            {
                if (user.Id.ToString() != await SecureStorage.GetAsync("user_id"))
                {
                    Users.Add(user);
                }
                //check if there are enough users
                EnoughUsers = Users.Count == 1 ? false : true;
            }
        }

        [RelayCommand]
        async Task DeleteUser()
        {
            List<IValidity> validations = new List<IValidity>()
            {
                SelectedUserIndex
            };

            if (Validate(validations))
            {
                //delete the user from the picker and reset
                WrongInputValues = false;

                DeleteUserDto deleteUserDto = new DeleteUserDto(Users[SelectedUserIndex.Value].Id);

                await _userService.DeleteUser(deleteUserDto);

                ClearData();
                await GetUsers();
            }
            else
            {
                WrongInputValues = true;
            }
        }
    }
}