using HetFietsenStation.Models;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.PhotoBike;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Validations;

namespace HetFietsenStation.ViewModels
{
    public partial class BikeDetailsViewModel : ViewModelBase, IQueryAttributable
    {
        public ValidatableObject<string> Date { get; set; }
        public ValidatableObject<string> ImageUrl { get; set; }

        [ObservableProperty]
        PhotoBikeModel photoBike;

        [ObservableProperty]
        bool showMechanic;

        IPhotoBikeService _photoBikeService;

        public BikeDetailsViewModel(IPhotoBikeService photoBikeService, INavigationService navigationService, ISettingsService settingsService) : base (navigationService, settingsService)
        {
            InitializedData();

            _photoBikeService = photoBikeService;
        }
        
        //create the variables for this page
        private void InitializedData()
        {
            Title = "Fiets Details";
            PhotoBike = new PhotoBikeModel();
            Date = new ValidatableObject<string>();
            ImageUrl = new ValidatableObject<string>();
        }

        //obtain the bike that was send from the catalog page
        public async void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            PhotoBike = new PhotoBikeModel();

            string bikeId = query.First().Value.ToString();

            await GetBike(Convert.ToInt32(bikeId));
        }

        //obtain the bike from the database by grabbing all the bikes first and then getting the first bike from the list which has the id that was send
        private async Task GetBike(int id)
        {
            IEnumerable<PhotoBikeModel> photoBikeModel = await _photoBikeService.GetBikes();

            if (photoBikeModel != null)
            {
                //get the first bike that contains the specified id from the ienumerable list
                PhotoBike = photoBikeModel.First(b => b.Id == id);

                //check for each image of the bike if the image is a valid image link
                foreach (ImageModel image in PhotoBike.Images)
                {
                    ChangeImageToPlacehold(image);
                }

                ImageUrl.Value = PhotoBike.Images[0].Url;

                ShowMechanic = PhotoBike.Mechanic.Id == 0 ? false : true;
                Date.Value = PhotoBike.RegistrationData.Day.ToString() + " - " + PhotoBike.RegistrationData.Month.ToString() + " - " + PhotoBike.RegistrationData.Year.ToString();
            }
        }

        //change the image if the variable is empty or not a correct image url
        private void ChangeImageToPlacehold(ImageModel image)
        {
            if (image.Url == "")
            {
                image.Url = "bike_placeholder.png";
            }
            else
            {
                if (!IsImageUrl(image.Url))
                {
                    image.Url = "bike_placeholder";
                }
            }
        }

        //check if the image is not empty or null and ends with an image format
        bool IsImageUrl(string imageCheck)
        {
            var extension = Path.GetExtension(imageCheck);
            return !string.IsNullOrEmpty(extension) && (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".gif");
        }

        [RelayCommand]
        public async Task GoBackToCatalogus()
        {
            //return to the catalogus by removing the upmost layer of the app
            await _navigationService.PopAsync();
        }

        [RelayCommand]
        public async Task ToEditPhotoBike()
        {
            await _navigationService.NavigateToAsync("EditPhotoBike", new Dictionary<string, object>
            {
                {
                    nameof(PhotoBike), PhotoBike.Id
                }
            });
        }

        [RelayCommand]
        public async Task ToAddPhoto()
        {
            await _navigationService.NavigateToAsync("AddPhoto");
        }
    }
}