﻿using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Models;

namespace HetFietsenStation.ViewModels
{
    public partial class RepairBikeDetailsViewModel : ViewModelBase, IQueryAttributable
    {
        [ObservableProperty]
        RepairBikeModel repairBike;

        public RepairBikeDetailsViewModel(INavigationService navigationService, ISettingsService settingsService) : base(navigationService, settingsService)
        {
            Title = "Fiets details";
            RepairBike = new RepairBikeModel();
        }

        public void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            //show the bike that was sent from the catalog page
            RepairBike = new RepairBikeModel();
            RepairBike = (RepairBikeModel)query["RepairBike"];
            RepairBike.Images.Clear();
            foreach (ImageModel image in RepairBike.Images)
            {
                ChangeImageToPlacehold(image);
                RepairBike.Images.Add(image);
            }
        }

        private void ChangeImageToPlacehold(ImageModel image)
        {
            if (image.Url == "")
            {
                image.Url = "bike_placeholder.png";
            }
            else
            {
                if (!IsImageUrl(image.Url))
                {
                    image.Url = "bike_placeholder";
                }
            }
        }

        bool IsImageUrl(string currentBike)
        {
            var extension = Path.GetExtension(currentBike);
            return !string.IsNullOrEmpty(extension) && (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".gif");
        }

        [RelayCommand]
        public async Task ToRepair()
        {
            await _navigationService.NavigateToAsync("Repair", new Dictionary<string, object> 
            { 
                { 
                    nameof(RepairBike), RepairBike 
                } 
            });
        }

        [RelayCommand]
        public async Task ToEditRepairBike()
        {
            await _navigationService.NavigateToAsync("EditRepairBike", new Dictionary<string, object> 
            { 
                { 
                    nameof(RepairBike), RepairBike.Id 
                } 
            });
        }
    }
}
