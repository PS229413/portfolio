﻿using HetFietsenStation.Dtos.RepairBike;
using HetFietsenStation.Services.BikeColor;
using HetFietsenStation.Services.BikeCondition;
using HetFietsenStation.Services.BikeSource;
using HetFietsenStation.Services.BikeType;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.RepairBike;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;

namespace HetFietsenStation.ViewModels
{
    public partial class EditRepairBikeViewModel : ViewModelBase, IQueryAttributable
    {
        //Declaration of all ValidatableObject strings
        public ValidatableObject<string> Brand { get; set; }
        public ValidatableObject<string> Model { get; set; }
        public ValidatableObject<string> ImageUrl { get; set; }

        //Declaration of Images
        [ObservableProperty]
        ObservableCollection<string> images;

        //Declaration of all ValidatableObject ints
        public ValidatableObject<int> FrameNumber { get; set; }
        public ValidatableObject<int> FrameHeight { get; set; }
        public ValidatableObject<int> SelectedBikeTypeIndex { get; set; }
        public ValidatableObject<int> SelectedBikeColorIndex { get; set; }
        public ValidatableObject<int> SelectedBikeConditionIndex { get; set; }
        public ValidatableObject<int> SelectedBikeSourceIndex { get; set; }

        //Declaration of the RepairBike
        [ObservableProperty]
        RepairBikeModel repairBike;
        
        //Declaration of the picker collections
        [ObservableProperty]
        ObservableCollection<BikeTypeModel> bikeTypes;
        [ObservableProperty]
        ObservableCollection<BikeColorModel> bikeColors;
        [ObservableProperty]
        ObservableCollection<BikeConditionModel> bikeConditions;
        [ObservableProperty]
        ObservableCollection<BikeSourceModel> bikeSources;

        //Declaration of the picker selection
        [ObservableProperty]
        BikeTypeModel selectedBikeType;
        [ObservableProperty]
        BikeColorModel selectedBikeColor;
        [ObservableProperty]
        BikeConditionModel selectedBikeCondition;
        [ObservableProperty]
        BikeSourceModel selectedBikeSource;

        //Declaration of the SelectedColor Color
        [ObservableProperty]
        Color selectedColor;

        //Declaration of the error handlers
        [ObservableProperty]
        bool wrongInputValues;
        [ObservableProperty]
        bool editBikeFailed;

        //Delcarations of the services
        IRepairBikeService _repairBikeService;
        IBikeTypeService _BikeTypeService;
        IBikeColorService _BikeColorService;
        IBikeConditionService _BikeConditionService;
        IBikeSourceService _BikeSourceService;

        //Constructor which sets up the ViewModel to be used
        public EditRepairBikeViewModel(IRepairBikeService repairBikeService, IBikeTypeService bikeTypeService, 
            IBikeColorService bikeColorService, IBikeConditionService bikeConditionService,
            IBikeSourceService bikeSourceService, INavigationService navigationService, 
            ISettingsService settingsService)
            : base(navigationService, settingsService)
        {
            _repairBikeService = repairBikeService;
            _BikeTypeService = bikeTypeService;
            _BikeColorService = bikeColorService;
            _BikeConditionService = bikeConditionService;
            _BikeSourceService = bikeSourceService;

            InitializeData();

            AddValidations();
        }

        //Is fired when navigating to the page, clears all old data and fills the data with up to date data
        public async void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            ClearData();

            RepairBike = (RepairBikeModel)query[nameof(RepairBike)];

            await GetBikeTypes();
            await GetBikeColors();
            await GetBikeConditions();
            await GetBikeSources();

            Brand.Value = RepairBike.Brand;
            Model.Value = RepairBike.Model;
            FrameNumber.Value = RepairBike.FrameNumber;
            FrameHeight.Value = RepairBike.FrameHeight;
        }

        //Initializes all class fields with default data
        private void InitializeData()
        {
            Title = "Fiets aanpassen";

            Brand = new ValidatableObject<string>();
            Model = new ValidatableObject<string>();
            ImageUrl = new ValidatableObject<string>();
            FrameNumber = new ValidatableObject<int>();
            FrameHeight = new ValidatableObject<int>();

            SelectedBikeTypeIndex = new ValidatableObject<int>();
            SelectedBikeColorIndex = new ValidatableObject<int>();
            SelectedBikeConditionIndex = new ValidatableObject<int>();
            SelectedBikeSourceIndex = new ValidatableObject<int>();

            SelectedBikeTypeIndex.Value = -1;
            SelectedBikeColorIndex.Value = -1;
            SelectedBikeConditionIndex.Value = -1;
            SelectedBikeSourceIndex.Value = -1;

            RepairBike = new RepairBikeModel();
            Images = new ObservableCollection<string>();

            BikeTypes = new ObservableCollection<BikeTypeModel>();
            BikeColors = new ObservableCollection<BikeColorModel>();
            BikeConditions = new ObservableCollection<BikeConditionModel>();
            BikeSources = new ObservableCollection<BikeSourceModel>();

            SelectedColor = Color.FromArgb("#FFFFFF");

            WrongInputValues = false;
            EditBikeFailed = false;

            EntryIsEnabled = true;
        }

        //Adds the rules to the ValidatableObjects
        private void AddValidations()
        {
            Brand.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul het merk in!" });
            Brand.Validations.Add(new DoesNotContainSpecialCharacters<string> { ValidationMessage = "Merk mag geen speciale karakters bezitten!" });
            Model.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul het model in!" });
            Model.Validations.Add(new DoesNotContainSpecialCharacters<string> { ValidationMessage = "Model mag geen speciale karakters bezitten!" });
            FrameNumber.Validations.Add(new IsNotNullOrEmptyIntRule<int> { ValidationMessage = "Vul het frame nummer in!" });
            FrameNumber.Validations.Add(new IsNotLowerThenOneRule<int> { ValidationMessage = "Frame nummer mag niet lager zijn dan 0!" });
            FrameHeight.Validations.Add(new IsNotNullOrEmptyIntRule<int> { ValidationMessage = "Vul de frame hoogte in!" });
            FrameHeight.Validations.Add(new IsNotLowerThenOneRule<int> { ValidationMessage = "Frame hoogte mag niet lager zijn dan 0!" });
            SelectedBikeTypeIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een type!" });
            SelectedBikeColorIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een kleur!" });
            SelectedBikeConditionIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een staat!" });
            SelectedBikeSourceIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een afkomst!" });
        }

        //Returns all data of the class fields to a default state
        private void ClearData()
        {
            Brand.Clear();
            Model.Clear();
            FrameNumber.Clear();
            FrameHeight.Clear();
            
            SelectedBikeTypeIndex.Clear();
            SelectedBikeColorIndex.Clear();
            SelectedBikeConditionIndex.Clear();
            SelectedBikeSourceIndex.Clear();

            SelectedBikeTypeIndex.Value = -1;
            SelectedBikeColorIndex.Value = -1;
            SelectedBikeConditionIndex.Value = -1;
            SelectedBikeSourceIndex.Value = -1;

            BikeTypes.Clear();
            BikeColors.Clear();
            BikeConditions.Clear();
            BikeSources.Clear();

            SelectedColor = Color.FromArgb("#FFFFFF");

            WrongInputValues = false;
            EditBikeFailed = false;
        }

        //Inserts the view related data into the RepairBike
        private void UpdateBikeField()
        {
            RepairBike.Brand = Brand.Value;
            RepairBike.Model = Model.Value;
            RepairBike.FrameNumber = FrameNumber.Value;
            RepairBike.FrameHeight = FrameHeight.Value;
            RepairBike.BikeType = SelectedBikeType;
            RepairBike.BikeColor = SelectedBikeColor;
            RepairBike.BikeCondition = SelectedBikeCondition;
            RepairBike.BikeSource = SelectedBikeSource;
        }

        //Gets all BikeTypes and sets the SelectedBikeType
        public async Task GetBikeTypes()
        {
            await FetchAndSetData(_BikeTypeService.GetAllBikeTypes(), BikeTypes);

            SelectedBikeType = BikeTypes.First(bt => bt.Id == RepairBike.BikeType.Id);
        }

        //Gets all BikeColors and sets the SelectedBikeColor
        public async Task GetBikeColors()
        {
            await FetchAndSetData(_BikeColorService.GetAllBikeColors(), BikeColors);
            
            SelectedBikeColor = BikeColors.First(bc => bc.Id == RepairBike.BikeColor.Id);
        }

        //Gets all BikeConditions and sets the SelectedBikeCondition
        public async Task GetBikeConditions()
        {
            await FetchAndSetData(_BikeConditionService.GetBikeConditions(), BikeConditions);
            
            SelectedBikeCondition = BikeConditions.First(bc => bc.Id == RepairBike.BikeCondition.Id);
        }

        //Gets all BikeSources and sets the SelectedBikeSource
        public async Task GetBikeSources()
        {
            await FetchAndSetData(_BikeSourceService.GetBikeSources(), BikeSources);

            SelectedBikeSource = BikeSources.First(bs => bs.Id == RepairBike.BikeSource.Id);
        }

        //Is fired when button is clicked and checks if the data is right for the bike to be updated and if this is the case updates the bike
        [RelayCommand]
        public async Task EditBike()
        {
            List<IValidity> validations = new List<IValidity>()
            {
                Brand,
                Model,
                ImageUrl,
                FrameNumber,
                FrameHeight,
                SelectedBikeTypeIndex,
                SelectedBikeColorIndex,
                SelectedBikeConditionIndex,
                SelectedBikeSourceIndex
            };

            HideKeyboard();

            if (Validate(validations))
            {
                UpdateBikeField();

                WrongInputValues = false;

                UpdateRepairBikeDto repairBike = new UpdateRepairBikeDto(RepairBike);

                if (await _repairBikeService.UpdateRepairBike(repairBike))
                {
                    EditBikeFailed = false;

                    await _navigationService.PopAsync(new Dictionary<string, object>
                    {
                        {
                            "RepairBike", RepairBike
                        }
                    });

                    return;
                }

                EditBikeFailed = true;
            }
            else
            {
                WrongInputValues = true;
            }
        }

        //Is fired when the selection of the color picker is changed and sets the selected color according to the SelectedBikeColor and if empty returns it to the default data state
        public void ColorSelectionChanged()
        {
            if (SelectedBikeColor != null)
            {
                SelectedColor = Color.FromArgb(SelectedBikeColor.HexCode);
            }
            else
            {
                SelectedColor = Color.FromArgb("#FFFFFF");
            }
        }
        [RelayCommand]
        public async Task<FileResult> PickAndShow(PickOptions options)
        {
            HideKeyboard();
            //resets the imageUrl value so that it will no longer show the current route
            ImageUrl.Value = "";
            try
            {
                //opens an filepicker and allows user to pick a file
                var result = await FilePicker.Default.PickAsync(options);
                //sees if the result is not null
                if (result != null)
                {
                    //checks if the file is an image file.
                    if (result.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase) ||
                        result.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
                    {
                        //creates a path to the appdatadirectory with the name of the fill
                        string localFilePath = Path.Combine(FileSystem.AppDataDirectory, result.FileName);
                        //opens a stream to see the file that has been selected
                        using var stream = await result.OpenReadAsync();
                        var imageUrl = ImageSource.FromStream(() => stream);
                        //saves the file
                        using FileStream localFileStream = File.OpenWrite(localFilePath);
                        //saves a copy of the file to the file path
                        await stream.CopyToAsync(localFileStream);
                    }
                    //changes the value in the entry to the new image
                    ImageUrl.Value = result.FullPath;
                }

                // always return result if it was able to
                return result;
            }
            catch
            {
                // The user canceled or something went wrong
            }

            return null;
        }

        [RelayCommand]
        public async Task<FileResult> CaptureAndSave()
        {
            HideKeyboard();
            //checks if the camera is supported to take a photo
            if (MediaPicker.Default.IsCaptureSupported)
            {
                //save the permission status
                var status = await Permissions.CheckStatusAsync<Permissions.Camera>();
                
                if (status == PermissionStatus.Granted)
                {
                    //wait until the camera has taken a picture
                    FileResult photo = await MediaPicker.Default.CapturePhotoAsync();

                    //checks if the image is not empty
                    if (photo != null)
                    {
                        //resets the value of the image url
                        ImageUrl.Value = "";

                        //changes path to path in data directory
                        string localFilePath = Path.Combine(photo.FileName);

                        //reads the image that was taken
                        using Stream sourceStream = await photo.OpenReadAsync();
                        //writes the file to the file path
                        using FileStream localFileStream = File.OpenWrite(localFilePath);

                        //changes the entry value to the new file Path
                        ImageUrl.Value = localFilePath;

                        //return photo
                        return photo;
                    }
                }
                
                if (status == PermissionStatus.Denied)
                {
                    return null;
                }
            }

            return null;
        }
    }
}
