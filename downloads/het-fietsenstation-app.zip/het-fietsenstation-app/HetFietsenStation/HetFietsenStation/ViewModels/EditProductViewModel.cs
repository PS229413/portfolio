﻿using HetFietsenStation.Dtos.SideProduct;
using HetFietsenStation.Models;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.SideProduct;
using HetFietsenStation.Services.SideProductType;
using HetFietsenStation.Services.User;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;

namespace HetFietsenStation.ViewModels
{
    public partial class EditProductViewModel : ViewModelBase, IQueryAttributable
    {
        //Declaration of all ValidatableObject strings
        public ValidatableObject<string> Name { get; set; }
        public ValidatableObject<string> Description { get; set; }
        public ValidatableObject<string> ImageUrl { get; set; }
        public ValidatableObject<string> ImageUrlShow { get; set; }

        //Declaration of all ValidatableObject ints
        public ValidatableObject<int> Quantity { get; set; }
        public ValidatableObject<int> Price { get; set; }
        public ValidatableObject<int> SelectedProductTypeIndex { get; set; }

        //Declaration of model
        [ObservableProperty]
        SideProductModel sideProduct;
        [ObservableProperty]
        ObservableCollection<SideProductTypeModel> category;

        //Declaration of the picker selection
        [ObservableProperty]
        SideProductTypeModel selectedProductType;

        [ObservableProperty]
        bool productEntryVisible;

        //Declaration of the error handlers
        [ObservableProperty]
        bool wrongInputValues;
        [ObservableProperty]
        bool editProductFailed;

        //Declaration of service
        ISideProductTypeService _sideProductTypeService;
        ISideProductService _sideProductService;
        IUserService _userService;

        //Constructor which sets up the ViewModel to be used
        public EditProductViewModel(ISideProductService sideProductService, ISideProductTypeService sideProductTypeService, IUserService userService, INavigationService navigationService, ISettingsService settingsService) 
            : base(navigationService, settingsService)
        {
            //Give Title of the page
            Title = "Product Bewerken";

            //Define the service for the wholepage
            _sideProductService = sideProductService;
            _sideProductTypeService = sideProductTypeService;
            _userService = userService;

            // Call the Function to create all the variables and add validations to the entry and picker fields that require validations
            InitializeData();
            AddValidations();
        }

        private void InitializeData()
        {
            Name = new ValidatableObject<string>();
            Description = new ValidatableObject<string>();
            ImageUrl = new ValidatableObject<string>();
            ImageUrlShow = new ValidatableObject<string>();

            Quantity = new ValidatableObject<int>();
            Price = new ValidatableObject<int>();
            SelectedProductTypeIndex = new ValidatableObject<int>();
            
            Category = new ObservableCollection<SideProductTypeModel>();

            SelectedProductTypeIndex.Value = -1;

            ProductEntryVisible = true;

            WrongInputValues = false;
            EditProductFailed = false;
            EntryIsEnabled = true;
        }

        public async void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            //resets the data
            ClearData();
            //Obtain the product id that was send to this page from the catalog
            await GetProduct(query.First().Value.ToString());
        }

        public async void ShowFields()
        {
            ProductEntryVisible = true;

            var users = await _userService.GetUsers();

            //show the edit field that are needed for the specific role and hide the fields that are not needed
            foreach (var user in users)
            {
                if (user.Id.ToString() == await SecureStorage.GetAsync("user_id"))
                {
                    if (user.UserRoleId == Enums.UserRole.Photographer)
                    {
                        ProductEntryVisible = false;
                    }
                }
            }
        }

        private async Task GetProduct(string id)
        {
            //Obtain all the sideproducts from the API through the services
            IEnumerable<SideProductModel> productModels = await _sideProductService.GetAllSideProducts();

            //obtain the single product from the list of products that was just obtained by finding the id
            SideProduct = productModels.First(b => b.Id == Convert.ToInt32(id));

            //set all the variables to the single product
            if (SideProduct != null)
            {
                Name.Value = SideProduct.Name;
                Description.Value = SideProduct.Description;
                Quantity.Value = SideProduct.Stock;
                Price.Value = SideProduct.Price;

                if (SideProduct.Images.Count > 0)
                {
                    ImageUrlShow.Value = SideProduct.Images[0].Url;
                }

                ShowFields();
                await GetTypes();
            }
        }

        bool IsImageUrl(string currentProduct)
        {
            //check if the image is valid and exists
            var extension = Path.GetExtension(currentProduct);
            return !string.IsNullOrEmpty(extension) && (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".gif");
        }

        //resets all the variables on the page
        private void ClearData()
        {
            Name.Clear(); 
            Description.Clear(); 
            Quantity.Clear(); 
            Price.Clear();
            ImageUrlShow.Clear();

            Category.Clear();
            
            SelectedProductTypeIndex.Clear(); 
            
            WrongInputValues = false; 
            EditProductFailed = false;
        }

        private void AddValidations()
        {
            //set the validations of the variables to the check if they are filled in
            Name.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul een naam in!!!!" });
            Description.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul het in!!!!" });
            Quantity.Validations.Add(new IsNotNullOrEmptyIntRule<int> { ValidationMessage = "Vul het in!" });
            Quantity.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Het mag niet een negatieve getal zijn!" });
            Price.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Het mag niet een negatieve getal zijn!" });
            Price.Validations.Add(new IsNotNullOrEmptyIntRule<int> { ValidationMessage = "Vul het in!" });
            SelectedProductTypeIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Vul het in!" });
        }

        //Inserts the view related data into the Bike
        private void UpdateProductField()
        {
            //update the field to the new variables 
            SideProduct.Name = Name.Value;
            SideProduct.Description = Description.Value;
            SideProduct.Stock = Quantity.Value;
            SideProduct.Price = Price.Value;
            SideProduct.SideProductType = SelectedProductType;
        }

        private async Task GetTypes()
        {
            //clear all the categories
            Category.Clear();

            //obtain the categories
            await FetchAndSetData(_sideProductTypeService.GetTypes(), Category);
            
            //select the category that belongs to the product 
            SelectedProductType = Category.First(c => c.Id == SideProduct.SideProductType.Id);
        }

        [RelayCommand]
        public async Task EditProduct()
        {
            //make a list of all variables that need to check if they are valid
            List<IValidity> validations = new List<IValidity>()
            {
                Name, 
                Description, 
                Quantity, 
                Price,
                ImageUrl,
                SelectedProductTypeIndex
            };

            //hide keyboard to prevent phone keyboard to not stay up
            HideKeyboard();

            //continue if all the variables that need to be valid are indeed valid
            if (Validate(validations))
            {
                UpdateProductField();

                WrongInputValues = false;

                //set a dto to the value within the fields
                UpdateSideProductDto updateSideProductType = new UpdateSideProductDto(SideProduct.Id, Name.Value, Description.Value, Quantity.Value, Price.Value, SelectedProductType.Id);

                //update the product in the database through the API
                var succes = await _sideProductService.UpdateSideProduct(updateSideProductType);

                //Check if it succesfully updated the product
                if (succes)
                {
                    //Go back to the details page
                    await _navigationService.PopAsync(new Dictionary<string, object>
                    {
                        {
                            "Product", SideProduct
                        }
                    });
                }
                //if the product did not update show a message that says that
                else
                {
                    EditProductFailed = true;
                }
            }
            else
            {
                //if not all variables where valid than show a message that not all variables were valid
                WrongInputValues = true;
            }
        }
        
        [RelayCommand]
        public async Task<FileResult> PickAndShow(PickOptions options)
        {
            //resets the value of the image url
            ImageUrl.Value = "";
            try
            {
                //open the filepicker on the phone
                var result = await FilePicker.Default.PickAsync(options);
                if (result != null)
                {
                    //check if the selected file was an jpg or png
                    if (result.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase) ||
                        result.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
                    {
                        string localFilePath = Path.Combine(FileSystem.AppDataDirectory, result.FileName);
                        using var stream = await result.OpenReadAsync();
                        var ImageUrl = ImageSource.FromStream(() => stream);
                        using FileStream localFileStream = File.OpenWrite(localFilePath);
                        await stream.CopyToAsync(localFileStream);

                    }
                    //set the image value to the path of the image
                    ImageUrl.Value = result.FullPath;
                }

                return result;
            }
            catch
            {
                // The user canceled or something went wrong
            }

            return null;
        }

        [RelayCommand]
        public async Task<FileResult> CaptureAndSave()
        {
            //resets the image url
            ImageUrl.Value = "";
            if (MediaPicker.Default.IsCaptureSupported)
            {
                //Open the Camera on the phone
                FileResult photo = await MediaPicker.Default.CapturePhotoAsync();

                //Check if there was indeed a photo made
                if (photo != null)
                {
                    string localFilePath = Path.Combine(FileSystem.AppDataDirectory, photo.FileName);

                    using Stream sourceStream = await photo.OpenReadAsync();
                    using FileStream localFileStream = File.OpenWrite(localFilePath);

                    await sourceStream.CopyToAsync(localFileStream);
                    ImageUrl.Value = localFilePath;

                    return photo;
                }
            }

            return null;
        }
    }
}
