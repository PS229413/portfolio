﻿using HetFietsenStation.Dtos.SideProduct;
using HetFietsenStation.Models;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.SideProduct;
using HetFietsenStation.Services.SideProductType;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;

namespace HetFietsenStation.ViewModels
{
    public partial class AddProductViewModel : ViewModelBase
    {
        //Declaration of all ValidatableObject strings
        public ValidatableObject<string> Name { get; set; }
        public ValidatableObject<string> Description { get; set; }
        public ValidatableObject<string> Quantity { get; set; }
        public ValidatableObject<string> Price { get; set; }


        //Declaration of Images
        [ObservableProperty]
        ObservableCollection<string> images;

        //Declaration of all ValidatableObject ints
        public ValidatableObject<int> SelectedProductTypeIndex { get; set; }
        public ValidatableObject<int> QuantityAmount { get; set; }
        public ValidatableObject<int> PriceAmount { get; set; }

        //Declaration of picker collections
        [ObservableProperty]
        ObservableCollection<SideProductTypeModel> productTypes;

        //Declaration of the picker selection
        [ObservableProperty]
        SideProductTypeModel selectedProductType;

        //Declaration of the error handlers
        [ObservableProperty]
        bool wrongInputValues;
        [ObservableProperty]
        bool addProductFailed;
        [ObservableProperty]
        bool negativeNumbers;

        //Declaration of services
        ISideProductService _sideProductService;
        ISideProductTypeService _sideProductTypeService;

        //Constructor which sets up the ViewModel to be used
        public AddProductViewModel(INavigationService navigationService, ISettingsService settingsService, 
            ISideProductService sideProductService, ISideProductTypeService sideProductType) 
            : base(navigationService, settingsService)
        {
            Title = "Product Toevoegen";
            InitializeData();
            AddValidations();

            _sideProductService = sideProductService;
            _sideProductTypeService = sideProductType;
        }

        private void InitializeData()
        {
            Name = new ValidatableObject<string>();
            Description = new ValidatableObject<string>();
            Quantity = new ValidatableObject<string>();
            Price = new ValidatableObject<string>();
            QuantityAmount = new ValidatableObject<int>();
            PriceAmount = new ValidatableObject<int>();
            SelectedProductTypeIndex = new ValidatableObject<int>();

            SelectedProductTypeIndex.Value = -1;

            ProductTypes = new ObservableCollection<SideProductTypeModel>();

            WrongInputValues = false;
            AddProductFailed = false;
            NegativeNumbers = false;

            Images = new ObservableCollection<string>();

            EntryIsEnabled = true;
        }

        public async void OnNavigatedTo()
        {
            ClearData();

            //get the types from the db through the api
            await GetTypes();
        }

        private void ClearData()
        {
            Name.Clear();
            Description.Clear();
            Quantity.Clear();
            Price.Clear();

            SelectedProductTypeIndex.Clear();

            SelectedProductTypeIndex.Value = -1;

            ProductTypes.Clear();

            WrongInputValues = false;
            AddProductFailed = false;
            NegativeNumbers = false;
        }

        private void AddValidations()
        {
            Name.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul een naam in!!!!" });
            Description.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul het in!!!!" });
            Quantity.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul het in!" });
            Price.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul het in!" });
            SelectedProductTypeIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Vul het in!" });
        }

        //Gets all Users
        private async Task GetTypes()
        {
            //obtain data from application wide method located in the viewmodel base
            await FetchAndSetData(_sideProductTypeService.GetTypes(), ProductTypes);
        }

        [RelayCommand]
        public async Task AddProduct()
        {
            //create a list of all variables that need to be checked
            List<IValidity> validations = new List<IValidity>()
            {
                Name, 
                Description, 
                Quantity, 
                Price,
                SelectedProductTypeIndex
            };

            //hide keyboard
            HideKeyboard();

            if (Validate(validations))
            {
                //set the string form of the quantity and price value to intengers
                WrongInputValues = false;
                QuantityAmount.Value = Convert.ToInt32(Quantity.Value);
                PriceAmount.Value = Convert.ToInt32(Price.Value);

                //check if the values of integers are higher or equal to zero. they can't be negative
                if (QuantityAmount.Value >= 0 && PriceAmount.Value >= 0)
                {
                    //start to upload the side product to the database
                    NegativeNumbers = false;
                    int selectedType = SelectedProductTypeIndex.Value + 1;
                    AddSideProductDto addSideProduct = new AddSideProductDto(Name.Value, Description.Value, QuantityAmount.Value, PriceAmount.Value, selectedType);
                    await _sideProductService.AddSideProduct(addSideProduct, Images.ToList());

                    //clear the field in the input
                    ClearData();
                    SelectedProductTypeIndex.Value = -1;
                }
                else
                {
                    NegativeNumbers = true;
                }
            }
            else
            {
                WrongInputValues = true;
            }
        }

        [RelayCommand]
        public async Task<FileResult> PickAndShow(PickOptions options)
        {
            try
            {
                var result = await FilePicker.Default.PickAsync(options);
                if (result != null)
                {
                    //checks if the file is an image file.
                    if (result.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase) ||
                        result.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
                    {
                        //creates a path to the appdatadirectory with the name of the fill
                        string localFilePath = Path.Combine(FileSystem.AppDataDirectory, result.FileName);
                        //opens a stream to see the file that has been selected
                        using var stream = await result.OpenReadAsync();
                        var imageUrl = ImageSource.FromStream(() => stream);
                        //saves the file
                        using FileStream localFileStream = File.OpenWrite(localFilePath);
                        //saves a copy of the file to the file path
                        await stream.CopyToAsync(localFileStream);

                        // Combine the app data directory with the filename
                        Images.Add(result.FileName);
                    }

                    return result;
                }
            }
            catch
            {
                // The user canceled or something went wrong
            }

            return null;
        }

        [RelayCommand]
        public async Task<FileResult> CaptureAndSave()
        {
            if (MediaPicker.Default.IsCaptureSupported)
            {
                //wait until the camera has taken a picture
                FileResult photo = await MediaPicker.Default.CapturePhotoAsync();

                //checks if the image is not empty
                if (photo != null)
                {
                    //changes path to path in data directory
                    string localFilePath = Path.Combine(FileSystem.AppDataDirectory, photo.FileName);

                    //reads the image that was taken
                    using Stream sourceStream = await photo.OpenReadAsync();
                    //writes the file to the file path
                    using FileStream localFileStream = File.OpenWrite(localFilePath);

                    //copies te image to the new file path
                    await sourceStream.CopyToAsync(localFileStream);

                    Images.Add(photo.FileName);
                }
            }

            return null;
        }

        [RelayCommand]
        private void DeleteImage(string image)
        {
            //remove the image by pressing button
            Images.Remove(image);
        }

        [RelayCommand]
        public void OpenImage(string image)
        {
            //open the file and show the image
            string localFilePath = Path.Combine(FileSystem.AppDataDirectory, image);
            Launcher.OpenAsync(new OpenFileRequest
            {
                File = new ReadOnlyFile(localFilePath)
            });
        }
    }
}