﻿using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;

namespace HetFietsenStation.ViewModels
{
    public partial class AppShellViewModel : ViewModelBase
    {
        public AppShellViewModel(INavigationService navigationService, 
            ISettingsService settingsService) 
            : base(navigationService, settingsService)
        {

        }

        [RelayCommand]
        public async Task Back()
        {
            await _navigationService.PopAsync();
        }
    }
}
