﻿using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.RepairBike;
using HetFietsenStation.Services.User;
using HetFietsenStation.Dtos.RepairBike;
using HetFietsenStation.Builders;
using HetFietsenStation.Models;
using System.Collections.ObjectModel;
using HetFietsenStation.Validations;

namespace HetFietsenStation.ViewModels
{
    public partial class ConcludeRepairViewModel : ViewModelBase, IQueryAttributable
    {
        //Declaration of all ValidatableObjects strings
        public ValidatableObject<string> Note { get; set; }

        //Declaration of all ValidatableObjects ints
        public ValidatableObject<int> SelectedMechanicIndex { get; set; }

        //Declaration of the PhotographBike
        public PhotographBikeModel PhotographBike;

        //Declaration of the mechanic picker collection
        [ObservableProperty]
        ObservableCollection<UserModel> mechanics;

        //Declaration of the mechanic picker selection
        [ObservableProperty]
        UserModel selectedMechanic;

        //Declaration of the error handlers
        [ObservableProperty]
        bool wrongInputValues;
        [ObservableProperty]
        bool concludeRepairFailed;

        //Delcarations of the services
        IRepairBikeService _repairBikeService;
        IUserService _userService;

        //Constructor which sets up the ViewModel to be used
        public ConcludeRepairViewModel(IUserService userService,IRepairBikeService repairBikeService,
            INavigationService navigationService, ISettingsService settingsService )
            : base(navigationService, settingsService)
        {
            Title = "Reparatie concluderen";

            _repairBikeService = repairBikeService;
            _userService = userService;

            InitializeData();

            AddValidations();
        }

        //Is fired when navigating to the page, clears all old data and fills the data with up to date data
        public async void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            //obtain the bike from the the data send from the previous page
            ClearData();

            await GetMechanics();

            PhotographBike = (PhotographBikeModel)query["PhotographBike"];
        }

        //Initializes all class fields with default data
        private void InitializeData()
        {
            Note = new ValidatableObject<string>();

            SelectedMechanicIndex = new ValidatableObject<int>();

            PhotographBike = new PhotographBikeModel();

            Mechanics = new ObservableCollection<UserModel>();

            WrongInputValues = false;
            ConcludeRepairFailed = false;
            EntryIsEnabled = true;
        }

        //Adds the rules to the ValidatableObjects
        private void AddValidations()
        {
            Note.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul de notitie in!" });
            Note.Validations.Add(new DoesNotContainSpecialCharacters<string> { ValidationMessage = "Notitie mag geen speciale karakters bezitten!" });
            SelectedMechanicIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een monteur!" });
        }

        //Returns all data of the class fields to a default state
        private void ClearData()
        {
            Note.Clear();

            SelectedMechanicIndex.Clear();
            SelectedMechanicIndex.Value = -1;

            Mechanics.Clear();

            WrongInputValues = false;
            ConcludeRepairFailed = false;
        }

        //Inserts the view related data into the PhotographBike
        private void UpdateBikeField()
        {
            PhotographBike.Note = Note.Value;
            PhotographBike.RepairDate = DateTime.Now;
            PhotographBike.Mechanic = SelectedMechanic;
        }

        //Is fired when clicking the button ans is responsible for creating the PDF
        [RelayCommand]
        public async Task BuildPriceTag()
        {
            //make a list of the variables to check
            List<IValidity> validations = new List<IValidity>()
            {
                Note,
                SelectedMechanicIndex
            };

            HideKeyboard();

            //check if the variables are valid and filled in
            if (Validate(validations))
            {
                WrongInputValues = false;

                UpdateBikeField();

                //make a new repairBikeToPhotographBikeDto to save the bike and change it to a bike to be saved
                RepairBikeToPhotographBikeDto repairBikeToPhotographBikeDto = new RepairBikeToPhotographBikeDto(PhotographBike);

                //finish the bike repair and return the catalog
                if (await _repairBikeService.RepairBikeToPhotographBike(repairBikeToPhotographBikeDto))
                {
                    ConcludeRepairFailed = false;
#if ANDROID
                    PriceTagBuilder.Build(PhotographBike);
#endif
                    await _navigationService.NavigateToAsync("../../../");
                }
                else
                {
                    ConcludeRepairFailed = true;
                }
            }
            else
            {
                WrongInputValues = true;
            }
        }

        public async Task GetMechanics()
        {
            await FetchAndSetData(_userService.GetMechanics(), Mechanics);
        }
    }
}
