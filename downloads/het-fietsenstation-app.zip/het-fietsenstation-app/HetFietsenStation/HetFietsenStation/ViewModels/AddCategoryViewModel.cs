using HetFietsenStation.Dtos.SideProductType;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.SideProductType;
using HetFietsenStation.Validations;

namespace HetFietsenStation.ViewModels
{
    public partial class AddCategoryViewModel : ViewModelBase
    {
        //Declaration of all ValidatableObject strings
        public ValidatableObject<string> NewCategory { get; set; }
        public ValidatableObject<string> NewDescription { get; set; }

        //Declaration of the error handler
        [ObservableProperty]
        bool wrongInputValues;

        //Declaration to show if the label above if user got added
        [ObservableProperty]
        bool addedUserSucces;

        //Declaration of services
        ISideProductTypeService _sideProductTypeService;

        public AddCategoryViewModel(ISideProductTypeService sideProductTypeService, INavigationService navigationService, ISettingsService settingsService) : base(navigationService, settingsService)
        {
            _sideProductTypeService = sideProductTypeService;

            InitializedData();
            AddValidations();
        }

        //create the variables that are used on the page
        private void InitializedData()
        {
            Title = "Voeg category toe";

            NewCategory = new ValidatableObject<string>();
            NewDescription = new ValidatableObject<string>();

            WrongInputValues = false;
            AddedUserSucces = false;

            EntryIsEnabled = true;
        }
        //clear the variables every time you return to this page
        public void OnNavigatedTo()
        {
            ClearData();
        }

        private void AddValidations()
        {
            NewCategory.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul de naam van de categorie in" });
            NewDescription.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul een Beschrijving in" });
        }

        //resets the variables
        private void ClearData()
        {
            NewCategory.Clear();
            NewDescription.Clear();

            WrongInputValues = false;
            AddedUserSucces = false;
        }

        [RelayCommand]
        public async Task AddCategory()
        {
            HideKeyboard();
            //create a list of all variables that need to be checked
            List<IValidity> validations = new List<IValidity>()
            {
                NewCategory,
                NewDescription
            };

            
            if (Validate(validations))
            {
                //Add the category to the database to select as new category
                WrongInputValues = false;

                AddSideProductTypeDto sideProductType = new AddSideProductTypeDto(NewCategory.Value, NewDescription.Value);

                await _sideProductTypeService.AddType(sideProductType);

                NewCategory.Clear();
                NewDescription.Clear();
            }
            else
            {
                WrongInputValues = true;
            }
            AddedUserSucces = !WrongInputValues;
        }
    }
}