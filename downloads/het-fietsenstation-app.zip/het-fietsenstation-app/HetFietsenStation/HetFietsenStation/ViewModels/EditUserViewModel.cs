﻿using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;
using HetFietsenStation.Services.User;
using HetFietsenStation.Dtos.User;
using HetFietsenStation.Enums;

namespace HetFietsenStation.ViewModels
{
    public partial class EditUserViewModel : ViewModelBase
    {
        //Declaration of all ValidatableObject strings
        public ValidatableObject<string> EditUserName { get; set; }
        public ValidatableObject<string> EditPassword { get; set; }
        public ValidatableObject<string> SelectedItem { get; set; }

        //Declaration of all ValidatableObject ints
        public ValidatableObject<int> SelectedRoleIndex { get; set; }
        public ValidatableObject<int> SelectedUserIndex { get; set; }

        //Declaration of the error handler
        [ObservableProperty]
        bool wrongInputValues;
        [ObservableProperty]
        bool userSelected;
        [ObservableProperty]
        bool incorrectLength;

        //Declaration of the picker collections
        [ObservableProperty]
        ObservableCollection<UserModel> users;
        [ObservableProperty]
        ObservableCollection<RoleModel> roles;

        //Delcarations of the services
        IUserService _userService;

        public EditUserViewModel(IUserService userService, INavigationService navigationService, ISettingsService settingsService) : base(navigationService, settingsService)
        {
            _userService = userService;

            InitializedData();

            AddValidations();
        }

        private void InitializedData()
        {
            Title = "Wijzig gebruiker";

            EditUserName = new ValidatableObject<string>();
            EditPassword = new ValidatableObject<string>();
            SelectedItem = new ValidatableObject<string>();
            
            Roles = new ObservableCollection<RoleModel>();
            Users = new ObservableCollection<UserModel>();

            SelectedRoleIndex = new ValidatableObject<int>();
            SelectedUserIndex = new ValidatableObject<int>();

            WrongInputValues = false;
            UserSelected = false;
            IncorrectLength = false;

            EntryIsEnabled = true;
        }

        public async void OnNavigatedTo()
        {
            ClearData();

            await GetRoles();

            await GetUsers();
        }

        private void AddValidations()
        {
            SelectedUserIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een Gebruiker" });
            SelectedRoleIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Selecteer een rol" });
            EditUserName.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul een Gebruikersnaam in" });
            EditUserName.Validations.Add(new DoesNotContainSpecialCharacters<string> { ValidationMessage = "Gebruik geen speciale tekens!" });
            EditPassword.Validations.Add(new DoesNotContainSpecialCharacters<string> { ValidationMessage = "Gebruik geen speciale tekens!" });
        }

        private void ClearData()
        {
            EditUserName.Clear();
            EditPassword.Clear();
            SelectedItem.Clear();

            Roles.Clear();
            Users.Clear();

            SelectedRoleIndex.Clear();
            SelectedUserIndex.Clear();

            SelectedUserIndex.Value = -1;
            SelectedRoleIndex.Value = -1;

            WrongInputValues = false;
            UserSelected = false;
            IncorrectLength = false;
        }

        private void GetRoleId(UserRole roleId)
        {
            switch (roleId)
            {
                case UserRole.Mechanic:
                    SelectedRoleIndex.Value = 0;
                    break;
                case UserRole.Admin:
                    SelectedRoleIndex.Value = 1;
                    break;
                case UserRole.Photographer:
                    SelectedRoleIndex.Value = 2;
                    break;
                case UserRole.SalesPerson:
                    SelectedRoleIndex.Value = 3;
                    break;
                default:
                    break;
            }
        }

        //check if their was a user chosen and set the information to the users values
        public void ChosenUser()
        {
            if (SelectedUserIndex.Value != -1)
            {
                EditUserName.Value = Users[SelectedUserIndex.Value].Name;
                GetRoleId(Users[SelectedUserIndex.Value].UserRoleId);
                UserSelected = true;
            }
            else
            {
                EditUserName.Clear();
                SelectedRoleIndex.Clear();
                UserSelected = false;
            }
        }

        //Gets all Roles
        private async Task GetRoles()
        {
            await FetchAndSetData(_userService.GetRoles(), Roles);
        }

        //Gets all Users
        private async Task GetUsers()
        {
            await FetchAndSetData(_userService.GetUsers(), Users);
        }

        //use this command to add a user to the database
        [RelayCommand]
        public async Task EditUser()
        {
            //makes an list to check if the given variables are valid
            List<IValidity> validations = new List<IValidity>()
            {
                SelectedUserIndex,
                SelectedRoleIndex,
                EditUserName
            };

            HideKeyboard();

            if (Validate(validations))
            {
                //if it goes threw it means that no variables were invalid
                WrongInputValues = false;

                if (EditPassword.Value == null || EditPassword.Value == "")
                {
                    EditPassword.Value = "";
                }

                if (EditPassword.Value.Length == 4)
                {
                    int selectedRole = SelectedRoleIndex.Value + 1;

                    //set the dto to the input variables
                    UpdateUserDto updateUser = new UpdateUserDto(Users[SelectedUserIndex.Value].Id, EditUserName.Value, EditPassword.Value, selectedRole);

                    //update an user to the database via the api
                    await _userService.UpdateUser(updateUser);

                    if (updateUser.Id.ToString() == await SecureStorage.GetAsync("user_id"))
                    {
                        await _navigationService.PopToRootAsync();
                    }

                    ClearData();
                    await GetRoles();
                    await GetUsers();
                }

                else
                {
                    IncorrectLength = true;
                }
            }
            else
            {
                WrongInputValues = true;
            }
        }
    }
}