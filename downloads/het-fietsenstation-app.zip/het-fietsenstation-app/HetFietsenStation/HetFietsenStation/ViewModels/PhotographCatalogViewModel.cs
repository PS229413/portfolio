using HetFietsenStation.Models;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.PhotoBike;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.SideProduct;
using HetFietsenStation.Services.User;
using System.Collections.ObjectModel;

namespace HetFietsenStation.ViewModels
{
	public partial class PhotographCatalogViewModel : ViewModelBase
	{
		public ObservableCollection<PhotoBikeModel> _allBikes { get; set; }

		[ObservableProperty]
		ProductModel selectedProduct;
		[ObservableProperty]
		UserModel user;

		[ObservableProperty]
		ObservableCollection<ProductModel> bikes;

		[ObservableProperty]
		bool productSelected;
		[ObservableProperty]
		bool showBackButton;


        IPhotoBikeService _photoBikeService;
		ISideProductService _sideProductService;
		IUserService _userService;

		public PhotographCatalogViewModel(IPhotoBikeService photoBikeService, ISideProductService sideProductService, INavigationService navigationService, ISettingsService settingsService, IUserService userService) : base(navigationService, settingsService)
		{
			_photoBikeService = photoBikeService;
			_sideProductService = sideProductService;
			_userService = userService;

            InitializedData();
			GetBikes();
		}

		private void InitializedData()
		{
			Title = "Foto Catalogus";

			Bikes = new ObservableCollection<ProductModel>();

			ProductSelected = false;
            ShowBackButton = false;
        }

        bool IsImageUrl(string imageCheck)
        {
			//check if image is valid
            var extension = Path.GetExtension(imageCheck);
            return !string.IsNullOrEmpty(extension) && (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".gif");
        }

        public async void GetBikes()
		{
			//get all the bikes and all of the side products
			IEnumerable<PhotoBikeModel> bikes = await _photoBikeService.GetBikes();
			IEnumerable<SideProductModel> sideProducts = await _sideProductService.GetAllSideProducts();

			foreach (PhotoBikeModel bike in bikes)
			{
				foreach (ImageModel image in bike.Images)
                {
                    ChangeImageToPlacehold(image);
                }
                bike.Info = bike.Brand + " " + bike.Model + " - " + bike.Id;
				Bikes.Add(bike);
			}
			foreach (SideProductModel side in sideProducts)
			{
				foreach (ImageModel image in side.Images)
				{
					ChangeImageToPlacehold(image);
				}
				side.Info = side.Name + " - " + side.Id;
				Bikes.Add(side);
			}
		}

        private void ChangeImageToPlacehold(ImageModel image)
        {
            if (image.Url == "")
            {
                image.Url = "bike_placeholder.png";
            }
            else
            {
                if (!IsImageUrl(image.Url))
                {
                    image.Url = "bike_placeholder.png";
                }
            }
        }

        public void ClearValues()
		{
			SelectedProduct = null;
			ProductSelected = false;
		}

		public void ShowDetails()
		{
			ProductSelected = true;
		}

		public void OnNavigatedTo()
		{
			ClearValues();
		}

		public async void GoToEdit(string bType, string sType)
		{
			if (bType == null && sType != null)
			{
				await _navigationService.NavigateToAsync("EditProduct", new Dictionary<string, object>
				{
					{
						"SideProduct", SelectedProduct.Id
					}
				});
			}
			else if (sType == null && bType != null)
			{
				await _navigationService.NavigateToAsync("EditShopBike", new Dictionary<string, object>
				{
					{
						"RepairBike", SelectedProduct.Id
					}
				});
			}
			else
			{
				ClearValues();
			}
		}
	}
}