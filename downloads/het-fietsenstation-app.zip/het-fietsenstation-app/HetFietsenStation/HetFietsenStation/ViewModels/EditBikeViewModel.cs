﻿using HetFietsenStation.Dtos.SideProduct;
using HetFietsenStation.Models;
using HetFietsenStation.Services.Bike;
using HetFietsenStation.Services.BikeColor;
using HetFietsenStation.Services.BikeCondition;
using HetFietsenStation.Services.BikeSource;
using HetFietsenStation.Services.BikeType;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.User;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;

namespace HetFietsenStation.ViewModels
{
    public partial class EditBikeViewModel : ViewModelBase, IQueryAttributable
    {
        //Declaration of all ValidatableObject strings
        public ValidatableObject<string> Brand { get; set; }
        public ValidatableObject<string> Model { get; set; }

        //Declaration of Images
        [ObservableProperty]
        ObservableCollection<string> images;

        //Declaration of all ValidatableObject ints
        public ValidatableObject<int> FrameNumber { get; set; }
        public ValidatableObject<int> FrameHeight { get; set; }
        public ValidatableObject<int> Price { get; set; }
        public ValidatableObject<int> SelectedBikeTypeIndex { get; set; }
        public ValidatableObject<int> SelectedBikeColorIndex { get; set; }
        public ValidatableObject<int> SelectedBikeConditionIndex { get; set; }
        public ValidatableObject<int> SelectedBikeSourceIndex { get; set; }
        public ValidatableObject<int> SelectedMechanicIndex { get; set; }

        //Declaration of the PhotoBike
        [ObservableProperty]
        BikeModel bike;

        //Declaration of the picker collections
        [ObservableProperty]
        ObservableCollection<BikeTypeModel> bikeTypes;
        [ObservableProperty]
        ObservableCollection<BikeColorModel> bikeColors;
        [ObservableProperty]
        ObservableCollection<BikeConditionModel> bikeConditions;
        [ObservableProperty]
        ObservableCollection<BikeSourceModel> bikeSources;
        [ObservableProperty]
        ObservableCollection<UserModel> users;

        //Declaration of the picker selection
        [ObservableProperty]
        BikeTypeModel selectedBikeType;
        [ObservableProperty]
        BikeColorModel selectedBikeColor;
        [ObservableProperty]
        BikeConditionModel selectedBikeCondition;
        [ObservableProperty]
        BikeSourceModel selectedBikeSource;
        [ObservableProperty]
        UserModel selectedMechanic;

        //Declaration of the selected color
        [ObservableProperty]
        Color selectedColor;

        //Declaration of the error handlers
        [ObservableProperty]
        bool wrongInputValues;
        [ObservableProperty]
        bool editBikeFailed;

        //Show entries for certain roles
        [ObservableProperty]
        bool salesPersonInvisible;
        [ObservableProperty]
        bool photographerInvisible;
        [ObservableProperty]
        bool mechanicInvisible;

        //Declaration of services
        IBikeService _bikeService;
        IBikeTypeService _bikeTypeService;
        IBikeColorService _bikeColorService;
        IBikeConditionService _bikeConditionService;
        IBikeSourceService _bikeSourceService;
        IUserService _userService;

        //Constructor which sets up the ViewModel to be used
        public EditBikeViewModel(IBikeService bikeService, IBikeTypeService bikeTypeService, IBikeColorService bikeColorService, IBikeConditionService bikeConditionService, IBikeSourceService bikeSourceService, IUserService userService, INavigationService navigationService, ISettingsService settingsService) : base(navigationService, settingsService)
        {
            _bikeService = bikeService;
            _bikeTypeService = bikeTypeService;
            _bikeColorService = bikeColorService;
            _bikeConditionService = bikeConditionService;
            _bikeSourceService = bikeSourceService;
            _userService = userService;

            InitializedData();

            AddValidations();
        }

        //Is fired when navigating to the page, clears all old data and fills the data with up date data
        public async void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            string bikeId = query.First().Value.ToString();

            await GetBike(bikeId);
        }

        //Initializes all class field with the default data
        private void InitializedData()
        {
            Title = "Bewerken fiets";

            Brand = new ValidatableObject<string>();
            Model = new ValidatableObject<string>();

            FrameNumber = new ValidatableObject<int>();
            FrameHeight = new ValidatableObject<int>();
            Price = new ValidatableObject<int>();
            SelectedBikeTypeIndex = new ValidatableObject<int>();
            SelectedBikeColorIndex = new ValidatableObject<int>();
            SelectedBikeSourceIndex = new ValidatableObject<int>();
            SelectedBikeConditionIndex = new ValidatableObject<int>();
            SelectedMechanicIndex = new ValidatableObject<int>();

            SelectedBikeTypeIndex.Value = -1;
            SelectedBikeColorIndex.Value = -1;
            SelectedBikeSourceIndex.Value = -1;
            SelectedBikeConditionIndex.Value = -1;
            SelectedMechanicIndex.Value = -1;

            BikeTypes = new ObservableCollection<BikeTypeModel>();
            BikeColors = new ObservableCollection<BikeColorModel>();
            BikeSources = new ObservableCollection<BikeSourceModel>();
            BikeConditions = new ObservableCollection<BikeConditionModel>();
            Users = new ObservableCollection<UserModel>();

            Images = new ObservableCollection<string>();
            EntryIsEnabled = true;
        }

        public async void ShowFields()
        {
            ResetVisibility();

            var users = await _userService.GetUsers();

            //show the edit field that are needed for the specific role and hide the fields that are not needed
            foreach (var user in users)
            {
                if (user.Id.ToString() == await SecureStorage.GetAsync("user_id"))
                {
                    if (user.UserRoleId == Enums.UserRole.Photographer || user.UserRoleId == Enums.UserRole.SalesPerson)
                    {
                        SalesPersonInvisible = false;
                        if (user.UserRoleId == Enums.UserRole.Photographer)
                        {
                            MechanicInvisible = false;
                            PhotographerInvisible = false;
                        }
                    }
                    else if (user.UserRoleId == Enums.UserRole.Mechanic)
                    {
                        MechanicInvisible = false;
                    }
                }
            }
        }

        //reset the visibility of the field of the edit bike page
        private void ResetVisibility()
        {
            SalesPersonInvisible = true;
            PhotographerInvisible = true;
            MechanicInvisible = true;
        }

        //Adds the rules to the ValidtableObjects
        private void AddValidations()
        {
            Brand.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul het merk in!" });
            Brand.Validations.Add(new DoesNotContainSpecialCharacters<string> { ValidationMessage = "Merk mag geen speciale karakters bezitten!" });
            Model.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul het model in!" });
            Model.Validations.Add(new DoesNotContainSpecialCharacters<string> { ValidationMessage = "Model mag geen speciale karakters bezitten!" });
            FrameNumber.Validations.Add(new IsNotNullOrEmptyIntRule<int> { ValidationMessage = "Vul het frame nummer in!" });
            FrameNumber.Validations.Add(new IsNotLowerThenOneRule<int> { ValidationMessage = "Frane nummer mag niet lager zijn dan 1!" });
            FrameHeight.Validations.Add(new IsNotNullOrEmptyIntRule<int> { ValidationMessage = "Vul de frame hoogte in!" });
            FrameHeight.Validations.Add(new IsNotLowerThenOneRule<int> { ValidationMessage = "Frame hoogte mag niet lager zijn dan 1!" });
            Price.Validations.Add(new IsNotNullOrEmptyIntRule<int> { ValidationMessage = "Vul de prijs in!" });
            Price.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Prijs kan niet negatief zijn!" });
            SelectedBikeColorIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een kleur!" });
            SelectedBikeTypeIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een type!" });
            SelectedBikeSourceIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies eem afkomst!" });
            SelectedBikeConditionIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een conditie!" });
        }

        //Return all data of the class fieldsto a default state
        public void ClearData()
        {
            Brand.Clear();
            Model.Clear();

            FrameNumber.Clear();
            FrameHeight.Clear();
            Price.Clear();
            SelectedBikeTypeIndex.Clear();
            SelectedBikeColorIndex.Clear();
            SelectedBikeSourceIndex.Clear();
            SelectedBikeConditionIndex.Clear();
            SelectedMechanicIndex.Clear();

            SelectedBikeTypeIndex.Value = -1;
            SelectedBikeColorIndex.Value = -1;
            SelectedBikeSourceIndex.Value = -1;
            SelectedBikeConditionIndex.Value = -1;
            SelectedMechanicIndex.Value = -1;

            BikeTypes.Clear();
            BikeColors.Clear();
            BikeSources.Clear();
            BikeConditions.Clear();
            Users.Clear();

            SelectedColor = Color.FromArgb("FFFFFF");

            WrongInputValues = false;
            EditBikeFailed = false;
        }

        //Is Fired when the selection of the color picker is changed ans sets the selected color according to the SelectedBikeColor and if empty returns it to the default data state
        public void ColorSelectionChanged()
        {
            if (SelectedBikeColorIndex.Value != -1)
            {
                SelectedColor = Color.FromArgb(SelectedBikeColor.HexCode);
            }
            else
            {
                SelectedColor = Color.FromArgb("FFFFFF");
            }
        }

        //get bike that belongs to id
        private async Task GetBike(string id)
        {
            //reset all the data for a new bike to be shown
            ClearData();

            //obtain all the bikes from the database
            IEnumerable<BikeModel> bikeModel = await _bikeService.GetAllBikes();

            //obtain the bike from the list by id
            Bike = bikeModel.First(b => b.Id == Convert.ToInt32(id));

            if (Bike != null)
            {
                Brand.Value = Bike.Brand;
                Model.Value = Bike.Model;
                FrameNumber.Value = Bike.FrameNumber;
                FrameHeight.Value = Bike.FrameHeight;
                Price.Value = Bike.Price;

                // Make the Images ObverableCollection based off Bike.Images' Url property.
                foreach (var currentBike in Bike.Images)
                {
                    Images.Add(currentBike.Url);
                }

                await GetBikeColors();
                await GetBikeTypes();
                await GetBikeConditions();
                await GetBikeSources();
                await GetMechanic();

                ShowFields();
            }
        }

        //check if image is valid
        bool IsImageUrl(string currentBike)
        {
            var extension = Path.GetExtension(currentBike);
            return !string.IsNullOrEmpty(extension) && (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".gif");
        }

        //Inserts the view related data into the Bike
        private void UpdatePhotoBikeField()
        {
            Bike.Brand = Brand.Value;
            Bike.Model = Model.Value;
            Bike.FrameHeight = FrameHeight.Value;
            Bike.FrameNumber = FrameNumber.Value;
            Bike.BikeType = SelectedBikeType;
            Bike.BikeColor = SelectedBikeColor;
            Bike.BikeSource = SelectedBikeSource;
            Bike.BikeCondition = SelectedBikeCondition;
            Bike.User = SelectedMechanic;
        }

        //Gets all BikeTypes and sets the SelectedBikeType
        private async Task GetBikeTypes()
        {
            await FetchAndSetData(_bikeTypeService.GetAllBikeTypes(), BikeTypes);
            
            SelectedBikeType = BikeTypes.First(bt => bt.Name == Bike.BikeType.Name);
        }

        //Gets all BikeColors and sets the SelectedBikeColor
        private async Task GetBikeColors()
        {
            await FetchAndSetData(_bikeColorService.GetAllBikeColors(), BikeColors);
            IEnumerable<BikeColorModel> bikeColorModels = await _bikeColorService.GetAllBikeColors();

            foreach (BikeColorModel bikeColor in bikeColorModels)
            {
                BikeColors.Add(bikeColor);
            }

            SelectedBikeColor = BikeColors.First(bc => bc.Name == Bike.BikeColor.Name);
        }

        //Gets all BikeSources and sets the SelectedBikeSource
        private async Task GetBikeSources()
        {
            await FetchAndSetData(_bikeSourceService.GetBikeSources(), BikeSources);
            
            SelectedBikeSource = BikeSources.First(bs => bs.Name == Bike.BikeSource.Name);
        }

        //Gets all BikeCondition and sets the SelectedBikeConditions
        private async Task GetBikeConditions()
        {
            await FetchAndSetData(_bikeConditionService.GetBikeConditions(), BikeConditions);

            SelectedBikeCondition = BikeConditions.First(bc => bc.Name == Bike.BikeCondition.Name);
        }

        //Gets all Mechanics and sets the SelectedBikecondition
        private async Task GetMechanic()
        {
            IEnumerable<UserModel> userModels = await _userService.GetUsers();

            foreach (UserModel user in userModels)
            {
                if (user.UserRoleId == Enums.UserRole.Mechanic)
                {
                    Users.Add(user);
                }
            }

            if (Bike.User.Id != 0)
            {
                SelectedMechanic = Users.First(u => u.Name == Bike.User.Name);
            }
        }

        //Is fired when button is clicked and checks if the data is right for the bike to be updated and if this is the case updates the bike
        [RelayCommand]
        public async Task EditBike()
        {
            List<IValidity> validations = new List<IValidity>
            {
                Brand,
                Model,
                FrameNumber,
                FrameHeight,
                SelectedBikeColorIndex,
                SelectedBikeConditionIndex,
                SelectedBikeTypeIndex,
                SelectedBikeSourceIndex
            };

            if (Validate(validations))
            {
                UpdatePhotoBikeField();

                WrongInputValues = false;

                if (SelectedMechanic == null)
                {
                    SelectedMechanic = new UserModel(0, "-", 0);
                }

                UpdateBikeDto photoBike = new UpdateBikeDto(Bike.Id, Brand.Value, Model.Value, Bike.Note, FrameNumber.Value, FrameHeight.Value, Price.Value, SelectedBikeType.Id, SelectedBikeColor.Id, SelectedBikeCondition.Id, SelectedBikeSource.Id, SelectedMechanic.Id);

                if (await _bikeService.UpdateBike(photoBike))
                {
                    EditBikeFailed = false;

                    await _navigationService.PopAsync(new Dictionary<string, object>
                    {
                        {
                            "Bike", Bike.Id
                        }
                    });

                    return;
                }

                EditBikeFailed = true;
            }
            else
            {
                WrongInputValues = true;
            }
        }

        [RelayCommand]
        public async Task<FileResult> PickAndShow(PickOptions options)
        {
            HideKeyboard();
            //resets the imageUrl value so that it will no longer show the current route
            try
            {
                //opens an filepicker and allows user to pick a file
                var result = await FilePicker.Default.PickAsync(options);
                //sees if the result is not null
                if (result != null)
                {
                    //checks if the file is an image file.
                    if (result.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase) ||
                        result.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
                    {
                        //creates a path to the appdatadirectory with the name of the fill
                        string localFilePath = Path.Combine(FileSystem.AppDataDirectory, result.FileName);
                        //opens a stream to see the file that has been selected
                        using var stream = await result.OpenReadAsync();
                        var imageUrl = ImageSource.FromStream(() => stream);
                        //saves the file
                        using FileStream localFileStream = File.OpenWrite(localFilePath);
                        //saves a copy of the file to the file path
                        await stream.CopyToAsync(localFileStream);

                        await _bikeService.AddBikeImage(Bike.Id, localFilePath);
                        // Combine the app data directory with the filename
                        Images.Add(localFilePath);
                    }
                }

                // always return result if it was able to
                return result;
            }
            catch
            {
                // The user canceled or something went wrong
            }

            return null;
        }

        [RelayCommand]
        public async Task OpenFile(string FileName)
        {
            // Get the full file path
            var fullPath = Path.Combine(FileSystem.AppDataDirectory, FileName);

            // Open the file using the appropriate platform function
            await Launcher.OpenAsync(new OpenFileRequest
            {
                File = new ReadOnlyFile(fullPath)
            });
        }

        [RelayCommand]
        public async Task<FileResult> CaptureAndSave()
        {
            HideKeyboard();
            //checks if the camera is supported to take a photo
            if (MediaPicker.Default.IsCaptureSupported)
            {
                //wait until the camera has taken a picture
                FileResult photo = await MediaPicker.Default.CapturePhotoAsync();

                //checks if the image is not empty
                if (photo != null)
                {
                    //changes path to path in data directory
                    string localFilePath = Path.Combine(FileSystem.AppDataDirectory, photo.FileName);

                    //reads the image that was taken
                    using Stream sourceStream = await photo.OpenReadAsync();
                    //writes the file to the file path
                    using FileStream localFileStream = File.OpenWrite(localFilePath);

                    //copies te image to the new file path
                    await sourceStream.CopyToAsync(localFileStream);

                    await _bikeService.AddBikeImage(Bike.Id, localFilePath);
                    Images.Add(photo.FileName);
                }
            }

            return null;
        }

        //delete the image from the database and then remove it from the view
        [RelayCommand]
        private async void DeleteImage(string image)
        {
            //await _bikeService.DeleteImage(image);

            Images.Remove(image);
        }

        [RelayCommand]
        public async void OpenImage(string image)
        {
            Uri uri = new Uri(image);
            await Browser.Default.OpenAsync(uri, BrowserLaunchMode.SystemPreferred);
        }
    }
}
