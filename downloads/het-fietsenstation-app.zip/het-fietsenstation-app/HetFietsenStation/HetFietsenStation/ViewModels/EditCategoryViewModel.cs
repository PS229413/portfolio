﻿using HetFietsenStation.Dtos.SideProductType;
using HetFietsenStation.Models;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.SideProductType;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;

namespace HetFietsenStation.ViewModels
{
    public partial class EditCategoryViewModel : ViewModelBase
    { 
        //Declaration of all ValidatableObject strings
        public ValidatableObject<string> EditDescription { get; set; }
        public ValidatableObject<string> EditName { get; set; }

        //Declaration of all ValidatableObject int
        public ValidatableObject<int> SelectedCategoryIndex { get; set; }

        //Declaration of the picker collection
        [ObservableProperty]
        ObservableCollection<SideProductTypeModel> category;

        //Declaration of the error handler
        [ObservableProperty]
        bool wrongInputValue;

        //Declaration of services
        ISideProductTypeService _sideProductTypeService;

        public EditCategoryViewModel(ISideProductTypeService sideProductTypeService, INavigationService navigationService, ISettingsService settingsService) : base(navigationService, settingsService)
        {
            _sideProductTypeService = sideProductTypeService;
            InitializedData();
            Addvalidations();
        }

        private void InitializedData()
        {
            Title = "Wijzig Category";

            EditDescription = new ValidatableObject<string>();
            EditName = new ValidatableObject<string>();

            SelectedCategoryIndex = new ValidatableObject<int>();

            Category = new ObservableCollection<SideProductTypeModel>();

            WrongInputValue = false;
            EntryIsEnabled = true;
        }

        public async void OnNavigatedTo()
        {
            ClearData();

            await GetTypes();
        }

        private void Addvalidations()
        {
            SelectedCategoryIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Selecteer een categorie" });
            EditName.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul een naam in" });
            EditDescription.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul een beschrijving in" });
        }

        private void ClearData()
        {
            EditDescription.Clear();
            EditName.Clear();

            SelectedCategoryIndex.Clear();
            SelectedCategoryIndex.Value = -1;

            WrongInputValue = false;
        }

        public void ChosenCategory()
        {
            //change the information of the entry values to the now selected category or reset the entry field
            if (SelectedCategoryIndex.Value != -1)
            {
                EditName.Value = Category[SelectedCategoryIndex.Value].Name;
                EditDescription.Value = Category[SelectedCategoryIndex.Value].Description;
            }
            else
            {
                EditName.Clear();
                EditDescription.Clear();
            }
        }

        private async Task GetTypes()
        {
            //obtain all the categories from the database
            Category.Clear();

            await FetchAndSetData(_sideProductTypeService.GetTypes(), Category);
        }

        [RelayCommand]
        public async Task EditType()
        {
            //make a list of all field that need to be validated
            List<IValidity> validations = new List<IValidity>()
            {
                EditDescription,
                EditName,
                SelectedCategoryIndex
            };

            HideKeyboard();

            //check if all the fields are filled in
            if (Validate(validations))
            {
                WrongInputValue = false;

                //update the category in the database and than reload the page
                UpdateSideProductTypeDto updateSideProductType = new UpdateSideProductTypeDto(Category[SelectedCategoryIndex.Value].Id, EditName.Value, EditDescription.Value);

                await _sideProductTypeService.UpdateType(updateSideProductType);

                ClearData();
                await GetTypes();
            }
            else
            {
                WrongInputValue = true;
            }
        }
    }
}
