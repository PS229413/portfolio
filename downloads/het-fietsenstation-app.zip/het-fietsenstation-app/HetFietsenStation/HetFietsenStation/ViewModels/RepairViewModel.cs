﻿using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.RepairStep;
using HetFietsenStation.Services.BikeRepairStep;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;
using HetFietsenStation.Dtos.BikeRepairStep;

namespace HetFietsenStation.ViewModels
{
    //ViewModel which contains the logic of the RepairView
    public partial class RepairViewModel : ViewModelBase, IQueryAttributable
    {
        //List containing all required RepairSteps
        [ObservableProperty]
        ObservableCollection<RepairStepModel> requiredRepairSteps;
        //List containing all optional RepairSteps
        [ObservableProperty]
        ObservableCollection<RepairStepModel> optionalRepairSteps;
        
        //String containing the Price of the bike
        public ValidatableObject<int> Price { get; private set; }

        //Int containg the bike id of the current bike
        [ObservableProperty]
        RepairBikeModel repairBike;

        //Bool containg wether or not the Price can be filled or not and the Confirm button is activated or not
        [ObservableProperty]
        bool requiredRepairStepsDone;

        //Bool containg wether or not the update was succesful
        [ObservableProperty]
        bool updateFailed;

        //Bool containg wether or not the update was succesful
        [ObservableProperty]
        bool doesRepairStepNotExist;

        //Services used by the ViewModel
        IBikeRepairStepService _bikeRepairStepService;
        IRepairStepService _repairStepService;

        //Constructor of the ViewModel which injects the services needed for the ViewModel
        public RepairViewModel(IBikeRepairStepService bikeRepairStepService, IRepairStepService repairStepService, 
            INavigationService navigationService, ISettingsService settingsService) 
            : base(navigationService, settingsService)
        {
            //Defines the title of the View
            Title = "Fiets reparatie";
            //Sets empty lists
            RequiredRepairSteps = new ObservableCollection<RepairStepModel>();
            OptionalRepairSteps = new ObservableCollection<RepairStepModel>();
            //Sets empty string
            Price = new ValidatableObject<int>();
            //Sets the default PriceReady to false
            RequiredRepairStepsDone = false;
            //Sets the default UpdateFailed to false
            UpdateFailed = false;
            doesRepairStepNotExist = false;

            EntryIsEnabled = true;
            //Sets injected services
            _bikeRepairStepService = bikeRepairStepService;
            _repairStepService = repairStepService;
            //Call to the function which sets the validations
            AddValidations();
        }

        public void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            RepairBike = (RepairBikeModel)query[nameof(RepairBike)];
        }

        //Function which loads all RepairSteps
        public async Task NavigatedTo()
        {
            //Makes sure the lists are empty when navigated to this page
            RequiredRepairSteps = new ObservableCollection<RepairStepModel>();
            OptionalRepairSteps = new ObservableCollection<RepairStepModel>();

            Price.Value = 0;

            //Function which laods all RepairSteps
            await LoadRepairSteps(RepairBike.Id);
        }

        public async Task<bool> LoadRepairSteps(int repairBikeId)
        {
            try
            {
                //Gets all RepairSteps from the RepairBikeService and define them as a IEnumerable List
                IEnumerable<GetBikeRepairStepDto> repairStepsDtos = await _repairStepService.GetRepairSteps(repairBikeId);
                //Returns false if GetRepairSteps returned null
                if (repairStepsDtos == null)
                {
                    return false;
                }
                //Creates a empty List of RepairStepModels
                List<RepairStepModel> repairSteps = new List<RepairStepModel>();
                //Converts all GetBikeRepairStepModelDto's into RepairStepModels and adds them to the repairSteps List
                foreach (GetBikeRepairStepDto bikeRepairStepDto in repairStepsDtos)
                {
                    repairSteps.Add(new RepairStepModel(bikeRepairStepDto.RepairStep, bikeRepairStepDto.Done));
                }

                //Filters the repairSteps into Required and Optional RepairSteps using the Rquired bool
                foreach (RepairStepModel repairStep in repairSteps)
                {
                    if (repairStep.Required)
                    {
                        RequiredRepairSteps.Add(repairStep);
                    }
                    else
                    {
                        OptionalRepairSteps.Add(repairStep);
                    }
                }

                //Calls the function which checks if all RequiredRepairSteps have been Done
                RequiredRepairStepsDone = RequiredRepairSteps.All(rrs => rrs.Done == true);
                return true;
            }
            catch 
            {
                return false;
            }
        }

        //Function which sets the RepairStep's Done field to true or false depending on the old value
        [RelayCommand]
        public async Task UpdateRepairStepChecked(int repairStepId)
        {
            if (repairStepId != 0)
            {
                DoesRepairStepNotExist = false;

                ObservableCollection<RepairStepModel> repairSteps = CombineObservableCollections(RequiredRepairSteps, OptionalRepairSteps);
                //Gets the first RepairStep from the ObservableCollection which Id is equal to repairStepId
                RepairStepModel currentRepairStep = repairSteps.Where(rrs => rrs.Id == repairStepId).First();

                //Changes the Done field to false if the previous value was true or to true if the previous value was false
                currentRepairStep.Done = !currentRepairStep.Done;

                UpdateBikeRepairStepDto updatedBikeRepairStep = new UpdateBikeRepairStepDto(RepairBike.Id, currentRepairStep.Id, currentRepairStep.Done);

                if (await _bikeRepairStepService.UpdateBikeRepairStep(updatedBikeRepairStep))
                {
                    UpdateFailed = false;

                    RequiredRepairStepsDone = RequiredRepairSteps.All(rrs => rrs.Done == true);
                }
                else 
                {
                    UpdateFailed = true;

                    currentRepairStep.Done = !currentRepairStep.Done;
                }
            }
            else 
            {
                DoesRepairStepNotExist = true;
            }
        }

        //Function which combines 2 ObservableCollections of type RepairStepModel
        public ObservableCollection<RepairStepModel> CombineObservableCollections(ObservableCollection<RepairStepModel> collection1, ObservableCollection<RepairStepModel> collection2) 
        {
            //Creates a List which will contain the combined ObservableCollections
            ObservableCollection<RepairStepModel> combinedCollection = new ObservableCollection<RepairStepModel>();

            //Adds all RepairStepModels from ObservableCollection 1 to the combined ObservableCollection
            foreach (RepairStepModel item in collection1) combinedCollection.Add(item);
            //Adds all RepairStepModels from ObservableCollection 2 to the combined ObservableCollection
            foreach (RepairStepModel item in collection2) combinedCollection.Add(item);

            //Returns the combinedCollection
            return combinedCollection;
        }

        //Function which checks called via the view to check if all fields in the view are valid
        [RelayCommand]
        private async Task GoToConcludeRepair()
        {
            HideKeyboard();
            //Checks if the Price field is valid
            if (Price.Validate())
            {
                RepairBike.RepairSteps = CombineObservableCollections(RequiredRepairSteps, OptionalRepairSteps).ToList();
                PhotographBikeModel photographBike = new PhotographBikeModel(RepairBike, Price.Value);

                await _navigationService.NavigateToAsync("ConcludeRepair", new Dictionary<string, object> { { "PhotographBike", photographBike } });
            }
        }

        //Adds the types of validations for the fields in the view
        private void AddValidations()
        {
            //Adds a not null or empty validation to the Price field which checks if the field is not null or empty
            Price.Validations.Add(new IsNotNullOrEmptyIntRule<int> { ValidationMessage = "Vul de prijs in!" });
            Price.Validations.Add(new IsNotLowerThenOneRule<int> { ValidationMessage = "De prijs moet positief zijn!" });
        }
    }
}
