﻿using HetFietsenStation.Dtos.RepairBike;
using HetFietsenStation.Services.BikeColor;
using HetFietsenStation.Services.BikeCondition;
using HetFietsenStation.Services.BikeSource;
using HetFietsenStation.Services.BikeType;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.RepairBike;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;

namespace HetFietsenStation.ViewModels
{
    public partial class AddBikeViewModel : ViewModelBase
    {
        //Declaration of all ValidatableObject strings
        public ValidatableObject<string> Brand { get; set; }
        public ValidatableObject<string> Model { get; set; }
        public ValidatableObject<int> FrameNumber { get; set; }
        public ValidatableObject<int> FrameHeight { get; set; }
        //Declaration of all ValidatableObject ints
        public ValidatableObject<int> SelectedBikeTypeIndex { get; set; }
        public ValidatableObject<int> SelectedBikeColorIndex { get; set; }
        public ValidatableObject<int> SelectedBikeConditionIndex { get; set; }
        public ValidatableObject<int> SelectedBikeSourceIndex { get; set; }

        //Declaration of the picker collections
        [ObservableProperty]
        ObservableCollection<BikeTypeModel> bikeTypes;
        [ObservableProperty]
        ObservableCollection<BikeColorModel> bikeColors;
        [ObservableProperty]
        ObservableCollection<BikeConditionModel> bikeConditions;
        [ObservableProperty]
        ObservableCollection<BikeSourceModel> bikeSources;

        //Declaration of the picker selection
        [ObservableProperty]
        BikeTypeModel selectedBikeType;
        [ObservableProperty]
        BikeColorModel selectedBikeColor;
        [ObservableProperty]
        BikeConditionModel selectedBikeCondition;
        [ObservableProperty]
        BikeSourceModel selectedBikeSource;

        //Declaration of the SelectedColor Color
        [ObservableProperty]
        Color selectedColor;

        //Declaration of Images
        [ObservableProperty]
        ObservableCollection<string> images;

        //Declaration of the error handlers
        [ObservableProperty]
        bool wrongInputValues;
        [ObservableProperty]
        bool addBikeFailed;

        //Delcarations of the services
        IRepairBikeService _repairBikeService { get; set; }
        IBikeTypeService _BikeTypeService { get; set; }
        IBikeColorService _BikeColorService { get; set; }
        IBikeConditionService _BikeConditionService { get; set; }
        IBikeSourceService _BikeSourceService { get; set; }

        //Constructor which sets up the ViewModel to be used
        public AddBikeViewModel(IRepairBikeService repairBikeService, IBikeTypeService bikeTypeService,
            IBikeColorService bikeColorService, IBikeConditionService bikeConditionService,
            IBikeSourceService bikeSourceService, INavigationService navigationService,
            ISettingsService settingsService)
            : base(navigationService, settingsService)
        {
            _repairBikeService = repairBikeService;
            _BikeTypeService = bikeTypeService;
            _BikeColorService = bikeColorService;
            _BikeConditionService = bikeConditionService;
            _BikeSourceService = bikeSourceService;

            InitializeData();

            AddValidations();
        }

        //Is fired when navigating to the page, clears all old data and fills the data with up to date data
        public async void OnNavigatedTo()
        {
            ClearData();

            await GetBikeTypes();
            await GetBikeColors();
            await GetBikeConditions();
            await GetBikeSources();
        }

        //Initializes all class fields with default data
        private void InitializeData()
        {
            Title = "Fiets toevoegen";

            Brand = new ValidatableObject<string>();
            Model = new ValidatableObject<string>();
            //Images = new ValidatableObject<List<ImageModel>>();
            FrameNumber = new ValidatableObject<int>();
            FrameHeight = new ValidatableObject<int>();

            SelectedBikeTypeIndex = new ValidatableObject<int>();
            SelectedBikeColorIndex = new ValidatableObject<int>();
            SelectedBikeConditionIndex = new ValidatableObject<int>();
            SelectedBikeSourceIndex = new ValidatableObject<int>();

            SelectedBikeTypeIndex.Value = -1;
            SelectedBikeColorIndex.Value = -1;
            SelectedBikeConditionIndex.Value = -1;
            SelectedBikeSourceIndex.Value = -1;

            BikeTypes = new ObservableCollection<BikeTypeModel>();
            BikeColors = new ObservableCollection<BikeColorModel>();
            BikeConditions = new ObservableCollection<BikeConditionModel>();
            BikeSources = new ObservableCollection<BikeSourceModel>();

            SelectedColor = Color.FromArgb("#FFFFFF");

            WrongInputValues = false;
            //AddBikeFailed = false;

            Images = new ObservableCollection<string>();
            EntryIsEnabled = true;
        }

        //Adds the rules to the ValidatableObjects
        private void AddValidations()
        {
            Brand.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul het merk in!" });
            Brand.Validations.Add(new DoesNotContainSpecialCharacters<string> { ValidationMessage = "Merk mag geen speciale karakters bezitten!" });
            Model.Validations.Add(new IsNotNullOrEmptyStringRule<string> { ValidationMessage = "Vul het model in!" });
            Model.Validations.Add(new DoesNotContainSpecialCharacters<string> { ValidationMessage = "Model mag geen speciale karakters bezitten!" });
            FrameNumber.Validations.Add(new IsNotNullOrEmptyIntRule<int> { ValidationMessage = "Vul het frame nummer in!" });
            FrameNumber.Validations.Add(new IsNotLowerThenOneRule<int> { ValidationMessage = "Frame nummer mag niet lager zijn dan 0!" });
            FrameHeight.Validations.Add(new IsNotNullOrEmptyIntRule<int> { ValidationMessage = "Vul de frame hoogte in!" });
            FrameHeight.Validations.Add(new IsNotLowerThenOneRule<int> { ValidationMessage = "Frame hoogte mag niet lager zijn dan 0!" });
            SelectedBikeTypeIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een type!" });
            SelectedBikeColorIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een kleur!" });
            SelectedBikeConditionIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een staat!" });
            SelectedBikeSourceIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Kies een afkomst!" });
        }

        //Returns all data of the class fields to a default state
        private void ClearData()
        {
            Brand.Clear();
            Model.Clear();
            //ImageUrl.Clear();
            FrameNumber.Clear();
            FrameHeight.Clear();
            BikeTypes.Clear();

            SelectedBikeTypeIndex.Clear();
            SelectedBikeColorIndex.Clear();
            SelectedBikeConditionIndex.Clear();
            SelectedBikeSourceIndex.Clear();

            SelectedBikeTypeIndex.Value = -1;
            SelectedBikeColorIndex.Value = -1;
            SelectedBikeConditionIndex.Value = -1;
            SelectedBikeSourceIndex.Value = -1;

            BikeTypes.Clear();
            BikeColors.Clear();
            BikeConditions.Clear();
            BikeSources.Clear();

            SelectedColor = Color.FromArgb("#FFFFFF");

            WrongInputValues = false;
            //AddBikeFailed = false;
        }

        //Gets all BikeTypes and sets the SelectedBikeType
        public async Task GetBikeTypes()
        {
            await FetchAndSetData(_BikeTypeService.GetAllBikeTypes(), BikeTypes);
        }

        //Gets all BikeColors and sets the SelectedBikeColor
        public async Task GetBikeColors()
        {
            await FetchAndSetData(_BikeColorService.GetAllBikeColors(), BikeColors);
        }

        //Gets all BikeConditions and sets the SelectedBikeCondition
        public async Task GetBikeConditions()
        {
            await FetchAndSetData(_BikeConditionService.GetBikeConditions(), BikeConditions);
        }

        //Gets all BikeSources and sets the SelectedBikeSource
        public async Task GetBikeSources()
        {
            await FetchAndSetData(_BikeSourceService.GetBikeSources(), BikeSources);
        }

        //Is fired when button is clicked and checks if the data is right for the bike to be added and if this is the case adds the bike
        [RelayCommand]
        public async Task AddBike()
        {
            HideKeyboard();
            List<IValidity> validations = new List<IValidity>()
            {
                Brand,
                Model,
                //ImageUrl,
                FrameNumber,
                FrameHeight,
                SelectedBikeTypeIndex,
                SelectedBikeColorIndex,
                SelectedBikeConditionIndex,
                SelectedBikeSourceIndex
            };

            if (Validate(validations))
            {
                WrongInputValues = false;

                AddRepairBikeDto repairBike = new AddRepairBikeDto(Brand.Value, Model.Value, FrameNumber.Value,
                    FrameHeight.Value, SelectedBikeType.Id, SelectedBikeColor.Id, SelectedBikeCondition.Id, SelectedBikeSource.Id);

                if (await _repairBikeService.AddRepairBike(repairBike, Images.ToList()))
                {
                    //AddBikeFailed = false;

                    await _navigationService.PopAsync();

                    return;
                }

                //AddBikeFailed = true;
            }
            else
            {
                WrongInputValues = true;
            }
        }

        //Is fired when the selection of the color picker is changed and sets the selected color according to the SelectedBikeColor and if empty returns it to the default data state
        public void ColorSelectionChanged()
        {
            if (SelectedBikeColor != null)
            {
                SelectedColor = Color.FromArgb(SelectedBikeColor.HexCode);
            }
            else
            {
                SelectedColor = Color.FromArgb("#FFFFFF");
            }
        }

        [RelayCommand]
        public async Task<FileResult> PickAndShow(PickOptions options)
        {
            HideKeyboard();
            //resets the imageUrl value so that it will no longer show the current route
            try
            {
                //opens an filepicker and allows user to pick a file
                var result = await FilePicker.Default.PickAsync(options);
                //sees if the result is not null
                if (result != null)
                {
                    //checks if the file is an image file.
                    if (result.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase) ||
                        result.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
                    {
                        //creates a path to the appdatadirectory with the name of the fill
                        string localFilePath = Path.Combine(FileSystem.AppDataDirectory, result.FileName);
                        //opens a stream to see the file that has been selected
                        using var stream = await result.OpenReadAsync();
                        var imageUrl = ImageSource.FromStream(() => stream);
                        //saves the file
                        using FileStream localFileStream = File.OpenWrite(localFilePath);
                        //saves a copy of the file to the file path
                        await stream.CopyToAsync(localFileStream);

                        // Combine the app data directory with the filename
                        Images.Add(localFilePath);
                    }
                }

                // always return result if it was able to
                return result;
            }
            catch
            {
                // The user canceled or something went wrong
            }

            return null;
        }

        [RelayCommand]
        public async Task OpenFile(string FileName)
        {
            // Get the full file path
            var fullPath = Path.Combine(FileSystem.AppDataDirectory, FileName);

            // Open the file using the appropriate platform function
            await Launcher.OpenAsync(new OpenFileRequest
            {
                File = new ReadOnlyFile(fullPath)
            });
        }

        [RelayCommand]
        public async Task<FileResult> CaptureAndSave()
        {
            HideKeyboard();
            //checks if the camera is supported to take a photo
            if (MediaPicker.Default.IsCaptureSupported)
            {
                //wait until the camera has taken a picture
                FileResult photo = await MediaPicker.Default.CapturePhotoAsync();

                //checks if the image is not empty
                if (photo != null)
                {
                    //changes path to path in data directory
                    string localFilePath = Path.Combine(FileSystem.AppDataDirectory, photo.FileName);

                    //reads the image that was taken
                    using Stream sourceStream = await photo.OpenReadAsync();
                    //writes the file to the file path
                    using FileStream localFileStream = File.OpenWrite(localFilePath);

                    //copies te image to the new file path
                    await sourceStream.CopyToAsync(localFileStream);

                    Images.Add(photo.FileName);
                }
            }

            return null;
        }
    }
}