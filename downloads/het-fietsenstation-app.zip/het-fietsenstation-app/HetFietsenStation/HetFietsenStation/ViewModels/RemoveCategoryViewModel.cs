﻿using HetFietsenStation.Models;
using HetFietsenStation.Dtos.SideProductType;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.SideProductType;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;

namespace HetFietsenStation.ViewModels
{
    public partial class RemoveCategoryViewModel : ViewModelBase
    {
        //Declaration of all ValidatableObject int
        public ValidatableObject<int> SelectedCategoryIndex { get; set; }

        //Declaration of the picker collection
        [ObservableProperty]
        ObservableCollection<SideProductTypeModel> category;

        //Declaration of the error handler
        [ObservableProperty]
        bool wrongInputValues;

        //Declaration of service
        ISideProductTypeService _sideProductTypeService;
        
        public RemoveCategoryViewModel(ISideProductTypeService sideProductTypeService, INavigationService navigationService, ISettingsService settingsService) : base(navigationService, settingsService)
        {
            _sideProductTypeService = sideProductTypeService;
            InitializedData();
            Validations();
            
            Title = "Categorie Verwijderen";
        }

        private void InitializedData()
        {
            SelectedCategoryIndex = new ValidatableObject<int> ();

            Category = new ObservableCollection<SideProductTypeModel>();

            WrongInputValues = false;
        }

        private void Validations()
        {
            SelectedCategoryIndex.Validations.Add(new IsNotLowerThenZeroRule<int> { ValidationMessage = "Selecteer een categorie" });
        }

        private void ClearData()
        {
            SelectedCategoryIndex.Clear();

            Category.Clear();

            WrongInputValues = false;
        }

        public async Task GetTypes()
        {
            Category.Clear();

            await FetchAndSetData(_sideProductTypeService.GetTypes(), Category);
        }

        public async void OnNavigatedTo()
        {
            ClearData();

            await GetTypes();
        }

        [RelayCommand]
        public async Task RemoveType()
        {
            List<IValidity> validations = new List<IValidity>()
            {
                SelectedCategoryIndex
            };

            if (Validate(validations))
            {
                WrongInputValues = false;

                //send the id of the category to the api so that it knows what to delete
                DeleteSideProductTypeDto deleteSideProductType = new DeleteSideProductTypeDto(Category[SelectedCategoryIndex.Value].Id);

                await _sideProductTypeService.DeleteType(deleteSideProductType);

                ClearData();
                await GetTypes();
            }
            else
            {
                WrongInputValues = true;
            }
        }
    }
}
