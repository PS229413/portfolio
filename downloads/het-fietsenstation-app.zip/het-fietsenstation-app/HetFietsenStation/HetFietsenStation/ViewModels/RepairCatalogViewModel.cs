﻿using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.RepairBike;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;
using HetFietsenStation.Validations;
using System.Collections.ObjectModel;
using HetFietsenStation.Services.BikeType;

namespace HetFietsenStation.ViewModels
{
    public partial class RepairCatalogViewModel : ViewModelBase
    {
        public ValidatableObject<int?> SearchBikeValue { get; set; }

        public ObservableCollection<RepairBikeModel> _allRepairBikes;

        [ObservableProperty]
        ObservableCollection<RepairBikeModel> repairBikes;
        [ObservableProperty]
        ObservableCollection<BikeTypeModel> bikeTypes;

        [ObservableProperty]
        BikeTypeModel selectedBikeType;

        [ObservableProperty]
        string[] heightsOptions;

        [ObservableProperty]
        string selectedPriceOption;
        [ObservableProperty]
        string selectedHeightOption;

        IRepairBikeService _repairBikeService;
        IBikeTypeService _bikeTypeService;

        public RepairCatalogViewModel(IRepairBikeService repairBikeService, IBikeTypeService bikeTypeService, INavigationService navigationService, ISettingsService settingsService) 
            : base(navigationService, settingsService)
        {
            Title = "Reparatie catalogus";

            SearchBikeValue = new ValidatableObject<int?>();

            RepairBikes = new ObservableCollection<RepairBikeModel>();
            BikeTypes = new ObservableCollection<BikeTypeModel>();

            _repairBikeService = repairBikeService;
            _bikeTypeService = bikeTypeService;

            HeightsOptions = new string[]
{
                "Minder dan 50",
                "50 - 55",
                "55 - 60",
                "60 - 65",
                "Meer dan 65"
};

            EntryIsEnabled = true;

            AddValidations();
            LoadFilterOptions();
        }

        private void AddValidations()
        {
            SearchBikeValue.Validations.Add(new IsNotNullOrEmptyIntRule<int?> { ValidationMessage = "Vul het zoek vlak in!" });
        }

        [RelayCommand]
        async Task ToRepairBikeDetails(int repairBikeId) 
        {
            //obtain the first bike from the bikes collection who's id is equal to the id that was sent with the information to the page
            RepairBikeModel currentRepairBike = RepairBikes.First(rb => rb.Id == repairBikeId);

            await _navigationService.NavigateToAsync("RepairBikeDetails", new Dictionary<string, object> 
            { 
                { 
                    "RepairBike", currentRepairBike 
                } 
            });
        }

        public void ClearFilter()
        {
            SelectedBikeType = null;
            SelectedHeightOption = null;
        }

        public async void LoadFilterOptions()
        {
            //load the bike types from the database
            await FetchAndSetData(_bikeTypeService.GetAllBikeTypes(), BikeTypes);
        }

        [RelayCommand]
        public async Task SearchBike()
        {
            HideKeyboard();
            // Validate the SearchBikeValue input
            SearchBikeValue.Validate();

            // Clear the RepairBikes collection from the View
            RepairBikes.Clear();

            // Check if the SearchBikeValue input is null or 0
            if (SearchBikeValue.Value == null || SearchBikeValue.Value == 0)
            {
                // If the SearchBikeValue input is null or 0, then get all repair bikes
                await GetRepairBikes();
            }
            else 
            {
                /* If the SearchBikeValue input is not null or 0,
                 get a specific RepairBike based on the input value */
                RepairBikeModel repairBike = await _repairBikeService.GetRepairBike((int)SearchBikeValue.Value);

                // Check if a repair bike was found
                if (repairBike != null)
                {
                    foreach (ImageModel image in repairBike.Images)
                    {

                    }
                    // If a repair bike was found, add it to the RepairBikes collection and show to the View
                    RepairBikes.Add(repairBike);
                }
            }
        }

        public async Task ProductFilter()
        {
            // Retrieve bikes and products
            IEnumerable<RepairBikeModel> bikeModels = await _repairBikeService.GetAllRepairBikes();

            int maxHeight = 1000000;
            int minHeight = 0;

            RepairBikes.Clear();

            switch (SelectedHeightOption)
            {
                case "Minder dan 50":
                    maxHeight = 50;
                    break;
                case "50 - 55":
                    minHeight = 50;
                    maxHeight = 56;
                    break;
                case "55 - 60":
                    minHeight = 55;
                    maxHeight = 61;
                    break;
                case "60 - 65":
                    minHeight = 60;
                    maxHeight = 66;
                    break;
                case "Meer dan 65":
                    minHeight = 65;
                    break;
                default:
                    break;
            }

            // Add products to the Products collection if there are any
            foreach (RepairBikeModel bike in bikeModels)
            {
                if (SelectedBikeType == null || SelectedBikeType.Name == bike.BikeType.Name)
                {
                    if (SelectedHeightOption == "" || (minHeight <= bike.FrameHeight && bike.FrameHeight < maxHeight))
                    {
                        foreach (ImageModel image in bike.Images)
                        {
                            ChangeImageToPlacehold(image);
                        }
                        RepairBikes.Add(bike);
                    }
                }
            }
            SelectedBikeType = null;
            SelectedHeightOption = null;
            SelectedPriceOption = null;
        }

        public void OnSearchTextChanged(string searchText)
        {
            // Check if the _allRepairBikes collection has been initialized
            if (_allRepairBikes == null)
            {
                // Initialize the _allRepairBikes collection with a copy of the RepairBikes collection
                _allRepairBikes = new ObservableCollection<RepairBikeModel>(RepairBikes.ToList());
            }

            // Clear the RepairBikes collection from the View
            RepairBikes.Clear();

            // Check if the search text is empty or null
            if (string.IsNullOrEmpty(searchText))
            {
                /* If the search text is empty or null, 
                reset the RepairBikes collection to its original state */
                foreach (var bike in _allRepairBikes)
                {
                    foreach (ImageModel image in bike.Images)
                    {

                    }
                    RepairBikes.Add(bike);
                }

                // Clear SearchBox
                SearchBikeValue.Clear();
            }
            else
            {
                // Try to parse the search text as an integer
                int searchId;
                if (int.TryParse(searchText, out searchId))
                {
                    /* If the search text can be parsed as an integer,
                       filter the _allRepairBikes collection based on the bike Ids that start with the search text */
                    var repairBikes = _allRepairBikes.Where(b => b.Id.ToString().StartsWith(searchText));

                    // Check if any bikes were found
                    if (repairBikes != null)
                    {
                        // Add the found bikes to the RepairBikes collection to show in the View
                        foreach (var bike in repairBikes)
                        {
                            foreach (ImageModel image in bike.Images)
                            {
                                ChangeImageToPlacehold(image);
                            }
                           RepairBikes.Add(bike);
                        }
                    }
                }
            }
        }

        private void ChangeImageToPlacehold(ImageModel image)
        {
            if (image.Url == "")
            {
                image.Url = "bike_placeholder.png";
            }
            else
            {
                if (!IsImageUrl(image.Url))
                {
                    image.Url = "bike_placeholder";
                }
            }
        }

        [RelayCommand]
        async Task ToAddBike() 
        {
            HideKeyboard();
            await _navigationService.NavigateToAsync("AddBike");
        }

        public async Task GetRepairBikes()
        {
            ClearValues();

            //obtain all the bikes that still need to be repaired
            IEnumerable<RepairBikeModel> repairBikeModels = await _repairBikeService.GetAllRepairBikes();

            if (repairBikeModels != null)
            {
                foreach (RepairBikeModel repairBike in repairBikeModels)
                {
                    foreach (ImageModel image in repairBike.Images)
                    {
                        ChangeImageToPlacehold(image);
                    }
                    RepairBikes.Add(repairBike);
                }
            }
        }

        bool IsImageUrl(string currentBike)
        {
            var extension = Path.GetExtension(currentBike);
            return !string.IsNullOrEmpty(extension) && (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".gif");
        }

        private void ClearValues() 
        {
            RepairBikes.Clear();

            SearchBikeValue.Value = null;
        }
    }
}
