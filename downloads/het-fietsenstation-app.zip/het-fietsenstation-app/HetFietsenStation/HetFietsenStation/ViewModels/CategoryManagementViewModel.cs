﻿using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;

namespace HetFietsenStation.ViewModels
{
    public partial class CategoryManagementViewModel : ViewModelBase
    {
        public CategoryManagementViewModel(INavigationService navigationService, ISettingsService settingsService) 
            : base(navigationService, settingsService)
        {
            Title = "Categorie Beheren";
        }
    }
}