﻿using HetFietsenStation.Models;
using HetFietsenStation.Services.Bike;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Services.SideProduct;
using HetFietsenStation.Validations;
using Newtonsoft.Json;

namespace HetFietsenStation.ViewModels
{
    public partial class ProductDetailsViewModel : ViewModelBase, IQueryAttributable
    {
        public ValidatableObject<string> ImageUrl { get; set; }

        [ObservableProperty]
        ProductModel product;

        [ObservableProperty]
        List<ShoppingCartModel> shoppingCart;

        ISideProductService sideProductService;
        IBikeService bikeService;

        public ProductDetailsViewModel(INavigationService navigationService, ISettingsService settingsService, ISideProductService _sideProductService, IBikeService _bikeService) 
            : base(navigationService, settingsService)
        {
            Title = "Product Details";
            Product = new ProductModel();

            ImageUrl = new ValidatableObject<string>();

            ShoppingCart = new List<ShoppingCartModel>();

            sideProductService = _sideProductService;
            bikeService = _bikeService;
        }

        public void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            ShoppingCart.Clear();
            Product = new ProductModel();
            Product = (ProductModel)query["Product"];
        }

        bool IsImageUrl()
        {
            //check if the image is valid and exists
            var extension = Path.GetExtension(Product.Images[0].Url);
            return !string.IsNullOrEmpty(extension) && (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".gif");
        }

        public async Task ToEditProduct(string productId)
        {
            await _navigationService.NavigateToAsync("EditProduct", new Dictionary<string, object>
            {
                {
                    "SideProduct", productId
                }
            });
        }

        public async Task ToEditBike(string bikeId)
        {
            await _navigationService.NavigateToAsync("EditShopBike", new Dictionary<string, object>
            {
                {
                    "RepairBike", bikeId
                }
            });
        }

        public async Task SaveProductToSecureStorage()
        {
            var serializedProducts = JsonConvert.SerializeObject(ShoppingCart);
            await SecureStorage.SetAsync("ShoppingCart", serializedProducts);
        }

        public async Task LoadProductToList()
        {
            var serializedProducts = await SecureStorage.GetAsync("ShoppingCart");
            ShoppingCart = JsonConvert.DeserializeObject<List<ShoppingCartModel>>(serializedProducts);
        }

        public async Task AddProductToList(bool isProduct)
        {
            if (!isProduct)
            {
                ShoppingCart.Add(new ShoppingCartModel(Product.Id, "bike"));
            }
            else
            {
                ShoppingCart.Add(new ShoppingCartModel(Product.Id, "sideproduct"));
            }
        }

        public async Task AddToShoppingCart(bool isProduct)
        {
            await LoadProductToList();
            await AddProductToList(isProduct);
            await SaveProductToSecureStorage();
        }

        [RelayCommand]
        public async void ToShoppingCart()
        {
            await _navigationService.NavigateToAsync("ShoppingCart");
        }
    }
}