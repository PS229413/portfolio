﻿namespace HetFietsenStation.Enums
{
    public enum UserRole
    {
        Mechanic = 1,
        Admin = 2,
        Photographer = 3,
        SalesPerson = 4
    }
}