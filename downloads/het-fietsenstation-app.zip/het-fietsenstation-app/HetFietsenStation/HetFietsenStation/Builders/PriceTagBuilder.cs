﻿using Syncfusion.Drawing;
using Syncfusion.Pdf;
using Syncfusion.Pdf.Graphics;
using Color = Syncfusion.Drawing.Color;
using PointF = Syncfusion.Drawing.PointF;
using SizeF = Syncfusion.Drawing.SizeF;
using HetFietsenStation.Models;
using HetFietsenStation.Services;
using System.Reflection;

//using AppKit;

namespace HetFietsenStation.Builders
{
    public static class PriceTagBuilder
    {
        // this code makes bounds for the text used in notes so it doent get printed in one straight line
        static RectangleF TotalPriceCellBounds = RectangleF.Empty;
        static RectangleF QuantityCellBounds = RectangleF.Empty;

        public static async void Build(PhotographBikeModel photographBike) 
        {
            float price = photographBike.Price;
            int frameHeight = photographBike.FrameHeight;
            string Type = photographBike.BikeType.Name;
            string monteur = photographBike.Mechanic.Name;
            DateTime date = DateTime.Now;
            string description = photographBike.Note;

            //this code checks if note is less then 450 words and if so shortens it to 450
            if (description.Length > 450 && description.Length < 1)
            {
                description = description.Substring(0, 450);
            }

            //this code makes a new document and page
            PdfDocument document = new();
            document.PageSettings.Margins.All = 0;
            PdfPage page = document.Pages.Add();
            PdfGraphics graphics = page.Graphics;

            //this tilts the page 90 degrees left to display the content sideways
            page.Graphics.RotateTransform(90f);

            //this code gets the page width from the page
            //this float is used as a minus number because 0 is the the bottom of the page (relative to the orientation)
            //and -pageWidth the top
            float pageWidth = page.GetClientSize().Width;

            //this code gets the page height from the page
            float pageHeight = page.GetClientSize().Height;

            //there is a section float to make the code more readable
            //section * 1 = first page
            //section * 2 = second page
            float section = pageHeight / 3;

            //this is the pdf styling for the font ans shapes
            PdfColor blue = Color.FromArgb(255, 79, 147, 206);
            PdfBrush BlueBrush = new PdfSolidBrush(blue);
            PdfPen borderPen = new(BlueBrush, 3f);
            PdfStandardFont FontHeader = new PdfStandardFont(PdfFontFamily.Helvetica, 24, PdfFontStyle.Regular);
            PdfStandardFont FontText = new PdfStandardFont(PdfFontFamily.Helvetica, 18, PdfFontStyle.Regular);
            PdfStandardFont SmallText = new PdfStandardFont(PdfFontFamily.Helvetica, 11, PdfFontStyle.Regular);
            PdfTextElement textElement = new PdfTextElement(description, SmallText);

            string basePath = "HetFietsenStation.Resources.Pdf.";
            if (SampleBrowser.Maui.Base.BaseConfig.IsIndividualSB)
                basePath = "HetFietsenStation.Resources.Pdf.";

            //the PdfStringFormat is used in this document for the text alignment
            // format           = normal
            // formatAlignmentL = left
            // formatAlignmentR = right
            PdfStringFormat format = new();
            format.Alignment = PdfTextAlignment.Center;
            format.LineAlignment = PdfVerticalAlignment.Middle;

            PdfStringFormat formatAlignmentL = new();
            formatAlignmentL.Alignment = PdfTextAlignment.Left;
            formatAlignmentL.LineAlignment = PdfVerticalAlignment.Middle;

            PdfStringFormat formatAlignmentR = new();
            formatAlignmentR.Alignment = PdfTextAlignment.Right;
            formatAlignmentR.LineAlignment = PdfVerticalAlignment.Middle;

            Assembly assembly = typeof(PriceTagBuilder).GetTypeInfo().Assembly;
            basePath = "HetFietsenStation.Resources.Images.";

            //this function makes a new image based on the name "img" the position (pos1 and pos2)
            //and how tall and wide (width and height)
            void NewImage(string img, float pos1, float pos2, float width, float height)
            {
                Stream imageStream = assembly.GetManifestResourceStream(basePath + img);
                PdfBitmap bitmap = new PdfBitmap(imageStream);
                graphics.DrawImage(bitmap, new RectangleF(pos1, pos2, width, height));
            }

            //------------ work in progress

            //byte[] bytes = myWebClient.DownloadData("https://fietsenstation.nl/wp-content/uploads/2022/12/DSC3959-scaled.jpg");

            HttpClient myWebClient = new HttpClient();
            byte[] bytes = await myWebClient.GetByteArrayAsync("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSTaM8yLw8JYUVdG3fkFTN_X2svCXfuEh4KtNW3wXiiCQ&s");
            Stream imageStream2 = new MemoryStream(bytes);
            PdfBitmap image = new PdfBitmap(imageStream2);

            //------------ work in progress

            //DrawLine and drawText functions are made to shorten
            //the pre existing syncfusion functions and make them more readable
            void DrawLine(float m_pointA1, float m_pointA2, float m_pointB1, float m_pointB2)
            {
                PointF pointA = new PointF(m_pointA1, m_pointA2);
                PointF pointB = new PointF(m_pointB1, m_pointB2);
                page.Graphics.DrawLine(borderPen, pointA, pointB);
            }

            void drawText(string m_text, float pos1, float pos2, PdfStringFormat format)
            {
                if (format is null)
                {
                    graphics.DrawString(m_text, FontText, PdfBrushes.Black, new PointF(pos1, pos2));
                }
                else
                {
                    graphics.DrawString(m_text, FontText, PdfBrushes.Black, new PointF(pos1, pos2), format);
                }
            }

            //page 1 content
            #region page 1
            float section1 = section - 6.8f;
            float section2 = section * 2 + 13.6f;

            DrawLine(section1 - 3, -pageWidth, section1 - 3, pageWidth);
            DrawLine(section2 - 3, -pageWidth, section2 - 3, pageWidth);

            graphics.DrawRectangle(borderPen, new RectangleF(3, -pageWidth + 13.6f, section - 40.8f, pageWidth - 27.2f));

            NewImage("het_fietsenstation_symbol.png", 13.6f + (section1 / 2 - 27.2f) - (167 / 2 ), -pageWidth + 200, 167, 100);

            SizeF size = FontHeader.MeasureString(price.ToString() + " euro");
            graphics.DrawString(price.ToString() + " euro", FontHeader, PdfBrushes.Black, new PointF(13.6f + (section1 / 2 - 27.2f) - ( size.Width / 2), -pageWidth + 30));

            DrawLine(20, -pageWidth + 70, section - 60.9f, -pageWidth + 70);
            DrawLine(20, -pageWidth + 110, section - 60.9f, -pageWidth + 110);

            drawText("frame hoogte", 25, -pageWidth + 90, formatAlignmentL);
            drawText(frameHeight.ToString() + "cm", section - 65.9f, -pageWidth + 90, formatAlignmentR);

            drawText("soort", 25, -pageWidth + 130, formatAlignmentL);
            drawText(Type, section - 65.9f, -pageWidth + 130, formatAlignmentR);

            #endregion

            //page 2 content
            #region page 2

            graphics.DrawRectangle(borderPen, new RectangleF(section1 + 20.4f, -pageWidth + 13.6f, section - 27.2f, pageWidth - 27.2f));

            drawText("monteur", section * 1.3f, -pageWidth + 30, format);
            drawText(monteur, section * 1.3f, -pageWidth + 50, format);

            DrawLine(section * 1.6f, -pageWidth + 13.6f, section * 1.6f, -pageWidth + 70);

            //this image is at 16:9 ratio
            graphics.DrawImage(image, new RectangleF(section * 1.605f, - pageWidth + 15 , 96, 54));

            DrawLine(section + 13.6f, -pageWidth + 70, section * 2 - 13.6f, -pageWidth + 70);

            size = FontHeader.MeasureString("voorwerp" + price.ToString());
            drawText("voorwerp", section * 1.25f, -pageWidth + 90, format);

            DrawLine(section * 1.5f, -pageWidth + 70, section * 1.5f, -pageWidth + 110);

            size = FontHeader.MeasureString("voorwerp" + price.ToString());
            drawText("controlen", section * 1.75f, -pageWidth + 90, format);

            DrawLine(section + 13.6f, -pageWidth + 110, section * 2 - 13.6f, -pageWidth + 110);


            //this code defies the first repair position (itemList) and goes through a list foreach repair step
            int itemList = 115;
            bool isFirst = true;
            List<string> rpBikeList = new List<string>();
            size = FontText.MeasureString("text");

            //this method will make a image based on the position (pos1 and pos2) and will print a checkmark or a 
            //cross based off it being repaired or not
            void PrintCheckMark(bool NotDone, float pos1, float pos2)
            {
                if (NotDone)
                {
                    NewImage("cross.png", pos1, pos2, 15, 15);
                }
                else
                {
                    NewImage("check_mark.png", pos1, pos2, 15, 15);
                }
            }

            //this part of the code goes through every repair step and lists it on the second page of the pricetag
            foreach (var step in photographBike.RepairSteps)
            {
                rpBikeList.Add(step.Name);
                if (isFirst == true)
                {
                    itemList += 15;
                    drawText(step.Name , section + 30.4f, -pageWidth + itemList, formatAlignmentL);
                    PrintCheckMark(step.NotDone, section * 1.75f, -pageWidth + itemList - (size.Height / 2.5f));
                    isFirst = false;
                }
                else
                {
                    DrawLine(section + 25.4f, -pageWidth + itemList, section * 2 - 39, -pageWidth + itemList);
                    itemList += 15;
                    drawText(step.Name, section + 30.4f, -pageWidth + itemList, formatAlignmentL);
                    PrintCheckMark(step.NotDone, section * 1.75f, -pageWidth + itemList - (size.Height / 2.5f));
                }
                itemList += 15;
            }

            DrawLine(section + 13.6f, -pageWidth + 365, section * 2 - 13.6f, -pageWidth + 365);

            drawText("reparatie datum", section + 27.2f, -pageWidth + 380, formatAlignmentL);
            drawText(date.Day.ToString() + "/" + date.Month.ToString() + "/" + date.Year.ToString(), section * 2 - 27.2f, -pageWidth + 380, formatAlignmentR);

            DrawLine(section + 13.6f, -pageWidth + 395, section * 2 - 13.6f, -pageWidth + 395);

            SizeF size2 = FontText.MeasureString("opmerkingen");
            graphics.DrawString("opmerkingen", FontText, PdfBrushes.Black, new PointF(section * 1.5f - size2.Width / 2, -pageWidth + 400));

            DrawLine(section + 13.6f, -pageWidth + 425, section * 2 - 13.6f, -pageWidth + 425);

            textElement.Draw(page, new RectangleF(section + 27.2f, -pageWidth + 430, section - 47.6f, 500));

            #endregion

            // save & view ########################
            using MemoryStream ms = new();
            document.Save(ms);
            ms.Position = 0;

            #if WINDOWS
                SaveWindows saveService = new SaveWindows();
                saveService.SaveAndView($"{photographBike.Id}.pdf", "pdf", ms);
            #endif
            #if ANDROID
                SaveAndroidService saveService = new SaveAndroidService();
                saveService.SaveAndView($"{photographBike.Id}.pdf", ms);
            #endif
        }
    }
}
