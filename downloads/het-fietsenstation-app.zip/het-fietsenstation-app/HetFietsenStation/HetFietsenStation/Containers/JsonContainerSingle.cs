﻿namespace HetFietsenStation.Containers
{
    public class JsonContainerSingle<T>
    {
        public T data { get; set; }
        public bool succes { get; set; }
        public string message { get; set; }
    }
}
