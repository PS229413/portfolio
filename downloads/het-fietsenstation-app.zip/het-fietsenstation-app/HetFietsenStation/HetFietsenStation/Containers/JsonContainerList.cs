﻿namespace HetFietsenStation.Containers
{
    public class JsonContainerList<T>
    {
        public T[] data { get; set; }
        public bool succes { get; set; }
        public string message { get; set; }
    }
}
