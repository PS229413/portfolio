using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class EditShopBikeView : ContentPage
{
    private readonly EditShopBikeViewModel _vm;
    public EditShopBikeView(EditShopBikeViewModel vm)
    {
        BindingContext = _vm = vm;
        InitializeComponent();
    }

    void OnPickerSelectedIndexChanged(object sender, EventArgs e)
    {
        _vm.ColorSelectionChanged();
    }
}