using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class AdminHomeView : ContentPage
{
    public AdminHomeView(StaticPageViewModel vm)
    {
        vm.OnNavigatedTo("Admin");
        BindingContext = vm;
        InitializeComponent();
    }

    private async void Shop_Clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("ShopCatalog");
    }

    private async void Repair_Clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("RepairCatalog");
    }

    private async void Photo_Clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("PhotographCatalog");
    }

    private async void Settings_Clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("Settings");
    }
}
