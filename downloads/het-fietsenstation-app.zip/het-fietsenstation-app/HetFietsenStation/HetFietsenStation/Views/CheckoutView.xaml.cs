namespace HetFietsenStation.Views;

public partial class CheckoutView : ContentPage
{
	public CheckoutView()
	{
		InitializeComponent();
	}
    private async void Checkout_Clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("Checkout");
        
    }

}