using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class EditRepairBikeView : ContentPage
{
	private readonly EditRepairBikeViewModel _vm;
	public EditRepairBikeView(EditRepairBikeViewModel vm)
	{
        BindingContext = _vm = vm;
        InitializeComponent();
	}

    void OnPickerSelectedIndexChanged(object sender, EventArgs e)
    {
        _vm.ColorSelectionChanged();
    }
}