using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class ProductDetailsView : ContentPage
{
    ProductDetailsViewModel _vm;

	public ProductDetailsView(ProductDetailsViewModel vm)
	{
        BindingContext = _vm = vm;
        InitializeComponent();
	}

    private async void Catalog_Clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("///" + typeof(ShopCatalogView).Name);
    }

    private async void Edit_Clicked(object sender, EventArgs e)
    {
        string id = Id.Text.Remove(0, 5);

        if (string.IsNullOrEmpty(BikeType.Text))
        {
            await _vm.ToEditProduct(id);
        }
        else
        {
            await _vm.ToEditBike(id);
        }
    }

    private async void AddToCart(object sender, EventArgs e)
    {
        string id = Id.Text.Remove(0, 5);

        if (string.IsNullOrEmpty(BikeType.Text))
        {
            await _vm.AddToShoppingCart(true);
        }
        else
        {
            await _vm.AddToShoppingCart(false);
        }
    }
}