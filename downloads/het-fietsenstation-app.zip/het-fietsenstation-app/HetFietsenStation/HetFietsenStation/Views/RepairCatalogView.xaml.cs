using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class RepairCatalogView : ContentPage
{
    RepairCatalogViewModel _vm;

    public RepairCatalogView(RepairCatalogViewModel vm)
	{
		InitializeComponent();
		BindingContext = _vm = vm;
	}

    protected override void OnNavigatedTo(NavigatedToEventArgs args)
    {
        Task.Run(async () => { await _vm.GetRepairBikes(); }).Wait();
        base.OnNavigatedTo(args);
    }

    private void OnSearchTextChanged(object sender, TextChangedEventArgs e)
    {
        // Update search results
        _vm.OnSearchTextChanged(e.NewTextValue);
    }

    private async void FilterProducts_Clicked(object sender, EventArgs e)
    {
        await _vm.ProductFilter();
        Pop.IsOpen = false;
    }

    private void Filter_Clicked(object sender, EventArgs e)
    {
        Pop.Show();
    }

    private async void ClearFilter_Clicked(object sender, EventArgs e)
    {
        _vm.ClearFilter();
        await _vm.GetRepairBikes();
        Pop.IsOpen = false;
    }

    private async void RefreshView_OnRefreshing(object sender, EventArgs e)
    {
        await _vm.GetRepairBikes();
        Refresh.IsRefreshing = false;
    }
}