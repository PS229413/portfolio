using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class RepairView : ContentPage
{
    //The ViewModel that is bound to the View
    private readonly RepairViewModel _vm;

    //Injects the right ViewModel into the View
    public RepairView(RepairViewModel vm)
	{
        //Sets the ViewModel as a variable and as BindingContext
		BindingContext = _vm = vm;
		InitializeComponent();
	}

    //Event which is triggered when navigated to the page
    protected override void OnNavigatedTo(NavigatedToEventArgs args)
    {
        //Runs async function to make the page ready
        Task.Run(async () => { await _vm.NavigatedTo(); }).Wait();
        base.OnNavigatedTo(args);
    }
}