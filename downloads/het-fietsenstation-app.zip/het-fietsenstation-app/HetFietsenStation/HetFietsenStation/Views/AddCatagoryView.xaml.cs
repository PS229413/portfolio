using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views
{
    public partial class AddCatagoryView : ContentPage
    {
        AddCategoryViewModel _vm;

        public AddCatagoryView(AddCategoryViewModel vm)
        {
            InitializeComponent();
            BindingContext = _vm = vm;
        }

        protected override void OnNavigatedTo(NavigatedToEventArgs args)
        {
            _vm.OnNavigatedTo();

            base.OnNavigatedTo(args);
        }
    }
}