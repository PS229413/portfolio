using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class CategoryManagementView : ContentPage
{
	public CategoryManagementView(StaticPageViewModel vm)
	{
        vm.OnNavigatedTo("Categories");
        BindingContext = vm;
        InitializeComponent();
	}

    private void Add_Clicked(object sender, EventArgs e)
    {
        Shell.Current.GoToAsync("AddCategory");
    }

    private void Remove_Clicked(object sender, EventArgs e)
    {
        Shell.Current.GoToAsync("RemoveCategory");
    }

    private void Button_Clicked(object sender, EventArgs e)
    {
        Shell.Current.GoToAsync("EditCategory");
    }
}