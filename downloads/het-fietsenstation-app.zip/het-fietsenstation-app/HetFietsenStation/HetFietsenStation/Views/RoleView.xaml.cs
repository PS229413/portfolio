using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class RoleView : ContentPage
{
	public RoleView()
	{
        InitializeComponent();
	}
}