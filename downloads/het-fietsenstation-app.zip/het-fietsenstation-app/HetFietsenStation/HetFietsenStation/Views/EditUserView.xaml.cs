using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views
{
    public partial class EditUserView : ContentPage
    {
        EditUserViewModel _vm;

        public EditUserView(EditUserViewModel vm)
        {
            InitializeComponent();
            BindingContext = _vm = vm;
        }

        protected override void OnNavigatedTo(NavigatedToEventArgs args)
        {
            _vm.OnNavigatedTo();
            base.OnNavigatedTo(args);
        }

        private void ChangedIndex(object sender, EventArgs e)
        {
            _vm.ChosenUser();
        }
    }
}