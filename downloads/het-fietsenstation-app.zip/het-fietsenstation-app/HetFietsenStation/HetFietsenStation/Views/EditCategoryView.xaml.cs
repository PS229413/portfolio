using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class EditCategoryView : ContentPage
{
	EditCategoryViewModel _vm;

	public EditCategoryView(EditCategoryViewModel vm)
	{
		InitializeComponent();
		BindingContext = _vm = vm;
	}

    protected override void OnNavigatedTo(NavigatedToEventArgs args)
    {
		_vm.OnNavigatedTo();
        base.OnNavigatedTo(args);
    }

    private void Chosen_Category(object sender, EventArgs e)
    {
        _vm.ChosenCategory();
    }
}