using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class EditProductView : ContentPage
{
	public EditProductView(EditProductViewModel vm)
	{
		InitializeComponent();
		BindingContext = vm;
	}
}