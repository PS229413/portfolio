using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views
{
	public partial class EditBikeView : ContentPage
	{
		EditBikeViewModel _vm;

		public EditBikeView(EditBikeViewModel vm)
		{
			BindingContext = _vm = vm;

			InitializeComponent();
		}

        private void OnPickerSelectedIndexChanged(object sender, EventArgs e)
        {
			_vm.ColorSelectionChanged();
        }
    }
}