using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views
{
    public partial class DeleteUserView : ContentPage
    {
        DeleteUserViewModel _vm;

        public DeleteUserView(DeleteUserViewModel vm)
        {
            BindingContext = _vm = vm;
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigatedToEventArgs args)
        {
            _vm.OnNavigatedTo();
            base.OnNavigatedTo(args);
        }
    }
}