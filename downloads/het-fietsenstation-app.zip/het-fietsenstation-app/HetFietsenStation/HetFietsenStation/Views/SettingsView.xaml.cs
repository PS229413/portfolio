using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class SettingsView : ContentPage
{
	public SettingsView(StaticPageViewModel vm)
	{
        vm.OnNavigatedTo("Settings");
        BindingContext = vm;
        InitializeComponent();
	}

    private async void CatagoryClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("CategoryManagement");
    }

    private async void RoleClicker(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("Role");
    }

    private async void UserClicker(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("User");
    }
}
