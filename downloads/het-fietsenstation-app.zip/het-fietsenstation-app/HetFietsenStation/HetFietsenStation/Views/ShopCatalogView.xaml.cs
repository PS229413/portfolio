using BarcodeScanner.Mobile;
using CommunityToolkit.Maui.Alerts;
using CommunityToolkit.Maui.Core;
using HetFietsenStation.Models;
using HetFietsenStation.ViewModels;
using Syncfusion.Maui.Popup;

namespace HetFietsenStation.Views;

public partial class ShopCatalogView : ContentPage
{
    ShopCatalogViewModel _vm;
    CameraView _cameraView;

    public ShopCatalogView(ShopCatalogViewModel vm)
	{
		InitializeComponent();
		BindingContext = _vm = vm;
    }

    protected override void OnNavigatedTo(NavigatedToEventArgs args)
    {
        Task.Run(async () => { await _vm.GetProducts(); });
        Task.Run(() => { _vm.LoadFilterOptions();; });
        base.OnNavigatedTo(args);
    }

    private void OnSearchTextChanged(object sender, TextChangedEventArgs e)
    {
        // Update search results
        _vm.OnSearchTextChanged(e.NewTextValue);
    }

    private void OnSelectedIndexChanged(object sender, EventArgs e)
    {
        _vm.CheckSubType();
    }

    private async void ScanButton_Clicked(object sender, EventArgs e)
    {
#if ANDROID
        try
        {
            if (DeviceInfo.DeviceType == DeviceType.Virtual)
            {
                //TODO: If the target is an emulator then show the error toast
                return;
            }

            await BarcodeScanner.Mobile.Methods.AskForRequiredPermission();

            var popup = new SfPopup
            {
                HeightRequest = 500,
                ShowFooter = true,
                HeaderTemplate = new DataTemplate(() =>
                {
                    var headerLabel = new Label
                    {
                        Text = "Scan",
                        FontAttributes = FontAttributes.Bold,
                        FontSize = 24,
                        HorizontalTextAlignment = TextAlignment.Center,
                        VerticalTextAlignment = TextAlignment.Center
                    };
                    return headerLabel;
                }),
                FooterTemplate = new DataTemplate(() =>
                {
                    var footerLabel = new Label
                    {
                        //TODO: Add the button to go back if the user don't want to scan
                    };
                    return footerLabel;
                })
            };

            var popupContent = new Grid();
            var cameraViewContainer = new Frame { Padding = new Thickness(0) };
            _cameraView = new CameraView { TorchOn = false, VibrationOnDetected = false, ScanInterval = 100 };
            _cameraView.OnDetected += CameraView_OnDetected;
            cameraViewContainer.Content = _cameraView;

            Grid.SetColumn(cameraViewContainer, 0);
            Grid.SetRow(cameraViewContainer, 0);

            popupContent.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            popupContent.RowDefinitions.Add(new RowDefinition { Height = GridLength.Star });

            popupContent.Children.Add(cameraViewContainer);

            popup.ContentTemplate = new DataTemplate(() => popupContent);


            popup.Show();
        }
        catch (PermissionException ex)
        {
            await DisplayAlert("Toestemming geweigerd.", ex.Message, "OK");
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", ex.Message, "OK");
        }
#else
        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

        string text = "Dit apparaat ondersteunt geen scannen!";
        ToastDuration duration = ToastDuration.Short;
        double fontSize = 14;

        var toast = Toast.Make(text, duration, fontSize);

        await toast.Show(cancellationTokenSource.Token);
#endif
    }
    public static void ScanPhoto(FileResult photo)
    {
        if (photo != null)
        {
            // scan the file using the app
        }
    }

    private void CameraView_OnDetected(object sender, BarcodeScanner.Mobile.OnDetectedEventArg e)
    {
        // Get a list of all the barcode results
        List<BarcodeResult> barcodeResults = e.BarcodeResults;
        // Concatenate all the display values into a single string
        string result = string.Concat(barcodeResults.Select(b => b.DisplayValue));

        // Use the dispatcher to ensure that the code runs on the UI thread
        this.Dispatcher.Dispatch(async () =>
        {
            // Try to parse the bike ID from the result string
            if (int.TryParse(new string(result.Where(char.IsDigit).ToArray()), out int bikeId))
            {
                // Call the OnBarcodeDetected method to get the bike details
                BikeModel bikeResult = await _vm.OnBarcodeDetected(bikeId);

                // If the bike details were found, navigate to the product details page
                if (bikeResult != null)
                {
                    await _vm.ToProductDetails(bikeResult);
                    _cameraView.IsScanning = false;
                }
                // If the bike details were not found, display an error message and keep scanning
                else
                {
                    await DisplayAlert("Fiets niet gevonden", "Er is geen fiets gevonden met dat ID.", "OK");
                    _cameraView.IsScanning = true;
                }
            }
            // If the result string doesn't contain a valid bike ID, display an error message and keep scanning
            else
            {
                await DisplayAlert("Ongeldige barcode", "De gescande barcode is geen geldige fiets-ID.", "OK");
                _cameraView.IsScanning = true;
            }
        });
    }

    private async void Product_Clicked(object sender, EventArgs e)
    {
        _vm.HideKeyboard();
        await Shell.Current.GoToAsync($"Product?id=1");
    }
    
    private async void Add_Product_Clicked(object sender, EventArgs e)
    {
        _vm.HideKeyboard();
        await Shell.Current.GoToAsync("AddProduct");
    }

    private async void FilterProducts_Clicked(object sender, EventArgs e)
    {
        await _vm.ProductFilter();
        Pop.IsOpen = false;
    }

    private void Filter_Clicked(object sender, EventArgs e)
    {
        Pop.Show();
    }

    private async void ClearFilters_Clicked(object sender, EventArgs e)
    {
        _vm.ClearFilter();
        await _vm.GetProducts();
        Pop.IsOpen = false;
    }

    private async void RefreshView_OnRefreshing(object sender, EventArgs e)
    {
        await _vm.GetProducts();
        await Task.Delay(500);
        Refresh.IsRefreshing = false;
    }
    private async void Shoppingcart_Clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("ShoppingCart");
    }
    private async void ShopCatalogView_Clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("ShopCatalogView");
    }
    private async void Catalog(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("Catalog");
    }

}
