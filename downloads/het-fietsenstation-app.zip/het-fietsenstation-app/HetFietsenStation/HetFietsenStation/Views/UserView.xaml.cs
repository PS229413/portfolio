using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class UserView : ContentPage
{
    public UserView(StaticPageViewModel vm)
    {
        vm.OnNavigatedTo("User");
        BindingContext = vm;
        InitializeComponent();
    }

    // navigates to the add user page
    private async void AddClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("AddUser");
    }

    private async void EditClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("EditUser");
    }

    private async void DeleteClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("DeleteUser");
    }
}