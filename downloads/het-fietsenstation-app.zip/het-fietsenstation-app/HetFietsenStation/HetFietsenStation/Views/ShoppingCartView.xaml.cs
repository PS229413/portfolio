using HetFietsenStation.ViewModels;
using Hetfietsenstation.Models;
using HetFietsenStation.Models;
using HetFietsenStation.Services.PDF;
using HetFietsenStation.Services.PrintAndView;


namespace HetFietsenStation.Views;

public partial class ShoppingCartView : ContentPage
{
    ShoppingCartViewModel _vm;

	public ShoppingCartView(ShoppingCartViewModel vm)
	{
		BindingContext = _vm = vm;

		InitializeComponent();
	}

    protected override void OnNavigatedTo(NavigatedToEventArgs args)
    {
        _vm.OnNavigatedTo();
        base.OnNavigatedTo(args);
    }

    private int _productId;
    private async void Checkout_Clicked(object sender, EventArgs e)
    {
	    var mockBikeModel = new BikeModel
	    {
		    Brand = "MockBrand",
		    Model = "MockModel",
		    Note = "MockNote",
		    Images = new List<ImageModel> { new ImageModel { Id = 1, Url = "https://example.com/helmet.png" } },
		    FrameNumber = 123456,
		    FrameHeight = 50,
		    Price = 50,
	    };
	    
	    var images = new List<ImageModel>
	    {
		    new ImageModel { Id = 1, Url = "https://example.com/image1.jpg" },
		    new ImageModel { Id = 2, Url = "https://example.com/image2.jpg" }
	    };
	    

	    var mockSideProduct = new SideProductModel(
		    id: 1,
		    name: "Sample Product",
		    description: "This is a sample side product",
		    images: images,
		    stock: 10,
		    price: 20,
		    sideProductType: null
	    );
	    
	    var mockPaymentModel = new PaymentFinishedFragmentModel
	    {
		    Id = "MockId",
		    Amount = mockBikeModel.Price + mockSideProduct.Price,
		    Reference = "MockReference",
		    Type = "PIN",
		    Datetime = "2023-05-15T10:30:00Z",
		    State = "Completed",
		    TransactionId = "MockTransactionId",
		    TerminalId = "MockTerminalId",
		    CardType = "Visa",
		    AID = "MockAID",
		    TruncatedPan = "**** **** **** 1234",
		    AuthCode = "MockAuthCode",
		    ErrorCode = "MockErrorCode",
		    Change = 500, // $5.00 in cents
		    Description = "MockProductDescription"
	    };
	    
	    var mockSaleModel = new SaleModel
	    {
		    Id = 1,
		    SubsidyType = SubsidyType.Amount,
		    SubsidyValue = 50.0m,
		    SubsidyProvider = SubsidyProvider.Leergeld,
		    SubsidyReference = "696969696969696969",
		    Btw = 21.0m,
		    Sold_At = DateTime.UtcNow,
		    FinalPrice = 450.0m,
		    BikeId = 123,
		    Uuid = Guid.NewGuid(),
		    Reference = "MockReference",
		    TransactionId = "MockTransactionId",
		    Terminal_Sold_At = DateTime.UtcNow
	    };

	    ProductModel[] product = { mockBikeModel, mockSideProduct };

	    IPDFService pdfService = new PDFService();
#if ANDROID
	    var resultPdf = await pdfService.CreateInvoicePDF(product, mockPaymentModel, mockSaleModel);
	    await DependencyService.Get<IPrintAndViewService>().SaveAndView($"yee.pdf", "Invoices", "application/pdf", resultPdf);
#endif
    }
}



