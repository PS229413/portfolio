using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class AddProductView : ContentPage
{
	AddProductViewModel _vm;

	public AddProductView(AddProductViewModel vm)
	{
		InitializeComponent();
		BindingContext = _vm = vm;
	}

    protected override void OnNavigatedTo(NavigatedToEventArgs args)
    {
		_vm.OnNavigatedTo();

        base.OnNavigatedTo(args);
    }
}