using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class AddBikeView : ContentPage
{
    AddBikeViewModel _vm;

    public AddBikeView(AddBikeViewModel vm)
	{
		InitializeComponent();
        BindingContext = _vm = vm;
    }

    protected override void OnNavigatedTo(NavigatedToEventArgs args)
    {
        _vm.OnNavigatedTo();

        base.OnNavigatedTo(args);
    }

    void OnPickerSelectedIndexChanged(object sender, EventArgs e)
    {
        _vm.ColorSelectionChanged();
    }

    private async void Refresh_OnRefreshing(object sender, EventArgs e)
    {
        _vm.OnNavigatedTo();
        await Task.Delay(500);
        Refresh.IsRefreshing = false;
    }
}