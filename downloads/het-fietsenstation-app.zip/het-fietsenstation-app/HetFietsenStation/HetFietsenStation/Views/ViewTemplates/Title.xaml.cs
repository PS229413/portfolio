﻿namespace HetFietsenStation.Views.ViewTemplates;

public partial class Title : ContentView
{
    public Title()
    {
        InitializeComponent();
    }
}