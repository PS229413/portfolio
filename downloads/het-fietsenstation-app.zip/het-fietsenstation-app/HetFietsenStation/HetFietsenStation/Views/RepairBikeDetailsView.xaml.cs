using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class RepairBikeDetailsView : ContentPage
{
	public RepairBikeDetailsView(RepairBikeDetailsViewModel vm)
	{
		InitializeComponent();
		BindingContext = vm;
	}
}