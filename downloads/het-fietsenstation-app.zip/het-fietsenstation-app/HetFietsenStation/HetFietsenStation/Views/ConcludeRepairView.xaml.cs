using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class ConcludeRepairView : ContentPage
{
    public ConcludeRepairView(ConcludeRepairViewModel vm)
    {
        InitializeComponent();
        BindingContext = vm;
    }
}