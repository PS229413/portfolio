using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class PhotographCatalogView : ContentPage
{
	PhotographCatalogViewModel _vm;

	public PhotographCatalogView(PhotographCatalogViewModel vm)
	{
		InitializeComponent();

		BindingContext = _vm = vm;
	}

    protected override void OnNavigatedTo(NavigatedToEventArgs args)
    {
        _vm.OnNavigatedTo();
        base.OnNavigatedTo(args);
    }

    private void Product_SelectedIndexChanged(object sender, EventArgs e)
    {
        _vm.ShowDetails();
    }

    private void ClearProduct_Clicked(object sender, EventArgs e)
    {
        _vm.ClearValues();
    }

    private void ChangePhotos_Clicked(object sender, EventArgs e)
    {
        string bType = BikeType.Text;
        string sType = SideproductType.Text;
        _vm.GoToEdit(bType, sType);
    }
}