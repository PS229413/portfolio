using HetFietsenStation.ViewModels;

namespace HetFietsenStation.Views;

public partial class LoginView : ContentPage
{
    LoginViewModel _vm;

    public LoginView(LoginViewModel vm)
	{
        BindingContext = _vm = vm;

        InitializeComponent();
	}

    protected override void OnNavigatedTo(NavigatedToEventArgs args)
    {
        _vm.OnNavigatedTo();

        base.OnNavigatedTo(args);
    }

    private async void RefreshView_OnRefreshing(object sender, EventArgs e)
    {
        _vm.OnNavigatedTo();
        await Task.Delay(500);
        Refresh.IsRefreshing = false;
    }
}