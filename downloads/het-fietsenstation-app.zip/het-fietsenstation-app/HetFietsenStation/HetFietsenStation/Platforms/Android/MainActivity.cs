﻿using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Hetfietsenstation.Models;
using HetFietsenStation.Services.Payment;
using HetFietsenStation.Services.PrintAndView;

namespace HetFietsenStation;

[Activity(Theme = "@style/Maui.SplashTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.UiMode | ConfigChanges.ScreenLayout | ConfigChanges.SmallestScreenSize | ConfigChanges.Density)]
public class MainActivity : MauiAppCompatActivity
{
    // Request code for the payment process. This code is used to identify the payment process
    public static readonly int PaymentProcessId = 5300;
    
    // Static instance of the MainActivity. This is used to access the MainActivity from the PaymentAndroidService
    internal static MainActivity Instance { get; private set; }
    
    // Task completion source for the payment process. This is used to track the completion of the payment process
    public TaskCompletionSource<PaymentFinishedFragmentModel> PaymentTaskCompletionSource { set; get; }
    
    // This method is called when the activity is created. This method is used to register the PaymentAndroidService
    protected override void OnCreate(Bundle savedInstanceState)
    {
        base.OnCreate(savedInstanceState);

        // Register the Services
        DependencyService.Register<IPaymentService, PaymentAndroidService>();
        DependencyService.Register<IPrintAndViewService, PrintAndViewAndroidService>();
        
        // Set the static instance of MainActivity to this instance.
        Instance = this;
        
        // Initialize the PaymentTaskCompletionSource
        PaymentTaskCompletionSource = new TaskCompletionSource<PaymentFinishedFragmentModel>();
    }
    
    // This method is called when an activity returns a result. This method is used to parse the result of the payment process
    protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
    {
        base.OnActivityResult(requestCode, resultCode, data);

        Android.Util.Log.Debug("success", "OnActivityResult is fired");
        if (PaymentTaskCompletionSource != null && !PaymentTaskCompletionSource.Task.IsCompleted)
        {
            switch (resultCode)
            {
                case Result.Ok:
                    ParseOkResult(data);
                    break;
                case Result.Canceled:
                    ParseCancelResult(data);
                    break;
            }
        }
    }
    
    // Parse the result of a successful payment process.
    private void ParseOkResult(Intent data)
    {
        // Create a new PaymentFinishedFragmentModel and populate its properties from the Intent data.
        PaymentFinishedFragmentModel pff = new PaymentFinishedFragmentModel()
        {
            Id = data.GetStringExtra("id"),
            Reference = data.GetStringExtra("reference"),
            Amount = Convert.ToDecimal(data.GetIntExtra("amount", -1)) / 100,
            Type = data.GetStringExtra("type"),
            Datetime = data.GetStringExtra("datetime"),
            State = data.GetStringExtra("state"),
            TransactionId = data.GetStringExtra("transactionId"),

            // Additional properties for pin payments
            TerminalId = data.GetStringExtra("terminalId"),
            CardType = data.GetStringExtra("cardType"),
            AID = data.GetStringExtra("AID"),
            TruncatedPan = data.GetStringExtra("truncatedPan"),
            AuthCode = data.GetStringExtra("authCode"),
            ErrorCode = data.GetStringExtra("errorCode"),
            
            // Additional properties for cash payments
            Change = data.GetIntExtra("change", default)
        };
        
        Android.Util.Log.Debug("success", "parseOkResult is OK....");
        PaymentTaskCompletionSource.SetResult(pff);
    }
    
    // Parse the result of a canceled payment process.
    private void ParseCancelResult(Intent data)
    {
        // Parse the result of a canceled payment process.
        PaymentFinishedFragmentModel paymentFinishedFragment = new PaymentFinishedFragmentModel();
        if (data != null)
        {
            paymentFinishedFragment.Id = data.GetStringExtra("id");
            paymentFinishedFragment.State = data.GetStringExtra("state");
            paymentFinishedFragment.Amount = Convert.ToDecimal(Int32.Parse(data.GetStringExtra("amount") ?? string.Empty) / 100);

            // Log error
            Android.Util.Log.Debug("success", "parseCancelResult cancel data is not null");
        }
        else
        {
            Android.Util.Log.Debug("error", "parseCancelResult data is null");
        }

        PaymentTaskCompletionSource.SetResult(paymentFinishedFragment);
    }
}
