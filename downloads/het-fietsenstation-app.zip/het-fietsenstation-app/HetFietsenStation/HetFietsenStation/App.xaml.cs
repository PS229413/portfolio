﻿namespace HetFietsenStation;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();
        Licenser.LicenseSyncFusion();
        MainPage = new AppShell();
	}
}
