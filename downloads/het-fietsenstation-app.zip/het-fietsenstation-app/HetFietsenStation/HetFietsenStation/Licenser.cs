﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HetFietsenStation
{
    public class Licenser
    {
        static public bool LicenseSyncFusion()
        {
            Syncfusion.Licensing.SyncfusionLicenseProvider.
                RegisterLicense("Mgo+DSMBaFt/QHRqVVhkXlpFdEBBXHxAd1p/VWJYdVt5flBPcDwsT3RfQF5jSH5Xdk1jWn5WeXxRRw==;Mgo+DSMBPh8sVXJ0S0J+XE9AdFRDX3xKf0x/TGpQb19xflBPallYVBYiSV9jS31Td0VnWXdec3VcRmBfUQ==;ORg4AjUWIQA/Gnt2VVhkQlFacl1JXGFWfVJpTGpQdk5xdV9DaVZUTWY/P1ZhSXxQdkRjXX9WcHdUT2BeUkU=;ODcyNTEwQDMyMzAyZTM0MmUzMEJPNCtqMjNuU1N1S29nSjZYRVRZVUJ3MFl5eVlXVTFOMkQzZWt6YTVSQ2c9;ODcyNTExQDMyMzAyZTM0MmUzME15SlRnQTdYQVVJd1VXNG9DOEJSV05Td3p4WHdEcElWWkpTYis5WW5GQVE9;NRAiBiAaIQQuGjN/V0Z+WE9EaFtAVmJLYVB3WmpQdldgdVRMZVVbQX9PIiBoS35RdUViWXteeHRWR2leWUV3;ODcyNTEzQDMyMzAyZTM0MmUzME45QmRSV04wZUlJMU5nclFmVzlVaWM2bUJSd1F0b2ZmNWFwV2ExVjlmK3M9;ODcyNTE0QDMyMzAyZTM0MmUzMERNcDZsOTNzaCtWSlVRVTFHQ25xSm80c05RazNEOEhqa0R3V1lmODBwaDQ9;Mgo+DSMBMAY9C3t2VVhkQlFacl1JXGFWfVJpTGpQdk5xdV9DaVZUTWY/P1ZhSXxQdkRjXX9WcHdUT2NbV0U=;ODcyNTE2QDMyMzAyZTM0MmUzMGlxQlYrVUN6MUZMeEZpTG5wVjZXeEhaWGdyWFJBdXhRalJiSEx4VXVma3M9;ODcyNTE3QDMyMzAyZTM0MmUzMEtGUTEzZUVWWE9oWmJTMk1EWkhWRTBhSEhLQkdEemZycFRSUi9ES2dBaGc9;ODcyNTE4QDMyMzAyZTM0MmUzME45QmRSV04wZUlJMU5nclFmVzlVaWM2bUJSd1F0b2ZmNWFwV2ExVjlmK3M9");

            return true;
        }
    }
}
