﻿namespace HetFietsenStation.Dtos.SideProduct
{
    public class UpdateSideProductDto
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int Stock { get; set; } = 0;
        public int Price { get; set; } = 0;
        public int SideproductTypeId { get; set; }

        public UpdateSideProductDto(int id, string name, string description,
            int stock, int price, int sideproductTypeId)
        {
            Id = id;
            Name = name;
            Description = description;
            Stock = stock;
            Price = price;
            SideproductTypeId = sideproductTypeId;
        }
    }
}
