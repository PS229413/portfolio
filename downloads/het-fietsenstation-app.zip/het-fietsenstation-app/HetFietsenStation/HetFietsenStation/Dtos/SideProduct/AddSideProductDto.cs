﻿namespace HetFietsenStation.Dtos.SideProduct
{
    public class AddSideProductDto
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int Stock { get; set; } = 0;
        public int Price { get; set; } = 0;
        public int SideproductTypeId { get; set; }

        public AddSideProductDto(string name, string description, int stock, int price, int sideproductTypeId) 
        {
            Name = name;
            Description = description;
            Stock = stock;
            Price = price;
            SideproductTypeId = sideproductTypeId;
        }
    }
}
