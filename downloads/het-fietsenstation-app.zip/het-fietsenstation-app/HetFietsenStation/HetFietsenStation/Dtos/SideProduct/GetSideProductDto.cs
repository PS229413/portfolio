﻿using HetFietsenStation.Dtos.SideProductType;
using HetFietsenStation.Models;

namespace HetFietsenStation.Dtos.SideProduct
{
    public class GetSideProductDto
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public List<ImageModel> Images { get; set; }
        public int Stock { get; set; } = 0;
        public int Price { get; set; } = 0;
        public GetSideProductTypeDto SideProductType { get; set; } = null;

        public GetSideProductDto(int id, string name, string description,
            List<ImageModel> images, int stock, int price, GetSideProductTypeDto sideProductType) 
        {
            Id = id;
            Name = name;
            Description = description;
            Images = images;
            Stock = stock;
            Price = price;
            SideProductType = sideProductType;
        }
    }
}
