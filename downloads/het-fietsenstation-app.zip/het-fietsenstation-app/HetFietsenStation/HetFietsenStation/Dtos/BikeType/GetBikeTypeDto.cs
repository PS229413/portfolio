﻿namespace HetFietsenStation.Dtos.BikeType
{
    public class GetBikeTypeDto
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;

        public GetBikeTypeDto(int id, string name, string description)
        {
            Id = id;
            Name = name;
            Description = description;
        }
    }
}
