﻿using HetFietsenStation.Models;

namespace HetFietsenStation.Dtos.RepairBike
{
    public class RepairBikeToPhotographBikeDto
    {
        public int Id { get; set; } = 0;
        public string Note { get; set; } = string.Empty;
        public int Price { get; set; } = 0;
        public DateTime RepairDate { get; set; }
        public int BikeStatusId { get; set; } = 2;
        public int MechanicId { get; set; } = 0;

        public RepairBikeToPhotographBikeDto(PhotographBikeModel photographBike) 
        {
            Id = photographBike.Id;
            Note = photographBike.Note;
            Price = photographBike.Price;
            RepairDate = photographBike.RepairDate;
            MechanicId = photographBike.Mechanic.Id;
        }
    }
}
