﻿using HetFietsenStation.Dtos.BikeCondition;
using HetFietsenStation.Dtos.BikeColor;
using HetFietsenStation.Dtos.BikeStatus;
using HetFietsenStation.Dtos.BikeType;
using HetFietsenStation.Dtos.BikeSource;
using HetFietsenStation.Models;

namespace HetFietsenStation.Dtos.RepairBike
{
    public class GetRepairBikeDto
    {
        public int Id { get; set; } = 0; 
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public List<ImageModel> Images { get; set; }
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public DateTime RegistrationDate { get; set; }
        public GetBikeTypeDto BikeType { get; set; }
        public GetBikeColorDto BikeColor { get; set; }
        public GetBikeConditionDto BikeCondition { get; set; }
        public GetBikeStatusDto BikeStatus { get; set; }
        public GetBikeSourceDto BikeSource { get; set; }

        public GetRepairBikeDto(int id, string brand, string model, List<ImageModel> images, int frameNumber, 
            int frameHeight, DateTime registrationDate, GetBikeTypeDto type, 
            GetBikeColorDto color, GetBikeConditionDto condition, GetBikeStatusDto status, 
            GetBikeSourceDto source)
        {
            Id = id;
            Brand = brand;
            Model = model;
            Images = images;
            FrameNumber = frameNumber;
            FrameHeight = frameHeight;
            RegistrationDate = registrationDate;
            BikeType = type;
            BikeColor = color;
            BikeCondition = condition;
            BikeStatus = status;
            BikeSource = source;
        }
    }
}
