﻿namespace HetFietsenStation.Dtos.RepairBike
{
    public class AddRepairBikeDto
    {
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public DateTime RegistrationDate { get; set; } = DateTime.Now;
        public int BikeTypeId { get; set; }
        public int BikeColorId { get; set; }
        public int BikeConditionId { get; set; }
        public int BikeStatusId { get; set; } = 1;
        public int BikeSourceId { get; set; }

        public AddRepairBikeDto(string brand, string model, int frameNumber,
            int frameHeight, int bikeTypeId, int bikeColorId, int bikeConditionId, 
            int bikeSourceId)
        {
            Brand = brand;
            Model = model;
            FrameNumber = frameNumber;
            FrameHeight = frameHeight;
            BikeTypeId = bikeTypeId;
            BikeColorId = bikeColorId;
            BikeConditionId = bikeConditionId;
            BikeSourceId = bikeSourceId;
        }
    }
}
