﻿using HetFietsenStation.Models;

namespace HetFietsenStation.Dtos.RepairBike
{
    public class UpdateRepairBikeDto
    {
        public int Id { get; set; } = 0; 
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public List<ImageModel> Images { get; set; }
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public int BikeTypeId { get; set; }
        public int BikeColorId { get; set; }
        public int BikeConditionId { get; set; }
        public int BikeSourceId { get; set; }

        public UpdateRepairBikeDto(int id, string brand, string model, int frameNumber, 
            int frameHeight, int bikeTypeId, int bikeColorId, int bikeConditionId, 
            int bikeSourceId)
        {
            Id = id;
            Brand = brand;
            Model = model;
            FrameNumber = frameNumber;
            FrameHeight = frameHeight;
            BikeTypeId = bikeTypeId;
            BikeColorId = bikeColorId;
            BikeConditionId = bikeConditionId;
            BikeSourceId = bikeSourceId;
        }

        public UpdateRepairBikeDto(RepairBikeModel bike)
        {
            Id = bike.Id;
            Brand = bike.Brand;
            Model = bike.Model;
            FrameNumber = bike.FrameNumber;
            FrameHeight = bike.FrameHeight;
            BikeTypeId = bike.BikeType.Id;
            BikeColorId = bike.BikeColor.Id;
            BikeConditionId = bike.BikeCondition.Id;
            BikeSourceId = bike.BikeSource.Id;
        }
    }
}
