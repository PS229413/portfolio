﻿using HetFietsenStation.Dtos.BikeColor;
using HetFietsenStation.Dtos.BikeCondition;
using HetFietsenStation.Dtos.BikeSource;
using HetFietsenStation.Dtos.BikeStatus;
using HetFietsenStation.Dtos.BikeType;
using HetFietsenStation.Dtos.User;
using HetFietsenStation.Models;

namespace HetFietsenStation.Dtos.PhotoBike
{
    public class GetPhotoBikeDto
    {
        public int Id { get; set; } = 0;
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public List<ImageModel> Images { get; set; }
        public int Price { get; set; } = 0;
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public DateTime RegistrationDate { get; set; }
        public GetBikeTypeDto BikeType { get; set; } = null;
        public GetBikeColorDto BikeColor { get; set; } = null;
        public GetBikeStatusDto BikeStatus { get; set; } = null;
        public GetBikeSourceDto BikeSource { get; set; } = null;
        public GetBikeConditionDto BikeCondition { get; set; } = null;
        public GetUserDto Mechanic { get; set; } = null;

        public GetPhotoBikeDto(int id, string brand, string model, List<ImageModel> images, int price, int frameNumber, int frameHeight, DateTime registrationDate, GetBikeTypeDto type, GetBikeColorDto getBikeColorDto, GetBikeConditionDto getBikeConditionDto, GetBikeStatusDto getBikeStatusDto, GetBikeSourceDto getBikeSourceDto, GetUserDto getUserDto)
        {
            Id = id;
            Brand = brand;
            Model = model;
            Images = images;
            Price = price;
            FrameNumber = frameNumber;
            FrameHeight = frameHeight;
            RegistrationDate = registrationDate;
            BikeType = type;
            BikeColor = getBikeColorDto;
            BikeStatus = getBikeStatusDto;
            BikeSource = getBikeSourceDto;
            BikeCondition = getBikeConditionDto;
            Mechanic = getUserDto;
        }
    }
}