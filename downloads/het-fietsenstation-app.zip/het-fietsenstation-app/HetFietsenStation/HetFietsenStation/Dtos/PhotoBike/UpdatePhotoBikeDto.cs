﻿using HetFietsenStation.Models;

namespace HetFietsenStation.Dtos.PhotoBike
{
    public class UpdatePhotoBikeDto
    {
        public int Id { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public string Note { get; set; }
        public string ImageUrl { get; set; }
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public int Price { get; set; } = 0;
        public int BikeTypeId { get; set; } = 0;
        public int BikeColorId { get; set; } = 0;
        public int BikeConditionId { get; set; } = 0;
        public int BikeSourceId { get; set; } = 0;
        public int MechanicID { get; set; } = 0;

        public UpdatePhotoBikeDto(int id, string brand, string model, string note, int frameNumber, int frameHeight, int bikeTypeId, int bikeColorId, int bikeConditionId, int bikeSourceId, int MechanicId)
        {
            Id = id;
            Brand = brand;
            Model = model;
            Note = note;
            FrameNumber = frameNumber;
            FrameHeight = frameHeight;
            BikeTypeId = bikeTypeId;
            BikeColorId = bikeColorId;
            BikeConditionId = bikeConditionId;
            BikeSourceId = bikeSourceId;
            MechanicID = MechanicId;
        }

        public UpdatePhotoBikeDto(BikeModel bike)
        {
            Id = bike.Id;
            Brand = bike.Brand;
            Model = bike.Model;
            Note = bike.Note;
            FrameNumber = bike.FrameNumber;
            FrameHeight = bike.FrameHeight;
            BikeTypeId = bike.BikeType.Id;
            BikeColorId = bike.BikeColor.Id;
            BikeConditionId = bike.BikeCondition.Id;
            BikeSourceId = bike.BikeSource.Id;
            MechanicID = bike.User.Id;
        }
    }
}
