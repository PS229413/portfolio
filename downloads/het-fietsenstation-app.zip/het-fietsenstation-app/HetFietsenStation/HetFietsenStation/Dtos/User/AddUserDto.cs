﻿namespace HetFietsenStation.Dtos.User
{
    public class AddUserDto
    {
        public string Name { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public int Role { get; set; } = 0;

        public AddUserDto(string name, string password, int role)
        {
            Name = name;
            Password = password;
            Role = role;
        }
    }
}
