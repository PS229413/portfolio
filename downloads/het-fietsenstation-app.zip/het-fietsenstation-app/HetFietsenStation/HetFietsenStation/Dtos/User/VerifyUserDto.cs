﻿namespace HetFietsenStation.Dtos.User
{
    public class VerifyUserDto
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;

        public VerifyUserDto(int id, string name, string password) 
        { 
            Id = id;
            Name = name;
            Password = password;
        }
    }
}
