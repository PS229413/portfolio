﻿namespace HetFietsenStation.Dtos.User
{
    public class DeleteUserDto
    {
        public int Id { get; set; } = 0;

        public DeleteUserDto(int id)
        {
            Id = id;
        }
    }
}
