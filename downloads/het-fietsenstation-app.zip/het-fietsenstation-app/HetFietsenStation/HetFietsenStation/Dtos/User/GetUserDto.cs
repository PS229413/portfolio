﻿namespace HetFietsenStation.Dtos.User
{
    public class GetUserDto
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = string.Empty;
        public int UserRoleId { get; set; }

        public GetUserDto(int id, string name, int userRoleId)
        {
            Id = id;
            Name = name;
            UserRoleId = userRoleId;
        }
    }
}
