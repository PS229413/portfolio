﻿namespace HetFietsenStation.Dtos
{
    internal class AddPhotoDto
    {
        public MultipartFormDataContent Form { get; set; }

        public AddPhotoDto(MultipartFormDataContent form)
        {
            Form = form;
        }
    }
}
