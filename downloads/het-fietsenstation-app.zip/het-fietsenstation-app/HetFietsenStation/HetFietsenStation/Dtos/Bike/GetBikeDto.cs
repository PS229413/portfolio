﻿using HetFietsenStation.Dtos.BikeColor;
using HetFietsenStation.Dtos.BikeCondition;
using HetFietsenStation.Dtos.BikeSource;
using HetFietsenStation.Dtos.BikeStatus;
using HetFietsenStation.Dtos.BikeType;
using HetFietsenStation.Dtos.User;
using HetFietsenStation.Models;

namespace HetFietsenStation.Dtos.Product
{
    public class GetBikeDto
    {
        public int Id { get; set; } = 0;
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string Note { get; set; } = string.Empty;
        public List<ImageModel> Images { get; set; }
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public int Price { get; set; } = 0;
        public DateTime RegistrationDate { get; set; }
        public DateTime? RepairDate { get; set; } = null;
        public GetBikeTypeDto BikeType { get; set; } = null;
        public GetBikeColorDto BikeColor { get; set; } = null;
        public GetBikeConditionDto BikeCondition { get; set; } = null;
        public GetBikeStatusDto BikeStatus { get; set; } = null;
        public GetBikeSourceDto BikeSource { get; set; } = null;
        public GetUserDto Mechanic { get; set; } = null;

        public GetBikeDto(int id, string brand, string model, string note, List<ImageModel> images, int frameNumber, int frameHeight, int price, DateTime registrationDate, DateTime? repairDate, GetBikeTypeDto bikeType, GetBikeColorDto bikeColor, GetBikeConditionDto bikeCondition, GetBikeStatusDto bikeStatus, GetBikeSourceDto bikeSource, GetUserDto user)
        {
            Id = id;
            Brand = brand;
            Model = model;
            Note = note;
            Images = images;
            FrameNumber = frameNumber;
            FrameHeight = frameHeight;
            Price = price;
            RegistrationDate = registrationDate;
            RepairDate = repairDate;
            BikeType = bikeType;
            BikeColor = bikeColor;
            BikeCondition = bikeCondition;
            BikeStatus = bikeStatus;
            BikeSource = bikeSource;
            Mechanic = user;
        }
    }
}
