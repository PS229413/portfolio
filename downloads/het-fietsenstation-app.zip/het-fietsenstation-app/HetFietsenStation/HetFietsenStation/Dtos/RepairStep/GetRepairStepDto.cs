﻿namespace HetFietsenStation.Dtos.RepairStep
{
    public class GetRepairStepDto
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public bool Required { get; set; } = false;

        public GetRepairStepDto(int id, string name, string description, bool required)
        {
            Id = id;
            Name = name;
            Description = description;
            Required = required;
        }
    }
}
