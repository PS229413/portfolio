﻿namespace HetFietsenStation.Dtos.BikeRepairStep
{
    public class UpdateBikeRepairStepDto
    {
        public int BikeId { get; set; } = 0;
        public int RepairStepId { get; set; } = 0;
        public bool Done { get; set; } = false;

        public UpdateBikeRepairStepDto(int bikeId, int repairStepId, bool done)
        {
            BikeId = bikeId;
            RepairStepId = repairStepId;
            Done = done;
        }
    }
}
