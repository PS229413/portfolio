﻿using HetFietsenStation.Dtos.RepairStep;

namespace HetFietsenStation.Dtos.BikeRepairStep
{
    public class GetBikeRepairStepDto
    {
        public GetRepairStepDto RepairStep { get; set; }
        public bool Done { get; set; }

        public GetBikeRepairStepDto(GetRepairStepDto repairStep, bool done)
        {
            RepairStep = repairStep;
            Done = done;
        }
    }
}
