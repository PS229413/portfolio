﻿namespace HetFietsenStation.Dtos.SideProductType
{
    public class DeleteSideProductTypeDto
    {
        public int Id { get; set; }

        public DeleteSideProductTypeDto(int id)
        {
            Id = id;
        }
    }
}
