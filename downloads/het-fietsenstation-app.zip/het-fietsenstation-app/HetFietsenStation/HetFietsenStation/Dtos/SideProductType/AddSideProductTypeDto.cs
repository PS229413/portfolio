﻿namespace HetFietsenStation.Dtos.SideProductType
{
    public class AddSideProductTypeDto
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;

        public AddSideProductTypeDto(string name, string description)
        {
            Name = name;
            Description = description;
        }
    }
}
