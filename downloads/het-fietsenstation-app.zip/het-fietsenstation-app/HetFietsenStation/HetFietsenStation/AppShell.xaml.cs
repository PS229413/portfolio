﻿using HetFietsenStation.Views;

namespace HetFietsenStation;

public partial class AppShell : Shell
{

	public AppShell()
	{
        InitializeRouting();
		InitializeComponent();
	}

    private static void InitializeRouting()
    {
        //Shop views
        Routing.RegisterRoute("AddProduct", typeof(AddProductView));
        Routing.RegisterRoute("EditProduct", typeof(EditProductView));
        Routing.RegisterRoute("EditShopBike", typeof(EditBikeView));
        Routing.RegisterRoute("ProductDetails", typeof(ProductDetailsView));
        Routing.RegisterRoute("ShopCatalog", typeof(ShopCatalogView));
        Routing.RegisterRoute("ShoppingCart", typeof(ShoppingCartView));
        Routing.RegisterRoute("Checkout", typeof(CheckoutView));
        //Photo views
        Routing.RegisterRoute("PhotographCatalog", typeof(PhotographCatalogView));
        Routing.RegisterRoute("BikeDetails", typeof(BikeDetailsView));
        Routing.RegisterRoute("EditPhotoBike", typeof(EditBikeView));
        //Repair views
        Routing.RegisterRoute("ConcludeRepair", typeof(ConcludeRepairView));
        Routing.RegisterRoute("RepairCatalog", typeof(RepairCatalogView));
        Routing.RegisterRoute("RepairBikeDetails", typeof(RepairBikeDetailsView));
        Routing.RegisterRoute("Repair", typeof(RepairView));
        Routing.RegisterRoute("AddBike", typeof(AddBikeView));
        Routing.RegisterRoute("EditRepairBike", typeof(EditBikeView));
        //Admin views
        Routing.RegisterRoute("AdminHome", typeof(AdminHomeView));
        Routing.RegisterRoute("CategoryManagement", typeof(CategoryManagementView));
        Routing.RegisterRoute("AddCategory", typeof(AddCatagoryView));
        Routing.RegisterRoute("EditCategory", typeof(EditCategoryView));
        Routing.RegisterRoute("RemoveCategory", typeof(RemoveCategoryView));
        Routing.RegisterRoute("Role", typeof(RoleView));
        Routing.RegisterRoute("User", typeof(UserView));
        Routing.RegisterRoute("AddUser", typeof(AddUserView));
        Routing.RegisterRoute("EditUser", typeof(EditUserView));
        Routing.RegisterRoute("DeleteUser", typeof(DeleteUserView));
        Routing.RegisterRoute("Settings", typeof(SettingsView));
        //Login views
        Routing.RegisterRoute("//Login", typeof(LoginView));
    }
}
