﻿#if ANDROID
using Hetfietsenstation.Models;
using Android.Content;
using Android.Content.PM;

namespace HetFietsenStation.Services.Payment
{
    public class PaymentAndroidService : IPaymentService
    {
        // Initiates the payment process
        public Task<PaymentFinishedFragmentModel> Pay(PaymentFinishedFragmentModel fragment)
        {
            // Set the PaymentTaskCompletionSource to track the completion of the payment task
            MainActivity.Instance.PaymentTaskCompletionSource = new TaskCompletionSource<PaymentFinishedFragmentModel>();

            // Process the payment
            Process(fragment);

            // Return the payment task
            return MainActivity.Instance.PaymentTaskCompletionSource.Task;
        }

        // Process the payment by launching the payment activity
        private void Process(PaymentFinishedFragmentModel fragment)
        {
            try
            {
                // Convert the amount to round number
                int amount = (int)(fragment.Amount * 100);

                // Create an intent for the payment activity
                Intent intent = new Intent();
                intent.SetAction("nl.rabobank.smartpin.PAY");
                intent.SetFlags(ActivityFlags.ClearTop);
                intent.PutExtra("id", fragment.Id);
                intent.PutExtra("amount", amount);
                intent.PutExtra("reference", fragment.Reference);  // Optional
                intent.PutExtra("type", fragment.Type);             // Optional

                // Check if there are activities that can handle the payment intent
                if (MainActivity.Instance.ApplicationContext.PackageManager
                        .QueryIntentActivities(intent, PackageInfoFlags.MatchDefaultOnly).Count > 0)
                {
                    // Start the payment activity and wait for the result
                    MainActivity.Instance.StartActivityForResult(intent, MainActivity.PaymentProcessId);
                    Android.Util.Log.Debug("Success", "This is a success message");
                }
                else
                {
                    // No activities can handle the payment intent, set the result to null
                    MainActivity.Instance.PaymentTaskCompletionSource.SetResult(null);
                    Android.Util.Log.Debug("error", "QueryIntentActivities is less than zero");
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions that occur during the payment process
                Android.Util.Log.Debug("error", ex.Message);
            }
        }
    }
}
#endif