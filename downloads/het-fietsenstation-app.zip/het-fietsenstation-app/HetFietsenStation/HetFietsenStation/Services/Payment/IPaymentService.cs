﻿using Hetfietsenstation.Models;

namespace HetFietsenStation.Services.Payment
{
    public interface IPaymentService
    {
        Task<PaymentFinishedFragmentModel> Pay(PaymentFinishedFragmentModel fragment);
    }
}