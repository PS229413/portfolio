﻿using Hetfietsenstation.Models;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.Payment
{
    public class PaymentService
    {
        public async Task<bool> CreateNewSaleRecord(SaleModel newSale)
        {
            //TODO: Create new sale record in database
            return false;
        }

        private decimal GetSubsidyByPercentage(decimal discount)
        {
            //TODO: Calculate subsidy by percentage
            return decimal.Zero;
        }
        
        public decimal GetSubsidyByAmount(decimal amount)
        {
            return amount;
        }

        public async Task CalculateFinalPrice(string discount, string subsidy)
        {
            //TODO: Calculate final price
        }

        public async void CheckPaymentState(PaymentFinishedFragmentModel fragment, int bikeId)
        {
            //TODO: Check payment state
        }

        public async Task SendInvoiceData()
        {
            //TODO: Send invoice data
        }
        
        public void ShowMessage(string message)
        {
            //TODO: Show message
        }

        public void SendMail(Stream invoice)
        {
            //TODO: Send mail
        }
    }
}