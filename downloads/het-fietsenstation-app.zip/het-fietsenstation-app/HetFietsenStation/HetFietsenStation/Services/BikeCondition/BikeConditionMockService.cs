﻿using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeCondition
{
    public class BikeConditionMockService : IBikeConditionService
    {
        List<BikeConditionModel> BikeConditions = new List<BikeConditionModel>
        {
            new BikeConditionModel(1, "condition 1", "description"),
            new BikeConditionModel(2, "condition 2", "description")
        };

        public async Task<IEnumerable<BikeConditionModel>> GetBikeConditions()
        {
            try
            {
                await Task.Delay(10);

                return BikeConditions;
            }
            catch
            {
                return null;
            }
        }
    }
}
