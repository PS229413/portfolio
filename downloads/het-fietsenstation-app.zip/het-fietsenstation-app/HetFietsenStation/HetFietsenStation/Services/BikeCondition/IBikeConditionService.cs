﻿using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeCondition
{
    public interface IBikeConditionService
    {
        Task<IEnumerable<BikeConditionModel>> GetBikeConditions();
    }
}
