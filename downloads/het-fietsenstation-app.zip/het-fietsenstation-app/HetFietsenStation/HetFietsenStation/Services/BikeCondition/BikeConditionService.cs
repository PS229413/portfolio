﻿using HetFietsenStation.Dtos.BikeCondition;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeCondition
{
    public class BikeConditionService : HttpCallServiceBase, IBikeConditionService
    {
        public BikeConditionService(ISettingsService settingsService, bool isUnitTest = false) : base(settingsService, isUnitTest) 
        {
            Route = "api/BikeCondition";
        }

        //obtain all the bike colors from the database
        public async Task<IEnumerable<BikeConditionModel>> GetBikeConditions()
        {
            return await GetAllBase<GetBikeConditionDto, BikeConditionModel>(Route, dto => new BikeConditionModel(dto));
        }
    }
}
