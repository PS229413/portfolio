﻿using HetFietsenStation.Dtos.BikeRepairStep;

namespace HetFietsenStation.Services.RepairStep
{
    public interface IRepairStepService
    {
        Task<IEnumerable<GetBikeRepairStepDto>> GetRepairSteps(int bikeId);
    }
}
