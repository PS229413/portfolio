﻿using HetFietsenStation.Dtos.BikeRepairStep;
using HetFietsenStation.Services.Settings;

namespace HetFietsenStation.Services.RepairStep
{
    public class RepairStepService : HttpCallServiceBase, IRepairStepService
    {
        public RepairStepService(ISettingsService settingsService, bool isUnitTest = false) : base(settingsService, isUnitTest)
        {
            Route = "api/RepairStep";
        }

        //get all the repair steps
        public async Task<IEnumerable<GetBikeRepairStepDto>> GetRepairSteps(int bikeId)
        {
            return await GetAllBase<GetBikeRepairStepDto, GetBikeRepairStepDto>(Route + "/" + bikeId, dto => dto);
        }
    }
}
