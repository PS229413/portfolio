﻿using HetFietsenStation.Dtos.BikeRepairStep;
using HetFietsenStation.Dtos.RepairStep;

namespace HetFietsenStation.Services.RepairStep
{
    public class RepairStepMockService : IRepairStepService
    {
        private List<IEnumerable<GetBikeRepairStepDto>> MockGetBikeRepairStepModelDtos = new List<IEnumerable<GetBikeRepairStepDto>>() 
        {
            new List<GetBikeRepairStepDto>()
            {
                new GetBikeRepairStepDto(new GetRepairStepDto(1,"Test 1", "Test 1", true), true),
                new GetBikeRepairStepDto(new GetRepairStepDto(2,"Test 2", "Test 2", false), false)
            },
            new List<GetBikeRepairStepDto>()
            {
                new GetBikeRepairStepDto(new GetRepairStepDto(1,"Test 1", "Test 1", true), true),
                new GetBikeRepairStepDto(new GetRepairStepDto(2,"Test 2", "Test 2", false), false)
            } 
        };


        public async Task<IEnumerable<GetBikeRepairStepDto>> GetRepairSteps(int bikeId)
        {
            try
            {
                await Task.Delay(10);

                return MockGetBikeRepairStepModelDtos[bikeId];
            }
            catch
            {
                return null;
            }
        }
    }
}
