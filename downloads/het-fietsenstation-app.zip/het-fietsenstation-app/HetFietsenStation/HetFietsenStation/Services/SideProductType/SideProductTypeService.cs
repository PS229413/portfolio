﻿using HetFietsenStation.Dtos.SideProductType;
using HetFietsenStation.Models;
using HetFietsenStation.Services.Settings;

namespace HetFietsenStation.Services.SideProductType
{
    public class SideProductTypeService : HttpCallServiceBase, ISideProductTypeService
    {
        public SideProductTypeService(ISettingsService settingsService, bool isUnitTest = false) : base(settingsService, isUnitTest)
        {
            Route = "api/SideProductType";
        }

        //get all the categories that a side product can belong to
        public async Task<IEnumerable<SideProductTypeModel>> GetTypes()
        {
            return await GetAllBase<GetSideProductTypeDto, SideProductTypeModel>(Route, dto => new SideProductTypeModel(dto));
        }

        //add different catagories for side products if needed
        public async Task<bool> AddType(AddSideProductTypeDto addSideProductType)
        {
            return await AddBase(addSideProductType, Route);
        }

        //update side product category
        public async Task<bool> UpdateType(UpdateSideProductTypeDto updateSideProductType)
        {
            return await UpdateBase(updateSideProductType, Route);
        }

        //Delete the sideproduct category when it no longer has any products attached
        public async Task<bool> DeleteType(DeleteSideProductTypeDto deleteSideProductTypeDto)
        {
            return await DeleteBase(deleteSideProductTypeDto, Route);
        }
    }
}
