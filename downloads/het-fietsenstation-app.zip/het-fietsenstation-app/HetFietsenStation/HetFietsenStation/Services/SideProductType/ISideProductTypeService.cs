﻿using HetFietsenStation.Dtos.SideProductType;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.SideProductType
{
    public interface ISideProductTypeService
    {
        public Task<IEnumerable<SideProductTypeModel>> GetTypes();
        public Task<bool> AddType(AddSideProductTypeDto addSideProductType);
        public Task<bool> UpdateType(UpdateSideProductTypeDto updateSideProductType);
        public Task<bool> DeleteType(DeleteSideProductTypeDto deleteSideProductType);
    }
}
