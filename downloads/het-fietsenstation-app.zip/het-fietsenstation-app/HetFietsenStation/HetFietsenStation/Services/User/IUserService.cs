﻿using HetFietsenStation.Dtos.User;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.User
{
    public interface IUserService
    {
        Task<IEnumerable<UserModel>> GetUsers();
        Task<IEnumerable<UserModel>> GetMechanics();
        Task<IEnumerable<RoleModel>> GetRoles();
        Task<string> ValidateUser(VerifyUserDto user);
        Task<bool> AddUser(AddUserDto addUser);
        Task<bool> UpdateUser(UpdateUserDto updateUser);
        Task<bool> DeleteUser(DeleteUserDto deleteUser);
    }
}
