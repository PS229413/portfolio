﻿using HetFietsenStation.Dtos.Role;
using HetFietsenStation.Dtos.User;
using HetFietsenStation.Models;
using HetFietsenStation.Services.Settings;
using System.Text;

namespace HetFietsenStation.Services.User
{
    public class UserService : HttpCallServiceBase, IUserService
    {
        public UserService(ISettingsService settingsService, bool isUnitTest = false) : base(settingsService, isUnitTest)
        {
            Route = "api/User";
        }

        //Obtains all the users
        public async Task<IEnumerable<UserModel>> GetUsers()
        {
            return await GetAllBase<GetUserDto, UserModel>(Route, dto => new UserModel(dto));
        }

        //Obtains all the users that have the role Mechanic
        public async Task<IEnumerable<UserModel>> GetMechanics()
        {
            return await GetAllBase<GetUserDto, UserModel>(Route + "/Mechanics", dto => new UserModel(dto));
        }

        //check if the password and user combo to login iscorrect and if it is return a confirmation
        public async Task<string> ValidateUser(VerifyUserDto user)
        {
            try
            {
                string json = System.Text.Json.JsonSerializer.Serialize(user);

                StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = null;

                response = await Client.PostAsync("api/Auth/login", content);
                string result = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }

                return result;
            }
            catch
            {
                return null;
            }
        }

        //Add the user to the database
        public async Task<bool> AddUser(AddUserDto user)
        {
            return await AddBase(user, "api/Auth/register");
        }

        //updates the user
        public async Task<bool> UpdateUser(UpdateUserDto updateUserDto)
        {
            return await UpdateBase(updateUserDto, "/api/Auth/update");  
        }

        //deletes the user
        public async Task<bool> DeleteUser(DeleteUserDto deleteUser)
        {
            return await DeleteBase(deleteUser, "api/Auth/delete");
        }

        //obtains all the possible roles that a user can be
        public async Task<IEnumerable<RoleModel>> GetRoles()
        {
            return await GetAllBase<GetRoleDto, RoleModel>("api/Role", dto => new RoleModel(dto));
        }
    }
}
