﻿using HetFietsenStation.Dtos.User;
using HetFietsenStation.Enums;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.User
{
    public class UserMockService : IUserService
    {
        List<UserModel> MockUsers = new List<UserModel>()
        {
            new UserModel(1, "user 1", (int)UserRole.Mechanic),
            new UserModel(2, "user 2", (int)UserRole.Mechanic),
            new UserModel(3, "user 3", (int)UserRole.Admin)
        };

        public async Task<IEnumerable<UserModel>> GetUsers()
        {
            try
            {
                return await Task.FromResult(MockUsers);
            }
            catch
            {
                return null;
            }
        }

        public async Task<IEnumerable<UserModel>> GetMechanics()
        {
            try
            {
                List<UserModel> mechanics = MockUsers.Where(mu => mu.Id == (int)UserRole.Mechanic).ToList();

                return await Task.FromResult(mechanics);
            }
            catch
            {
                return null;
            }
        }

        public async Task<string> ValidateUser(VerifyUserDto user)
        {
            try
            {
                UserModel mechanic = MockUsers.Where(mu => mu.Name == user.Name).First();

                return await Task.FromResult("token");

            }
            catch
            {
                return null;
            }
        }

        public async Task<bool> AddUser(AddUserDto user)
        {
            try
            {
                UserModel newUser = new UserModel(MockUsers.Count + 1, user.Name, user.Role);
                MockUsers.Add(newUser);
                return await Task.FromResult(true);
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> UpdateUser(UpdateUserDto updateUser)
        {
            try
            {
                var userToUpdate = MockUsers.FirstOrDefault(mu => mu.Id == updateUser.Id);
                if (userToUpdate == null)
                {
                    return await Task.FromResult(false);
                }

                userToUpdate.Name = updateUser.Name;
                return await Task.FromResult(true);
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> DeleteUser(DeleteUserDto deleteUser)
        {
            try
            {
                var userToDelete = MockUsers.FirstOrDefault(mu => mu.Id == deleteUser.Id);
                if (userToDelete == null)
                {
                    return await Task.FromResult(false);
                }

                MockUsers.Remove(userToDelete);
                return await Task.FromResult(true);
            }
            catch
            {
                return false;
            }
        }

        public async Task<IEnumerable<RoleModel>> GetRoles()
        {
            try
            {
                var roles = Enum.GetValues(typeof(UserRole))
                    .Cast<UserRole>()
                    .Select(r => new RoleModel((int)r, r.ToString(), ""));

                return await Task.FromResult(roles);
            }
            catch
            {
                return null;
            }
        }
    }
}
