﻿using Hetfietsenstation.Models;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.PDF
{
    public interface IPDFService
    {
        public Task<MemoryStream> CreateInvoicePDF(ProductModel[] product, PaymentFinishedFragmentModel payment, SaleModel NewSale);
        public void CreateBarcodePDF();
    }
}