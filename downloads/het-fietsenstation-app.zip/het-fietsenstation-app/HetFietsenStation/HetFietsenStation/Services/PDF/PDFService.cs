﻿using System.Reflection;
using Hetfietsenstation.Models;
using HetFietsenStation.Models;
using Syncfusion.Drawing;
using Syncfusion.Pdf;
using Syncfusion.Pdf.Graphics;
using Syncfusion.Pdf.Grid;

namespace HetFietsenStation.Services.PDF
{
    public class PDFService : IPDFService
    {
	    public PDFService()
	    {
		    Licenser.LicenseSyncFusion();
	    }
	    
        public async Task<MemoryStream> CreateInvoicePDF(ProductModel[] product, PaymentFinishedFragmentModel payment, SaleModel newSale)
        {
	        return await Task.Run(() =>
	        {
		        //Create a PDF document instance
		        PdfDocument document = new PdfDocument();

		        // var font = new PdfTrueTypeFont(fontStream, 12, PdfFontStyle.Regular);

		        //Add page to the document
		        PdfPage page = document.Pages.Add();
		        PdfGraphics graphics = page.Graphics;

		        //Load the image and font as stream
		        Stream fontStream = Assembly.GetExecutingAssembly()
			        .GetManifestResourceStream("HetFietsenStation.Resources.Fonts.hp-simplified.ttf");
		        Stream imageStream = Assembly.GetExecutingAssembly()
			        .GetManifestResourceStream("HetFietsenStation.Resources.Images.logo_lt.png");
		        var baseColor = new PdfSolidBrush(Syncfusion.Drawing.Color.FromArgb(0, 119, 255));

		        PdfBitmap image = new PdfBitmap(imageStream);

		        // Draw the image
		        graphics.DrawImage(image, 0, 20, 100, 25);

		        // Create Text.
		        string Title = "Betaling geslaagd";
		        string SubTitle = "Bedankt voor uw aankoop!";
		        string Declaration =
			        "Met deze aankoop heeft u kennis genomen van en bent u akkoord met onze voorwaarden, deze kunt u " +
			        "ook digitaal vinden via https://wp.me/a9gs4H-1gw.";
		        string endWord =
			        $"Deze Bon wordt gegenereerd door Het FietsenStation App op {DateTime.Now.ToShortDateString()}";

		        string priceEnd = string.Format("{0:N2}", payment.Amount);

		        // Create a text element with the text and font
		        PdfTextElement TitleTextElement = new PdfTextElement(Title,
			        new PdfTrueTypeFont(fontStream, 22, PdfFontStyle.Regular), baseColor);
		        PdfTextElement SubTitleTextElement =
			        new PdfTextElement(SubTitle, new PdfTrueTypeFont(fontStream, 12), PdfBrushes.Black);
		        PdfTextElement DeclarationTextElement =
			        new PdfTextElement(Declaration, new PdfTrueTypeFont(fontStream, 12), PdfBrushes.Black);
		        PdfTextElement EndWordTextElement =
			        new PdfTextElement(endWord, new PdfTrueTypeFont(fontStream, 9), PdfBrushes.LightGray);

		        PdfLayoutFormat layoutFormat = new PdfLayoutFormat
		        {
			        Layout = PdfLayoutType.OnePage,
			        Break = PdfLayoutBreakType.FitPage
		        };

		        RectangleF TitleRectangleF =
			        new RectangleF(0, 85, page.GetClientSize().Width, page.GetClientSize().Height);
		        RectangleF SubTitleRectangleF =
			        new RectangleF(0, 115, page.GetClientSize().Width, page.GetClientSize().Height);
		        RectangleF DeclarationRectangleF =
			        new RectangleF(0, 145, page.GetClientSize().Width, page.GetClientSize().Height);
		        RectangleF endWordRectangleF = new RectangleF(0, page.Size.Height - 100, page.GetClientSize().Width,
			        page.GetClientSize().Height);

		        // Draw the first paragraph
		        TitleTextElement.Draw(page, TitleRectangleF, layoutFormat);
		        SubTitleTextElement.Draw(page, SubTitleRectangleF, layoutFormat);
		        DeclarationTextElement.Draw(page, DeclarationRectangleF, layoutFormat);
		        EndWordTextElement.Draw(page, endWordRectangleF, layoutFormat);

		        // Create a new PdfGrid. (To make a table)

		        PdfGridCellStyle GridRowsTwoStyle = new PdfGridCellStyle
		        {
			        TextBrush = baseColor,
			        Font = new PdfTrueTypeFont(fontStream, 20),
			        StringFormat = new PdfStringFormat
			        {
				        Alignment = PdfTextAlignment.Left,
				        LineAlignment = PdfVerticalAlignment.Bottom,
			        },
		        };

		        GridRowsTwoStyle.Borders.Left.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        GridRowsTwoStyle.Borders.Right.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        GridRowsTwoStyle.Borders.Bottom.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        GridRowsTwoStyle.Borders.Top.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);

		        PdfGridCellStyle overviewTotalStyle = new PdfGridCellStyle
		        {
			        TextBrush = baseColor,
			        Font = new PdfTrueTypeFont(fontStream, 13),
		        };

		        //Borders style
		        overviewTotalStyle.Borders.Left.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        overviewTotalStyle.Borders.Right.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        overviewTotalStyle.Borders.Top.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        overviewTotalStyle.Borders.Bottom.Color = new PdfColor(Syncfusion.Drawing.Color.LightGray);

		        PdfGrid overview = new PdfGrid();
		        overview.Columns.Add(3);
		        overview.Columns[0].Width = 290;

		        PdfGridRow header = overview.Headers.Add(1)[0];
		        header.Cells[0].Value = "Omschrijving";
		        header.Cells[1].Value = "Prijs per stuk";
		        header.Cells[2].Value = "Totaal";

		        PdfGridCellStyle overviewStyle = new PdfGridCellStyle
		        {
			        TextBrush = PdfBrushes.Black,
			        Font = new PdfTrueTypeFont(fontStream, 10),
		        };

		        //Borders style
		        overviewStyle.Borders.Left.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        overviewStyle.Borders.Right.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        overviewStyle.Borders.Bottom.Color = new PdfColor(Syncfusion.Drawing.Color.LightGray);
		        overviewStyle.Borders.Top.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);

		        var size = new Syncfusion.Drawing.PointF(0, 300);

		        // TODO: iterate over multiple products, create new row for each

		        var options = new ParallelOptions
		        {
			        MaxDegreeOfParallelism = Environment.ProcessorCount // Set the maximum number of threads to the number of available CPU cores.
		        };

		        // TODO: iterate over multiple products, create a new row for each using Parallel.ForEach

		        Parallel.ForEach(product, options, (products, state) =>
		        {
			        string priceFull = string.Format("{0:N2}", products.Price);

			        PdfGridRow rowPrice = overview.Rows.Add();
			        rowPrice.Height = 35;
			        rowPrice.Cells[0].Value = $"1  {payment.Description}";   // Description Model type id
			        rowPrice.Cells[1].Value = $"{priceFull}";                // price
			        rowPrice.Cells[2].Value = $"{priceFull}";                // total

			        rowPrice.ApplyStyle(overviewStyle);
			        rowPrice.Cells[2].Style = overviewTotalStyle;

			        size.Y += 35;
		        });

		        //Initialize PdfGridCellStyle.
		        PdfGridCellStyle GridHeaderStyle = new PdfGridCellStyle
		        {
			        TextBrush = PdfBrushes.Black,
			        Font = new PdfTrueTypeFont(fontStream, 12, PdfFontStyle.Regular),
		        };

		        //Borders style
		        GridHeaderStyle.Borders.Left.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        GridHeaderStyle.Borders.Right.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        GridHeaderStyle.Borders.Top.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        GridHeaderStyle.Borders.Bottom.Color = new PdfColor(Syncfusion.Drawing.Color.LightGray);

		        //Grid Two
		        PdfGridCellStyle GridTowRowsStyle = new PdfGridCellStyle
		        {
			        TextBrush = new PdfSolidBrush(Syncfusion.Drawing.Color.FromArgb(153, 153, 153)),
			        Font = new PdfTrueTypeFont(fontStream, 10),
			        BackgroundBrush = new PdfSolidBrush(Syncfusion.Drawing.Color.FromArgb(248, 248, 248)),
			        CellPadding = new PdfPaddings(10, 10, 15, 0),
			        StringFormat = new PdfStringFormat
			        {
				        Alignment = PdfTextAlignment.Left,
				        LineAlignment = PdfVerticalAlignment.Top,
			        }
		        };

		        //Borders style
		        GridTowRowsStyle.Borders.Left.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        GridTowRowsStyle.Borders.Right.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        GridTowRowsStyle.Borders.Bottom.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        GridTowRowsStyle.Borders.Top.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);

		        PdfGridCellStyle GridTotalStyleTwo = new PdfGridCellStyle
		        {
			        TextBrush = baseColor,
			        Font = new PdfTrueTypeFont(fontStream, 22),
			        StringFormat = new PdfStringFormat
			        {
				        Alignment = PdfTextAlignment.Right,
				        LineAlignment = PdfVerticalAlignment.Middle,
			        },
		        };

		        //Borders style
		        GridTotalStyleTwo.Borders.Left.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        GridTotalStyleTwo.Borders.Right.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        GridTotalStyleTwo.Borders.Top.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        GridTotalStyleTwo.Borders.Bottom.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);

		        //Apply style
		        PdfGridRow GridHeader = overview.Headers[0];
		        GridHeader.ApplyStyle(GridHeaderStyle);


		        PdfStringFormat ColumnsStringFormatV1 = new PdfStringFormat
		        {
			        Alignment = PdfTextAlignment.Left,
			        LineAlignment = PdfVerticalAlignment.Middle,
		        };
		        PdfStringFormat ColumnsStringFormatV2 = new PdfStringFormat
		        {
			        Alignment = PdfTextAlignment.Right,
			        LineAlignment = PdfVerticalAlignment.Middle,
		        };

		        // Apply Columns String Formats

		        overview.Columns[0].Format = ColumnsStringFormatV1;
		        overview.Columns[1].Format = ColumnsStringFormatV2;
		        overview.Columns[2].Format = ColumnsStringFormatV2;

		        if (newSale.SubsidyType != SubsidyType.None)
		        {
			        PdfGridRow pdfGridRowSubsidy = overview.Rows.Add();

			        pdfGridRowSubsidy.Height = 35;
			        pdfGridRowSubsidy.Cells[0].Value = $"Subsidy"; //Description Model type id
			        pdfGridRowSubsidy.Cells[1].Value = $"Gezinsnummer: {newSale.SubsidyReference}"; // type
			        pdfGridRowSubsidy.Cells[2].Value = $"-{newSale.SubsidyValue}"; // total

			        pdfGridRowSubsidy.ApplyStyle(overviewStyle);
			        pdfGridRowSubsidy.Cells[2].Style = overviewTotalStyle;

			        size.Y += 35;
		        }

		        PdfGridRow rowTotal = overview.Rows.Add();
		        rowTotal.Height = 60;
		        rowTotal.Cells[0].Value = $"Totaal, {product.Length} product"; // Description
		        rowTotal.Cells[1].Value = ""; // Description
		        rowTotal.Cells[2].Value = $"€ {priceEnd}"; // total

		        // Set style for total row

		        PdfGridCellStyle s = new PdfGridCellStyle
		        {
			        TextBrush = baseColor,
			        Font = new PdfTrueTypeFont(fontStream, 16),
			        StringFormat = new PdfStringFormat
			        {
				        Alignment = PdfTextAlignment.Left,
				        LineAlignment = PdfVerticalAlignment.Bottom,
			        }
		        };

		        s.Borders.Left.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        s.Borders.Right.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        s.Borders.Bottom.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);
		        s.Borders.Top.Color = new PdfColor(Syncfusion.Drawing.Color.Transparent);

		        rowTotal.ApplyStyle(s);

		        var s2 = s.Clone() as PdfGridCellStyle;
		        s2.StringFormat = new PdfStringFormat
		        {
			        Alignment = PdfTextAlignment.Right,
			        LineAlignment = PdfVerticalAlignment.Bottom,
		        };
		        s2.Font = overviewTotalStyle.Font;

		        rowTotal.Cells[2].Style = s2;

		        // Create details block

		        PdfGrid details = new PdfGrid();
		        details.Columns.Add(2);

		        PdfGridRow row = details.Rows.Add();
		        row.Height = 60;
		        row.Cells[0].Value = $"Datum:{payment.Datetime}\n UUID:{newSale.Uuid}";
		        row.Cells[1].Value = $"Transactie ID:{payment.TransactionId}\nContant betaald: {priceEnd}";

		        details.Rows[0].ApplyStyle(GridTowRowsStyle);

		        details.Draw(page, size);

		        overview.Draw(page, new Syncfusion.Drawing.PointF(0, 200));

		        MemoryStream stream = new MemoryStream();
		        document.Save(stream);
		        document.Close(true);

		        return stream;
	        });
        }

        public void CreateBarcodePDF()
        {
            //TODO: Create barcode PDF
        }

         async Task<MemoryStream> GetImageFromStream(Uri url)
        {
	        using HttpClient client = new HttpClient();
	        
	        byte[] bytes = await client.GetByteArrayAsync(url);
	        return new MemoryStream(bytes);
        }
    }
}