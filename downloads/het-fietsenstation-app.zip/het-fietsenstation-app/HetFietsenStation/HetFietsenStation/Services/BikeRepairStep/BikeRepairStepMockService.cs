﻿using HetFietsenStation.Dtos.BikeRepairStep;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeRepairStep
{
    public class BikeRepairStepMockService : IBikeRepairStepService
    {
        List<RepairBikeModel> RepairBikes = new List<RepairBikeModel>()
        {
            new RepairBikeModel { Id = 1, 
                RepairSteps = new List<RepairStepModel>()
                {
                    new RepairStepModel(1, "repair step 1", "description", true, false),
                    new RepairStepModel(2, "repair step 2", "description", true, true)
                } 
            },

            new RepairBikeModel { Id = 2, 
                RepairSteps = new List<RepairStepModel>()
                {
                    new RepairStepModel(1, "repair step 1", "description", true, true),
                    new RepairStepModel(2, "repair step 2", "description", true, false)
                } 
            }
        };

        public async Task<bool> UpdateBikeRepairStep(UpdateBikeRepairStepDto bikeRepairStep)
        {
            try
            {
                await Task.Delay(10);

                RepairBikeModel repairBikeResult = RepairBikes.Where(rb => rb.Id == bikeRepairStep.BikeId).First();

                foreach (RepairStepModel repairStep in repairBikeResult.RepairSteps) 
                { 
                    if(repairStep.Id == bikeRepairStep.RepairStepId)
                    {
                        repairStep.Done = bikeRepairStep.Done;
                        return true;
                    }
                }

                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
