﻿using HetFietsenStation.Services.Settings;
using HetFietsenStation.Dtos.BikeRepairStep;

namespace HetFietsenStation.Services.BikeRepairStep
{
    //Service responsible for BikeRepairSteps
    public class BikeRepairStepService : HttpCallServiceBase, IBikeRepairStepService
    {
        //Constructor which injects the a object which implments the ISettingsService interface
        public BikeRepairStepService(ISettingsService settingsService, bool isUnitTest = false) : base(settingsService, isUnitTest) 
        {
            Route = "api/BikeRepairStep";
        }

        //Function which is responsible for updating exising a BikeRepairStep
        public async Task<bool> UpdateBikeRepairStep(UpdateBikeRepairStepDto bikeRepairStep)
        {
            return await UpdateBase(bikeRepairStep, Route);
        }
    }
}
