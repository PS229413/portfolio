﻿using HetFietsenStation.Dtos.BikeRepairStep;

namespace HetFietsenStation.Services.BikeRepairStep
{
    public interface IBikeRepairStepService
    {
        Task<bool> UpdateBikeRepairStep(UpdateBikeRepairStepDto bikeRepairStep);
    }
}
