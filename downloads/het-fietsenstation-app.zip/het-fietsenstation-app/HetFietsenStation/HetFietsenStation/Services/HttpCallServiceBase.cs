﻿using CommunityToolkit.Maui.Alerts;
using CommunityToolkit.Maui.Core;
using HetFietsenStation.Containers;
using HetFietsenStation.Services.Settings;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace HetFietsenStation.Services
{
    public abstract class HttpCallServiceBase
    {
        //HttpClient object responsible for http related functions
        public HttpClient Client { get; set; }

        //Contains the authentication token
        string Token = "";

        //Contains the service default API route
        protected string Route = "";

        //Refrence to a object which implements the ISettingsService interface
        private ISettingsService SettingsService { get; set; }

        //Constructor which injects the a object which implments the ISettingsService interface
        public HttpCallServiceBase(ISettingsService settingsService, bool isUnitTest = false)
        {
            //Sets the SettingsService
            SettingsService = settingsService;
            //Sets the BaseUrl of the API from the SettingService
            Client = new HttpClient { BaseAddress = new Uri(SettingsService.ApiBaseUrl), Timeout = TimeSpan.FromSeconds(10) };
            //Sets the async token variable
            if (!isUnitTest)
            {
                Task.Run(async () => { await SetToken(); }).Wait();
                Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
            }
        }

        private async Task SetToken(bool debug = false)
        {
            if (debug)
            {
                await SecureStorage.Default.SetAsync("oauth_token", "eyJhbGciOiJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGRzaWctbW9yZSNobWFjLXNoYTUxMiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoibWVjaGFuaWMiLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiJtZWNoYW5pYyIsImV4cCI6MTY3ODc3NjU5NH0.RETQ1M9FnEM1yM4dkkMU69YtDF_YdLD2svDApmB0Tbe1WMDpgurL8CQHDXR7mQ2QO6A8Gx5Z4k7qQIDZNVLZPQ");
            }

            // var tokenJson = await SecureStorage.Default.GetAsync("oauth_token");
            //
            // // Extract the token value from the JSON
            // var tokenObject = JObject.Parse(tokenJson);
            // Token = tokenObject.Value<string>("token");
            
            Token = await SecureStorage.Default.GetAsync("oauth_token");
        }

        //application wide function to use to obtain data from database based on the route and model that was sent from the service. This is specific for data where everything from the table need to be fetched
        protected async Task<IEnumerable<TModel>> GetAllBase<TDto, TModel>(string route, Func<TDto, TModel> createModelFunc)
            where TDto : class
        {
            try
            {
                //go to the get endpoint with thich has the address that was send through the route
                HttpResponseMessage response = await Client.GetAsync(route);

                //check if the connection was succesfull and if there were data retrieved
                if (!response.IsSuccessStatusCode)
                {
                    return Enumerable.Empty<TModel>();
                }

                //set the data string to a json string
                string json = await response.Content.ReadAsStringAsync();

                //transform the json string into a list that contains the dto that was send
                var result = JsonConvert.DeserializeObject<JsonContainerList<TDto>>(json);

                var output = new List<TModel>();

                //put the data into the list
                foreach (TDto dto in result.data)
                {
                    output.Add(createModelFunc(dto));
                }

                return output;
            }
            //if it fails then return an empty enumerable
            catch
            {
                return Enumerable.Empty<TModel>();
            }
        }

        //get the data from the database depending on the route, dto and model that was sent together
        protected async Task<TModel> GetBase<TDto, TModel>(string route, Func<TDto, TModel> createModelFunc)
            where TDto : class
            where TModel : class
        {
            try
            {
                //obtain the data from the get endpoint from the route
                HttpResponseMessage response = await Client.GetAsync(route);

                //check if the connection was succesfull and no error happened
                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }

                //create a json string data from the data
                string json = await response.Content.ReadAsStringAsync();

                //convert the json string to the form of the dto that was sent
                var result = JsonConvert.DeserializeObject<JsonContainerSingle<TDto>>(json);

                //set the value of this local dto value to the result even if its null
                var dto = result?.data;

                if (dto == null)
                {
                    return null;
                }
                //create a model
                var model = createModelFunc(dto);

                return model;
            }
            catch
            {
                return null;
            }
        }

        protected async Task<bool> UpdateBase<TDto>(TDto dto, string route)
            where TDto : class
        {
            try
            {
                // Serialize the DTO to JSON
                var jsonData = System.Text.Json.JsonSerializer.Serialize(dto);

                // Create an HttpContent object from the JSON data
                var content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                // Send the HTTP request to the API endpoint
                var response = await Client.PutAsync(route, content);

                // Read the response content as string
                var result = await response.Content.ReadAsStringAsync();

                // Return null if the response status code indicates failure
                if (!response.IsSuccessStatusCode)
                {
                    return false;
                }

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                var toast = Toast.Make($"{dto.GetType().Name.Replace("Dto", "").Replace("Update", "")} aangepast", ToastDuration.Short);
                await toast.Show(cancellationTokenSource.Token);

                return true;
            }
            catch
            {
                return false;
            }
        }

        protected async Task<bool> DeleteBase<TDto>(TDto dto, string route)
            where TDto : class
        {
            try
            {
                // Serialize the DTO to JSON
                var jsonData = System.Text.Json.JsonSerializer.Serialize(dto);

                // Create an HttpContent object from the JSON data
                var content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                // Send the HTTP request to the API endpoint
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Delete,
                    RequestUri = new Uri(route, UriKind.Relative),
                    Content = content
                };
                var response = await Client.SendAsync(request);

                // Read the response content as string
                var result = await response.Content.ReadAsStringAsync();

                // Return null if the response status code indicates failure
                if (!response.IsSuccessStatusCode)
                {
                    return false;
                }

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                var toast = Toast.Make($"{dto.GetType().Name.Replace("Dto", "").Replace("Delete", "")} verwijderd", ToastDuration.Short);
                await toast.Show(cancellationTokenSource.Token);

                return true;
            }
            catch
            {
                return false;
            }
        }

        protected async Task<bool> AddBase<TDto>(TDto dto, string route)
            where TDto : class
        {
            try
            {
                // Serialize the DTO to JSON
                var jsonData = System.Text.Json.JsonSerializer.Serialize(dto);

                // Create an HttpContent object from the JSON data
                var content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                // Send the HTTP request to the API endpoint
                var response = await Client.PostAsync(route, content);

                // Read the response content as string
                var result = await response.Content.ReadAsStringAsync();

                // Return null if the response status code indicates failure
                if (!response.IsSuccessStatusCode)
                {
                    return false;
                }

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                var toast = Toast.Make($"{dto.GetType().Name.Replace("Dto", "").Replace("Add", "")} toegevoegd", ToastDuration.Short);
                await toast.Show(cancellationTokenSource.Token);

                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
