﻿namespace HetFietsenStation.Services.PrintAndView
{
    public interface IPrintAndViewService
    {
        // Method to save document as a file and view the saved document
        Task SaveAndView(string filename, string directory, string contentType, MemoryStream stream);
    }
}