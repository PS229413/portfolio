﻿#if ANDROID
using Android;
using Android.App;
using Android.Content;
using Android.Content.PM;
using AndroidX.Core.App;
using AndroidX.Core.Content;
using Java.IO;
using FileProvider = Microsoft.Maui.Storage.FileProvider;

namespace HetFietsenStation.Services.PrintAndView
{
    public class PrintAndViewAndroidService : IPrintAndViewService
    {
        internal static PrintAndViewAndroidService Instance;
        
        private readonly Context CurrentContext = MainActivity.Instance;

        private string Root = null;

        public string FileName { get; set; }
        public string Directory { get; set; }
        public string ContentType { get; set; }
        public MemoryStream Stream { get; set; }


        // Method to save document as a file in Android and view the saved document
        public async Task SaveAndView(string fileName, string directory, String contentType, MemoryStream stream)
        {
            Instance = this;
            FileName = fileName;
            Directory = directory;
            ContentType = contentType;
            Stream = stream;
            await CheckStoragePermission();
        }

        private void ProcessPrinting()
        {
			Root = Android.OS.Environment.IsExternalStorageEmulated ? Android.OS.Environment.ExternalStorageDirectory.ToString()
																	: Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            Java.IO.File myDir = new Java.IO.File(Root + $"/{Directory}");
            myDir.Mkdir();

            Java.IO.File file = new Java.IO.File(myDir, FileName);

            if (file.Exists())
				file.Delete();

            try
            {
                FileOutputStream outs = new FileOutputStream(file);
                outs.Write(Stream.ToArray());

                outs.Flush();
                outs.Close();
            }
            catch (Exception e)
            {
                Android.Util.Log.Error("Error", e.Message);
            }
            finally
            {
                if (file.Exists() && ContentType != "application/html")
                {
                    string extension = Android.Webkit.MimeTypeMap.GetFileExtensionFromUrl(Android.Net.Uri.FromFile(file).ToString());
                    string mimeType = Android.Webkit.MimeTypeMap.Singleton.GetMimeTypeFromExtension(extension);
                    Intent intent = new Intent(Intent.ActionView);
                    intent.SetFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask);
                    Android.Net.Uri path = FileProvider.GetUriForFile(CurrentContext, Android.App.Application.Context.PackageName + ".provider", file);
                    intent.SetDataAndType(path, mimeType);
                    intent.AddFlags(ActivityFlags.GrantReadUriPermission);
                    CurrentContext.StartActivity(intent);
                }
            }
        }

        private async Task CheckStoragePermission()
        {
            await Task.Factory.StartNew(() =>
            {
                if (ContextCompat.CheckSelfPermission(CurrentContext, Manifest.Permission.WriteExternalStorage) != Permission.Granted)
                    ActivityCompat.RequestPermissions((Activity)CurrentContext, new string[] { Manifest.Permission.WriteExternalStorage }, 200);
                else
                    ProcessPrinting();
            });
        }
    }
}
#endif