﻿using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeColor
{
    public class BikeColorMockService : IBikeColorService
    {
        List<BikeColorModel> BikeColors = new List<BikeColorModel>
        {
            new BikeColorModel(1, "color 1", "description", "#FFFFFF"),
            new BikeColorModel(2, "color 2", "description", "#000000")
        };

        public async Task<IEnumerable<BikeColorModel>> GetAllBikeColors()
        {
            try
            {
                await Task.Delay(10);

                return BikeColors;
            }
            catch
            {
                return null;
            }
        }
    }
}
