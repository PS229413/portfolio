﻿using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeColor
{
    public interface IBikeColorService
    {
        Task<IEnumerable<BikeColorModel>> GetAllBikeColors();
    }
}
