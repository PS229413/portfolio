﻿using HetFietsenStation.Dtos.BikeColor;
using HetFietsenStation.Models;
using HetFietsenStation.Services.Settings;

namespace HetFietsenStation.Services.BikeColor
{
    public class BikeColorService : HttpCallServiceBase, IBikeColorService
    {
        public BikeColorService(ISettingsService settingsService, bool isUnitTest = false) : base(settingsService, isUnitTest) 
        {
            Route = "api/BikeColor";
        }

        //obtain all the possible options for a bike from the database
        public async Task<IEnumerable<BikeColorModel>> GetAllBikeColors()
        {
            return await GetAllBase<GetBikeColorDto, BikeColorModel>(Route, dto => new BikeColorModel(dto));
        }
    }
}
