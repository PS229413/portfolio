﻿using HetFietsenStation.Dtos;
using HetFietsenStation.Dtos.SideProduct;
using HetFietsenStation.Models;
using HetFietsenStation.Services.Settings;
using Newtonsoft.Json;
using System.Text;

namespace HetFietsenStation.Services.SideProduct
{
    public class SideProductService : HttpCallServiceBase, ISideProductService
    {
        public SideProductService(ISettingsService settingsService, bool isUnitTest = false) : base(settingsService, isUnitTest) 
        {
            Route = "api/SideProduct";
        }

        //get a single side product
        public async Task<SideProductModel> GetSideProduct(int sideProductId)
        {
            return await GetBase<GetSideProductDto, SideProductModel>(Route + "/" + sideProductId, dto => new SideProductModel(dto));
        }

        //add a side product
        public async Task<bool> AddSideProduct(AddSideProductDto sideProduct, List<string> imagePaths)
        {
            // create a json string to send to create a string content
            string json = System.Text.Json.JsonSerializer.Serialize(sideProduct);
            HttpResponseMessage response = null;
            //make a string content that get sends to the API
            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

            //send the data to the API
            response = await Client.PostAsync(Route, content);

            if (response.IsSuccessStatusCode != true)
            {
                return false;
            }

            // Get the id of the product by sending a request to the lastAdded route
            var responseLast = await Client.GetAsync(Route + "/lastAdded");

            if (responseLast.IsSuccessStatusCode != true)
            {
                return false;
            }

            var jsonString = await responseLast.Content.ReadAsStringAsync();
            dynamic jsonO = JsonConvert.DeserializeObject(jsonString);
            string id = jsonO.data.id;

#if ANDROID
            // Upload the image(s) to the server
            var i = 0;

            var Form = new MultipartFormDataContent();

            HttpContent stringContent = new StringContent(id);
            Form.Add(stringContent, "Id");
            Form.Add(new StringContent("Product"), "Type");

            foreach (string image in imagePaths)
            {
                i++;
                var fileContent = new StreamContent(File.OpenRead(Path.Combine(FileSystem.AppDataDirectory, image)));
                fileContent.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("form-data")
                {
                    Name = $"Files",
                    FileName = $"test{i}.jpeg"
                };
                Form.Add(fileContent);

            }

            AddPhotoDto repairBikePhoto = new AddPhotoDto(Form);
            response = await Client.PostAsync("api/PhotographyBike/AddPhoto", Form);

            if (response.IsSuccessStatusCode != true)
            {
                return false;
            }
#endif
            return true;
        }

        //obtain all the sideproducts
        public async Task<IEnumerable<SideProductModel>> GetAllSideProducts()
        {
            return await GetAllBase<GetSideProductDto, SideProductModel>(Route, dto => new SideProductModel(dto));
        }

        //update the sideproduct
        public async Task<bool> UpdateSideProduct(UpdateSideProductDto updateSideProductDto)
        {
            return await UpdateBase(updateSideProductDto, Route);
        }
    }
}
