﻿using HetFietsenStation.Dtos.SideProduct;
using HetFietsenStation.Dtos.SideProductType;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.SideProduct
{
    public class SideProductMockService : ISideProductService
    {
        private readonly List<SideProductModel> _sideProducts;

        public SideProductMockService()
        {
            // Initialize the list of side products with some sample data
            _sideProducts = new List<SideProductModel>
            {
                new SideProductModel(1, "Bike Helmet", "Safety first!", new List<ImageModel> { new ImageModel { Id = 1, Url = "https://example.com/helmet.png" } }, 1999, 10, new SideProductTypeModel(new GetSideProductTypeDto(1, "Safety", ""))),
                new SideProductModel(2, "Bike Lock", "Keep your bike safe and secure", new List<ImageModel> { new ImageModel { Id = 2, Url = "https://example.com/lock.png" } }, 2999, 5, new SideProductTypeModel(new GetSideProductTypeDto(1, "Safety", ""))),
                new SideProductModel(3, "Water Bottle", "Stay hydrated on your ride", new List<ImageModel> { new ImageModel { Id = 3, Url = "https://example.com/bottle.png" } }, 999, 20, new SideProductTypeModel(new GetSideProductTypeDto(2, "Accessories", ""))),
                new SideProductModel(4, "Repair Kit", "Fix your bike on the go", new List<ImageModel> { new ImageModel { Id = 4, Url = "https://example.com/kit.png" } }, 3999, 3, new SideProductTypeModel(new GetSideProductTypeDto(3, "Maintenance", "")))

            };
        }

        public Task<SideProductModel> GetSideProduct(int sideProductId)
        {
            return Task.FromResult(_sideProducts.FirstOrDefault(p => p.Id == sideProductId));
        }

        public Task<bool> AddSideProduct(AddSideProductDto sideProduct, List<string> imagePaths)
        {
            // Create a new side product model from the DTO and add it to the list
                _sideProducts.Add(new SideProductModel(
                _sideProducts.Max(p => p.Id) + 1,
                sideProduct.Name,
                sideProduct.Price.ToString(),
                imagePaths.Select(path => new ImageModel { Id = GetNextImageId(), Url = path }).ToList(),
                sideProduct.SideproductTypeId,
                0,
                null));

            return Task.FromResult(true);
        }

        public Task<IEnumerable<SideProductModel>> GetAllSideProducts()
        {
            return Task.FromResult<IEnumerable<SideProductModel>>(_sideProducts);
        }

        public Task<bool> UpdateSideProduct(UpdateSideProductDto updateSideProductDto)
        {
            // Find the side product to update by its ID
            SideProductModel sideProduct = _sideProducts.FirstOrDefault(p => p.Id == updateSideProductDto.Id);
            if (sideProduct == null)
            {
                return Task.FromResult(false);
            }

            // Update the properties of the side product model
            sideProduct.Name = updateSideProductDto.Name;
            sideProduct.Price = updateSideProductDto.Price;
            sideProduct.SideProductType.Id = updateSideProductDto.SideproductTypeId;

            return Task.FromResult(true);
        }

        private int GetNextImageId()
        {
            int maxId = _sideProducts.SelectMany(p => p.Images).Max(i => i.Id);
            return maxId + 1;
        }
    }
}
