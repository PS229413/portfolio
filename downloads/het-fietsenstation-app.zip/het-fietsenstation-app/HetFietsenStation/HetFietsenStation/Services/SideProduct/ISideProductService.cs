﻿using HetFietsenStation.Dtos.SideProduct;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.SideProduct
{
    public interface ISideProductService
    {
        Task<SideProductModel> GetSideProduct(int sideProductId);
        Task<bool> AddSideProduct(AddSideProductDto sideProduct, List<string> imagePaths);
        Task<IEnumerable<SideProductModel>> GetAllSideProducts();
        Task<bool> UpdateSideProduct(UpdateSideProductDto updateSideProductDto);
    }
}
