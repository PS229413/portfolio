﻿using HetFietsenStation.Containers;
using HetFietsenStation.Dtos.Product;
using HetFietsenStation.Dtos.SideProduct;
using HetFietsenStation.Dtos.User;
using HetFietsenStation.Models;
using HetFietsenStation.Services.Settings;
using Newtonsoft.Json;

namespace HetFietsenStation.Services.Bike
{
    public class BikeService : HttpCallServiceBase, IBikeService
    {
        public BikeService(ISettingsService settingsService, bool isUnitTest = false) : base(settingsService, isUnitTest) 
        {
            Route = "api/Bike";
        }

        //get all the bikes whether they need to be repaired or are ready to be sold
        public async Task<IEnumerable<BikeModel>> GetAllBikes()
        {
            try
            {
                HttpResponseMessage response = await Client.GetAsync(Route + "/all");

                var output = new List<BikeModel>(); // Make a list of bikes

                if (!response.IsSuccessStatusCode)
                {
                    return output;
                }

                string json = await response.Content.ReadAsStringAsync();

                JsonContainerList<GetBikeDto> result = JsonConvert.DeserializeObject<JsonContainerList<GetBikeDto>>(json);

                foreach (GetBikeDto dto in result.data)
                {
                    if (dto.Mechanic == null)
                    {
                        dto.Mechanic = new GetUserDto(0, "-", 0); // If mechanic is null display "-"
                    }
                    output.Add(new BikeModel(dto)); // Add bikemodel to the output
                }

                return output;
            }
            catch
            {
                return null;
            }
        }

        //obtain a single bike
        public async Task<BikeModel> GetBike(int bikeId)
        {
            return await GetBase<GetBikeDto, BikeModel>(Route + "/" + bikeId, dto => new BikeModel(dto));
         }
        
        //update the bike
        public async Task<bool> UpdateBike(UpdateBikeDto bike)
        {
            return await UpdateBase(bike, Route);
        }

        //get all the bikes that have already been repaired and are ready to be sold
        public async Task<IEnumerable<BikeModel>> GetRepairedBikes()
        {
            try
            {
                //go to the endpoint where all of the repaired bikes are being retrieved
                HttpResponseMessage response = await Client.GetAsync(Route + "/Repaired");

                var output = new List<BikeModel>(); // Make a list of repaired bikes

                //checks if the retrieving of the bikes was succesfull and if not return the message
                if (!response.IsSuccessStatusCode)
                {
                    return output;
                }

                string json = await response.Content.ReadAsStringAsync();

                //Turn the retrieved data back from json to a dto
                JsonContainerList<GetBikeDto> result = JsonConvert.DeserializeObject<JsonContainerList<GetBikeDto>>(json);

                foreach (GetBikeDto dto in result.data)
                {
                    if (dto.Mechanic == null)
                    {
                        dto.Mechanic = new GetUserDto(0, "-", 0); // If mechanic is null display "-"
                    }
                    output.Add(new BikeModel(dto)); // Add bike to output
                }

                return output;
            }
            catch
            {
                return null;
            }
        }

        // Add image for bike
        public async Task<bool> AddBikeImage(int bikeId, string imagePath)
        {
            try
            {
                var Form = new MultipartFormDataContent(); // Make a new multipart form

                HttpContent stringContent = new StringContent(bikeId.ToString()); // Bike ID
                Form.Add(stringContent, "Id"); // Add the bike id as Param "Id"
                Form.Add(new StringContent("Bike"), "Type"); // Add the type of image (Bike)

                var fileContent = new StreamContent(File.OpenRead(imagePath)); // Read the image path provided 
                fileContent.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("form-data"); // Set the headers to specify it is form-data
                Form.Add(fileContent, "Image", Path.GetFileName(imagePath)); // Add the file stream to the form with param "Image"

                HttpResponseMessage response = await Client.PostAsync("api/PhotographyBike/AddPhoto", Form); // Send it!

                if (!response.IsSuccessStatusCode)
                {
                    return false;
                }

                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
