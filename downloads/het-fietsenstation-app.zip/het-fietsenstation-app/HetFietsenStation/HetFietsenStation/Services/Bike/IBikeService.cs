﻿using HetFietsenStation.Dtos.SideProduct;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.Bike
{
    public interface IBikeService
    {
        Task<IEnumerable<BikeModel>> GetAllBikes();
        Task<BikeModel> GetBike(int bikeId);
        Task<bool> UpdateBike(UpdateBikeDto bike);
        Task<IEnumerable<BikeModel>> GetRepairedBikes();
        Task<bool> AddBikeImage(int bikeId, string imagePath);
    }
}