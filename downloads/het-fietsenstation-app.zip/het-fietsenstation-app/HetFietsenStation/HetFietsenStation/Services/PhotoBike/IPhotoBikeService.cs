﻿using HetFietsenStation.Dtos.PhotoBike;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.PhotoBike
{
    public interface IPhotoBikeService
    {
        public Task<IEnumerable<PhotoBikeModel>> GetBikes();
        public Task<bool> UpdatePhotoBike(UpdatePhotoBikeDto photoBike);
    }
}