﻿using HetFietsenStation.Containers;
using HetFietsenStation.Dtos.PhotoBike;
using HetFietsenStation.Dtos.User;
using HetFietsenStation.Models;
using HetFietsenStation.Services.Settings;
using Newtonsoft.Json;

namespace HetFietsenStation.Services.PhotoBike
{
    public class PhotoBikeService : HttpCallServiceBase, IPhotoBikeService
    {
        public PhotoBikeService(ISettingsService settingsService, bool isUnitTest = false) : base(settingsService, isUnitTest) 
        {
            Route = "api/Bike";
        }
        
        //obtain all the bikes from the database
        public async Task<IEnumerable<PhotoBikeModel>> GetBikes()
        {
            try
            {
                HttpResponseMessage response = await Client.GetAsync(Route + "/all"); // Get the bikes

                List<PhotoBikeModel> output = new List<PhotoBikeModel>(); // Make a list of bikes

                if (!response.IsSuccessStatusCode) //check if the bikes were obtained
                {
                    return output;
                }

                string json = await response.Content.ReadAsStringAsync();

                JsonContainerList<GetPhotoBikeDto> result = JsonConvert.DeserializeObject<JsonContainerList<GetPhotoBikeDto>>(json); //transform the json string into a list of which contains dto's

                foreach (GetPhotoBikeDto dto in result.data)
                {
                    if (dto.Mechanic == null)
                    {
                        dto.Mechanic = new GetUserDto(0, "-", 0); // Display "-" if no mechanic 
                    }
                    output.Add(new PhotoBikeModel(dto)); // Add bike to output
                }

                return output;
            }
            catch
            {
                return null;
            }
        }

        //update the photo bike
        public async Task<bool> UpdatePhotoBike(UpdatePhotoBikeDto photobike)
        {
            return await UpdateBase(photobike, Route);
        }
    }
}
