﻿using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeSource
{
    public interface IBikeSourceService
    {
        Task<IEnumerable<BikeSourceModel>> GetBikeSources();
    }
}
