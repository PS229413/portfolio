﻿using HetFietsenStation.Dtos.BikeSource;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeSource
{
    public class BikeSourceService : HttpCallServiceBase, IBikeSourceService
    {
        public BikeSourceService(ISettingsService settingsService, bool isUnitTest = false) : base(settingsService, isUnitTest)
        {
            Route = "api/BikeSource";
        }

        public async Task<IEnumerable<BikeSourceModel>> GetBikeSources()
        {
            return await GetAllBase<GetBikeSourceDto, BikeSourceModel>(Route, dto => new BikeSourceModel(dto));
        }
    }
}
