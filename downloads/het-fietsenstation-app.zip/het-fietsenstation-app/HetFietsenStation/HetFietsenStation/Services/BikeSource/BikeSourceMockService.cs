﻿using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeSource
{
    public class BikeSourceMockService : IBikeSourceService
    {
        List<BikeSourceModel> BikeSources = new List<BikeSourceModel>
        {
            new BikeSourceModel(1, "source 1", "description"),
            new BikeSourceModel(2, "source 2", "description")
        };

        public async Task<IEnumerable<BikeSourceModel>> GetBikeSources()
        {
            try
            {
                await Task.Delay(10);

                return BikeSources;
            }
            catch
            {
                return null;
            }
        }
    }
}
