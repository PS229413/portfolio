﻿using HetFietsenStation.Dtos.BikeStatus;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeStatus
{
    public class BikeStatusService : HttpCallServiceBase, IBikeStatusService
    {
        public BikeStatusService(ISettingsService settingsService, bool isUnitTest = false) : base(settingsService, isUnitTest)
        {
            Route = "api/BikeStatus";
        }

        //get all different status that are in the database
        public async Task<IEnumerable<BikeStatusModel>> GetBikeStatuses()
        {
            return await GetAllBase<GetBikeStatusDto, BikeStatusModel>(Route, dto => new BikeStatusModel(dto));
        }

    }
}
