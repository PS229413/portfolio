﻿using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeStatus
{
    public interface IBikeStatusService
    {
        Task<IEnumerable<BikeStatusModel>> GetBikeStatuses();
    }
}
