﻿using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeStatus
{
    public class BikeStatusMockService : IBikeStatusService
    {
        List<BikeStatusModel> BikeStatuses = new List<BikeStatusModel>
        {
            new BikeStatusModel(1, "status 1", "description"),
            new BikeStatusModel(2, "status 2", "description")
        };

        public async Task<IEnumerable<BikeStatusModel>> GetBikeStatuses()
        {
            try
            {
                await Task.Delay(10);

                return BikeStatuses;
            }
            catch
            {
                return null;
            }
        }
    }
}