﻿using HetFietsenStation.Dtos.RepairBike;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.RepairBike
{
    public class RepairBikeMockService : IRepairBikeService
    {
        List<RepairBikeModel> MockRepairBikes = new List<RepairBikeModel>()
        {
            new RepairBikeModel(
                1, 
                "Batavus", 
                "M1",
                new List<ImageModel> { new ImageModel { Id = 1, Url = "imageUrl" } }, 
                1000, 
                100, 
                DateTime.Now,
                new BikeTypeModel(1, "HerenFiets", "Een herenfiets"),
                new BikeColorModel(1, "Blauw", "Een blauwe fiets", "#0000FF"),
                new BikeConditionModel(1, "Goede staat", "Een fiets in goede staat"),
                new BikeStatusModel(1, "Reparatie nodig", "Een fiets die reparatie nodig heeft"),
                new BikeSourceModel(1, "ANWB", "Een fiets gedoneert vanuit de ANWB"),
                new List<RepairStepModel>(){ new RepairStepModel(1, "Test1 ", "Test 1", true, true), new RepairStepModel(1, "Test2 ", "Test 1", false, false) }),

            new RepairBikeModel(
                2, 
                "Gazelle", 
                "M2",
                new List<ImageModel> { new ImageModel { Id = 1, Url = "imageUrl" } }, 
                1001, 
                101, 
                DateTime.Now,
                new BikeTypeModel(2, "VrouwenFiets", "Een vrouwenfiets"),
                new BikeColorModel(2, "Zwart", "Een zwarte fiets", "#000000"),
                new BikeConditionModel(2, "Slechte staat", "Een fiets in slechte staat"),
                new BikeStatusModel(1, "Reparatie nodig", "Een fiets die reparatie nodig heeft"),
                new BikeSourceModel(2, "Gemeente Helmond", "Een fiets gedoneert vanuit de Gemeente Helmond"),
                new List<RepairStepModel>(){ new RepairStepModel(1, "Test1 ", "Test 1", true, true), new RepairStepModel(1, "Test2 ", "Test 1", false, false) })
        };
        public async Task<IEnumerable<RepairBikeModel>> GetAllRepairBikes()
        {
            await Task.Delay(10);

            return MockRepairBikes;
        }

        public async Task<RepairBikeModel> GetRepairBike(int repairBikeId) 
        {
            await Task.Delay(10);

            try
            {
                return MockRepairBikes.Where(rb => rb.Id == repairBikeId).First();
            }
            catch 
            { 
                return null;
            }   
        }

        public async Task<bool> UpdateRepairBike(UpdateRepairBikeDto repairBike)
        {
            try
            {
                await Task.Delay(10);

                RepairBikeModel repairBikeResult = MockRepairBikes.Where(rb => rb.Id == repairBike.Id).First();

                repairBikeResult.Brand = repairBike.Brand;

                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> RepairBikeToPhotographBike(RepairBikeToPhotographBikeDto repairBike)
        {
            try
            {
                await Task.Delay(10);

                RepairBikeModel repairBikeResult = MockRepairBikes.Where(rb => rb.Id == repairBike.Id).First();

                PhotographBikeModel photographBike = new PhotographBikeModel(repairBikeResult, repairBike.Price);

                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> AddRepairBike(AddRepairBikeDto repairBike, List<string> imagePaths)
        {
            try
            {
                await Task.Delay(10);

                RepairBikeModel addedRepairBike = new RepairBikeModel()
                {
                    Brand = repairBike.Brand
                };
                
                MockRepairBikes.Add(addedRepairBike);

                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
