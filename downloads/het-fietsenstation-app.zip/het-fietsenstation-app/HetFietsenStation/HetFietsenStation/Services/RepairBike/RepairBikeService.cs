﻿using HetFietsenStation.Dtos.RepairBike;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;
using Newtonsoft.Json;
using System.Text;
using HetFietsenStation.Dtos;

namespace HetFietsenStation.Services.RepairBike
{
    public class RepairBikeService : HttpCallServiceBase, IRepairBikeService
    {
        public RepairBikeService(ISettingsService settingsService, bool isUnitTest = false) : base(settingsService, isUnitTest) 
        {
            Route = "api/Bike";
        }

        //get all the bikes that still need to be repaired
        public async Task<IEnumerable<RepairBikeModel>> GetAllRepairBikes()
        {
            return await GetAllBase<GetRepairBikeDto, RepairBikeModel>(Route + "/repair", dto => new RepairBikeModel(dto));
        }

        //get a singular bike that still needs to be repaired
        public async Task<RepairBikeModel> GetRepairBike(int repairBikeId)
        {
            return await GetBase<GetRepairBikeDto, RepairBikeModel>(Route + "/" + repairBikeId, dto => new RepairBikeModel(dto));
        }

        //update the current selected bike
        public async Task<bool> UpdateRepairBike(UpdateRepairBikeDto repairBike)
        {
            return await UpdateBase(repairBike, Route);
        }

        //change the bikes from needing repairs to being able to be sold.
        public async Task<bool> RepairBikeToPhotographBike(RepairBikeToPhotographBikeDto repairBike)
        {
            try
            {
                string json = System.Text.Json.JsonSerializer.Serialize(repairBike);
                HttpResponseMessage response = null;
                StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                response = await Client.PutAsync(Route + "/Photograph", content);

                if (response.IsSuccessStatusCode != true)
                {
                    return false;
                }

                return true;

            }
            catch
            {
                return false;
            }
        }

        //add a new repair bike
        public async Task<bool> AddRepairBike(AddRepairBikeDto repairBike, List<string> imagePaths)
        {
            // Add the actual bike
            string json = System.Text.Json.JsonSerializer.Serialize(repairBike);
            HttpResponseMessage response = null;
            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

            //go back to the catalog page after creating a repair bike
            response = await Client.PostAsync(Route, content);

            if (response.IsSuccessStatusCode != true)
            {
                return false;
            }

            // Get the id of the bike by sending a request to the lastAdded route
            var responseLast = await Client.GetAsync(Route + "/lastAdded");

            if (responseLast.IsSuccessStatusCode != true)
            {
                return false;
            }

            var jsonString = await responseLast.Content.ReadAsStringAsync();
            dynamic jsonO = JsonConvert.DeserializeObject(jsonString);
            string id = jsonO.data.id;

#if ANDROID
            // Upload the image(s) to the server
            var i = 0;

            var Form = new MultipartFormDataContent();

            HttpContent stringContent = new StringContent(id);
            Form.Add(stringContent, "Id");
            Form.Add(new StringContent("Bike"), "Type");

            foreach (string image in imagePaths)
            {
                i++;
                var fileContent = new StreamContent(File.OpenRead(Path.Combine(FileSystem.AppDataDirectory, image)));
                fileContent.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("form-data")
                {
                    Name = $"Files",
                    FileName = $"test{i}.jpeg"
                };
                Form.Add(fileContent);

            }

            AddPhotoDto repairBikePhoto = new AddPhotoDto(Form);
            response = await Client.PostAsync("api/PhotographyBike/AddPhoto", Form);

            if (response.IsSuccessStatusCode != true)
            {
                return false;
            }
#endif
            return true;
        }
    }
}
