﻿using HetFietsenStation.Dtos.RepairBike;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.RepairBike
{
    public interface IRepairBikeService
    {
        Task<IEnumerable<RepairBikeModel>> GetAllRepairBikes();
        Task<RepairBikeModel> GetRepairBike(int repairBikeId);
        Task<bool> UpdateRepairBike(UpdateRepairBikeDto repairBike);
        Task<bool> RepairBikeToPhotographBike(RepairBikeToPhotographBikeDto repairBike);
        Task<bool> AddRepairBike(AddRepairBikeDto repairBike, List<string> imagePaths);
    }
}
