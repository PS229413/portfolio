﻿namespace HetFietsenStation.Services.Settings
{
    public class SettingsService : ISettingsService
    {

        private const string ApiBaseUrlDefault = "http://192.168.111.1:5046/";
        private const string ApiBaseUrlDefaultAndroid = "http://192.168.111.1:5046/";

        public string ApiBaseUrl 
        {
#if ANDROID
            get => ApiBaseUrlDefaultAndroid;
#else
            get => ApiBaseUrlDefault;
#endif
        }

    }
}
