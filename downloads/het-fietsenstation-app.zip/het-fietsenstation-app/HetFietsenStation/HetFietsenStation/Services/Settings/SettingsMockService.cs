﻿namespace HetFietsenStation.Services.Settings
{
    public class SettingsMockService : ISettingsService
    {
        private const string ApiBaseUrlDefault = "https://nu.nl";
        public string ApiBaseUrl
        {
            get => ApiBaseUrlDefault;
        }
    }
}
