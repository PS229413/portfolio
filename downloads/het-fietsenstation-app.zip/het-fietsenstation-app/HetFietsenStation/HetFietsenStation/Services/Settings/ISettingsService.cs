﻿namespace HetFietsenStation.Services.Settings
{
    public interface ISettingsService
    {
        string ApiBaseUrl { get; }
    }
}
