﻿using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeType
{
    public class BikeTypeMockService : IBikeTypeService
    {
        List<BikeTypeModel> BikeTypes = new List<BikeTypeModel>
        {
            new BikeTypeModel(1, "type 1", "description"),
            new BikeTypeModel(2, "type 2", "description")
        };

        public async Task<IEnumerable<BikeTypeModel>> GetAllBikeTypes()
        {
            try
            {
                await Task.Delay(10);

                return BikeTypes;
            }
            catch
            {
                return null;
            }
        }
    }
}
