﻿using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeType
{
    public interface IBikeTypeService
    {
        Task<IEnumerable<BikeTypeModel>> GetAllBikeTypes();
    }
}
