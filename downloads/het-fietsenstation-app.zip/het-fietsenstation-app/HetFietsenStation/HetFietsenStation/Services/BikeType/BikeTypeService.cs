﻿using HetFietsenStation.Dtos.BikeType;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;

namespace HetFietsenStation.Services.BikeType
{
    public class BikeTypeService : HttpCallServiceBase, IBikeTypeService
    {
        public BikeTypeService(ISettingsService settingsService, bool isUnitTest = false) : base(settingsService, isUnitTest)
        {
            Route = "api/BikeType";
        }

        public async Task<IEnumerable<BikeTypeModel>> GetAllBikeTypes()
        {
            return await GetAllBase<GetBikeTypeDto, BikeTypeModel>(Route, dto => new BikeTypeModel(dto));
        }

    }
}
