﻿namespace HetFietsenStation.Services.Navigation
{
    public class NavigationMockService : INavigationService
    {
#nullable enable
        public Task NavigateToAsync(string route, IDictionary<string, object>? routeParameters = null)
        {
            return Task.CompletedTask;
        }

        public Task PopAsync(IDictionary<string, object>? routeParameters = null)
        {
            return Task.CompletedTask;
        }

        public Task PopToRootAsync()
        {
            return Task.CompletedTask;
        }
    }
}
