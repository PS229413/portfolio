﻿namespace HetFietsenStation.Services.Navigation
{
    internal class NavigationService : INavigationService
    {
        public NavigationService() { 
            
        }

        public Task NavigateToAsync(string route, IDictionary<string, object> routeParameters = null)
        {
            var shellNavigation = new ShellNavigationState(route);

            return routeParameters != null
                ? Shell.Current.GoToAsync(shellNavigation, routeParameters)
                : Shell.Current.GoToAsync(shellNavigation);
        }

        public Task PopAsync(IDictionary<string, object> routeParameters = null)
        {
            return routeParameters != null
                ? Shell.Current.GoToAsync("..", routeParameters)
                : Shell.Current.GoToAsync("..");
        }

        public Task PopToRootAsync()
        {
            return Shell.Current.GoToAsync("//Login");
        }
    }
}
