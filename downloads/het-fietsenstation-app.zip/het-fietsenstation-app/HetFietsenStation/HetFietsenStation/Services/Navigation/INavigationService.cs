﻿namespace HetFietsenStation.Services.Navigation
{
    public interface INavigationService
    {
        public Task NavigateToAsync(string route, IDictionary<string, object> routeParameters = null);

        public Task PopAsync(IDictionary<string, object> routeParameters = null);

        public Task PopToRootAsync();
    }
}
