﻿using HetFietsenStation.Dtos.PhotoBike;

namespace HetFietsenStation.Models
{
    public class PhotoBikeModel : ProductModel
    {
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string Info { get; set; } = string.Empty;
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public DateTime RegistrationData { get; set; } = DateTime.MinValue;
        public BikeTypeModel BikeType { get; set; } = null;
        public BikeSourceModel BikeSource { get; set; } = null;
        public BikeColorModel BikeColor { get; set; } = null;
        public BikeConditionModel BikeCondition { get; set; } = null;
        public BikeStatusModel BikeStatus { get; set; } = null;
        public UserModel Mechanic { get; set; } = null;

        public PhotoBikeModel(int id, List<ImageModel> images, int price, string brand, string model, int frameNumber, int frameHeight, DateTime registrationData, BikeTypeModel bikeType, BikeSourceModel bikeSourceModel, BikeColorModel bikeColorModel, BikeConditionModel bikeConditionModel, BikeStatusModel bikestatus, UserModel userModel)
        {
            Id = id;
            Images = images;
            Price = price;
            Brand = brand;
            Model = model;
            FrameNumber = frameNumber;
            FrameHeight = frameHeight;
            BikeType = bikeType;
            BikeSource = bikeSourceModel;
            BikeColor = bikeColorModel;
            BikeCondition = bikeConditionModel;
            BikeStatus = bikestatus;
            Mechanic = userModel;
        }

        public PhotoBikeModel(GetPhotoBikeDto dto)
        {
            Id = dto.Id;
            Images = dto.Images;
            Price = dto.Price;
            Brand = dto.Brand;
            Model = dto.Model;
            FrameNumber = dto.FrameNumber;
            FrameHeight = dto.FrameHeight;
            RegistrationData = dto.RegistrationDate;
            BikeType = new BikeTypeModel(dto.BikeType);
            BikeCondition = new BikeConditionModel(dto.BikeCondition);
            BikeSource = new BikeSourceModel(dto.BikeSource);
            BikeColor = new BikeColorModel(dto.BikeColor);
            BikeStatus = new BikeStatusModel(dto.BikeStatus);
            Mechanic = new UserModel(dto.Mechanic);
        }

        public PhotoBikeModel(string info)
        {
            Info = info;
        }

        public PhotoBikeModel() { }
    }
}
