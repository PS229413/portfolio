﻿using HetFietsenStation.Dtos.SideProduct;
using HetFietsenStation.Dtos.SideProductType;

namespace HetFietsenStation.Models
{
    public class SideProductModel : ProductModel
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Info { get; set; } = string.Empty;
        public int Stock { get; set; } = 0;
        public SideProductTypeModel SideProductType { get; set; } = null;

        public SideProductModel(int id, string name, string description,
            List<ImageModel> images, int stock, int price, SideProductTypeModel sideProductType)
        {
            Id = id;
            Name = name;
            Description = description;
            Images = images;
            Stock = stock;
            Price = price;
            SideProductType = sideProductType;
        }

        public SideProductModel(GetSideProductDto dto)
        {
            Id = dto.Id;
            Name = dto.Name;
            Description = dto.Description;
            Images = dto.Images;
            Stock = dto.Stock;
            Price = dto.Price;
            SideProductType = new SideProductTypeModel(dto.SideProductType);
        }

        public SideProductModel(string info)
        {
            Info = info;
        }
    }
}
