using HetFietsenStation.Dtos.Product;

namespace HetFietsenStation.Models
{
    public class BikeModel : ProductModel
    {
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string Note { get; set; } = string.Empty;
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public BikeTypeModel BikeType { get; set; } = null;
        public BikeColorModel BikeColor { get; set; } = null;
        public BikeConditionModel BikeCondition { get; set; } = null;
        public BikeStatusModel BikeStatus { get; set; } = null;
        public BikeSourceModel BikeSource { get; set; } = null;
        public UserModel User { get; set; } = null;
        public List<RepairStepModel> RepairSteps { get; set; } = null;

        public BikeModel(int id, string brand, string model, string note, List<ImageModel> images, int frameNumber, int frameHeight, int price, BikeTypeModel bikeType, BikeColorModel bikeColor, BikeConditionModel bikeCondition, BikeStatusModel bikeStatus, BikeSourceModel bikeSource, UserModel user, List<RepairStepModel> repairSteps)
        {
            Id = id;
            Brand = brand;
            Model = model;
            Note = note;
            Images = images;
            FrameNumber = frameNumber;
            FrameHeight = frameHeight;
            Price = price;
            BikeType = bikeType;
            BikeColor = bikeColor;
            BikeCondition = bikeCondition;
            BikeStatus = bikeStatus;
            BikeSource = bikeSource;
            User = user;
            RepairSteps = repairSteps;
        }

        public BikeModel(GetBikeDto dto)
        {
            Id = dto.Id;
            Brand = dto.Brand;
            Model = dto.Model;
            Note = dto.Note;
            Images = dto.Images;
            FrameNumber = dto.FrameNumber;
            FrameHeight = dto.FrameHeight;
            Price = dto.Price;
            BikeType = new BikeTypeModel(dto.BikeType);
            BikeColor = new BikeColorModel(dto.BikeColor);
            BikeCondition = new BikeConditionModel(dto.BikeCondition);
            BikeStatus = new BikeStatusModel(dto.BikeStatus);
            BikeSource = new BikeSourceModel(dto.BikeSource);
            User = new UserModel(dto.Mechanic);
        }

        public BikeModel()
        {

        }
    }
}
