﻿namespace HetFietsenStation.Models
{
    public class ProductModel

    {
        public int Id { get; set; } = 0;
        public List<ImageModel> Images { get; set; }
        public int Price { get; set; } = 0;
        public static void Add(ProductModel product)
        {
            ProductModel.Add(product);
        }
    }

}
    
    


