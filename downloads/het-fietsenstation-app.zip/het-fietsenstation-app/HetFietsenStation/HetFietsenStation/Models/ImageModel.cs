﻿namespace HetFietsenStation.Models
{
    public class ImageModel
    {
        public int Id { get; set; }
        public string Url { get; set; }
        public int? ProductId { get; set; }
        public int? BikeId { get; set; }
    }
}
