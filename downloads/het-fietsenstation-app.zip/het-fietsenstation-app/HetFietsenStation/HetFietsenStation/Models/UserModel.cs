﻿using HetFietsenStation.Dtos.User;
using HetFietsenStation.Enums;

namespace HetFietsenStation.Models
{
    public class UserModel
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = string.Empty;
        public UserRole UserRoleId { get; set; }

        public UserModel(int id, string name, int userRoleId) 
        { 
            Id = id;
            Name = name;
            UserRoleId = (UserRole)userRoleId;
        }

        public UserModel(GetUserDto dto)
        {
            Id = dto.Id;
            Name = dto.Name;
            UserRoleId = (UserRole)dto.UserRoleId;
        }
    }
}
