﻿using HetFietsenStation.Dtos.Role;
using HetFietsenStation.Enums;

namespace HetFietsenStation.Models
{
    public class RoleModel
    { 
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public RoleModel(int id, string name, string description)
        {
            Id = id;
            Name = name;
            Description = description;
        }

        public RoleModel(GetRoleDto dto)
        {
            Id = dto.Id;
            Name = dto.Name;
            Description = dto.Description;
        }
    }
}
