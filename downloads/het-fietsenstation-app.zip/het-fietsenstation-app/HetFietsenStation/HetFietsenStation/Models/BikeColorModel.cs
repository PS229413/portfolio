﻿using HetFietsenStation.Dtos.BikeColor;

namespace HetFietsenStation.Models
{
    public class BikeColorModel
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string HexCode { get; set; } = string.Empty;

        public BikeColorModel(int id, string name, string description, string hexCode) 
        { 
            Id = id;
            Name = name;
            Description = description;
            HexCode = hexCode;
        }

        public BikeColorModel(GetBikeColorDto dto)
        {
            Id = dto.Id;
            Name = dto.Name;
            Description = dto.Description;
            HexCode = dto.HexCode;
        }
    }
}
