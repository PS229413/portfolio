﻿using System.Text.Json.Serialization;

namespace HetFietsenStation.Models
{
    public class ShoppingCartModel
    {
        public int Id { get; set; } = 0;
        public string Type { get; set; } = string.Empty;

        public ShoppingCartModel(int id, string type)
        {
            Id = id;
            Type = type;
        }
    }
}