﻿namespace HetFietsenStation.Models
{
    public class PhotographBikeModel
    {
        public int Id { get; set; } = 0;
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string Note { get; set; } = string.Empty;
        public List<ImageModel> Images { get; set; }
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public int Price { get; set; } = 0;
        public DateTime RegistrationDate { get; set; }
        public DateTime RepairDate { get; set; }
        public BikeTypeModel BikeType { get; set; }
        public BikeColorModel BikeColor { get; set; }
        public BikeConditionModel BikeCondition { get; set; }
        public BikeStatusModel BikeStatus { get; set; }
        public BikeSourceModel BikeSource { get; set; }
        public UserModel Mechanic { get; set; }
        public List<RepairStepModel> RepairSteps { get; set; }

        public PhotographBikeModel(RepairBikeModel repairBike, int price)
        {
            Id = repairBike.Id;
            Brand = repairBike.Brand;
            Model = repairBike.Model;
            Images = repairBike.Images;
            FrameNumber = repairBike.FrameNumber;
            FrameHeight = repairBike.FrameHeight;
            RegistrationDate = repairBike.RegistrationDate;
            RepairSteps = repairBike.RepairSteps;
            BikeType = repairBike.BikeType;
            BikeColor = repairBike.BikeColor;
            BikeCondition = repairBike.BikeCondition;
            BikeStatus = repairBike.BikeStatus;
            BikeSource = repairBike.BikeSource;
            RepairSteps = repairBike.RepairSteps;
            Price = price;
        }

        public PhotographBikeModel(RepairBikeModel repairBike, UserModel mechanic, int price, string note)
        {
            Id = repairBike.Id;
            Brand = repairBike.Brand;
            Model = repairBike.Model;
            FrameNumber = repairBike.FrameNumber;
            FrameHeight = repairBike.FrameHeight;
            RegistrationDate = repairBike.RegistrationDate;
            RepairSteps = repairBike.RepairSteps;
            BikeType = repairBike.BikeType;
            BikeColor = repairBike.BikeColor;
            BikeCondition = repairBike.BikeCondition;
            BikeStatus = repairBike.BikeStatus;
            BikeSource = repairBike.BikeSource;
            RepairSteps = repairBike.RepairSteps;
            Images = repairBike.Images;
            Mechanic = mechanic;
            Price = price;
            Note = note;
        }

        public PhotographBikeModel()
        {

        }
    }
}
