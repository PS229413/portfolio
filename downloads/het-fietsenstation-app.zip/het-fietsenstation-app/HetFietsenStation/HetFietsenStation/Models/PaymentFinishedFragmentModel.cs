﻿namespace Hetfietsenstation.Models
{
    public class PaymentFinishedFragmentModel
    {
        // Id string As provided by the third-party app
        public string Id { get; set; }
        
        // Amount int As provided by the third-party app
        public decimal Amount { get; set; }  // in cents
        
        // Reference string As provided by the third-party app
        public string Reference { get; set; }
        
        // Type string ["PIN" | "CASH"] Payment method
        public string Type { get; set; }
        
        // Datetime string Date and time of the payment (ISO8601)
        public string Datetime { get; set; }
        
        // State string Payment status (see below)
        public string State { get; set; }
        
        // TransactionId string Transaction ID
        public string TransactionId { get; set; }
        
        // TerminalId string Only for PIN, terminal ID
        public string TerminalId { get; set; }
        
        // CardType string Only for PIN, card type
        public string CardType { get; set; }
        
        // AID string Only for PIN, AID
        public string AID { get; set; }
        
        // TruncatedPan string Only for PIN, card number
        public string TruncatedPan { get; set; }
        
        // AuthCode string Only for PIN, authorization code
        public string AuthCode { get; set; }
        
        // ErrorCode string Only for PIN, error code
        public string ErrorCode { get; set; }
        
        // Change int Change in cents
        public int Change { get; set; }
        
        // Product description
        public string Description { get; set; }
    }
}