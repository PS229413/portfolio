﻿using System.ComponentModel.DataAnnotations;

namespace HetFietsenStation.Models
{
    public enum SubsidyType
    {
        [Display(Description = "Geen")]
        None = 0,
        [Display(Description = "Percentage")]
        Percentage = 1,
        [Display(Description = "Bedrag")]
        Amount = 3,
    }

    public enum SubsidyProvider
    {
        [Display(Description = "Geen")] 
        None = 0,
        [Display(Description = "Leergeld")] 
        Leergeld = 1,
        [Display(Description = "Senzer")] 
        Senzer = 2,
    }

    public class SaleModel
    {
        public int Id { get; set; }
        public SubsidyType SubsidyType { get; set; }
        public decimal? SubsidyValue { get; set; }
        public SubsidyProvider SubsidyProvider { get; set; }
        public string SubsidyReference { get; set; }
        public decimal Btw { get; set; }
        public DateTime Sold_At { get; set; }
        public decimal? FinalPrice { get; set; }
        public int BikeId { get; set; }
        public System.Guid Uuid { get; set; }
        public string Reference { get; set; }
        public string TransactionId { get; set; }
        public DateTime Terminal_Sold_At { get; set; }
    }
}