﻿using HetFietsenStation.Dtos.RepairBike;

namespace HetFietsenStation.Models
{
    public class RepairBikeModel
    {
        public int Id { get; set; } = 0;
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public List<ImageModel> Images { get; set; }
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public int Price { get; set; } = 0;
        public DateTime RegistrationDate { get; set; }
        public BikeTypeModel BikeType { get; set; }
        public BikeColorModel BikeColor { get; set; }
        public BikeConditionModel BikeCondition { get; set; }
        public BikeStatusModel BikeStatus { get; set; }
        public BikeSourceModel BikeSource { get; set; }
        public List<RepairStepModel> RepairSteps { get; set; }

        public RepairBikeModel(int id, string brand, string model, List<ImageModel> images, int frameNumber,
            int frameHeight, DateTime registrationDate, BikeTypeModel bikeType,
            BikeColorModel bikeColor, BikeConditionModel bikeCondition, BikeStatusModel bikeStatus,
            BikeSourceModel bikeSource, List<RepairStepModel> repairSteps)
        {
            Id = id;
            Brand = brand;
            Model = model;
            Images = images;
            FrameNumber = frameNumber;
            FrameHeight = frameHeight;
            RegistrationDate = registrationDate;
            BikeType = bikeType;
            BikeColor = bikeColor;
            BikeCondition = bikeCondition;
            BikeStatus = bikeStatus;
            BikeSource = bikeSource;
            RepairSteps = repairSteps;
        }

        public RepairBikeModel(GetRepairBikeDto dto)
        {
            Id = dto.Id;
            Brand = dto.Brand;
            Model = dto.Model;
            Images = dto.Images;
            FrameNumber = dto.FrameNumber;
            FrameHeight = dto.FrameHeight;
            RegistrationDate = dto.RegistrationDate;
            BikeType = new BikeTypeModel(dto.BikeType);
            BikeColor = new BikeColorModel(dto.BikeColor);
            BikeCondition = new BikeConditionModel(dto.BikeCondition);
            BikeStatus = new BikeStatusModel(dto.BikeStatus);
            BikeSource = new BikeSourceModel(dto.BikeSource);
        }

        public RepairBikeModel()
        {

        }
    }
}
