﻿using System.ComponentModel;
using System.Runtime.CompilerServices;
using HetFietsenStation.Dtos.RepairStep;

namespace HetFietsenStation.Models
{
    //A model containg all data of the RepairStep
    public class RepairStepModel : ObservableObject, INotifyPropertyChanged
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public bool Required { get; set; } = false;
        private bool done = false;
        private bool notDone = true;

        //Makes sure the done field gets updated in the view when changed
        public bool Done 
        {
            get => done;
            set
            {
                SetField(ref done, value);
                NotDone = !value;
            }
        }

        public bool NotDone
        {
            get => notDone;
            set => SetField(ref notDone, value);
        }

        //Constructor used to gain the data of a json response
        public RepairStepModel(GetRepairStepDto data, bool done)
        {
            Id = data.Id;
            Name = data.Name;
            Description = data.Description;
            Required = data.Required;
            Done = done;
        }

        //Basic constructor used to generate the object with data
        public RepairStepModel(int id, string name, string description, bool required, bool done)
        {
            Id = id;
            Name = name;
            Description = description;
            Required = required;
            Done = done;
        }

        //Basic constructor used to generate the object without data
        public RepairStepModel()
        {

        }

        //Defines a event
#nullable enable
        public new event PropertyChangedEventHandler? PropertyChanged;
        //Invokes the event to trigger when the property is changed
        protected new void OnPropertyChanged(string propertyName) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        //Function which makes sure the property gets changed in the view when changed somewhere else
        protected bool SetField<T>(ref T field, T value, [CallerMemberName] string propertyName = "") 
        {
            if (EqualityComparer<T>.Default.Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }
}
