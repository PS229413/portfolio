﻿using HetFietsenStation.Dtos.SideProductType;

namespace HetFietsenStation.Models
{
    public class SideProductTypeModel
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; }

        public SideProductTypeModel(int id, string name, string description) 
        {
            Id = id;
            Name = name;
            Description = description;
        }

        public SideProductTypeModel(GetSideProductTypeDto dto) 
        {
            Id = dto.Id;
            Name = dto.Name;
            Description = dto.Description;
        }
    }
}
