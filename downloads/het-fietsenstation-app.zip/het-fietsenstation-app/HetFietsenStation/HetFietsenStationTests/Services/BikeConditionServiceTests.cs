﻿using HetFietsenStation.Services.BikeCondition;
using HetFietsenStation.Dtos.BikeCondition;
using HetFietsenStation.Models;
using System.Text.Json;
using System.Net;
using HetFietsenStation.Containers;

namespace HetFietsenStationTests.Services
{
    public class BikeConditionServiceTests : ServiceTestsBase
    {
        BikeConditionService Service;

        public BikeConditionServiceTests()
        {
            Service = new BikeConditionService(_settingsService, true);
        }

        [Fact]
        public async Task GetBikeConditions_Should_Return_List_When_Status_Code_200_Is_Returned()
        {
            JsonContainerList<GetBikeConditionDto> response = new()
            {
                data = new GetBikeConditionDto[1]
                {
                    new GetBikeConditionDto(1, "condition", "description")
                },
                message = "",
                succes = true
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.OK, json);

            IEnumerable<BikeConditionModel> result = await Service.GetBikeConditions();

            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetBikeConditions_Should_Return_Empty_When_Status_Code_404_Is_Returned()
        {
            JsonContainerList<GetBikeConditionDto> response = new()
            {
                data = null,
                message = "",
                succes = false
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.NotFound, json);

            IEnumerable<BikeConditionModel> result = await Service.GetBikeConditions();

            Assert.Empty(result);
        }
    }
}
