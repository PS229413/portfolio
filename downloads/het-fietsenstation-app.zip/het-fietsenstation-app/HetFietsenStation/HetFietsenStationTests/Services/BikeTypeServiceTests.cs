﻿using HetFietsenStation.Services.BikeType;
using HetFietsenStation.Dtos.BikeType;
using HetFietsenStation.Models;
using System.Text.Json;
using System.Net;
using HetFietsenStation.Containers;

namespace HetFietsenStationTests.Services
{
    public class BikeTypeServiceTests : ServiceTestsBase
    {
        BikeTypeService Service;

        public BikeTypeServiceTests()
        {
            Service = new BikeTypeService(_settingsService, true);
        }

        [Fact]
        public async Task GetBikeTypes_Should_Return_List_When_Status_Code_200_Is_Returned()
        {
            JsonContainerList<GetBikeTypeDto> response = new()
            {
                data = new GetBikeTypeDto[1]
                {
                    new GetBikeTypeDto(1, "type", "description")
                },
                message = "",
                succes = true
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.OK, json);

            IEnumerable<BikeTypeModel> result = await Service.GetAllBikeTypes();

            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetBikeTypes_Should_Return_Empty_When_Status_Code_404_Is_Returned()
        {
            JsonContainerList<GetBikeTypeDto> response = new()
            {
                data = null,
                message = "",
                succes = false
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.NotFound, json);

            IEnumerable<BikeTypeModel> result = await Service.GetAllBikeTypes();

            Assert.Empty(result);
        }
    }
}
