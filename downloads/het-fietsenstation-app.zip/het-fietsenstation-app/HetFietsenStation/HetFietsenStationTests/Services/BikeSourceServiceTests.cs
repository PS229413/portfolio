﻿using HetFietsenStation.Services.BikeSource;
using HetFietsenStation.Dtos.BikeSource;
using HetFietsenStation.Models;
using System.Text.Json;
using System.Net;
using HetFietsenStation.Containers;

namespace HetFietsenStationTests.Services
{
    public class BikeSourceServiceTests : ServiceTestsBase
    {
        BikeSourceService Service;

        public BikeSourceServiceTests()
        {
            Service = new BikeSourceService(_settingsService, true);
        }
         
        [Fact]
        public async Task GetBikeSources_Should_Return_List_When_Status_Code_200_Is_Returned()
        {
            JsonContainerList<GetBikeSourceDto> response = new()
            {
                data = new GetBikeSourceDto[1]
                {
                    new GetBikeSourceDto(1, "source", "description")
                },
                message = "",
                succes = true
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.OK, json);

            IEnumerable<BikeSourceModel> result = await Service.GetBikeSources();

            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetBikeSources_Should_Return_Empty_When_Status_Code_404_Is_Returned()
        {
            JsonContainerList<GetBikeSourceDto> response = new()
            {
                data = null,
                message = "",
                succes = false
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.NotFound, json);

            IEnumerable<BikeSourceModel> result = await Service.GetBikeSources();

            Assert.Empty(result);
        }
    }
}
