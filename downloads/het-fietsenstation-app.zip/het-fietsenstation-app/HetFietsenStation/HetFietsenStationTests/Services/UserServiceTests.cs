﻿using HetFietsenStation.Services.User;
using HetFietsenStation.Models;
using System.Text.Json;
using System.Net;
using HetFietsenStation.Dtos.User;
using HetFietsenStation.Containers;

namespace HetFietsenStationTests.Services
{
    public class UserServiceTests : ServiceTestsBase
    {
        UserService Service;

        public UserServiceTests()
        {
            Service = new UserService(_settingsService, true);
        }

        [Fact]
        public async Task GetUsers_Should_Return_List_When_Status_Code_200_Is_Returned()
        {
            JsonContainerList<GetUserDto> response = new()
            {
                data = new GetUserDto[1]
                {
                    new GetUserDto(1, "user", 1)
                },
                message = "",
                succes = true
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.OK, json);

            IEnumerable<UserModel> result = await Service.GetUsers();

            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetUsers_Should_Return_Empty_When_Status_Code_404_Is_Returned()
        {
            JsonContainerList<GetUserDto> response = new()
            {
                data = null,
                message = "",
                succes = false
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.NotFound, json);

            IEnumerable<UserModel> result = await Service.GetUsers();

            Assert.Empty(result);
        }

        [Fact]
        public async Task GetMechanics_Should_Return_List_When_Status_Code_200_Is_Returned()
        {
            JsonContainerList<GetUserDto> response = new()
            {
                data = new GetUserDto[1]
                {
                    new GetUserDto(2, "user", 2)
                },
                message = "",
                succes = true
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.OK, json);

            IEnumerable<UserModel> result = await Service.GetMechanics();

            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetMechanics_Should_Return_Empty_When_Status_Code_404_Is_Returned()
        {
            JsonContainerList<GetUserDto> response = new()
            {
                data = null,
                message = "",
                succes = false
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.NotFound, json);

            IEnumerable<UserModel> result = await Service.GetMechanics();

            Assert.Empty(result);
        }

        [Fact]
        public async Task ValidateUser_Should_Return_List_When_Status_Code_200_Is_Returned()
        {
            VerifyUserDto requestData = new VerifyUserDto(1, "username", "password");

            Service.Client = HttpClientMockGenerator(HttpStatusCode.OK);

            string result = await Service.ValidateUser(requestData);

            Assert.NotNull(result);
        }

        [Fact]
        public async Task ValidateUser_Should_Return_Null_When_Status_Code_404_Is_Returned()
        {
            VerifyUserDto requestData = new VerifyUserDto(-1, "username", "password");

            Service.Client = HttpClientMockGenerator(HttpStatusCode.NotFound);

            string result = await Service.ValidateUser(requestData);

            Assert.Null(result);
        }
    }
}
