﻿using HetFietsenStation.Services.BikeColor;
using HetFietsenStation.Dtos.BikeColor;
using HetFietsenStation.Models;
using System.Text.Json;
using System.Net;
using HetFietsenStation.Containers;

namespace HetFietsenStationTests.Services
{
    public class BikeColorServiceTests : ServiceTestsBase
    {
        BikeColorService Service;

        public BikeColorServiceTests()
        {
            Service = new BikeColorService(_settingsService, true);
        }

        [Fact]
        public async Task GetBikeColors_Should_Return_List_When_Status_Code_200_Is_Returned()
        {
            JsonContainerList<GetBikeColorDto> response = new()
            {
                data = new GetBikeColorDto[1]
                {
                    new GetBikeColorDto(1, "color", "description", "#FFFFFF")
                },
                message = "",
                succes = true
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.OK, json);

            IEnumerable<BikeColorModel> result = await Service.GetAllBikeColors();

            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetBikeColors_Should_Return_Empty_When_Status_Code_404_Is_Returned()
        {
            JsonContainerList<GetBikeColorDto> response = new()
            {
                data = null,
                message = "",
                succes = false
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.NotFound, json);

            IEnumerable<BikeColorModel> result = await Service.GetAllBikeColors();

            Assert.Empty(result);
        }
    }
}
