﻿using HetFietsenStation.Services.Settings;
using Moq.Protected;
using Moq;
using System.Net;

namespace HetFietsenStationTests.Services
{
    public class ServiceTestsBase
    {
        protected readonly ISettingsService _settingsService;

        public ServiceTestsBase()
        {
            _settingsService = new SettingsMockService();
        }

        protected HttpClient HttpClientMockGenerator(HttpStatusCode mockStatusCode, string requestData = "{}") 
        {
            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);

            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = mockStatusCode,
                    Content = new StringContent(requestData)
                })
                .Verifiable();

            HttpClient mockHttpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri(_settingsService.ApiBaseUrl)
            };

            return mockHttpClient;
        }
    }
}
