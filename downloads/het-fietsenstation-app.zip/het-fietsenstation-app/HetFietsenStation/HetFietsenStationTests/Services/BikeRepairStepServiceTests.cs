﻿using HetFietsenStation.Dtos.BikeRepairStep;
using HetFietsenStation.Services.BikeRepairStep;
using HetFietsenStation.Services.Settings;
using Moq;
using Moq.Protected;
using System.Net;

namespace HetFietsenStationTests.Services
{
    public class BikeRepairStepServiceTests : ServiceTestsBase
    {
        BikeRepairStepService Service;

        public BikeRepairStepServiceTests()
        {
            Service = new BikeRepairStepService(_settingsService, true);
        }

        [Fact]
        public async Task UpdateBikeRepairStep_Should_Return_True_When_Status_Code_200_Is_Returned() 
        {
            //arange
            UpdateBikeRepairStepDto requestData = new UpdateBikeRepairStepDto(1, 1, false);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.OK);

            //Act
            bool succeeded = await Service.UpdateBikeRepairStep(requestData);

            //Assert
            Assert.True(succeeded);
        }

        [Fact]
        public async Task UpdateBikeRepairStep_Should_Return_False_When_Status_Code_404_Is_Returned()
        {
            //arange
            UpdateBikeRepairStepDto requestData = new UpdateBikeRepairStepDto(1, 1, false);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.NotFound);

            //Act
            bool succeeded = await Service.UpdateBikeRepairStep(requestData);

            //Assert
            Assert.False(succeeded);
        }
    }
}
