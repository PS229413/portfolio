﻿using HetFietsenStation.Services.BikeStatus;
using HetFietsenStation.Dtos.BikeStatus;
using HetFietsenStation.Models;
using System.Text.Json;
using System.Net;
using HetFietsenStation.Containers;

namespace HetFietsenStationTests.Services
{
    public class BikeStatusServiceTests : ServiceTestsBase
    {
        BikeStatusService Service;

        public BikeStatusServiceTests()
        {
            Service = new BikeStatusService(_settingsService, true);
        }

        [Fact]
        public async Task GetBikeStatuses_Should_Return_List_When_Status_Code_200_Is_Returned()
        {
            JsonContainerList<GetBikeStatusDto> response = new()
            {
                data = new GetBikeStatusDto[1]
                {
                    new GetBikeStatusDto(1, "source", "description")
                },
                message = "",
                succes = true
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.OK, json);

            IEnumerable<BikeStatusModel> result = await Service.GetBikeStatuses();

            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetBikeStatuses_Should_Return_Empty_When_Status_Code_404_Is_Returned()
        {
            JsonContainerList<GetBikeStatusDto> response = new()
            {
                data = null,
                message = "",
                succes = false
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.NotFound, json);

            IEnumerable<BikeStatusModel> result = await Service.GetBikeStatuses();

            Assert.Empty(result);
        }
    }
}
