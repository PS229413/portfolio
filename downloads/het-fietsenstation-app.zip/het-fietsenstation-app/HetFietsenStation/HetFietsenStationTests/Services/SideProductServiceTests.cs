﻿using HetFietsenStation.Services.SideProduct;

namespace HetFietsenStationTests.Services
{
    public class SideProductServiceTests
    {
        private readonly SideProductMockService _service;

        public SideProductServiceTests()
        {
            _service = new SideProductMockService();
        }

        [Fact]
        public async void GetAllSideProducts_ReturnsAllSideProducts()
        {
            // Arrange

            // Act
            var result = await _service.GetAllSideProducts();

            // Assert
            Assert.Equal(4, result.Count());
        }

        [Fact]
        public async void GetSideProduct_ExistingId_ReturnsSideProduct()
        {
            // Arrange
            var existingId = 1;

            // Act
            var result = await _service.GetSideProduct(existingId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(existingId, result.Id);
        }

        [Fact]
        public async void GetSideProduct_NonExistingId_ReturnsNull()
        {
            // Arrange
            var nonExistingId = 99;

            // Act
            var result = await _service.GetSideProduct(nonExistingId);

            // Assert
            Assert.Null(result);
        }

        // Add more test methods here...
    }
}
