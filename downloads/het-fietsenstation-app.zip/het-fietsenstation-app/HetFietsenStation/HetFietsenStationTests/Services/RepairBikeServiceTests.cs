﻿using HetFietsenStation.Models;
using HetFietsenStation.Services.RepairBike;
using HetFietsenStation.Dtos.RepairBike;
using HetFietsenStation.Dtos.BikeType;
using HetFietsenStation.Dtos.BikeColor;
using HetFietsenStation.Dtos.BikeCondition;
using HetFietsenStation.Dtos.BikeStatus;
using HetFietsenStation.Dtos.BikeSource;
using System.Text.Json;
using System.Net;
using HetFietsenStation.Containers;

namespace HetFietsenStationTests.Services
{
    public class RepairBikeServiceTests : ServiceTestsBase
    {
        private readonly RepairBikeMockService _service;

        public RepairBikeServiceTests()
        {
            _service = new RepairBikeMockService();
        }

        [Fact]
        public async Task GetRepairBikes_Should_Return_List_When_Status_Code_200_Is_Returned()
        {
            JsonContainerList<GetRepairBikeDto> response = new()
            {
                data = new GetRepairBikeDto[1]
                {
                    new GetRepairBikeDto
                    (
                        1,
                        "brand",
                        "model",
                        new List<ImageModel> { new ImageModel { Id = 1, Url = "imageUrl" } },
                        1,
                        1,
                        DateTime.Now,
                        new GetBikeTypeDto(1, "type", "description"),
                        new GetBikeColorDto(1, "color", "description", "#FFFFFF"),
                        new GetBikeConditionDto(1, "condition", "description"),
                        new GetBikeStatusDto(1, "status", "description"),
                        new GetBikeSourceDto(1, "source", "description")
                    )
                },
                message = "",
                succes = true
            };

            string json = JsonSerializer.Serialize(response);

            RepairBikeService Service = new(_settingsService, true)
            {
                Client = HttpClientMockGenerator(HttpStatusCode.OK)
            };

            IEnumerable<RepairBikeModel> result = await Service.GetAllRepairBikes();

            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetRepairBikes_Should_Return_Empty_When_Status_Code_404_Is_Returned()
        {
            JsonContainerList<GetRepairBikeDto> response = new()
            {
                data = null,
                message = "",
                succes = false
            };

            string json = JsonSerializer.Serialize(response);

            RepairBikeService Service = new(_settingsService, true)
            {
                Client = HttpClientMockGenerator(HttpStatusCode.NotFound)
            };

            IEnumerable<RepairBikeModel> result = await Service.GetAllRepairBikes();

            Assert.Empty(result);
        }

        [Fact]
        public async Task GetRepairBike_Should_Return_RepairBike_When_Status_Code_200_Is_Returned()
        {
            JsonContainerSingle<GetRepairBikeDto> response = new()
            {
                data = 
                    new GetRepairBikeDto
                    (
                       1,
                       "brand",
                       "model",
                       new List<ImageModel> { new ImageModel { Id = 1, Url = "imageUrl" } },
                       1,
                       1,
                       DateTime.Now,
                       new GetBikeTypeDto(1, "type", "description"),
                       new GetBikeColorDto(1, "color", "description", "#FFFFFF"),
                       new GetBikeConditionDto(1, "condition", "description"),
                       new GetBikeStatusDto(1, "status", "description"),
                       new GetBikeSourceDto(1, "source", "description")
                    ),
                message = "",
                succes = true
            };

            string json = JsonSerializer.Serialize(response);

            RepairBikeService Service = new(_settingsService, true)
            {
                Client = HttpClientMockGenerator(HttpStatusCode.OK)
            };

            RepairBikeModel result = await _service.GetRepairBike(1);

            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetRepairBike_Should_Return_Null_When_Status_Code_404_Is_Returned()
        {
            RepairBikeService Service = new(_settingsService, true)
            {
                Client = HttpClientMockGenerator(HttpStatusCode.NotFound)
            };

            RepairBikeModel result = await Service.GetRepairBike(2);

            Assert.Null(result);
        }

        [Fact]
        public async Task UpdateRepairBike_Should_Return_True_When_Status_Code_200_Is_Returned()
        {
            UpdateRepairBikeDto requestData = new(1, "Brand", "Model", 1, 1, 1, 1, 1, 1);

            RepairBikeService Service = new(_settingsService, true)
            {
                Client = HttpClientMockGenerator(HttpStatusCode.OK)
            };

            bool result = await Service.UpdateRepairBike(requestData);

            Assert.True(result);
        }

        [Fact]
        public async Task UpdateRepairBike_Should_Return_False_When_Status_Code_404_Is_Returned()
        {
            UpdateRepairBikeDto requestData = new(-1, "Brand", "Model", 1, 1, 1, 1, 1, 1);

            RepairBikeService Service = new(_settingsService, true)
            {
                Client = HttpClientMockGenerator(HttpStatusCode.NotFound)
            };

            bool result = await Service.UpdateRepairBike(requestData);

            Assert.False(result);
        }

        [Fact]
        public async Task RepairBikeToPhotographBike_Should_Return_True_When_Status_Code_200_Is_Returned()
        {
            RepairBikeToPhotographBikeDto requestData = new(
                new PhotographBikeModel(
                    new RepairBikeModel(
                        1, 
                        "brand", 
                        "model",
                        new List<ImageModel> { new ImageModel { Id = 1, Url = "imageUrl" } },
                        1, 
                        1, 
                        DateTime.Now, 
                        new BikeTypeModel(1, "type", "description"), 
                        new BikeColorModel(1, "color", "description", "#FFFFFF"), 
                        new BikeConditionModel(1, "condition", "description"), 
                        new BikeStatusModel(1, "status", "description"), 
                        new BikeSourceModel(1, "source", "description"), 
                        new List<RepairStepModel> 
                        {
                            new RepairStepModel(1, "repair step", "description", true, true) 
                        }),
                    new UserModel(1, "martie", 1),
                    100,
                    "note"
                )
            );

            RepairBikeService Service = new RepairBikeService(_settingsService, true);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.OK);

            bool result = await Service.RepairBikeToPhotographBike(requestData);

            Assert.True(result);
        }

        [Fact]
        public async Task RepairBikeToPhotographBike_Should_Return_False_When_Status_Code_404_Is_Returned()
        {
            RepairBikeToPhotographBikeDto requestData = new(
                new PhotographBikeModel(
                    new RepairBikeModel(
                        1,
                        "brand",
                        "model",
                        new List<ImageModel> { new ImageModel { Id = 1, Url = "imageUrl" } },
                        1,
                        1,
                        DateTime.Now,
                        new BikeTypeModel(1, "type", "description"),
                        new BikeColorModel(1, "color", "description", "#FFFFFF"),
                        new BikeConditionModel(1, "condition", "description"),
                        new BikeStatusModel(1, "status", "description"),
                        new BikeSourceModel(1, "source", "description"),
                        new List<RepairStepModel>
                        {
                            new RepairStepModel(1, "repair step", "description", true, true)
                        }),
                    new UserModel(1, "martie", 1),
                    100,
                    "note"
                )
            );

            RepairBikeService Service = new RepairBikeService(_settingsService, true);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.NotFound);

            bool result = await Service.RepairBikeToPhotographBike(requestData);

            Assert.False(result);
        }

        [Fact]
        public async Task AddRepairBike_Should_Return_True_When_Status_Code_200_Is_Returned()
        {
            AddRepairBikeDto requestData = new("brand", "model", 1, 1, 1, 1, 1, 1);

            List<string> requestImages = new() { "imageUrl" };

            RepairBikeService Service = new(_settingsService, true)
            {
                Client = HttpClientMockGenerator(HttpStatusCode.OK)
            };

            bool result = await _service.AddRepairBike(requestData, requestImages);

            Assert.True(result);
        }

        [Fact]
        public async Task AddRepairBike_Should_Return_False_When_Status_Code_404_Is_Returned()
        {
            AddRepairBikeDto requestData = new("brand", "model", 1, 1, 1, 1, 1, 1);

            List<string> requestImages = new() { "imageUrl" };

            RepairBikeService Service = new(_settingsService, true)
            {
                Client = HttpClientMockGenerator(HttpStatusCode.NotFound)
            };

            bool result = await Service.AddRepairBike(requestData, requestImages);

            Assert.False(result);
        }
    }
}
