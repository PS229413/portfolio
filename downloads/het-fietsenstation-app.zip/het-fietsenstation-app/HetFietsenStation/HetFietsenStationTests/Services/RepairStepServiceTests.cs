﻿using HetFietsenStation.Containers;
using HetFietsenStation.Dtos.BikeRepairStep;
using HetFietsenStation.Dtos.RepairStep;
using HetFietsenStation.Services.RepairStep;
using System.Net;
using System.Text.Json;

namespace HetFietsenStationTests.Services
{
    public class RepairStepServiceTests : ServiceTestsBase
    {
        RepairStepService Service;
        public RepairStepServiceTests() 
        {
            Service = new RepairStepService(_settingsService, true);
        }

        [Fact]
        public async Task GetRepairSteps_Should_Return_RepairSteps_When_Status_Code_200_Is_Returned()
        {
            JsonContainerList<GetBikeRepairStepDto> response = new()
            {
                data = new GetBikeRepairStepDto[1]
                {
                    new GetBikeRepairStepDto(new GetRepairStepDto(1,"repair step", "description", true), true) 
                },
                message = "",
                succes = true
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.OK, json);

            IEnumerable<GetBikeRepairStepDto> result = await Service.GetRepairSteps(1);

            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetRepairSteps_Should_Return_Empty_When_Status_Code_404_Is_Returned()
        {
            JsonContainerList<GetBikeRepairStepDto> response = new()
            {
                data = null,
                message = "",
                succes = false
            };

            string json = JsonSerializer.Serialize(response);

            Service.Client = HttpClientMockGenerator(HttpStatusCode.NotFound, json);

            IEnumerable<GetBikeRepairStepDto> result = await Service.GetRepairSteps(-1);

            Assert.Empty(result);
        }
    }
}
