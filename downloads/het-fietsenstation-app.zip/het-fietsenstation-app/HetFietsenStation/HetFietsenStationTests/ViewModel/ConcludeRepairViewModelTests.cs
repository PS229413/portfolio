﻿using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;
using HetFietsenStation.ViewModels;
using HetFietsenStation.Services.RepairBike;
using HetFietsenStation.Services.User;

namespace HetFietsenStationTests.ViewModel
{
    public class ConcludeRepairViewModelTests
    {
        private readonly IUserService _userService;
        private readonly IRepairBikeService _repairBikeService;
        private readonly INavigationService _navigationService;
        private readonly ISettingsService _settingsService;

        ConcludeRepairViewModel Vm;

        public ConcludeRepairViewModelTests()
        {
            _userService = new UserMockService();
            _repairBikeService = new RepairBikeMockService();
            _navigationService = new NavigationMockService();
            _settingsService = new SettingsMockService();

            Vm = new ConcludeRepairViewModel(_userService ,_repairBikeService, _navigationService, _settingsService);
        }

        [Fact]
        public async Task GetMechanics_Should_Return_All_Mechanics()
        {
            //Act
            await Vm.GetMechanics();
            //Assert
            Assert.Single(Vm.Mechanics);
        }

        [Fact]
        public void Return_True_When_Check_Validation_Property_Data_Is_Zero()
        {
            //Arrange
            Vm.SelectedMechanicIndex.Value = 0;
            //Act
            bool isValid = Vm.SelectedMechanicIndex.Validate();
            //Assert
            Assert.True(isValid);
        }

        [Fact]
        public void Return_False_When_Check_Validation_Property_Data_Is_Minus_One()
        {
            //Arrange
            Vm.SelectedMechanicIndex.Value = -1;
            //Act
            bool isValid = Vm.SelectedMechanicIndex.Validate();
            //Assert
            Assert.False(isValid);
        }

        [Fact]
        public void Return_True_When_Check_Validation_Property_Data_Is_Filled()
        {
            //Arrange
            Vm.Note.Value = "note";
            //Act
            bool isValid = Vm.Note.Validate();
            //Assert
            Assert.True(isValid);
        }

        [Fact]
        public void Return_False_When_Check_Validation_Property_Data_Is_Null()
        {
            //Arrange
            Vm.Note.Value = null;
            //Act
            bool isValid = Vm.Note.Validate();
            //Assert
            Assert.False(isValid);
        }

        [Fact]
        public void Return_False_When_Check_Validation_Property_Data_Is_Empty_Space()
        {
            //Arrange
            Vm.Note.Value = "";
            //Act
            bool isValid = Vm.Note.Validate();
            //Assert
            Assert.False(isValid);
        }

        [Fact]
        public void Return_True_When_Check_Validation_Property_Data_Does_Not_Contain_Strange_Characters()
        {
            //Arrange
            Vm.Note.Value = "note";
            //Act
            bool isValid = Vm.Note.Validate();
            //Assert
            Assert.True(isValid);
        }

        [Fact]
        public void Return_False_When_Check_Validation_Property_Data_Does_Contain_Strange_Characters()
        {
            //Arrange
            Vm.Note.Value = "note@";
            //Act
            bool isValid = Vm.Note.Validate();
            //Assert
            Assert.False(isValid);
        }

        [Fact]
        public async Task BuildPriceTag_WrongInputValues_Should_Return_True()
        {
            //Arrange
            Vm.Note.Value = "brand@";
            Vm.SelectedMechanicIndex.Value = 1;
            //Act
            await Vm.BuildPriceTag();
            //Assert
            Assert.True(Vm.WrongInputValues);
        }

        [Fact]
        public async Task AddBike_Everything_Should_Return_False()
        {
            //Arrange
            Vm.PhotographBike = new PhotographBikeModel();
            Vm.PhotographBike.Id = 1;
            Vm.PhotographBike.Price = 1;
            Vm.Note.Value = "brand";
            Vm.SelectedMechanicIndex.Value = 1;
            Vm.SelectedMechanic = new UserModel(1, "user", 1);
            //Act
            await Vm.BuildPriceTag();
            //Assert
            Assert.False(Vm.WrongInputValues);
            Assert.False(Vm.ConcludeRepairFailed);
        }
    }
}
