﻿using HetFietsenStation.Services.BikeRepairStep;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.RepairStep;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;
using HetFietsenStation.ViewModels;
using System.Collections.ObjectModel;

namespace HetFietsenStationTests.ViewModel
{
    public class RepairViewModelTests 
    {
        private readonly IBikeRepairStepService _bikeRepairStepService;
        private readonly IRepairStepService _repairStepService;
        private readonly INavigationService _navigationService;
        private readonly ISettingsService _settingsService;

        RepairViewModel Vm;

        public RepairViewModelTests()
        {
            _bikeRepairStepService = new BikeRepairStepMockService();
            _repairStepService = new RepairStepMockService();
            _navigationService = new NavigationMockService();
            _settingsService = new SettingsMockService();

            Vm = new RepairViewModel(_bikeRepairStepService, _repairStepService, _navigationService, _settingsService);
        }

        [Fact]
        public async Task LoadRepairSteps_Should_Load_All_Repair_Steps()
        {
            //Act
            bool output = await Vm.LoadRepairSteps(1);
            //Assert
            Assert.True(output);
        }

        [Fact]
        public async Task LoadRepairSteps_Should_Not_Load_All_Repair_Steps_When_Bike_Does_NotExist()
        {
            //Act
            bool output = await Vm.LoadRepairSteps(3);
            //Assert
            Assert.False(output);
        }

        [Fact]
        public async Task LoadRepairSteps_Should_Not_Load_All_Repair_Steps_When_Error_Occurs()
        {
            //Arrange
            RepairViewModel vm = new RepairViewModel(null, null, null, null);
            //Act
            bool output = await vm.LoadRepairSteps(3);
            //Assert
            Assert.False(output);
        }

        [Fact]
        public async Task UpdateRepairStepChecked_Should_Update_Repair_Step()
        {
            //Arrange
            Vm.RequiredRepairSteps.Add(new RepairStepModel(1, "Test 1", "Test 1", true, false));
            Vm.RepairBike = new RepairBikeModel { Id = 1 };
            //Act
            await Vm.UpdateRepairStepChecked(1);
            bool output = Vm.RequiredRepairSteps.Where(rrs => rrs.Id == 1).First().Done;
            //Assert
            Assert.True(output);
        }

        [Fact]
        public async Task UpdateRepairStepChecked_Should_Not_Update_Repair_Step()
        {
            //Arrange
            Vm.RequiredRepairSteps.Add(new RepairStepModel(1, "Test 1", "Test 1", true, true));
            Vm.RepairBike = new RepairBikeModel { Id = 1 };
            //Act
            await Vm.UpdateRepairStepChecked(1);
            bool output = Vm.RequiredRepairSteps.Where(rrs => rrs.Id == 1).First().Done;
            //Assert
            Assert.False(output);
        }

        [Fact]
        public async Task UpdateRepairStepChecked_DoesRepairStepNotExist_Should_Return_True()
        {
            //Arrange
            Vm.RequiredRepairSteps.Add(new RepairStepModel(0, "Test 1", "Test 1", true, true));
            Vm.RepairBike = new RepairBikeModel { Id = 1 };
            //Act
            await Vm.UpdateRepairStepChecked(0);
            //Assert
            Assert.True(Vm.DoesRepairStepNotExist);
        }

        [Fact]
        public async Task UpdateRepairStepChecked_DoesRepairStepNotExist_Should_Return_False()
        {
            //Arrange
            Vm.RequiredRepairSteps.Add(new RepairStepModel(3, "Test 1", "Test 1", true, true));
            Vm.RepairBike = new RepairBikeModel { Id = 1 };
            //Act
            await Vm.UpdateRepairStepChecked(3);
            //Assert
            Assert.False(Vm.DoesRepairStepNotExist);
        }

        [Fact]
        public void CombineObservableCollections_Should_Combine_ObservableCollections()
        {
            ObservableCollection<RepairStepModel> input1 = new ObservableCollection<RepairStepModel>() { new RepairStepModel(1, "Test 1 ", "Test 1", true, true), new RepairStepModel(1, "Test 2 ", "Test 2", false, false) };
            ObservableCollection<RepairStepModel> input2 = new ObservableCollection<RepairStepModel>() { new RepairStepModel(1, "Test 1 ", "Test 1", true, true), new RepairStepModel(1, "Test 2 ", "Test 2", false, false) };
            //Act
            int output = Vm.CombineObservableCollections(input1, input2).Count;
            //Assert
            Assert.Equal(4, output);
        }

        [Fact]
        public void Return_True_When_Validation_Property_Data_Is_Above_Zero()
        {
            Vm.Price.Value = 1;
            //Act
            bool isValid = Vm.Price.Validate();
            //Assert
            Assert.True(isValid);
        }

        [Fact]
        public void Return_False_When_Check_Validation_Property_Data_Is_Below_Zero()
        {
            Vm.Price.Value = -1;
            //Act
            bool isValid = Vm.Price.Validate();
            //Assert
            Assert.False(isValid);
        }
    }
}
