﻿using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;
using HetFietsenStation.ViewModels;
using HetFietsenStation.Services.RepairBike;
using HetFietsenStation.Services.BikeType;
using HetFietsenStation.Services.BikeColor;
using HetFietsenStation.Services.BikeCondition;
using HetFietsenStation.Services.BikeSource;

namespace HetFietsenStationTests.ViewModel
{
    public class EditRepairBikeViewModelTests
    {
        private readonly IRepairBikeService _repairBikeService;
        private readonly IBikeTypeService _BikeTypeService;
        private readonly IBikeColorService _BikeColorService;
        private readonly IBikeConditionService _BikeConditionService;
        private readonly IBikeSourceService _BikeSourceService;
        private readonly INavigationService _navigationService;
        private readonly ISettingsService _settingsService;

        EditRepairBikeViewModel Vm;

        public EditRepairBikeViewModelTests()
        {
            _repairBikeService = new RepairBikeMockService();
            _BikeTypeService = new BikeTypeMockService();
            _BikeColorService = new BikeColorMockService();
            _BikeConditionService = new BikeConditionMockService();
            _BikeSourceService = new BikeSourceMockService();
            _navigationService = new NavigationMockService();
            _settingsService = new SettingsMockService();

            Vm = new EditRepairBikeViewModel(_repairBikeService, _BikeTypeService, _BikeColorService, _BikeConditionService, _BikeSourceService, _navigationService, _settingsService);
        }

        [Fact]
        public async Task GetBikeTypes_Should_Return_All_BikeTypes()
        {
            //Assert
            Vm.RepairBike = new RepairBikeModel();
            Vm.RepairBike.BikeType = new BikeTypeModel(1, "type", "description");
            //Act
            await Vm.GetBikeTypes();
            //Assert
            Assert.Equal(2, Vm.BikeTypes.Count);
        }

        [Fact]
        public async Task GetBikeColors_Should_Return_All_BikeColors()
        {
            //Assert
            Vm.RepairBike = new RepairBikeModel();
            Vm.RepairBike.BikeColor = new BikeColorModel(1, "color", "description", "#FFFFFF");
            //Act
            await Vm.GetBikeColors();
            //Assert
            Assert.Equal(2, Vm.BikeColors.Count);
        }

        [Fact]
        public async Task GetBikeConditions_Should_Return_All_BikeConditions()
        {
            //Assert
            Vm.RepairBike = new RepairBikeModel();
            Vm.RepairBike.BikeCondition = new BikeConditionModel(1, "condition", "description");
            //Act
            await Vm.GetBikeConditions();
            //Assert
            Assert.Equal(2, Vm.BikeConditions.Count);
        }

        [Fact]
        public async Task GetBikeSources_Should_Return_All_BikeSources()
        {
            //Assert
            Vm.RepairBike = new RepairBikeModel();
            Vm.RepairBike.BikeSource = new BikeSourceModel(1, "source", "description");
            //Act
            await Vm.GetBikeSources();
            //Assert
            Assert.Equal(2, Vm.BikeSources.Count);
        }

        [Fact]
        public void Return_True_When_Check_Validation_Property_Data_Does_Not_Contain_Strange_Characters()
        {
            //Arrange
            Vm.Brand.Value = "brand";
            Vm.Model.Value = "model";
            //Act
            bool isBrandValid = Vm.Brand.Validate();
            bool isModelValid = Vm.Model.Validate();
            //Assert
            Assert.True(isBrandValid);
            Assert.True(isModelValid);
        }

        [Fact]
        public void Return_False_When_Check_Validation_Property_Data_Does_Contain_Strange_Characters()
        {
            //Arrange
            Vm.Brand.Value = "brand@";
            Vm.Model.Value = "model@";
            //Act
            bool isBrandValid = Vm.Brand.Validate();
            bool isModelValid = Vm.Model.Validate();
            //Assert
            Assert.False(isBrandValid);
            Assert.False(isModelValid);
        }

        [Fact]
        public void Return_True_When_Check_Validation_Property_Data_Is_Zero()
        {
            //Arrange
            Vm.SelectedBikeTypeIndex.Value = 0;
            Vm.SelectedBikeColorIndex.Value = 0;
            Vm.SelectedBikeConditionIndex.Value = 0;
            Vm.SelectedBikeSourceIndex.Value = 0;
            //Act
            bool isBiketypeValid = Vm.SelectedBikeTypeIndex.Validate();
            bool isBikeColorValid = Vm.SelectedBikeColorIndex.Validate();
            bool isBikeConditionValid = Vm.SelectedBikeConditionIndex.Validate();
            bool isBikeSourceValid = Vm.SelectedBikeSourceIndex.Validate();
            //Assert
            Assert.True(isBiketypeValid);
            Assert.True(isBikeColorValid);
            Assert.True(isBikeConditionValid);
            Assert.True(isBikeSourceValid);
        }

        [Fact]
        public void Return_False_When_Check_Validation_Property_Data_Is_Minus_One()
        {
            //Arrange
            Vm.SelectedBikeTypeIndex.Value = -1;
            Vm.SelectedBikeColorIndex.Value = -1;
            Vm.SelectedBikeConditionIndex.Value = -1;
            Vm.SelectedBikeSourceIndex.Value = -1;
            //Act
            bool isBiketypeValid = Vm.SelectedBikeTypeIndex.Validate();
            bool isBikeColorValid = Vm.SelectedBikeColorIndex.Validate();
            bool isBikeConditionValid = Vm.SelectedBikeConditionIndex.Validate();
            bool isBikeSourceValid = Vm.SelectedBikeSourceIndex.Validate();
            //Assert
            Assert.False(isBiketypeValid);
            Assert.False(isBikeColorValid);
            Assert.False(isBikeConditionValid);
            Assert.False(isBikeSourceValid);
        }

        [Fact]
        public void Return_True_When_Check_Validation_Property_Data_Is_One()
        {
            //Arrange
            Vm.FrameHeight.Value = 1;
            Vm.FrameNumber.Value = 1;
            //Act
            bool isFrameHeightValid = Vm.FrameHeight.Validate();
            bool isFrameNumberValid = Vm.FrameNumber.Validate();
            //Assert
            Assert.True(isFrameHeightValid);
            Assert.True(isFrameNumberValid);
        }

        [Fact]
        public void Return_False_When_Check_Validation_Property_Data_Is_Zero()
        {
            //Arrange
            Vm.FrameHeight.Value = 0;
            Vm.FrameNumber.Value = 0;
            //Act
            bool isFrameHeightValid = Vm.FrameHeight.Validate();
            bool isFrameNumberValid = Vm.FrameNumber.Validate();
            //Assert
            Assert.False(isFrameHeightValid);
            Assert.False(isFrameNumberValid);
        }

        [Fact]
        public void Return_True_When_Check_Validation_Property_Data_Is_Filled()
        {
            //Arrange
            Vm.Brand.Value = "brand";
            Vm.Model.Value = "model";
            //Act
            bool isBrandValid = Vm.Brand.Validate();
            bool isModelValid = Vm.Model.Validate();
            //Assert
            Assert.True(isBrandValid);
            Assert.True(isModelValid);
        }

        [Fact]
        public void Return_False_When_Check_Validation_Property_Data_Is_Null()
        {
            //Arrange
            Vm.Brand.Value = null;
            Vm.Model.Value = null;
            //Act
            bool isBrandValid = Vm.Brand.Validate();
            bool isModelValid = Vm.Model.Validate();
            //Assert
            Assert.False(isBrandValid);
            Assert.False(isModelValid);
        }

        [Fact]
        public void Return_False_When_Check_Validation_Property_Data_Is_Empty_Space()
        {
            //Arrange
            Vm.Brand.Value = "";
            Vm.Model.Value = "";
            //Act
            bool isBrandValid = Vm.Brand.Validate();
            bool isModelValid = Vm.Model.Validate();
            //Assert
            Assert.False(isBrandValid);
            Assert.False(isModelValid);
        }

        [Fact]
        public async Task AddBike_WrongInputValues_Should_Return_True()
        {
            //Arrange
            Vm.Brand.Value = "brand";
            Vm.Model.Value = "model";
            Vm.FrameHeight.Value = -1;
            Vm.FrameNumber.Value = 1;
            Vm.SelectedBikeTypeIndex.Value = 1;
            Vm.SelectedBikeColorIndex.Value = 1;
            Vm.SelectedBikeConditionIndex.Value = 1;
            Vm.SelectedBikeSourceIndex.Value = 1;
            //Act
            await Vm.EditBike();
            //Assert
            Assert.True(Vm.WrongInputValues);
        }

        [Fact]
        public async Task AddBike_Everything_Should_Return_False()
        {
            //Arrange
            Vm.RepairBike = new RepairBikeModel();
            Vm.RepairBike.Id = 1;
            Vm.Brand.Value = "brand";
            Vm.Model.Value = "model";
            Vm.FrameHeight.Value = 1;
            Vm.FrameNumber.Value = 1;
            Vm.SelectedBikeTypeIndex.Value = 1;
            Vm.SelectedBikeColorIndex.Value = 1;
            Vm.SelectedBikeConditionIndex.Value = 1;
            Vm.SelectedBikeSourceIndex.Value = 1;
            Vm.SelectedBikeColor = new BikeColorModel(1, "color", "description", "#FFFFFF");
            Vm.SelectedBikeType = new BikeTypeModel(1, "type", "description");
            Vm.SelectedBikeCondition = new BikeConditionModel(1, "condition", "description");
            Vm.SelectedBikeSource = new BikeSourceModel(1, "source", "description");
            //Act
            await Vm.EditBike();
            //Assert
            Assert.False(Vm.WrongInputValues);
            Assert.False(Vm.EditBikeFailed);
        }
    }
}
