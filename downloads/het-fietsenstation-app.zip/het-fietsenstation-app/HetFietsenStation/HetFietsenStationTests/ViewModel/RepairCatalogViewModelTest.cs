﻿using HetFietsenStation.Services.BikeType;
using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.RepairBike;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.ViewModels;

namespace HetFietsenStationTests.ViewModel
{
    public class RepairCatalogViewModelTests 
    {
        private readonly IRepairBikeService _repairBikeService;
        private readonly INavigationService _navigationService;
        private readonly ISettingsService _settingsService;
        private readonly IBikeTypeService _bikeTypeService;
        private readonly RepairCatalogViewModel Vm;

        public RepairCatalogViewModelTests()
        {
            _repairBikeService = new RepairBikeMockService();
            _navigationService = new NavigationMockService();
            _settingsService = new SettingsMockService();
            _bikeTypeService = new BikeTypeMockService();

            Vm = new RepairCatalogViewModel(_repairBikeService, _bikeTypeService, _navigationService, _settingsService);
        }


        [Fact]
        public async Task SearchBike_Should_Return_One_Repair_Bikes()
        {
            //Arrange
            Vm.SearchBikeValue.Value = 1;
            //Act
            await Vm.SearchBike();
            //Assert
            Assert.Single(Vm.RepairBikes);
        }

        [Fact]
        public async Task SearchBike_Should_Return_All_Repair_Bikes()
        {
            //Arrange
            Vm.SearchBikeValue.Value = 0;
            //Act
            await Vm.SearchBike();
            //Assert
            Assert.Equal(2, Vm.RepairBikes.Count);
        }

        [Fact]
        public async Task GetRepairBikes_Should_Return_All_Repair_Bikes()
        {
            //Act
            await Vm.GetRepairBikes();
            //Assert
            Assert.Equal(2, Vm.RepairBikes.Count);
        }


        [Fact]
        public void Return_True_When_Check_Validation_Property_Data_Is_Above_Zero()
        {
            //Arrange
            Vm.SearchBikeValue.Value = 1;
            //Act
            bool isValid = Vm.SearchBikeValue.Validate();
            //Assert
            Assert.True(isValid);
        }
    }
}
