﻿using HetFietsenStation.Services.Navigation;
using HetFietsenStation.Services.Settings;
using HetFietsenStation.Models;
using HetFietsenStation.ViewModels;
using HetFietsenStation.Services.User;
using HetFietsenStation.Enums;

namespace HetFietsenStationTests.ViewModel
{
    public class LoginViewModeTests
    {
        private readonly IUserService _userService;
        private readonly INavigationService _navigationService;
        private readonly ISettingsService _settingsService;

        private readonly LoginViewModel Vm;

        public LoginViewModeTests()
        {
            _userService = new UserMockService();
            _navigationService = new NavigationMockService();
            _settingsService = new SettingsMockService();

            Vm = new LoginViewModel(_userService, _navigationService, _settingsService);
        }

        [Fact]
        public void GetRouteByUserRoleId_Should_Return_RepairCatalog()
        {
            //Act
            string output = LoginViewModel.GetRouteByUserRoleId(UserRole.Mechanic);
            //Assert
            Assert.Equal("RepairCatalog", output);
        }

        [Fact]
        public void GetRouteByUserRoleId_Should_Return_AdminHome()
        {
            //Act
            string output = LoginViewModel.GetRouteByUserRoleId(UserRole.Admin);
            //Assert
            Assert.Equal("AdminHome", output);
        }

        [Fact]
        public void GetRouteByUserRoleId_Should_Return_PhotographCatalog()
        {
            //Act
            string output = LoginViewModel.GetRouteByUserRoleId(UserRole.Photographer);
            //Assert
            Assert.Equal("PhotographCatalog", output);
        }

        [Fact]
        public void GetRouteByUserRoleId_Should_Return_ShopCatalog()
        {
            //Act
            string output = LoginViewModel.GetRouteByUserRoleId(UserRole.SalesPerson);
            //Assert
            Assert.Equal("ShopCatalog", output);
        }

        [Fact]
        public async Task GetUsers_Should_Return_All_Users() 
        {
            //Act
            await Vm.GetUsers();
            //Assert
            Assert.Equal(3, Vm.Users.Count);
        }

        [Fact]
        public async Task Login_WrongInputValues_Should_Return_True()
        {
            //Arrange
            Vm.SelectedUserIndex.Value = -1;
            Vm.Password.Value = "something";
            //Act
            await Vm.Login();
            //Assert
            Assert.True(Vm.WrongInputValues);
        }

        [Fact]
        public async Task Login_LoginFailed_Should_Return_True()
        {
            //Arrange
            Vm.SelectedUserIndex.Value = 5;
            Vm.SelectedUser = new UserModel(5, "user 5", 1);
            Vm.Password.Value = "something";
            //Act
            await Vm.Login();
            //Assert
            Assert.True(Vm.LoginFailed);
        }

        [Fact]
        public async Task Login_UserRoleExistsNot_Should_Return_True()
        {
            //Arrange
            Vm.SelectedUserIndex.Value = 1;
            Vm.SelectedUser = new UserModel(1, "user 1", 5);
            Vm.Password.Value = "something";
            //Act
            await Vm.Login();
            //Assert
            Assert.True(Vm.UserRoleExistsNot);
        }

        [Fact]
        public void Return_True_When_Check_Validation_Property_Data_Is_Above_Zero()
        {
            //Arrange
            Vm.SelectedUserIndex.Value = 1;
            //Act
            bool isValid = Vm.SelectedUserIndex.Validate();
            //Assert
            Assert.True(isValid);
        }

        [Fact]
        public void Return_False_When_Check_Validation_Property_Data_Is_Below_Zero()
        {
            //Arrange
            Vm.SelectedUserIndex.Value = -1;
            //Act
            bool isValid = Vm.SelectedUserIndex.Validate();
            //Assert
            Assert.False(isValid);
        }

        [Fact]
        public void Return_True_When_Check_Validation_Property_Data_Is_Filled()
        {
            //Arrange
            Vm.Password.Value = "password";
            //Act
            bool isValid = Vm.Password.Validate();
            //Assert
            Assert.True(isValid);
        }

        [Fact]
        public void Return_False_When_Check_Validation_Property_Data_Is_Null()
        {
            //Arrange
            Vm.Password.Value = null;
            //Act
            bool isValid = Vm.Password.Validate();
            //Assert
            Assert.False(isValid);
        }

        [Fact]
        public void Return_False_When_Check_Validation_Property_Data_Is_Empty_Space()
        {
            //Arrange
            Vm.Password.Value = "";
            //Act
            bool isValid = Vm.Password.Validate();
            //Assert
            Assert.False(isValid);
        }
    }
}
