# Het Fietsenstation App

[![windowsCI](https://github.com/Het-Beginstation/het-fietsenstation-app/actions/workflows/Maui.yml/badge.svg)](https://github.com/Het-Beginstation/het-fietsenstation-app/actions/workflows/Maui.yml)

Welcome to the Het Fietsenstation App! 🚲

Wiki
You can find more information about the project, including documentation and guides, in our [Wiki](https://github.com/Het-Beginstation/het-fietsenstation-app/wiki).

Feel free to explore the Wiki to learn more about the Het Fietsenstation App and its features!

Happy cycling! 🚴‍♀️🚴‍♂️