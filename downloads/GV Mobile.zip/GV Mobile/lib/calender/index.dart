import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CalendarScreen extends StatefulWidget {
  final String staffId;

  CalendarScreen({required this.staffId});

  @override
  _CalendarScreenState createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  List<Schedule> schedules = [];
  bool isLoading = false;
  bool isError = false;

  @override
  void initState() {
    super.initState();
    fetchSchedules();
  }

  Future<void> fetchSchedules() async {
    setState(() {
      isLoading = true;
    });

    Uri url = Uri.parse('http://10.0.2.2:8001/api/staff/${widget.staffId}/schedules');

    try {
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var jsonData = json.decode(response.body);
        List<Schedule> loadedSchedules = [];
        for (var item in jsonData) {
          loadedSchedules.add(Schedule.fromJson(item));
        }
        setState(() {
          schedules = loadedSchedules;
          isLoading = false;
          isError = false;
        });
      } else {
        print('Failed to load schedules');
        setState(() {
          isLoading = false;
          isError = true;
        });
      }
    } catch (e) {
      print('Network error: $e');
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  Future<void> createSchedule(String date, String startTime, String endTime) async {
    final Uri url = Uri.parse('http://10.0.2.2:8001/api/schedules/create');
    final Map<String, dynamic> requestData = {
      'date': date,
      'start_time': startTime,
      'end_time': endTime,
      'staff_id': widget.staffId,
    };

    try {
      var response = await http.post(
        url,
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(requestData),
      );

      if (response.statusCode == 201) {
        fetchSchedules();
        Navigator.pop(context);
      } else {
        print('Failed to create schedule: ${response.statusCode}');
      }
    } catch (e) {
      print('Network error: $e');
    }
  }

  Future<void> deleteSchedule(int id) async {
    final Uri url = Uri.parse('http://10.0.2.2:8001/api/schedules/$id');

    try {
      var response = await http.delete(url);
      if (response.statusCode == 200 || response.statusCode == 204) {
        fetchSchedules();
      } else {
        print('Failed to delete schedule: ${response.statusCode}');
      }
    } catch (e) {
      print('Network error: $e');
    }
  }

  void showCreateScheduleOverlay(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return CreateScheduleOverlay(
          onCreate: (date, startTime, endTime) {
            createSchedule(date, startTime, endTime);
          },
        );
      },
    );
  }

  void navigateBackToMenuScreen() {
    Navigator.of(context).pop(widget.staffId); // Pass staffId back to MenuScreen
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            top: 25, // Adjust position here
            left: 16, // Adjust position here
            child: IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: navigateBackToMenuScreen,
            ),
          ),
          Positioned(
            top: 0,
            right: 0,
            child: Image.asset(
              'lib/assets/Ellipse1.png',
              width: 205,
              height: 220,
              fit: BoxFit.cover,
            ),
          ),
          Container(
            padding: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 40),
                Text(
                  'Weekly Schedule',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue,
                  ),
                ),
                SizedBox(height: 20),
                Expanded(
                  child: _buildScheduleList(),
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 16,
            right: 16,
            child: FloatingActionButton(
              onPressed: () {
                showCreateScheduleOverlay(context);
              },
              tooltip: 'Add Schedule',
              child: Icon(Icons.add),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScheduleList() {
    if (isLoading) {
      return Center(
        child: CircularProgressIndicator(),
      );
    } else if (isError) {
      return Center(
        child: Text(
          'Failed to load schedules',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.red,
          ),
        ),
      );
    } else if (schedules.isEmpty) {
      return Center(
        child: Text(
          'No schedules available',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black54,
          ),
        ),
      );
    } else {
      return ListView.builder(
        itemCount: schedules.length,
        itemBuilder: (context, index) {
          return _buildScheduleCard(schedules[index]);
        },
      );
    }
  }

  Widget _buildScheduleCard(Schedule schedule) {
    return Card(
      elevation: 4,
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Date: ${schedule.date}',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    'Start Time: ${schedule.startTime}',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
                Expanded(
                  child: Text(
                    'End Time: ${schedule.endTime}',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    if (schedule.id != null) {
                      deleteSchedule(schedule.id);
                    } else {
                      print('Schedule id is null');
                    }
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class Schedule {
  final int id;
  final String date;
  final String startTime;
  final String endTime;

  Schedule({
    required this.id,
    required this.date,
    required this.startTime,
    required this.endTime,
  });

  factory Schedule.fromJson(Map<String, dynamic> json) {
    return Schedule(
      id: json['id'] ?? 0,
      date: json['date'] ?? '',
      startTime: json['start_time'] ?? '',
      endTime: json['end_time'] ?? '',
    );
  }
}

class CreateScheduleOverlay extends StatefulWidget {
  final Function(String, String, String) onCreate;

  CreateScheduleOverlay({required this.onCreate});

  @override
  _CreateScheduleOverlayState createState() => _CreateScheduleOverlayState();
}

class _CreateScheduleOverlayState extends State<CreateScheduleOverlay> {
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _startTimeController = TextEditingController();
  final TextEditingController _endTimeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Create Schedule'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _dateController,
            decoration: InputDecoration(labelText: 'Date'),
          ),
          TextField(
            controller: _startTimeController,
            decoration: InputDecoration(labelText: 'Start Time'),
          ),
          TextField(
            controller: _endTimeController,
            decoration: InputDecoration(labelText: 'End Time'),
          ),
        ],
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            widget.onCreate(
              _dateController.text,
              _startTimeController.text,
              _endTimeController.text,
            );
          },
          child: Text('Create'),
        ),
      ],
    );
  }
}