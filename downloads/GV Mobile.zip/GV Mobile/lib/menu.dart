import 'package:flutter/material.dart';
import 'package:gvmobile/calender/index.dart';
import 'package:gvmobile/persoonlijke_gegevens/index.dart';
import 'package:gvmobile/ziek/index.dart';
import 'package:gvmobile/vakantie/index.dart';
import 'package:gvmobile/salaris/index.dart';

class MenuScreen extends StatelessWidget {
  final String loggedInStaffId;

  MenuScreen({required this.loggedInStaffId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            top: 0,
            right: 0,
            child: Image.asset(
              'lib/assets/Ellipse1.png',
              width: 205,
              height: 220,
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(height: 20), // Add spacing between image and buttons
                _buildGroup(context, 'Main Features', [
                  _buildMenuButton(
                    context,
                    text: 'Kalender',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => CalendarScreen(staffId: loggedInStaffId)),
                      );
                    },
                  ),
                  _buildMenuButton(
                    context,
                    text: 'Persoons gegevens',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => PersoonlijkeGegevensScreen(loggedInStaffId: loggedInStaffId),
                      ),
                      );
                    },
                  ),
                ]),
                _buildGroup(context, 'Work Related', [
                  _buildMenuButton(
                    context,
                    text: 'Ziek',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ZiekScreen(loggedInStaffId: loggedInStaffId)),
                      );
                    },
                  ),
                  _buildMenuButton(
                    context,
                    text: 'Vakantie',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => VakantieScreen(loggedInStaffId: loggedInStaffId)),
                      );
                    },
                  ),
                  _buildMenuButton(
                    context,
                    text: 'Salaris',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SalaryScreen(loggedInStaffId: loggedInStaffId)),
                      );
                    },
                  ),
                ]),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGroup(BuildContext context, String title, List<Widget> buttons) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            title,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.blue,
            ),
          ),
        ),
        SizedBox(height: 10),
        ...buttons,
        SizedBox(height: 20),
      ],
    );
  }

  Widget _buildMenuButton(BuildContext context, {required String text, required Function onPressed}) {
    return Container(
      width: 200,
      margin: EdgeInsets.symmetric(vertical: 10),
      child: TextButton(
        onPressed: () => onPressed(),
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all(Color(0xFF2CBB1F)),
          foregroundColor: MaterialStateProperty.all(Colors.white),
          shape: MaterialStateProperty.all(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5),
            ),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Text(
            text,
            style: TextStyle(fontSize: 18),
          ),
        ),
      ),
    );
  }
}