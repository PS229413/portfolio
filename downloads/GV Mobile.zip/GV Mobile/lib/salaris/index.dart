import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class SalaryScreen extends StatefulWidget {
  final String loggedInStaffId;

  SalaryScreen({required this.loggedInStaffId});

  @override
  _SalaryScreenState createState() => _SalaryScreenState();
}

class _SalaryScreenState extends State<SalaryScreen> {
  List<Salary> salaryRecords = [];
  bool isLoading = false;
  bool isError = false;

  @override
  void initState() {
    super.initState();
    fetchSalaryRecords();
  }

  Future<void> fetchSalaryRecords() async {
    setState(() {
      isLoading = true;
    });

    final url = Uri.parse('http://10.0.2.2:8001/api/salaries');

    try {
      var response = await http.get(url, headers: {'Content-Type': 'application/json'});
      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        var jsonData = json.decode(response.body);
        if (jsonData is List) {
          List<Salary> loadedSalaryRecords = [];
          for (var item in jsonData) {
            loadedSalaryRecords.add(Salary.fromJson(item));
          }
          setState(() {
            salaryRecords = loadedSalaryRecords;
            isLoading = false;
            isError = false;
          });
        } else {
          print('Unexpected JSON format');
          setState(() {
            isLoading = false;
            isError = true;
          });
        }
      } else {
        print('Failed to load salary records: ${response.statusCode}');
        setState(() {
          isLoading = false;
          isError = true;
        });
      }
    } catch (e) {
      print('Network error: $e');
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Salary Records'),
      ),
      body: Stack(
        children: [
          Container(
            padding: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 40),
                Text(
                  'Salary Records',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue,
                  ),
                ),
                SizedBox(height: 20),
                Expanded(
                  child: _buildSalaryRecordsList(),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showCreateSalaryRecordDialog();
        },
        child: Icon(Icons.add),
      ),
    );
  }

  Widget _buildSalaryRecordsList() {
    if (isLoading) {
      return Center(
        child: CircularProgressIndicator(),
      );
    } else if (isError) {
      return Center(
        child: Text(
          'Failed to load salary records',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.red,
          ),
        ),
      );
    } else if (salaryRecords.isEmpty) {
      return Center(
        child: Text(
          'No salary records available',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black54,
          ),
        ),
      );
    } else {
      return ListView.builder(
        itemCount: salaryRecords.length,
        itemBuilder: (context, index) {
          return _buildSalaryRecordCard(salaryRecords[index]);
        },
      );
    }
  }

  Widget _buildSalaryRecordCard(Salary record) {
    return Card(
      elevation: 4,
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Amount: \$${record.amount}',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Date: ${record.salaryDate}',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    _showEditSalaryRecordDialog(record);
                  },
                  child: Text('Edit'),
                ),
                TextButton(
                  onPressed: () {
                    _confirmDeleteSalaryRecord(record.id);
                  },
                  child: Text(
                    'Delete',
                    style: TextStyle(color: Colors.red),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showCreateSalaryRecordDialog() async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return CreateSalaryRecordOverlay(
          loggedInStaffId: widget.loggedInStaffId,
          onCreate: (data) {
            createSalaryRecord(data);
            Navigator.of(context).pop();
          },
        );
      },
    );
  }

  Future<void> _showEditSalaryRecordDialog(Salary record) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return EditSalaryRecordOverlay(
          salaryRecord: record,
          onUpdate: (id, data) {
            updateSalaryRecord(id, data);
            Navigator.of(context).pop();
          },
        );
      },
    );
  }

  Future<void> _confirmDeleteSalaryRecord(int id) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirm Deletion'),
          content: Text('Are you sure you want to delete this salary record?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                deleteSalaryRecord(id);
                Navigator.of(context).pop();
              },
              child: Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  Future<void> createSalaryRecord(Map<String, dynamic> data) async {
    final url = Uri.parse('http://10.0.2.2:8001/api/salaries');

    try {
      var response = await http.post(
        url,
        body: json.encode(data),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode == 201) {
        fetchSalaryRecords();
      } else {
        print('Failed to create salary record: ${response.statusCode}');
      }
    } catch (e) {
      print('Network error: $e');
    }
  }

  Future<void> updateSalaryRecord(int id, Map<String, dynamic> data) async {
    final url = Uri.parse('http://10.0.2.2:8001/api/salaries/$id');

    try {
      var response = await http.put(
        url,
        body: json.encode(data),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode == 200) {
        fetchSalaryRecords();
      } else {
        print('Failed to update salary record: ${response.statusCode}');
      }
    } catch (e) {
      print('Network error: $e');
    }
  }

  Future<void> deleteSalaryRecord(int id) async {
    final url = Uri.parse('http://10.0.2.2:8001/api/salaries/$id');

    try {
      var response = await http.delete(url);
      if (response.statusCode == 200 || response.statusCode == 204) {
        fetchSalaryRecords();
      } else {
        print('Failed to delete salary record: ${response.statusCode}');
      }
    } catch (e) {
      print('Network error: $e');
    }
  }
}

class Salary {
  final int id;
  final int staffId; // Assuming you also want to capture staff ID
  final double amount;
  final String salaryDate;
  final DateTime createdAt; // Optional: If you want to capture creation date
  final DateTime updatedAt; // Optional: If you want to capture update date

  Salary({
    required this.id,
    required this.staffId,
    required this.amount,
    required this.salaryDate,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Salary.fromJson(Map<String, dynamic> json) {
    return Salary(
      id: json['id'] ?? 0,
      staffId: json['staff_id'] ?? 0,
      amount: double.parse(json['amount']), // Parse 'amount' as double
      salaryDate: json['salary_date'] ?? '',
      createdAt: DateTime.parse(json['created_at']), // Optional: Parse date
      updatedAt: DateTime.parse(json['updated_at']), // Optional: Parse date
    );
  }
}

class CreateSalaryRecordOverlay extends StatefulWidget {
  final String loggedInStaffId;
  final Function(Map<String, dynamic>) onCreate;

  CreateSalaryRecordOverlay({required this.loggedInStaffId, required this.onCreate});

  @override
  _CreateSalaryRecordOverlayState createState() => _CreateSalaryRecordOverlayState();
}

class _CreateSalaryRecordOverlayState extends State<CreateSalaryRecordOverlay> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _salaryDateController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Create Salary Record'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _amountController,
              decoration: InputDecoration(labelText: 'Amount'),
              keyboardType: TextInputType.numberWithOptions(decimal: true),
            ),
            TextField(
              controller: _salaryDateController,
              decoration: InputDecoration(labelText: 'Salary Date (YYYY-MM-DD)'),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            widget.onCreate({
              'amount': double.parse(_amountController.text),
              'salary_date': _salaryDateController.text,
              'staff_id': widget.loggedInStaffId,  // Include staff_id
            });
          },
          child: Text('Create'),
        ),
      ],
    );
  }
}

class EditSalaryRecordOverlay extends StatefulWidget {
  final Salary salaryRecord;
  final Function(int, Map<String, dynamic>) onUpdate;

  EditSalaryRecordOverlay({required this.salaryRecord, required this.onUpdate});

  @override
  _EditSalaryRecordOverlayState createState() => _EditSalaryRecordOverlayState();
}

class _EditSalaryRecordOverlayState extends State<EditSalaryRecordOverlay> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _salaryDateController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _amountController.text = widget.salaryRecord.amount.toString();
    _salaryDateController.text = widget.salaryRecord.salaryDate;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Edit Salary Record'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _amountController,
              decoration: InputDecoration(labelText: 'Amount'),
              keyboardType: TextInputType.numberWithOptions(decimal: true),
            ),
            TextField(
              controller: _salaryDateController,
              decoration: InputDecoration(labelText: 'Salary Date (YYYY-MM-DD)'),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            widget.onUpdate(widget.salaryRecord.id, {
              'amount': double.parse(_amountController.text),
              'salary_date': _salaryDateController.text,
              'staff_id': widget.salaryRecord.staffId,  // Include staff_id
            });
          },
          child: Text('Update'),
        ),
      ],
    );
  }
}