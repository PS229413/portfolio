import 'package:flutter/material.dart';
import 'package:gvmobile/auth/login.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          // Investor Bro Picture
          Positioned(
            top: 120,
            left: 0,
            right: 0,
            child: Center(
              child: Column(
                children: <Widget>[
                  Image.asset(
                    'lib/assets/Investing-bro1.png',
                    width: 360,
                    height: 360,
                  ),
                  SizedBox(height: 25), // Increase the spacing between image and text
                  Container(
                    width: 200, // Set the width of the container
                    child: Text(
                      'Welcome to the GV Staff APP',
                      textAlign: TextAlign.center, // Center the text horizontally
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(height: 20), // Add spacing between text and button
                  // Center the button horizontally
                  Center(
                    child: Container(
                      width: 150, // Set the width of the button
                      height: 50, // Set the height of the button
                      decoration: BoxDecoration(
                        color: Color(0xFF2CBB1F), // Set the color
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(5),
                          bottomLeft: Radius.circular(5),
                          topRight: Radius.circular(5),
                          bottomRight: Radius.circular(5),
                        ),
                      ),
                      child: InkWell(
                        onTap: () {
                          // Navigate to LoginScreen when the button is tapped
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => LoginScreen()),
                          );
                        },
                        child: Center(
                          child: Text(
                            'Login',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Ellipse Picture at the Top Right
          Positioned(
            top: 0,
            right: 0,
            child: Image.asset(
              'lib/assets/Ellipse1.png',
              width: 205,
              height: 220,
            ),
          ),
        ],
      ),
    );
  }
}