import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ZiekScreen extends StatefulWidget {
  final String loggedInStaffId;

  ZiekScreen({required this.loggedInStaffId});

  @override
  _ZiekScreenState createState() => _ZiekScreenState();
}

class _ZiekScreenState extends State<ZiekScreen> {
  List<SickRecord> sickRecords = [];
  bool isLoading = false;
  bool isError = false;

  @override
  void initState() {
    super.initState();
    fetchSickRecords();
  }

  Future<void> fetchSickRecords() async {
    setState(() {
      isLoading = true;
    });

    final url = Uri.parse('http://10.0.2.2:8001/api/sicks/by_staff/${widget.loggedInStaffId}');

    try {
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var jsonData = json.decode(response.body);
        List<SickRecord> loadedSickRecords = [];
        for (var item in jsonData) {
          loadedSickRecords.add(SickRecord.fromJson(item));
        }
        setState(() {
          sickRecords = loadedSickRecords;
          isLoading = false;
          isError = false;
        });
      } else {
        print('Failed to load sick records');
        setState(() {
          isLoading = false;
          isError = true;
        });
      }
    } catch (e) {
      print('Network error: $e');
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sick Records'),
      ),
      body: Stack(
        children: [
          Positioned(
            top: 0,
            right: 0,
            child: Image.asset(
              'lib/assets/Ellipse1.png',
              width: 205,
              height: 220,
              fit: BoxFit.cover,
            ),
          ),
          Container(
            padding: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 40),
                Text(
                  'Sick Records',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue,
                  ),
                ),
                SizedBox(height: 20),
                Expanded(
                  child: _buildSickRecordsList(),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showCreateSickRecordDialog();
        },
        child: Icon(Icons.add),
      ),
    );
  }

  Widget _buildSickRecordsList() {
    if (isLoading) {
      return Center(
        child: CircularProgressIndicator(),
      );
    } else if (isError) {
      return Center(
        child: Text(
          'Failed to load sick records',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.red,
          ),
        ),
      );
    } else if (sickRecords.isEmpty) {
      return Center(
        child: Text(
          'No sick records available',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black54,
          ),
        ),
      );
    } else {
      return ListView.builder(
        itemCount: sickRecords.length,
        itemBuilder: (context, index) {
          return _buildSickRecordCard(sickRecords[index]);
        },
      );
    }
  }

  Widget _buildSickRecordCard(SickRecord record) {
    return Card(
      elevation: 4,
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Start Date: ${record.startDate}',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'End Date: ${record.endDate}',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    _showEditSickRecordDialog(record);
                  },
                  child: Text('Edit'),
                ),
                TextButton(
                  onPressed: () {
                    _confirmDeleteSickRecord(record.id);
                  },
                  child: Text(
                    'Delete',
                    style: TextStyle(color: Colors.red),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showCreateSickRecordDialog() async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return CreateSickRecordOverlay(
          loggedInStaffId: widget.loggedInStaffId,
          onCreate: (data) {
            createSickRecord(data);
            Navigator.of(context).pop();
          },
        );
      },
    );
  }

  Future<void> _showEditSickRecordDialog(SickRecord record) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return EditSickRecordOverlay(
          sickRecord: record,
          onUpdate: (id, data) {
            updateSickRecord(id, data);
            Navigator.of(context).pop();
          },
        );
      },
    );
  }

  Future<void> _confirmDeleteSickRecord(int id) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirm Deletion'),
          content: Text('Are you sure you want to delete this sick record?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                deleteSickRecord(id);
                Navigator.of(context).pop();
              },
              child: Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  Future<void> createSickRecord(Map<String, dynamic> data) async {
    final url = Uri.parse('http://10.0.2.2:8001/api/sicks/create');

    try {
      var response = await http.post(
        url,
        body: json.encode(data),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode == 201) {
        fetchSickRecords();
      } else {
        print('Failed to create sick record: ${response.statusCode}');
      }
    } catch (e) {
      print('Network error: $e');
    }
  }

  Future<void> updateSickRecord(int id, Map<String, dynamic> data) async {
    final url = Uri.parse('http://10.0.2.2:8001/api/sicks/update/$id');

    try {
      var response = await http.put(
        url,
        body: json.encode(data),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode == 200) {
        fetchSickRecords();
      } else {
        print('Failed to update sick record: ${response.statusCode}');
      }
    } catch (e) {
      print('Network error: $e');
    }
  }

  Future<void> deleteSickRecord(int id) async {
    final url = Uri.parse('http://10.0.2.2:8001/api/sicks/$id');

    try {
      var response = await http.delete(url);
      if (response.statusCode == 200 || response.statusCode == 204) {
        fetchSickRecords();
      } else {
        print('Failed to delete sick record: ${response.statusCode}');
      }
    } catch (e) {
      print('Network error: $e');
    }
  }
}

class SickRecord {
  final int id;
  final String startDate;
  final String endDate;
  final int staffId; // Assuming staffId is of type int

  SickRecord({
    required this.id,
    required this.startDate,
    required this.endDate,
    required this.staffId,
  });

  factory SickRecord.fromJson(Map<String, dynamic> json) {
    return SickRecord(
      id: json['id'] ?? 0,
      startDate: json['start_date'] ?? '',
      endDate: json['end_date'] ?? '',
      staffId: json['staff_id'] ?? 0, // Adjust according to your API response
    );
  }
}

class CreateSickRecordOverlay extends StatefulWidget {
  final String loggedInStaffId;
  final Function(Map<String, dynamic>) onCreate;

  CreateSickRecordOverlay({required this.loggedInStaffId, required this.onCreate});

  @override
  _CreateSickRecordOverlayState createState() => _CreateSickRecordOverlayState();
}

class _CreateSickRecordOverlayState extends State<CreateSickRecordOverlay> {
  final TextEditingController _startDateController = TextEditingController();
  final TextEditingController _endDateController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Create Sick Record'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _startDateController,
              decoration: InputDecoration(labelText: 'Start Date (YYYY-MM-DD)'),
            ),
            TextField(
              controller: _endDateController,
              decoration: InputDecoration(labelText: 'End Date (YYYY-MM-DD)'),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            widget.onCreate({
              'start_date': _startDateController.text,
              'end_date': _endDateController.text,
              'staff_id': widget.loggedInStaffId,
            });
          },
          child: Text('Create'),
        ),
      ],
    );
  }
}

class EditSickRecordOverlay extends StatefulWidget {
  final SickRecord sickRecord;
  final Function(int, Map<String, dynamic>) onUpdate;

  EditSickRecordOverlay({required this.sickRecord, required this.onUpdate});

  @override
  _EditSickRecordOverlayState createState() => _EditSickRecordOverlayState();
}

class _EditSickRecordOverlayState extends State<EditSickRecordOverlay> {
  final TextEditingController _startDateController = TextEditingController();
  final TextEditingController _endDateController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _startDateController.text = widget.sickRecord.startDate;
    _endDateController.text = widget.sickRecord.endDate;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Edit Sick Record'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _startDateController,
              decoration: InputDecoration(labelText: 'Start Date (YYYY-MM-DD)'),
            ),
            TextField(
              controller: _endDateController,
              decoration: InputDecoration(labelText: 'End Date (YYYY-MM-DD)'),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            widget.onUpdate(widget.sickRecord.id, {
              'start_date': _startDateController.text,
              'end_date': _endDateController.text,
              'staff_id': widget.sickRecord.staffId.toString(), // Assuming staffId is of type int
            });
          },
          child: Text('Update'),
        ),
      ],
    );
  }
}
