import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class PersoonlijkeGegevensScreen extends StatefulWidget {
  final String loggedInStaffId;

  PersoonlijkeGegevensScreen({required this.loggedInStaffId});

  @override
  _PersoonlijkeGegevensScreenState createState() => _PersoonlijkeGegevensScreenState();
}

class _PersoonlijkeGegevensScreenState extends State<PersoonlijkeGegevensScreen> {
  List<StaffInformation> staffInformation = [];
  bool isLoading = false;
  bool isError = false;

  @override
  void initState() {
    super.initState();
    fetchStaffInformation();
  }

  Future<void> fetchStaffInformation() async {
    setState(() {
      isLoading = true;
    });

    Uri url = Uri.parse('http://10.0.2.2:8001/api/staff_information');

    try {
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var jsonData = json.decode(response.body);
        List<StaffInformation> loadedStaffInformation = [];
        for (var item in jsonData) {
          loadedStaffInformation.add(StaffInformation.fromJson(item));
        }
        setState(() {
          staffInformation = loadedStaffInformation;
          isLoading = false;
          isError = false;
        });
      } else {
        print('Failed to load staff information');
        setState(() {
          isLoading = false;
          isError = true;
        });
      }
    } catch (e) {
      print('Network error: $e');
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Persoonlijke Gegevens'),
      ),
      body: Stack(
        children: [
          Positioned(
            top: 0,
            right: 0,
            child: Image.asset(
              'lib/assets/Ellipse1.png',
              width: 205,
              height: 220,
              fit: BoxFit.cover,
            ),
          ),
          Container(
            padding: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 40),
                Text(
                  'Persoonlijke Gegevens',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue,
                  ),
                ),
                SizedBox(height: 20),
                Expanded(
                  child: _buildStaffInformationList(),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showCreateStaffInformationDialog();
        },
        child: Icon(Icons.add),
      ),
    );
  }

  Widget _buildStaffInformationList() {
    if (isLoading) {
      return Center(
        child: CircularProgressIndicator(),
      );
    } else if (isError) {
      return Center(
        child: Text(
          'Failed to load staff information',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.red,
          ),
        ),
      );
    } else if (staffInformation.isEmpty) {
      return Center(
        child: Text(
          'No staff information available',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black54,
          ),
        ),
      );
    } else {
      return ListView.builder(
        itemCount: staffInformation.length,
        itemBuilder: (context, index) {
          return _buildStaffInformationCard(staffInformation[index]);
        },
      );
    }
  }

  Widget _buildStaffInformationCard(StaffInformation info) {
    return Card(
      elevation: 4,
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Name: ${info.name}',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Street Address: ${info.streetAddress}',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8),
            Text(
              'Postcode: ${info.postcode}',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8),
            Text(
              'City: ${info.city}',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8),
            Text(
              'Identification BSN: ${info.identificationBsn}',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8),
            Text(
              'Identification ID Card: ${info.identificationIdCard}',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8),
            Text(
              'Identification Passport: ${info.identificationPassport}',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8),
            Text(
              'Phone Number Mobile: ${info.phoneNumberMobile}',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8),
            Text(
              'Email: ${info.email}',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    _showEditStaffInformationDialog(info);
                  },
                  child: Text('Edit'),
                ),
                TextButton(
                  onPressed: () {
                    _confirmDeleteStaffInformation(info.id);
                  },
                  child: Text(
                    'Delete',
                    style: TextStyle(color: Colors.red),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showCreateStaffInformationDialog() async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return CreateStaffInformationOverlay(
          loggedInStaffId: widget.loggedInStaffId,
          onCreate: (data) {
            createStaffInformation(data);
            Navigator.of(context).pop();
          },
        );
      },
    );
  }

  Future<void> _showEditStaffInformationDialog(StaffInformation info) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return EditStaffInformationOverlay(
          staffInformation: info,
          onUpdate: (id, data) {
            updateStaffInformation(id, data);
            Navigator.of(context).pop();
          },
        );
      },
    );
  }

  Future<void> _confirmDeleteStaffInformation(int id) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirm Deletion'),
          content: Text('Are you sure you want to delete this staff information?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                deleteStaffInformation(id);
                Navigator.of(context).pop();
              },
              child: Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  Future<void> createStaffInformation(Map<String, dynamic> data) async {
    final Uri url = Uri.parse('http://10.0.2.2:8001/api/staff_information');

    try {
      var response = await http.post(
        url,
        body: json.encode(data),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode == 201) {
        fetchStaffInformation();
      } else {
        print('Failed to create staff information: ${response.statusCode}');
      }
    } catch (e) {
      print('Network error: $e');
    }
  }

  Future<void> updateStaffInformation(int id, Map<String, dynamic> data) async {
    final Uri url = Uri.parse('http://10.0.2.2:8001/api/staff_information/update/$id');

    try {
      var response = await http.put(
        url,
        body: json.encode(data),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode == 200) {
        fetchStaffInformation();
      } else {
        print('Failed to update staff information: ${response.statusCode}');
      }
    } catch (e) {
      print('Network error: $e');
    }
  }

  Future<void> deleteStaffInformation(int id) async {
    final Uri url = Uri.parse('http://10.0.2.2:8001/api/staff_information/$id');

    try {
      var response = await http.delete(url);
      if (response.statusCode == 200 || response.statusCode == 204) {
        fetchStaffInformation();
      } else {
        print('Failed to delete staff information: ${response.statusCode}');
      }
    } catch (e) {
      print('Network error: $e');
    }
  }
}

class StaffInformation {
  final int id;
  final String name;
  final String streetAddress;
  final String postcode;
  final String city;
  final int identificationBsn;
  final String identificationIdCard;
  final String identificationPassport;
  final int phoneNumberMobile;
  final String email;
  final int staffId;

  StaffInformation({
    required this.id,
    required this.name,
    required this.streetAddress,
    required this.postcode,
    required this.city,
    required this.identificationBsn,
    required this.identificationIdCard,
    required this.identificationPassport,
    required this.phoneNumberMobile,
    required this.email,
    required this.staffId,
  });

  factory StaffInformation.fromJson(Map<String, dynamic> json) {
    return StaffInformation(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      streetAddress: json['street_address'] ?? '',
      postcode: json['postcode'] ?? '',
      city: json['city'] ?? '',
      identificationBsn: json['identification_bsn'] ?? '',
      identificationIdCard: json['identification_id_card'] ?? '',
      identificationPassport: json['identification_passport'] ?? '',
      phoneNumberMobile: json['phone_number_mobile'] ?? '',
      email: json['email'] ?? '',
      staffId: json['staff_id'], // Ensure staff_id is converted to string
    );
  }
}

class CreateStaffInformationOverlay extends StatefulWidget {
  final String loggedInStaffId;
  final Function(Map<String, dynamic>) onCreate;

  CreateStaffInformationOverlay({required this.loggedInStaffId, required this.onCreate});

  @override
  _CreateStaffInformationOverlayState createState() => _CreateStaffInformationOverlayState();
}

class _CreateStaffInformationOverlayState extends State<CreateStaffInformationOverlay> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _streetAddressController = TextEditingController();
  final TextEditingController _postcodeController = TextEditingController();
  final TextEditingController _cityController = TextEditingController();
  final TextEditingController _identificationBsnController = TextEditingController();
  final TextEditingController _identificationIdCardController = TextEditingController();
  final TextEditingController _identificationPassportController = TextEditingController();
  final TextEditingController _phoneNumberMobileController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Add Personal Information'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: _streetAddressController,
              decoration: InputDecoration(labelText: 'Street Address'),
            ),
            TextField(
              controller: _postcodeController,
              decoration: InputDecoration(labelText: 'Postcode'),
            ),
            TextField(
              controller: _cityController,
              decoration: InputDecoration(labelText: 'City'),
            ),
            TextField(
              controller: _identificationBsnController,
              decoration: InputDecoration(labelText: 'Identification BSN'),
            ),
            TextField(
              controller: _identificationIdCardController,
              decoration: InputDecoration(labelText: 'Identification ID Card'),
            ),
            TextField(
              controller: _identificationPassportController,
              decoration: InputDecoration(labelText: 'Identification Passport'),
            ),
            TextField(
              controller: _phoneNumberMobileController,
              decoration: InputDecoration(labelText: 'Phone Number Mobile'),
            ),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            widget.onCreate({
              'name': _nameController.text,
              'street_address': _streetAddressController.text,
              'postcode': _postcodeController.text,
              'city': _cityController.text,
              'identification_bsn': _identificationBsnController.text,
              'identification_id_card': _identificationIdCardController.text,
              'identification_passport': _identificationPassportController.text,
              'phone_number_mobile': _phoneNumberMobileController.text,
              'email': _emailController.text,
              'staff_id': widget.loggedInStaffId,
            });
          },
          child: Text('Create'),
        ),
      ],
    );
  }
}

class EditStaffInformationOverlay extends StatefulWidget {
  final StaffInformation staffInformation;
  final Function(int, Map<String, dynamic>) onUpdate;

  EditStaffInformationOverlay({required this.staffInformation, required this.onUpdate});

  @override
  _EditStaffInformationOverlayState createState() => _EditStaffInformationOverlayState();
}

class _EditStaffInformationOverlayState extends State<EditStaffInformationOverlay> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _streetAddressController = TextEditingController();
  final TextEditingController _postcodeController = TextEditingController();
  final TextEditingController _cityController = TextEditingController();
  final TextEditingController _identificationBsnController = TextEditingController();
  final TextEditingController _identificationIdCardController = TextEditingController();
  final TextEditingController _identificationPassportController = TextEditingController();
  final TextEditingController _phoneNumberMobileController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _nameController.text = widget.staffInformation.name;
    _streetAddressController.text = widget.staffInformation.streetAddress;
    _postcodeController.text = widget.staffInformation.postcode;
    _cityController.text = widget.staffInformation.city;
    _identificationBsnController.text = widget.staffInformation.identificationBsn.toString();
    _identificationIdCardController.text = widget.staffInformation.identificationIdCard;
    _identificationPassportController.text = widget.staffInformation.identificationPassport;
    _phoneNumberMobileController.text = widget.staffInformation.phoneNumberMobile.toString();
    _emailController.text = widget.staffInformation.email;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Edit Personal Information'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: _streetAddressController,
              decoration: InputDecoration(labelText: 'Street Address'),
            ),
            TextField(
              controller: _postcodeController,
              decoration: InputDecoration(labelText: 'Postcode'),
            ),
            TextField(
              controller: _cityController,
              decoration: InputDecoration(labelText: 'City'),
            ),
            TextField(
              controller: _identificationBsnController,
              decoration: InputDecoration(labelText: 'Identification BSN'),
            ),
            TextField(
              controller: _identificationIdCardController,
              decoration: InputDecoration(labelText: 'Identification ID Card'),
            ),
            TextField(
              controller: _identificationPassportController,
              decoration: InputDecoration(labelText: 'Identification Passport'),
            ),
            TextField(
              controller: _phoneNumberMobileController,
              decoration: InputDecoration(labelText: 'Phone Number Mobile'),
            ),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            widget.onUpdate(widget.staffInformation.id, {
              'name': _nameController.text,
              'street_address': _streetAddressController.text,
              'postcode': _postcodeController.text,
              'city': _cityController.text,
              'identification_bsn': _identificationBsnController.text,
              'identification_id_card': _identificationIdCardController.text,
              'identification_passport': _identificationPassportController.text,
              'phone_number_mobile': _phoneNumberMobileController.text,
              'email': _emailController.text,
              'staff_id': widget.staffInformation.staffId,
            });
          },
          child: Text('Update'),
        ),
      ],
    );
  }
}