<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ClockController;
use App\Http\Controllers\VacationRequestController;

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});





Route::middleware('auth')->group(function () 
{
    Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/view-hours', [DashboardController::class, 'viewHours'])->name('view-hours');

    Route::get('/profile/{id}/edit', [ProfileController::class, 'edit'])->name('users.edit');
    Route::put('/profile/{id}', [ProfileController::class, 'update'])->name('users.update');
    Route::get('/profile/{id}', [ProfileController::class, 'showProfile'])->name('users.showProfile');
    Route::delete('/profile/{id}', [ProfileController::class, 'destroy'])->name('users.destroy');
    Route::get('/profile', [ProfileController::class, 'show'])->name('users.show');
    Route::get('/profile/create', [ProfileController::class, 'create'])->name('users.create');
    Route::post('/profile', [ProfileController::class, 'store'])->name('users.store');
    Route::delete('/profile/{id}', [ProfileController::class, 'destroy'])->name('users.destroy');
    
    Route::get('/Hours/{id}/edit', [DashboardController::class, 'edit'])->name('Hours.edit');
    Route::put('/Hours/{id}', [DashboardController::class, 'update'])->name('Hours.update');
    Route::patch('/Hours/{id}', [DashboardController::class, 'update'])->name('Hours.update');
    Route::delete('/Hours/{id}', [DashboardController::class, 'destroy'])->name('Hours.destroy');
    Route::get('/Hours/create', [DashboardController::class, 'create'])->name('Hours.create');
    Route::post('/Hours/store' ,[DashboardController::class,'store'])->name('Hours.store');

    Route::get('/clock', [ClockController::class, 'index'])->name('Clock.index');
    Route::post('/clock-in', [ClockController::class, 'clockIn'])->name('clock-in');
    Route::post('/clock-out', [ClockController::class, 'clockOut'])->name('clock-out');
    Route::get('/clock-in-time', [ClockController::class, 'getClockInTime'])->name('clock-in-time');

    Route::get('/vacation', [VacationRequestController::class, 'index'])->name('vacation.index');
    Route::post('/vacation', [VacationRequestController::class, 'store'])->name('vacation.store');
    Route::get('/vacation/{id}/approve', [VacationRequestController::class, 'approve'])->name('vacation.approve');
    Route::get('/vacation/{id}/decline', [VacationRequestController::class, 'decline'])->name('vacation.decline');

    Route::post('/send-hours-to-user', [DashboardController::class, 'sendHoursToUser'])->name('send-hours-to-user');    
});
require __DIR__.'/auth.php';
