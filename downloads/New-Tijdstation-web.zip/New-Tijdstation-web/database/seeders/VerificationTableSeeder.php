<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class VerificationTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = User::pluck('id');
        $emails = DB::table('email')->pluck('id');

        foreach ($users as $userId) {
            foreach ($emails as $emailId) {
                DB::table('verification')->insert([
                    'Verification_code' => rand(100000, 999999), // Generate a random verification code or use your own logic
                    'User_id' => $userId,
                    'Email_id' => $emailId,
                    'Timestamps' => now(),
                ]);
            }
        }
    }
}
