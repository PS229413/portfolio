<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Carbon;
use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('users')->insert([
            'name' => 'Raul Van der Zande',
            'email' => 'r.zande@beginstation.nl',
            'password' => bcrypt('Bstation7173'),
            'role' => 'admin',
            'nfc_card_data' => '4b01010004080473f921fb',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ]);

        DB::table('users')->insert([
            'name' => 'test user',
            'email' => 'test@user.nl',
            'password' => bcrypt('Bstation7173'),
            'nfc_card_data' => '4b01010004080473f921fb7',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ]);
    }
}
