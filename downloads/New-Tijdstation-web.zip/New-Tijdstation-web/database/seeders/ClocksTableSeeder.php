<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Faker\Factory as Faker;

class ClocksTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create();

        $users = User::pluck('id');

        foreach ($users as $userId) {
            // Generate random clock-in and clock-out times
            $clockIn = $faker->time('H:i:s');
            $clockOut = $faker->time('H:i:s', '16:30:00'); // You can set upper limit to 16:30:00 or use your own logic

            DB::table('clock')->insert([
                'Date' => Carbon::now()->toDateString(),
                'Clock_In' => $clockIn,
                'Clock_Out' => $clockOut,
                'User_id' => $userId,
                'Timestamps' => now(),
            ]);
        }
    }
}
