<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class AccessTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = User::pluck('id');

        foreach ($users as $userId) {
            DB::table('access')->insert([
                'Access_Token' => rand(100000, 999999), // Generate a random access token or use your own logic
                'User_id' => $userId,
                'Timestamps' => now(),
            ]);
        }

    }
}
