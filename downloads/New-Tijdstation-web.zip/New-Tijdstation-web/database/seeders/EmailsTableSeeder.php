<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class EmailsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Assuming you have some user records already created in the 'users' table.
        $users = User::pluck('id');

        foreach ($users as $userId) {
            DB::table('email')->insert([
                'Email_Address' => 'user'.$userId.'@example.com',
                'Email' => 'This is an email content for user '.$userId.'.',
                'User_id' => $userId,
                'Timestamps' => now(),
            ]);
        }
    }
}
