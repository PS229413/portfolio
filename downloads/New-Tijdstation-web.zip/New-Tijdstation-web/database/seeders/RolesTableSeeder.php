<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = User::pluck('id');

        foreach ($users as $userId) {
            DB::table('roles')->insert([
                'Role' => 'UserRole', // Set the role name as needed
                'User_id' => $userId,
                'Timestamps' => now(),
            ]);
        }
    }
}
