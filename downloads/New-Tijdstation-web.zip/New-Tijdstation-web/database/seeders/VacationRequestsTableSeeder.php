<?php

namespace Database\Seeders;

use App\Models\VacationRequest;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use App\Models\User;

class VacationRequestsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
              // Assuming you have a User model and at least one user in the database
              $users = User::all();

              foreach ($users as $user) {
                  // Create some sample vacation requests
                  VacationRequest::create([
                      'user_id' => $user->id,
                      'start_date' => Carbon::now()->addDays(5),
                      'end_date' => Carbon::now()->addDays(7),
                      'status' => 'approved',
                  ]);
      
                  VacationRequest::create([
                      'user_id' => $user->id,
                      'start_date' => Carbon::now()->addDays(10),
                      'end_date' => Carbon::now()->addDays(15),
                      'status' => 'pending',
                  ]);
      
                  // Add more vacation requests as needed
              }
    }
}
