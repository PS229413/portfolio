<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Work Hours Report</title>
    <!-- Add any additional styles or meta tags as needed for the PDF content -->
</head>

<body>
    <h1>Work Hours Report</h1>

    <?php if(isset($userData['name'])): ?>
        <p>Hello <?php echo e($userData['name']); ?>,</p>
    <?php endif; ?>

    <p>Here is your work hours report for the period:</p>
    <p>Start Date: <?php echo e($startDate); ?></p>
    <p>End Date: <?php echo e($endDate); ?></p>

    <p>Total Work Hours: <?php echo e($calculatedHours['totalHours']); ?></p>
    <p>Total Work Days: <?php echo e($calculatedHours['totalDays']); ?></p>

    <!-- Add more content as needed -->

</body>

</html>
<?php /**PATH C:\Het Beginstation\New-Tijdstation-web\resources\views/pdf/hours_report.blade.php ENDPATH**/ ?>