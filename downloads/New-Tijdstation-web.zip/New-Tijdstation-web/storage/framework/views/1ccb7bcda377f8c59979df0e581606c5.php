<html>

<head>
    <?php if(auth()->user()->isAdmin()): ?>
    <title>View Users</title>
    <?php endif; ?>
</head>
<style>
    /* Default light mode styles */
    body {
        background: linear-gradient(white, red);
        background-attachment: fixed;
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        transition: background-color 0.3s;
    }

    /* Style the table */
    table {
        width: 76%;
        margin: 20px auto;
        border-collapse: collapse;
        background-color: white;
        border-radius: 10px;
    }

    th,
    td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }

    /* Style the Total Hours Worked section as a professional form */
    div {
        width: 75%;
        margin: 20px auto;
        background-color: white;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
    }

    /* Dark mode button styles */
    .dark-mode-button {
        position: absolute;
        top: 20px;
        right: 20px;
        background-color: #333;
        color: white;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        cursor: pointer;
    }

    button {
        background-color: #007bff;
        color: white;
        padding: 12px 24px;
        border: none;
        border-radius: 5px;
        font-size: 20px;
        cursor: pointer;
        text-decoration: none;
        transition: background-color 0.3s ease;
    }

    input[type=text],
    select {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }

    input[type=password],
    select {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }

    /* public/css/custom.css */

.forbidden-container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 85vh;
    background: transparent;
    border-color: transparent;
}

.forbidden-message {
    text-align: center;
    padding: 30px;
    border-radius: 10px;
    background-color: #ffffff; /* White background color */
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    max-width: 400px;
    width: 100%;
}

.forbidden-message h1 {
    color: #e74c3c; /* Red color for the header */
    font-size: 36px;
    margin-bottom: 20px;
}

.forbidden-message p {
    color: #555; /* Dark gray color for paragraphs */
    font-size: 18px;
    margin-bottom: 15px;
}

.home-link {
    display: inline-block;
    padding: 10px 20px;
    background-color: #3498db; /* Blue color for the link */
    color: #fff; /* White color for text */
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.home-link:hover {
    background-color: #1f69c3; /* Darker blue color on hover */
}

#homepage {
    position: absolute;
            top: 20px;
            left: 20px;
            font-size: 18px;
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        #homepage:hover {
            background-color: #555;
        }
</style>
<body>
<form action="/" method="GET">
        <button id="homepage" type="submit">Go Back To home</button>
    </form>
<?php if(auth()->user()->isUser()): ?>
<div class="forbidden-container">
        <div class="forbidden-message">
            <h1>403 Forbidden</h1>
            <p>Oops! It seems you don't have permission to access this page.</p>
            <p>Please contact the administrator for assistance.</p>
            <a href="<?php echo e(url('/')); ?>" class="home-link">Go to Home</a>
        </div>
    </div>
<?php endif; ?>
    <?php if(auth()->user()->isAdmin()): ?>
    <table border="1">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Created At</th>
            <th>Updated At</th>
            <th>Show</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->role); ?></td>
            <td><?php echo e($user->created_at); ?></td>
            <td><?php echo e($user->updated_at); ?></td>
            <td>
                <form action="<?php echo e(route('users.showProfile', $user->id)); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <button type="submit">Show</button>
                </form>
            <td>
                <form action="<?php echo e(route('users.edit', $user->id)); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <button type="submit">Edit</button>
                </form>
            </td>
            <td>
                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div>
        <h1>Create User</h1>
        <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
        <form method="POST" action="/profile">
            <?php echo csrf_field(); ?>
            <label for="name">Name:</label><br>
            <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>"><br>
            <label for="email">Email:</label><br>
            <input type="text" id="email" name="email" value="<?php echo e(old('email')); ?>"><br>
            <label for="password">Password:</label><br>
            <input type="password" id="password" name="password"><br>
            <label for="password_confirmation">Confirm Password:</label><br>
            <input type="password" id="password_confirmation" name="password_confirmation"><br><br>
            <label for="cardnumber">NFC Card Number:</label><br>
            <input type="text" id="nfc_card_data" name="nfc_card_data"><br><br>
            <label for="role">Role:</label><br>
            <select name="role">
                <option value="user">User</option>
                <option value="admin">Admin</option>
                </select><br><br><br>
            <button type="submit">Create User</button>
        </form>
    </div>
    <?php endif; ?>
</body>

</html><?php /**PATH C:\Het Beginstation\New-Tijdstation-web\resources\views/users/index.blade.php ENDPATH**/ ?>