[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Het Beginstation\New-Tijdstation-web\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>