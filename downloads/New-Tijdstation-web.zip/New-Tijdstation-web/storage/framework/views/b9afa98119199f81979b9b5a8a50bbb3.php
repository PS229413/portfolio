<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clock In/Out</title>
    <style>
        body {
            background: linear-gradient(white, red);
            background-attachment: fixed;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            transition: background-color 0.3s;
        }

        .clock-container {
            text-align: center;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        button {
            background-color: #3498db;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px; /* Added margin-top for spacing between buttons */
        }

        button:hover {
            background-color: #2980b9;
        }

        p {
            font-size: 18px;
            margin-bottom: 20px;
        }

        #homepage {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 18px;
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        #homepage:hover {
            background-color: #555;
        }

        select {
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            margin-top: 10px; /* Added margin-top for spacing */
        }

        .form_clock{
            display: flex;
    flex-direction: column;
        }

        .invalid-card-error {
            color: red;
            margin-top: 5px;
        }

        #nfcCardData{
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            margin-top: 10px; /* Added margin-top for spacing */
        }

        .clock_text{
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <form action="/" method="GET">
        <button id="homepage" type="submit">Go Back To home</button>
    </form>

    <div class="clock-container">
        <?php if($clockedIn): ?>
            <p>You are currently clocked in for: <span id="clockInTime"><?php echo e($clockInTime); ?></span></p>
            <form action="<?php echo e(route('clock-out')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button type="submit">Clock Out</button>
            </form>
        <?php else: ?>
            <p>You are currently not clocked in</p>
            <form action="<?php echo e(route('clock-in')); ?>" method="post" class="form_clock">
                <?php echo csrf_field(); ?>
                <label for="nfcCardData">Enter NFC Card Data:</label>
                <input type="text" name="nfcCardData" id="nfcCardData" required>
                <br>
                <label for="userSelect">Select User:</label>
                <select name="userSelect" id="userSelect">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" onclick="return validateNfcCard()">Clock In</button>
                <div class="invalid-card-error" id="invalidCardError"></div>
                <br>
                <?php endif; ?>
            </form>
            <div>
                </div>
                <p class="clock_text">here you can add clock times if needed</p>
                <form action="<?php echo e(route('Hours.create')); ?>" method="get" class="form_clock">
                    <button type="submit">Create Hours</button>
                </form>
    </div>
    <script>
         function validateNfcCard() {
            var enteredCardData = document.getElementById('nfcCardData').value;
            var validCardData = "<?php echo e(Auth::user()->nfc_card_data); ?>";

            if (enteredCardData !== validCardData) {
                document.getElementById('invalidCardError').innerText = 'Invalid NFC Card Data';
                return false;
            }

            return true;
        }
        // JavaScript to update the clocked-in time every second
        <?php if($clockedIn): ?>
            setInterval(function() {
                // Get the current clocked-in time from the server and update the HTML
                fetch('<?php echo e(route('clock-in-time')); ?>', { method: 'GET' })
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('clockInTime').innerText = data.clockInTime;
                    });
            }, 900);
        <?php endif; ?>
    </script>

</body>
</html>
<?php /**PATH C:\Het Beginstation\New-Tijdstation-web\resources\views/Clock/index.blade.php ENDPATH**/ ?>