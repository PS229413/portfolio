<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clock System</title>
    <style>
        /* Default light mode styles */
        body {
            background: linear-gradient(white, red);
            background-attachment: fixed;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            transition: background-color 0.3s;
        }

        /* Style the table */
        table {
            width: 75%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: white;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Style the Total Hours Worked section as a professional form */
        div {
            width: 75%;
            margin: 20px auto;
            background-color: white;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
        }

        /* Dark mode button styles */
        .dark-mode-button {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }

        button {
            background-color: #007bff;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            font-size: 20px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .user-selection-form {
            width: 50%;
            margin: 20px auto;
            background-color: white;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
        }

        .user-selection-form label {
            display: block;
            margin-bottom: 5px;
        }

        .user-selection-form select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        /* Add this CSS section to your styles */
        #selected-user-info {
            background-color: #f2f2f2;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
            margin-bottom: 20px;
            width: 73%;
            text-align: center;
            height: 25px;
        }

        #selected-user-text {
            height: 50px;
            margin-top: 5px;
        }

      /* Add this CSS section to your styles */
    .pagination-links {
        margin-top: 20px;
    }

    .pagination-links a {
        display: inline-block;
        padding: 5px 10px;
        margin-right: 5px;
        background-color: #007bff;
        color: white;
        text-decoration: none;
        border-radius: 5px;
    }

    .pagination-links a.active {
        background-color: #0056b3;
    }

    #homepage {
        position: absolute;
            top: 20px;
            left: 20px;
            font-size: 18px;
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        #homepage:hover {
            background-color: #555;
        }
    </style>
</head>

<body>
<form action="/" method="GET">
        <button id="homepage" type="submit">Go Back To home</button>
    </form>
    <?php if(auth()->user()->isAdmin()): ?>
    <div class="user-selection-form">
        <form action="<?php echo e(route('view-hours')); ?>" method="get">
            <?php echo csrf_field(); ?>
            <label for="user_id">Select User:</label>
            <select name="user_id" id="user_id">
                <option value="" selected disabled>Select User</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>" <?php echo e($selectedUserId==$user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br><br>
            <button type="submit">View Hours</button>
        </form>
        <?php endif; ?>
    </div>
    <div id="selected-user-info">
        <?php if(isset($selectedUserId)): ?>
        <p id="selected-user-text">Hours of: <?php echo e($users->find($selectedUserId)->name); ?></p>
        <?php endif; ?>
    </div>
    <table>
    <thead>
        <tr>
            <th>Date</th>
            <th>Clocked In</th>
            <th>Clocked Out</th>
            <?php if(auth()->user()->isAdmin()): ?>
                <th>Edit</th>
                <th>Delete</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php
            $entriesCount = count($clockEntries);
            $perPage = 10;
            $currentPage = request()->get('page', 1);
            $start = ($currentPage - 1) * $perPage;
            $end = min($start + $perPage, $entriesCount);
            $sortedClockEntries = $clockEntries->sortByDesc('Date')->values();
        ?>

        <?php for($i = $start; $i < $end; $i++): ?>
            <tr>
                <td><?php echo e(\Carbon\Carbon::parse($sortedClockEntries[$i]->Date)->format('Y-m-d')); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($sortedClockEntries[$i]->Clock_In)->format('H:i')); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($sortedClockEntries[$i]->Clock_Out)->format('H:i')); ?></td>
                <?php if(auth()->user()->isAdmin()): ?>
                    <td>
                        <form action="<?php echo e(route('Hours.edit', $sortedClockEntries[$i]->id)); ?>" method="GET">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="entry_id" value="<?php echo e($sortedClockEntries[$i]->id); ?>">
                            <button type="submit">Edit</button>
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('Hours.destroy', $sortedClockEntries[$i]->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                <?php endif; ?>
            </tr>
        <?php endfor; ?>
    </tbody>
</table>

    <?php if($entriesCount > $perPage): ?>
        <!-- Pagination links for additional entries -->
        <div class="pagination-links">
            <?php for($i = 1; $i <= ceil($entriesCount / $perPage); $i++): ?>
                <a href="<?php echo e(route('view-hours', ['user_id' => $selectedUserId, 'page' => $i])); ?>" <?php echo e($currentPage == $i ? 'class=active' : ''); ?>><?php echo e($i); ?></a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>
    <div>
        <p>Total Work Hours: <?php echo e($totalHoursWorked); ?></p>
        <p>Total Work Days: <?php echo e($totalWorkDays); ?></p>
    </div>
    <div class="container">
        <h1>Work Hour Calculator</h1>

        <form action="<?php echo e(route('dashboard')); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="start_date">Start Date:</label>
                <input type="date" id="start_date" name="start_date" required>
            </div>
            <div class="form-group">
                <label for="end_date">End Date:</label>
                <input type="date" id="end_date" name="end_date" required>
            </div>
            <button type="submit" class="btn btn-primary">Calculate</button>
        </form>

        <h2>Weekly Work Hours</h2>
        <table class="table">
            <!-- Table headers here -->
            <tbody>
                <?php $__currentLoopData = $weeklyWorkHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week => $minutes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($week); ?></td>
                    <td><?php echo e(floor($minutes / 60)); ?> hours</td>
                    <td><?php echo e($minutes % 60); ?> minutes</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <h2>Daily Work Hours</h2>
        <table class="table">
            <!-- Table headers here -->
            <tbody>
                <?php $__currentLoopData = $dailyWorkHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($date); ?></td>
                    <td><?php echo e($time); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH C:\Het Beginstation\New-Tijdstation-web\resources\views/index.blade.php ENDPATH**/ ?>