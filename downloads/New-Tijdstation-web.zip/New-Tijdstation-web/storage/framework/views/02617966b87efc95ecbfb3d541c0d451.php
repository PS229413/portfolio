<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Hours</title>
    <style>
          body {
            background: linear-gradient(white, red);
            background-attachment: fixed;
            transition: background-color 0.3s;
            font-family: 'Arial', sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f4f4f4;
            box-sizing: border-box;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }


        .hours-container {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        button {
            background-color: #3498db;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>

<div class="hours-container">
    <h2>Enter Hours</h2>

    <form action="<?php echo e(route('Hours.store')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <label for="Date">Date:</label>
        <input type="date" id="Date" name="Date" required>

        <label for="Clock_In">Clock In:</label>
        <input type="datetime-local" id="Clock_In" name="Clock_In" required>

        <label for="Clock_Out">Clock Out:</label>
        <input type="datetime-local" id="Clock_Out" name="Clock_Out" required>

        <button type="submit">Submit Hours</button>
    </form>
</div>

</body>
</html>
<?php /**PATH C:\Het Beginstation\New-Tijdstation-web\resources\views/Hours/create.blade.php ENDPATH**/ ?>