<html>
    <head>
        <title>Profile</title>
        <style>
           /* Default light mode styles */
           body {
            background: linear-gradient(white, red);
            background-attachment: fixed;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            transition: background-color 0.3s;
        }

        /* Style the table */
        table {
            width: 75%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: white;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Style the Total Hours Worked section as a professional form */
        div {
            width: 75%;
            margin: 20px auto;
            background-color: white;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
        }

        /* Dark mode button styles */
        .dark-mode-button {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            font-size: 20px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        #homepage {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 18px;
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        #homepage:hover {
            background-color: #555;
        }
        </style>
    </head>
    <body>
    <form action="/" method="GET">
        <button id="homepage" type="submit">Go Back To home</button>
    </form>
        <div>
            <h2>Profile Information</h2>
            <table>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Created At</th>
                    <th>Edit</th>
                </tr>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->created_at); ?></td>
                    <td>
                    <form action="<?php echo e(route('users.edit', $user->id)); ?>" method="GET">
                        <?php echo csrf_field(); ?>
                        <button type="submit">Edit</button>
                    </form>
                </td>
                </tr>
            </table>
        </div>
        <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Clocked In</th>
                <th>Clocked Out</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clockEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e(\Carbon\Carbon::parse($entry->Date)->format('Y-m-d')); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($entry->Clock_In)->format('H:i')); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($entry->Clock_Out)->format('H:i')); ?></td>
                <td>
                    <form action="<?php echo e(route('Hours.edit', $entry->id)); ?>" method="GET">
                        <?php echo csrf_field(); ?>
                        <button type="submit">Edit</button>
                    </form>
                </td>
                <td>
                    <form action="<?php echo e(route('Hours.destroy', $entry->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Delete</button>
                    </form>
                    </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div>
        <p>Total Work Hours: <?php echo e($totalHoursWorked); ?></p>
        <p>Total Work Days: <?php echo e($totalWorkDays); ?></p>
    </div>
    <div class="container">
    <h1>Work Hour Calculator</h1>
    
    <form action="/profile/<?php echo e($user->id); ?>" method="GET">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="start_date">Start Date:</label>
            <input type="date" id="start_date" name="start_date" required>
        </div>
        <div class="form-group">
            <label for="end_date">End Date:</label>
            <input type="date" id="end_date" name="end_date" required>
        </div>
        <button type="submit" class="btn btn-primary">Calculate</button>
    </form>

    <h2>Weekly Work Hours</h2>
    <table class="table">
        <!-- Table headers here -->
        <tbody>
            <?php $__currentLoopData = $weeklyWorkHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week => $minutes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($week); ?></td>
                    <td><?php echo e(floor($minutes / 60)); ?> hours</td>
                    <td><?php echo e($minutes % 60); ?> minutes</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <h2>Daily Work Hours</h2>
    <table class="table">
        <!-- Table headers here -->
        <tbody>
            <?php $__currentLoopData = $dailyWorkHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($date); ?></td>
                    <td><?php echo e($time); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </body>
</html><?php /**PATH C:\Het Beginstation\New-Tijdstation-web\resources\views/users/show.blade.php ENDPATH**/ ?>