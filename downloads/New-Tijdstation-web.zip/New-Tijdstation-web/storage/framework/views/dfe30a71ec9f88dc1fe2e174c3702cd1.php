<!DOCTYPE html>
<html>

<head>
    <title>Edit User</title>
    <style>
        body {
            background: linear-gradient(white, red);
            background-attachment: fixed;
            transition: background-color 0.3s;
            font-family: 'Arial', sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f4f4f4;
            box-sizing: border-box;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        input,
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        #homepage {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 18px;
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        #homepage:hover {
            background-color: #555;
        }
    </style>
</head>

<body>
    <button id="homepage" type="button" onclick="goBackToHome()">Go Back To Home</button>

    <script>
        function goBackToHome() {
            window.location.href = "/";
        }
    </script>
    <form action="/profile/<?php echo e($user->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <h1>Edit User</h1>
        <br>
        <label for="name">Name</label>
        <input type="text" name="name" id="name" value="<?php echo e($user->name); ?>">
        <label for="email">Email</label>
        <input type="text" name="email" id="email" value="<?php echo e($user->email); ?>">
        <label for="password">Password</label>
        <input type="text" name="password" id="password" value="<?php echo e($user->password); ?>">
        <?php if(auth()->user()->isAdmin()): ?>
        <!-- Add the nfc_card_data row -->
        <label for="nfc_card_data">NFC Card Data</label>
        <input type="text" name="nfc_card_data" id="nfc_card_data" value="<?php echo e($user->nfc_card_data); ?>">

        <!-- Add the role dropdown -->
        <label for="role">Role</label>
        <select name="role" id="role">
            <option value="admin" <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>Admin</option>
            <option value="user" <?php echo e($user->role === 'user' ? 'selected' : ''); ?>>User</option>
        </select>
        <?php endif; ?>
        <input type="submit" value="Submit">
    </form>
</body>

</html><?php /**PATH C:\Het Beginstation\New-Tijdstation-web\resources\views/users/edit.blade.php ENDPATH**/ ?>