<?php echo e($slot); ?>

<?php /**PATH C:\Het Beginstation\New-Tijdstation-web\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>