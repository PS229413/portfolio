<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vacation Requests</title>
</head>
<style>
    /* styles.css */

    body {
        background: linear-gradient(white, red);
        background-attachment: fixed;
        margin: 0;
        padding: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        transition: background-color 0.3s;
    }

    .container {
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    }

    .header {
        text-align: center;
        color: #333;
        margin-bottom: 20px;
    }

    .success-message {
        color: #28a745;
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        padding: 10px;
        border-radius: 4px;
        margin-bottom: 20px;
    }

    .error-message {
        color: #721c24;
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
        padding: 10px;
        border-radius: 4px;
        margin-bottom: 20px;
    }

    .vacation-requests {
        margin-top: 20px;
    }

    .vacation-requests h2 {
        color: #333;
    }

    .vacation-requests ul {
        list-style: none;
        padding: 0;
    }

    .vacation-requests li {
        background-color: #f9f9f9;
        border: 1px solid #e1e1e1;
        padding: 10px;
        border-radius: 4px;
        margin-bottom: 10px;
    }

    .form-container {
        margin-top: 20px;
    }

    .form-container h2 {
        color: #333;
        margin-bottom: 20px;
    }

    .form-container label {
        display: block;
        margin-bottom: 8px;
        color: #333;
    }

    .form-container input {
        width: calc(100% - 16px);
        padding: 10px;
        margin-bottom: 12px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    .form-container button {
        background-color: #007bff;
        color: #fff;
        padding: 12px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
        transition: background-color 0.3s;
    }

    .form-container button:hover {
        background-color: #0056b3;
    }

    .error-container {
        color: #721c24;
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
        padding: 10px;
        border-radius: 4px;
        margin-bottom: 20px;
    }

    .pagination {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }

    .pagination a {
        color: #007bff;
        margin: 0 5px;
        text-decoration: none;
        cursor: pointer;
    }

    .pagination .active {
        font-weight: bold;
        color: #333;
    }

    #homepage {
        position: absolute;
            top: 20px;
            left: 20px;
            font-size: 18px;
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        #homepage:hover {
            background-color: #555;
        }
</style>
<body>
<form action="/" method="GET">
        <button id="homepage" type="submit">Go Back To home</button>
    </form>
<div class="container">
    <div class="header">
        <h1>Vacation Requests</h1>
    </div>

    <!-- Display success or error messages if needed -->
    @if(session('success'))
        <div class="success-message">{{ session('success') }}</div>
    @endif

    @if(session('error'))
        <div class="error-message">{{ session('error') }}</div>
    @endif

    @if($errors->any())
        <div class="error-container">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <!-- Display existing vacation requests -->
    <div class="vacation-requests">
    <h2>Your Vacation Requests</h2>
    @if($vacationRequests->isEmpty())
        <p>No vacation requests found.</p>
    @else
        <ul>
            @php
                $entriesCount = count($vacationRequests);
                $perPage = 10;
                $currentPage = request()->get('page', 1);
                $start = ($currentPage - 1) * $perPage;
                $end = min($start + $perPage, $entriesCount);
                $sortedVacationRequests = $vacationRequests->sortByDesc('start_date')->values();
            @endphp

            @for($i = $start; $i < $end; $i++)
                <li>
                    {{ $sortedVacationRequests[$i]->start_date }} to {{ $sortedVacationRequests[$i]->end_date }}
                    (Status: {{ $sortedVacationRequests[$i]->status }})
                </li>
            @endfor
        </ul>

        <!-- Pagination -->
        @if($entriesCount > $perPage)
            <div class="pagination">
                @for($i = 1; $i <= ceil($entriesCount / $perPage); $i++)
                    <a href="{{ route('vacation.index', ['page' => $i]) }}" {{ $currentPage == $i ? 'class=active' : '' }}>{{ $i }}</a>
                @endfor
            </div>
        @endif
    @endif
</div>

    <!-- Display the form for submitting new vacation requests -->
    <div class="form-container">
        <h2>Submit New Vacation Request</h2>
        <form method="post" action="{{ route('vacation.store') }}">
            @csrf

            <!-- Date Pickers -->
            <label for="start_date">Start Date:</label>
            <input type="date" id="start_date" name="start_date" required>

            <label for="end_date">End Date:</label>
            <input type="date" id="end_date" name="end_date" required>

            <!-- Add more form fields as needed -->

            <button type="submit">Submit Vacation Request</button>
        </form>
    </div>
</div>

</body>
</html>
