<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clock System</title>
    <style>
        /* Default light mode styles */
        body {
            background: linear-gradient(white, red);
            background-attachment: fixed;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            transition: background-color 0.3s;
        }

        /* Style the table */
        table {
            width: 75%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: white;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Style the Total Hours Worked section as a professional form */
        div {
            width: 75%;
            margin: 20px auto;
            background-color: white;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
        }

        /* Dark mode button styles */
        .dark-mode-button {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }

        button {
            background-color: #007bff;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            font-size: 20px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .user-selection-form {
            width: 50%;
            margin: 20px auto;
            background-color: white;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
        }

        .user-selection-form label {
            display: block;
            margin-bottom: 5px;
        }

        .user-selection-form select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        /* Add this CSS section to your styles */
        #selected-user-info {
            background-color: #f2f2f2;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
            margin-bottom: 20px;
            width: 73%;
            text-align: center;
            height: 25px;
        }

        #selected-user-text {
            height: 50px;
            margin-top: 5px;
        }

        /* Add this CSS section to your styles */
        .pagination-links {
            margin-top: 20px;
        }

        .pagination-links a {
            display: inline-block;
            padding: 5px 10px;
            margin-right: 5px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .pagination-links a.active {
            background-color: #0056b3;
        }

        #homepage {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 18px;
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        #homepage:hover {
            background-color: #555;
        }
    </style>
</head>

<body>
    <form action="/" method="GET">
        <button id="homepage" type="submit">Go Back To home</button>
    </form>
    @if(auth()->user()->isAdmin())
    <div class="user-selection-form">
        <form action="{{ route('view-hours') }}" method="get">
            @csrf
            <label for="user_id">Select User:</label>
            <select name="user_id" id="user_id">
                <option value="" selected disabled>Select User</option>
                @foreach ($users as $user)
                <option value="{{ $user->id }}" {{ $selectedUserId==$user->id ? 'selected' : '' }}>{{ $user->name }}
                </option>
                @endforeach
            </select><br><br>
            <button type="submit">View Hours</button>
        </form>
        @endif
    </div>
    <div id="selected-user-info">
        @if(isset($selectedUserId))
        <p id="selected-user-text">Hours of: {{ $users->find($selectedUserId)->name }}</p>
        @endif
    </div>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Clocked In</th>
                <th>Clocked Out</th>
                @if(auth()->user()->isAdmin())
                <th>Edit</th>
                <th>Delete</th>
                @endif
            </tr>
        </thead>
        <tbody>
            @php
            $entriesCount = count($clockEntries);
            $perPage = 10;
            $currentPage = request()->get('page', 1);
            $start = ($currentPage - 1) * $perPage;
            $end = min($start + $perPage, $entriesCount);
            $sortedClockEntries = $clockEntries->sortByDesc('Date')->values();
            @endphp

            @for($i = $start; $i < $end; $i++) <tr>
                <td>{{ \Carbon\Carbon::parse($sortedClockEntries[$i]->Date)->format('Y-m-d') }}</td>
                <td>{{ \Carbon\Carbon::parse($sortedClockEntries[$i]->Clock_In)->format('H:i') }}</td>
                <td>{{ \Carbon\Carbon::parse($sortedClockEntries[$i]->Clock_Out)->format('H:i') }}</td>
                @if(auth()->user()->isAdmin())
                <td>
                    <form action="{{ route('Hours.edit', $sortedClockEntries[$i]->id) }}" method="GET">
                        @csrf
                        <input type="hidden" name="entry_id" value="{{ $sortedClockEntries[$i]->id }}">
                        <button type="submit">Edit</button>
                    </form>
                </td>
                <td>
                    <form action="{{ route('Hours.destroy', $sortedClockEntries[$i]->id) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit">Delete</button>
                    </form>
                </td>
                @endif
                </tr>
                @endfor
        </tbody>
    </table>

    @if ($entriesCount > $perPage)
    <!-- Pagination links for additional entries -->
    <div class="pagination-links">
        @for ($i = 1; $i <= ceil($entriesCount / $perPage); $i++) <a
            href="{{ route('view-hours', ['user_id' => $selectedUserId, 'page' => $i]) }}" {{ $currentPage==$i
            ? 'class=active' : '' }}>{{ $i }}</a>
            @endfor
    </div>
    @endif
    <div>
        <p>Total Work Hours: {{ $totalHoursWorked }}</p>
        <p>Total Work Days: {{ $totalWorkDays }}</p>
    </div>
    <div class="container">
        <h1>Work Hour Calculator</h1>

        <form action="{{ route('dashboard') }}" method="GET">
            @csrf
            <div class="form-group">
                <label for="start_date">Start Date:</label>
                <input type="date" id="start_date" name="start_date" required>
            </div>
            <div class="form-group">
                <label for="end_date">End Date:</label>
                <input type="date" id="end_date" name="end_date" required>
            </div>
            <button type="submit" class="btn btn-primary">Calculate</button>
        </form>

        <h2>Weekly Work Hours</h2>
        <table class="table">
            <!-- Table headers here -->
            <tbody>
                @foreach ($weeklyWorkHours as $week => $minutes)
                <tr>
                    <td>{{ $week }}</td>
                    <td>{{ floor($minutes / 60) }} hours</td>
                    <td>{{ $minutes % 60 }} minutes</td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <h2>Daily Work Hours</h2>
        <table class="table">
            <!-- Table headers here -->
            <tbody>
                @foreach ($dailyWorkHours as $date => $time)
                <tr>
                    <td>{{ $date }}</td>
                    <td>{{ $time }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>

</html>