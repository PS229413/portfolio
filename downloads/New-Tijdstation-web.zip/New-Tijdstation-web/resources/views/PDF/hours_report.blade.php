<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Work Hours Report</title>
    <!-- Add any additional styles or meta tags as needed for the PDF content -->
</head>

<body>
    <h1>Work Hours Report</h1>

    @if (isset($userData['name']))
    <p>Hello {{ $userData['name'] }},</p>
    @endif
    <table style="border: 1px solid black; width: 50%; margin-left: auto; margin-right: auto;">
        <thead>
            <tr>
                <th scope="col">Date</th>
                <th scope="col">Hours Worked</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($data as $item)
            <tr>
                <td>{{ date('d/m/Y', strtotime($item->date)) }}</td>
                <td>{{ $item->work_hour }} hours worked on {{ implode(', ', json_decode($item->tasks))}}.</td>
                <td>{{ $item->work_hour }} hours</td>
            </tr>
            @endforeach
            <tr class="total-row">
                <td colspan="2"><b>Total work hours:</b>&nbsp;&nbsp;{{ $totalHour }} hours</td>
            </tr>
        </tbody>
    </table>
    @if (!empty($footerText))
    <div style="text-align: center; font-style: italic;">
        {!! nl2br(e($footerText)) !!}
    </div>
    @endif
</body>

</html>