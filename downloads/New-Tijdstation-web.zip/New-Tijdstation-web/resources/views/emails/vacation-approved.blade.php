<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f9f9f9;
            color: #555;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 30px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            position: relative;
            overflow: hidden;
        }
        h1 {
            color: #5cb85c; /* Green color for Approved */
            text-align: center;
            font-size: 28px;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .details {
            margin-top: 30px;
            border-top: 2px solid #5cb85c; /* Green color for Approved */
            padding-top: 20px;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        li {
            margin-bottom: 10px;
            font-size: 18px;
            line-height: 1.6;
        }
        .signature {
            margin-top: 40px;
            text-align: center;
            color: #555;
            font-size: 16px;
        }
        .cta-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #5cb85c; /* Green color for Approved */
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .cta-button:hover {
            background-color: #4cae4c; /* Darker green on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Vacation Request Approved</h1>
        <p>Hello {{ $vacationRequest->user->name }},</p>

        <p style='color: green; text-align: center; font-size: 20px;'>Congratulations! Your vacation request has been approved.</p>

        <div class="details">
            <p style="font-size: 18px;"><strong>Details:</strong></p>
            <ul>
                <li><strong>Start Date:</strong> {{ $vacationRequest->start_date }}</li>
                <li><strong>End Date:</strong> {{ $vacationRequest->end_date }}</li>
            </ul>
        </div>

        <p style="text-align: center; font-size: 18px;">Enjoy your vacation!</p>

        <div class="signature">
            <p>Best regards,<br>Het Beginstation</p>
        </div>
    </div>
</body>
</html>
