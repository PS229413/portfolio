<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f9f9f9;
            color: #555;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 30px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            position: relative;
            overflow: hidden;
            text-align: center;
        }
        h1 {
            color: #3498db; /* Blue color for New Vacation Request */
            font-size: 28px;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .details {
            margin-top: 20px;
            border-top: 2px solid #3498db; /* Blue color for New Vacation Request */
            padding-top: 20px;
            text-align: left;
        }
        .details ul {
            list-style: none;
            padding: 0;
            text-align: center;
        }
        .details li {
            font-size: 15px;
            line-height: 1.6;
            margin-bottom: 10px;
        }
        table {
            margin: 20px auto;
        }
        td {
            padding-right: 10px;
        }
        .cta-button {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            text-align: center;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .approve-button {
            background-color: green; /* Blue color for Approve button */
            color: #fff;
        }
        .decline-button {
            background-color: red; /* Red color for Decline button */
            color: #fff;
        }
        .cta-button:hover {
            filter: brightness(90%); /* Slightly reduce brightness on hover */
        }
        .signature {
            margin-top: 20px;
            text-align: center;
            color: #555;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>New Vacation Request</h1>
        <p>Hello Admin,</p>

        <p>You have received a new vacation request from {{ $vacationRequest->user->name }}.</p>

        <div class="details">
            <p style="font-size: 18px;"><strong>Details:</strong></p>
            <ul>
                <li><strong>Start Date:</strong> {{ $vacationRequest->start_date }}</li>
                <li><strong>End Date:</strong> {{ $vacationRequest->end_date }}</li>
            </ul>
        </div>

        <table>
            <tr>
                <td>
                    <a href="{{ route('vacation.approve', $vacationRequest->id) }}" class="cta-button approve-button">
                        Approve
                    </a>
                </td>
                <td>
                    <a href="{{ route('vacation.decline', $vacationRequest->id) }}" class="cta-button decline-button">
                        Decline
                    </a>
                </td>
            </tr>
        </table>

        <p>Thanks,<br>{{ $vacationRequest->user->name }}.</p>
    </div>
</body>
</html>
