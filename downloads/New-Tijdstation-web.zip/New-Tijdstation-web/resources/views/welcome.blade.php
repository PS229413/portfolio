<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to TimeStation</title>
    <style>
        /* Apply gradient background */
        body {
            background: linear-gradient(to bottom, white, red);
            margin: 0;
            padding: 0;
            height: 100vh;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
        }

        /* Container for content */
        .container {
            background: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        /* Style for header */
        h1 {
            font-size: 36px;
            color: #333;
        }

        /* Style for description */
        p {
            font-size: 18px;
            color: #666;
        }

        /* Style for dashboard button */
        button {
            background-color: #007bff;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            font-size: 20px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        /* Additional styles for the button if needed */
        button:hover {
            background-color: #0056b3;
        }

        /* Style for the progress bar container */
        .progress-container {
            display: none;
            width: 100%;
            background-color: #f1f1f1;
            border-radius: 8px;
            overflow: hidden;
            margin-top: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Style for the progress bar */
        .progress-bar {
            width: 0;
            height: 30px;
            line-height: 30px;
            color: white;
            text-align: center;
            background: linear-gradient(to right, #4caf50, #45a049);
            animation: progressBarAnimation 2s linear;
        }

        @keyframes progressBarAnimation {
            from {
                width: 0;
            }

            to {
                width: 100%;
            }
        }

        .login-link {
            display: inline-block;
            padding: 10px 20px;
            background-color: #3498db;
            /* Blue color for the link */
            color: #fff;
            /* White color for text */
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .login-link:hover {
            background-color: #1f69c3;
            /* Darker blue color on hover */
        }
    </style>
    <script>
        function updateTime() {
            var now = new Date();
            var hours = now.getHours();
            var minutes = now.getMinutes();
            var seconds = now.getSeconds();

            // Add a leading zero if it's a single digit
            hours = (hours < 10) ? "0" + hours : hours;
            minutes = (minutes < 10) ? "0" + minutes : minutes;
            seconds = (seconds < 10) ? "0" + seconds : seconds;

            var time = hours + ":" + minutes + ":" + seconds;

            document.getElementById('time').innerHTML = "Current Time: " + time;
        }

        setInterval(updateTime, 1000); // Update the time every second

        function startProgressBar() {
            // Display the progress bar container
            const progressContainer = document.querySelector('.progress-container');
            progressContainer.style.display = 'block';

            // Start the progress bar animation
            let width = 0;
            const progressBar = document.getElementById('myProgressBar');
            document.getElementById('dashboard-button').style.display = 'none';
            document.getElementById('Profile').style.display = 'none';
            document.getElementById('logout').style.display = 'none';
            document.getElementById('clockIndex').style.display = 'none';
            const timeText = document.createElement('div'); // Create a div for time display
            progressContainer.appendChild(timeText); // Append the time display div under the progress bar

            // Update the time every second
            setInterval(updateTime, 2000);

            const interval = setInterval(frame, 99); // Increase the interval to 50 milliseconds

            const startTime = new Date().getTime(); // Record the start time

            function frame() {
                const currentTime = new Date().getTime();
                const elapsedTime = currentTime - startTime;

                if (width >= 100) {
                    clearInterval(interval);
                    // Redirect to /dashboard when the progress bar is complete
                    window.location.href = '/dashboard';
                } else {
                    width++;
                    progressBar.style.width = width + '%';
                    progressBar.innerHTML = width + '%';

                    // Calculate the estimated time remaining
                    const totalTime = (100 / width) * elapsedTime;
                    const remainingTime = totalTime - elapsedTime;

                    // Display the time remaining under the progress bar
                    timeText.innerHTML = 'Time remaining: ' + formatTime(remainingTime);
                }
            }

            function formatTime(milliseconds) {
                const seconds = Math.ceil(milliseconds / 1000);
                return seconds + 's';
            }
        }
    </script>

</head>

<body>
    @guest
    <!-- Container for content -->
    <div class="container">
        <!-- Your content here -->
        <h1>Welcome to TimeStation</h1>
        <p>This is the TimeStation welcome page.</p>
        <h2 id="time"></h2>
        @endguest
        @auth
        <div class="container">
            <!-- Your content here -->
            <h1>Welcome to TimeStation</h1>
            <p>This is the TimeStation welcome page.</p>
            <h2 id="time"></h2>
            <button onclick="startProgressBar()" id="dashboard-button">Go to Dashboard</button><br>

            <!-- Progress bar container -->
            <div class="progress-container">
                <div class="progress-bar" id="myProgressBar">0%</div><br>
            </div><br>
            @if(auth()->user()->isAdmin())
            <form action="{{ url('/profile') }}" method="get">
                <button id="Profile" type="submit">Go To Profile</button>
            </form><br>
            @endif

            @if(auth()->user()->isUser())
            <form action="{{ route('users.showProfile', ['id' => auth()->user()->id]) }}" method="GET">
                @csrf
                <button id="Profile" type="submit">Go To Profile</button>
            </form><br>
            @endif

            <form action="{{ route('Clock.index') }}" method="GET">
                <button id="clockIndex" type="submit">Go To Clock</button>
            </form><br>

            <form action="{{ route('vacation.index') }}" method="GET">
                <button id="vacationIndex" type="submit">Go To Vacation</button>
            </form><br>

            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button id="logout" type="submit">Logout</button>
            </form>
        </div>
        @endauth
        @guest
        <a href="{{ url('/login') }}" class="login-link">Login</a>
        @endguest
</body>

</html>