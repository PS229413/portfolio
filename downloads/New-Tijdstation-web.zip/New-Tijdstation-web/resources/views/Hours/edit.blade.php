 <!DOCTYPE html>
 <html lang="en">
 <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <title>Edit Hours</title>
     <style>
        body {
            background: linear-gradient(white, red);
            background-attachment: fixed;
            transition: background-color 0.3s;
            font-family: 'Arial', sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f4f4f4;
            box-sizing: border-box;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .forbidden-container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 85vh;
    background: transparent;
    border-color: transparent;
}

.forbidden-message {
    text-align: center;
    padding: 30px;
    border-radius: 10px;
    background-color: #ffffff; /* White background color */
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    max-width: 400px;
    width: 100%;
}

.forbidden-message h1 {
    color: #e74c3c; /* Red color for the header */
    font-size: 36px;
    margin-bottom: 20px;
}

.forbidden-message p {
    color: #555; /* Dark gray color for paragraphs */
    font-size: 18px;
    margin-bottom: 15px;
}

.home-link {
    display: inline-block;
    padding: 10px 20px;
    background-color: #3498db; /* Blue color for the link */
    color: #fff; /* White color for text */
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s ease;
    position: absolute;
            top: 20px;
            left: 20px;
            font-size: 18px;
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
}

.home-link:hover {
    background-color: #1f69c3; /* Darker blue color on hover */
}

#homepage {
    position: absolute;
            top: 20px;
            left: 20px;
            font-size: 18px;
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        #homepage:hover {
            background-color: #555;
        }
     </style>
 </head>
 <body>
 <a href="{{ url('/') }}" class="home-link">Go to Home</a>

 @if(auth()->user()->isUser())
<div class="forbidden-container">
        <div class="forbidden-message">
            <h1>403 Forbidden</h1>
            <p>Oops! It seems you don't have permission to access this page.</p>
            <p>Please contact the administrator for assistance.</p>
            <a href="{{ url('/') }}" class="home-link">Go to Home</a>
        </div>
    </div>
@endif
@if(auth()->user()->isAdmin())
     <form action="/Hours/{{$clock->id}}" method="POST">
         @csrf
         @method('PUT')
         <h1>Edit Hours</h1>
         <label for="Date">Date</label>
         <input type="date" name="Date" id="Date" value="{{$clock->Date}}">
         <label for="Clock_In">Clock In</label>
         <input type="time" name="Clock_In" id="Clock_In" value="{{$clock->Clock_In}}">
         <label for="Clock_Out">Clock Out</label>
         <input type="time" name="Clock_Out" id="Clock_Out" value="{{$clock->Clock_Out}}">
         <input type="submit" value="Submit">
     </form>
@endif
 </body>
 </html>