<html>
    <head>
        <title>Profile</title>
        <style>
           /* Default light mode styles */
           body {
            background: linear-gradient(white, red);
            background-attachment: fixed;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            transition: background-color 0.3s;
        }

        /* Style the table */
        table {
            width: 75%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: white;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Style the Total Hours Worked section as a professional form */
        div {
            width: 75%;
            margin: 20px auto;
            background-color: white;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
        }

        /* Dark mode button styles */
        .dark-mode-button {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            font-size: 20px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        #homepage {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 18px;
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        #homepage:hover {
            background-color: #555;
        }
        </style>
    </head>
    <body>
    <form action="/" method="GET">
        <button id="homepage" type="submit">Go Back To home</button>
    </form>
        <div>
            <h2>Profile Information</h2>
            <table>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Created At</th>
                    <th>Edit</th>
                </tr>
                <tr>
                    <td>{{ $user->name }}</td>
                    <td>{{ $user->email }}</td>
                    <td>{{ $user->created_at }}</td>
                    <td>
                    <form action="{{ route('users.edit', $user->id) }}" method="GET">
                        @csrf
                        <button type="submit">Edit</button>
                    </form>
                </td>
                </tr>
            </table>
        </div>
        <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Clocked In</th>
                <th>Clocked Out</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            @foreach($clockEntries as $entry)
            <tr>
            <td>{{ \Carbon\Carbon::parse($entry->Date)->format('Y-m-d') }}</td>
                <td>{{ \Carbon\Carbon::parse($entry->Clock_In)->format('H:i') }}</td>
                <td>{{ \Carbon\Carbon::parse($entry->Clock_Out)->format('H:i') }}</td>
                <td>
                    <form action="{{ route('Hours.edit', $entry->id) }}" method="GET">
                        @csrf
                        <button type="submit">Edit</button>
                    </form>
                </td>
                <td>
                    <form action="{{ route('Hours.destroy', $entry->id) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit">Delete</button>
                    </form>
                    </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <div>
        <p>Total Work Hours: {{ $totalHoursWorked }}</p>
        <p>Total Work Days: {{ $totalWorkDays }}</p>
    </div>
    <div class="container">
    <h1>Work Hour Calculator</h1>
    
    <form action="/profile/{{$user->id}}" method="GET">
        @csrf
        <div class="form-group">
            <label for="start_date">Start Date:</label>
            <input type="date" id="start_date" name="start_date" required>
        </div>
        <div class="form-group">
            <label for="end_date">End Date:</label>
            <input type="date" id="end_date" name="end_date" required>
        </div>
        <button type="submit" class="btn btn-primary">Calculate</button>
    </form>

    <h2>Weekly Work Hours</h2>
    <table class="table">
        <!-- Table headers here -->
        <tbody>
            @foreach ($weeklyWorkHours as $week => $minutes)
                <tr>
                    <td>{{ $week }}</td>
                    <td>{{ floor($minutes / 60) }} hours</td>
                    <td>{{ $minutes % 60 }} minutes</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <h2>Daily Work Hours</h2>
    <table class="table">
        <!-- Table headers here -->
        <tbody>
            @foreach ($dailyWorkHours as $date => $time)
                <tr>
                    <td>{{ $date }}</td>
                    <td>{{ $time }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
    </body>
</html>