<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TotalHour extends Model
{
    use HasFactory;

    protected $fillable = ['user_id', 'total_hours', 'total_minutes'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
