<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Access extends Model
{
    protected $table = 'access';
    protected $fillable = [
        'Access_Token',
        'User_id',
        'Timestamps',
    ];

    // Define relationships or additional methods here if needed.
}
