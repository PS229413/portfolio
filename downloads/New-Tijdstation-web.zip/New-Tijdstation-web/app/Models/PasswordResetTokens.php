<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PasswordResetTokens extends Model
{
    protected $table = 'password_reset_tokens';
    protected $primaryKey = 'email'; // Assuming 'email' is the primary key.
    public $incrementing = false; // Since 'email' is not auto-incrementing.
    protected $fillable = [
        'token',
        'created_at',
    ];

    // Define relationships or additional methods here if needed.
}
