<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Clock extends Model
{
    protected $table = 'clock';
    public $timestamps = false;
    protected $fillable = [
        'User_id',
        'Date',
        'Clock_in',
        'Clock_out',
        'user_id',
        'Timestamps'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
