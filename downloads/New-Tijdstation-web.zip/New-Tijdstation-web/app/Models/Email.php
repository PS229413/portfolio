<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Email extends Model
{
    protected $table = 'email';
    protected $fillable = [
        'Email_Address',
        'Email',
        'User_id',
        'Timestamps',
    ];

    // Define relationships or additional methods here if needed.
}
