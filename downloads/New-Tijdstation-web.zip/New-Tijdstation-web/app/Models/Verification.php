<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Verification extends Model
{
    protected $table = 'verification';
    protected $fillable = [
        'Verification_code',
        'User_id',
        'Email_id',
        'Timestamps',
    ];

    // Define relationships or additional methods here if needed.
}
