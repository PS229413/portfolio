<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = 'product';
    protected $fillable = [
        'Name',
        'Card_Number',
        'Tag_Number',
        'User_id',
        'Timestamps',
    ];

    // Define relationships or additional methods here if needed.
}
