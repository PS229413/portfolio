<?php

namespace App\Console\Commands;

use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use App\Mail\ClockoutReminder;
use App\Models\User;
use App\Models\Clock;

class ClockoutReminderCommand extends Command
{
    protected $signature = 'clockout:reminder';
    protected $description = 'Check and send clockout reminders';

    public function handle()
    {
        $currentTime = now()->format('H:i:s');
        info("Current Time: $currentTime");

        if ($currentTime >= '18:00:00' && $currentTime <= '18:00:00') {
            info("Executing checkAndSendReminders");
            $this->checkAndSendReminders();
        } else {
            info("Conditions not met for execution");
        }
    }

    public function checkAndSendReminders()
    {
        $users = User::all();
    
        foreach ($users as $user) {
            $clockEntries = Clock::where('user_id', $user->id)
                ->whereDate('clock_in', Carbon::today())
                ->whereNull('clock_out')
                ->where('clock_in', '<', '07:30:00')
                ->get();
    
            if ($clockEntries->isNotEmpty()) {
                // Update the clock_out value for entries that need a reminder
                foreach ($clockEntries as $entry) {
                    $entry->clock_out = '16:30:00';
                    $entry->save();
                }
    
                // Send the reminder email
                Mail::to('r.zande@beginstation.nl')->send(new ClockoutReminder($user, $clockEntries));
            }
        }
    }    
}
