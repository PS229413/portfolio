<?php

namespace App\Jobs;

use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;
use App\Mail\ClockoutReminder;
use App\Models\User;

class ClockoutReminderJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle()
    {
        $usersToRemind = User::whereHas('clockEntries', function ($query) {
            $query->where('Clock_out', '<', '11:44:00')->whereDate('Date', Carbon::today());
        })->get();

        foreach ($usersToRemind as $user) {
            Mail::to('r.zande@beginstation.nl')->send(new ClockoutReminder($user));
        }
    }
}
