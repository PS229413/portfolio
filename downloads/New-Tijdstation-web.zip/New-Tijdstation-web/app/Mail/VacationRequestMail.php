<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class VacationRequestMail extends Mailable
{
    use Queueable, SerializesModels;

    public $vacationRequest;

    public function __construct($vacationRequest)
    {
        $this->vacationRequest = $vacationRequest;
    }

    public function build()
    {
        return $this->markdown('emails.vacation-request')
            ->subject('New Vacation Request');
    }
}
