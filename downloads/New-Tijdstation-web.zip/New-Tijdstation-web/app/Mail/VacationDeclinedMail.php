<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class VacationDeclinedMail extends Mailable
{
    use Queueable, SerializesModels;

    public $vacationRequest;

    public function __construct($vacationRequest)
    {
        $this->vacationRequest = $vacationRequest;
    }

    public function build()
    {
        return $this->markdown('emails.vacation-declined')
            ->subject('Vacation Request Declined');
    }
}
