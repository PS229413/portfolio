<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;

class CheckRole
{
    public function handle($request, Closure $next, $role)
    {
        // Check if the user is logged in
        if (Auth::check()) {
            // Check if the user has the specified role
            if (Auth::user()->role == $role) {
                return $next($request);
            }
        }

        // If the user is not logged in or does not have the required role, redirect to the login page or show an error
        return redirect('/login')->with('error', 'Unauthorized access');
    }
}
