<?php

namespace App\Http\Controllers;

use App\Models\Clock;
use Carbon\Carbon;
use App\Models\User;
use Barryvdh\DomPDF\Facade\Pdf;


use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        // In your controller method
        $users = User::all();
        $userId = Auth()->user()->id;
        $allClockEntries = Clock::where('User_id', $userId)->get();
        $totalHoursWorked = $this->calculateTotalWorkHours($allClockEntries);
        // Calculate total work days
        $totalWorkDays = $this->calculateTotalWorkDays($allClockEntries);
        $start_date = $request->input('start_date');
        $end_date = $request->input('end_date');

        $startDate = Carbon::parse($start_date)->format('Y-m-d');
        $endDate = Carbon::parse($end_date)->format('Y-m-d');

        $selectedUserId = $request->input('user_id');

        // Filter clock entries based on the chosen date range
        $clockEntries = $allClockEntries->filter(function ($entry) use ($start_date, $end_date) {
            $entryDate = Carbon::parse($entry->Date);
            return $entryDate->gte($start_date) && $entryDate->lte($end_date);
        });

        $weeklyWorkHours = $this->calculateWeeklyWorkHours($clockEntries, $start_date, $end_date);
        $dailyWorkHours = $this->calculateDailyWorkHours($clockEntries, $start_date, $end_date);


        return view('index', ['clockEntries' => $clockEntries, 'totalHoursWorked' => $totalHoursWorked, 'totalWorkDays' => $totalWorkDays, 'dailyWorkHours' => $dailyWorkHours, 'weeklyWorkHours' => $weeklyWorkHours, 'users' => $users, 'selectedUserId' => $selectedUserId,
        'startDate' => $startDate,'endDate' => $endDate,]);
    }

    public function viewHours(Request $request)
    {
        // Get the list of users to populate the dropdown
        $users = User::all();

        // Check if a user is selected
        if ($request->has('user_id')) {
            $userId = $request->input('user_id');

            // Fetch clock entries for the selected user
            $allClockEntries = Clock::where('user_id', $userId)->get();

            // Calculate total work hours, work days, etc.
            $totalHoursWorked = $this->calculateTotalWorkHours($allClockEntries);
            $totalWorkDays = $this->calculateTotalWorkDays($allClockEntries);
            $start_date = $request->input('start_date');
            $end_date = $request->input('end_date');

            // Filter clock entries based on the chosen date range
            $clockEntries = $allClockEntries->filter(function ($entry) use ($start_date, $end_date) {
                $entryDate = Carbon::parse($entry->Date);
                return $entryDate->gte($start_date) && $entryDate->lte($end_date);
            });
            $weeklyWorkHours = $this->calculateWeeklyWorkHours($clockEntries, $start_date, $end_date);
            $dailyWorkHours = $this->calculateDailyWorkHours($clockEntries, $start_date, $end_date);

            // Your other calculations...

            return view('index', [
                'users' => $users,
                'selectedUserId' => $userId,
                'clockEntries' => $allClockEntries,
                'totalHoursWorked' => $totalHoursWorked,
                'totalWorkDays' => $totalWorkDays,
                'dailyWorkHours' => $dailyWorkHours,
                'weeklyWorkHours' => $weeklyWorkHours,
            ]);
        }
    }


    public function calculateTotalWorkHours($clockEntries)
    {
        $totalHours = 0;
        $totalMinutes = 0;

        // Define work time ranges
        $workTimes = [
            ['start' => '07:30', 'end' => '09:00'],
            ['start' => '09:15', 'end' => '11:00'],
            ['start' => '11:15', 'end' => '12:30'],
            ['start' => '13:00', 'end' => '15:00'],
            ['start' => '15:10', 'end' => '16:30'],
        ];

        foreach ($clockEntries as $entry) {
            $clockIn = Carbon::parse($entry->Clock_In);
            $clockOut = Carbon::parse($entry->Clock_Out);

            // Initialize variables to track total worked time for this entry
            $entryHours = 0;
            $entryMinutes = 0;

            // Iterate through each work time range
            foreach ($workTimes as $workTime) {
                $workStart = Carbon::parse($workTime['start']);
                $workEnd = Carbon::parse($workTime['end']);

                // Determine the overlap between clock-in and clock-out times and work time range
                $overlapStart = $clockIn->max($workStart);
                $overlapEnd = $clockOut->min($workEnd);

                // Check if there is a valid overlap
                if ($overlapStart->lt($overlapEnd)) {
                    $overlapMinutes = $overlapStart->diffInMinutes($overlapEnd);
                    $entryHours += floor($overlapMinutes / 60);
                    $entryMinutes += $overlapMinutes % 60;
                }
            }

            // Subtract break times if the clock-in time is within a work time range
            $clockInWithinWorkHours = false;
            foreach ($workTimes as $workTime) {
                $workStart = Carbon::parse($workTime['start']);
                $workEnd = Carbon::parse($workTime['end']);

                if ($clockIn->between($workStart, $workEnd, true)) {
                    $clockInWithinWorkHours = true;
                    break;
                }
            }

            if ($clockInWithinWorkHours) {
                // Define break times
                $breakTimes = [
                    ['start' => '09:00', 'end' => '09:15'],
                    ['start' => '11:00', 'end' => '11:15'],
                    ['start' => '12:30', 'end' => '13:00'],
                    ['start' => '15:00', 'end' => '15:10'],
                ];

                foreach ($breakTimes as $breakTime) {
                    $breakStart = Carbon::parse($breakTime['start']);
                    $breakEnd = Carbon::parse($breakTime['end']);

                    // Subtract break time from the entry's worked hours and minutes
                    if ($clockIn->between($breakStart, $breakEnd, true)) {
                        $breakMinutes = $clockIn->diffInMinutes($breakEnd);
                        $entryHours -= floor($breakMinutes / 60);
                        $entryMinutes -= $breakMinutes % 60;
                    }
                }
            }

            // Add entry's worked hours and minutes to the running total
            $totalHours += $entryHours;
            $totalMinutes += $entryMinutes;
        }

        // Convert excess minutes to hours
        $totalHours += floor($totalMinutes / 60);
        $totalMinutes %= 60;

        // Convert total hours and minutes to a more human-readable format
        $totalTime = "$totalHours hours $totalMinutes minutes";

        // Separate hours and minutes for further processing if needed
        $totalTimeParts = explode(' ', $totalTime);
        $totalHours = (int) $totalTimeParts[0];
        $totalMinutes = (int) $totalTimeParts[2];

        return $totalTime;
    }

    public function calculateTotalWorkDays($clockEntries)
    {
        $totalDays = 0;

        foreach ($clockEntries as $entry) {
            // Check if the entry has a clock-in and clock-out time
            if ($entry->Clock_In && $entry->Clock_Out) {
                $totalDays++;
            }
        }

        return $totalDays;
    }

    public function calculateDailyWorkHours($clockEntries)
    {
        $dailyMinutes = [];

        $breakTimes = [
            ['start' => '09:00', 'end' => '09:15'],
            ['start' => '11:00', 'end' => '11:15'],
            ['start' => '12:30', 'end' => '13:00'],
            ['start' => '15:00', 'end' => '15:10'],
        ];

        foreach ($clockEntries as $entry) {
            // Check if the entry has a clock-in and clock-out time
            if ($entry->Clock_In && $entry->Clock_Out) {
                $date = Carbon::parse($entry->Date)->format('Y-m-d');
                $clockIn = Carbon::parse($entry->Clock_In);
                $clockOut = Carbon::parse($entry->Clock_Out);

                $totalMinutes = $clockOut->diffInMinutes($clockIn);

                // Subtract break times
                foreach ($breakTimes as $breakTime) {
                    $breakStart = Carbon::parse($breakTime['start']);
                    $breakEnd = Carbon::parse($breakTime['end']);

                    // Check if the break time overlaps with work time
                    if ($breakStart->between($clockIn, $clockOut) || $breakEnd->between($clockIn, $clockOut)) {
                        $totalMinutes -= $breakEnd->diffInMinutes($breakStart);
                    }
                }

                if (!isset($dailyMinutes[$date])) {
                    $dailyMinutes[$date] = 0;
                }
                $dailyMinutes[$date] += $totalMinutes;
            }
        }

        $dailyHours = [];
        foreach ($dailyMinutes as $date => $minutes) {
            $hours = floor($minutes / 60);
            $minutes = $minutes % 60;
            $time = $hours . ' hours ' . str_pad($minutes, 2, '0', STR_PAD_LEFT) . ' minutes';
            $dailyHours[$date] = $time;
        }

        return $dailyHours;
    }

    public function calculateWeeklyWorkHours($clockEntries)
    {
        $weeklyMinutes = [];

        $breakTimes = [
            ['start' => '09:00', 'end' => '09:15'],
            ['start' => '11:00', 'end' => '11:15'],
            ['start' => '12:30', 'end' => '13:00'],
            ['start' => '15:00', 'end' => '15:10'],
        ];

        foreach ($clockEntries as $entry) {
            // Check if the entry has a clock-in and clock-out time
            if ($entry->Clock_In && $entry->Clock_Out) {
                $date = Carbon::parse($entry->Date);
                $weekStartDate = $date->startOfWeek();
                $weekEndDate = $date->copy()->endOfWeek();

                $clockIn = Carbon::parse($entry->Clock_In);
                $clockOut = Carbon::parse($entry->Clock_Out);

                $totalMinutes = $clockOut->diffInMinutes($clockIn);

                // Subtract break times
                foreach ($breakTimes as $breakTime) {
                    $breakStart = Carbon::parse($breakTime['start']);
                    $breakEnd = Carbon::parse($breakTime['end']);

                    // Check if the break time overlaps with work time
                    if ($breakStart->between($clockIn, $clockOut) || $breakEnd->between($clockIn, $clockOut)) {
                        $totalMinutes -= $breakEnd->diffInMinutes($breakStart);
                    }
                }

                $weekKey = $weekStartDate->format('Y-m-d') . ' to ' . $weekEndDate->format('Y-m-d');
                if (!isset($weeklyMinutes[$weekKey])) {
                    $weeklyMinutes[$weekKey] = 0;
                }
                $weeklyMinutes[$weekKey] += $totalMinutes;
            }
        }

        return $weeklyMinutes;
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        // edit hours
        $clock = Clock::find($id);
        return view('Hours.edit', ['clock' => $clock]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        // update hours
        $clock = Clock::find($id);
        $clock->Date = $request->Date;
        $clock->Clock_In = $request->Clock_In;
        $clock->Clock_Out = $request->Clock_Out;
        $clock->save();
        return redirect('/dashboard');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        // delete hours
        $clock = Clock::find($id);
        $clock->delete();
        return redirect('/dashboard');
    }

    //create hours
    public function create()
    {
        return view('Hours.create');
    }

    //store hours
    public function store(Request $request)
    {
        $clock = new Clock;
        $clock->UserID = auth()->user()->id;
        $clock->Date = $request->Date;
        $clock->Clock_In = $request->Clock_In;
        $clock->Clock_Out = $request->Clock_Out;
        $clock->save();
        return redirect('/dashboard');
    }

    public function sendHoursToUser(Request $request)
    {
        // Validate the request data
        $request->validate([
            'user_id' => 'required|exists:users,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date',
        ]);
    
        // Fetch the selected user's data
        $recipientUser = User::findOrFail($request->input('user_id'));
    
        // Fetch the data needed for the PDF
        // Replace the following with your actual logic to fetch user data and calculate hours
        $userData = [];
        $calculatedHours = [];
        //generate pdf document
    
        // Generate PDF document
        $pdf = PDF::loadView('pdf.hours_report', compact($userData, $calculatedHours));

        return $pdf->download('Hours.pdf');
    }
}