<?php

namespace App\Http\Controllers;


use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\View\View;
use App\Models\User;
use App\Models\Clock;
use Carbon\Carbon;

class ProfileController extends Controller
{

    /**
     * Display the user's profile form.
     */
    public function edit(Request $request, string $id): View
    {
        $user = User::find($id);
        return view('users.edit', ['user' => $user]);
    }

    //show the user's profile
    public function show(Request $request): View
    {
        $users = User::all();

        return view('users.index', compact('users'));
    }

    public function calculateTotalWorkHours($clockEntries)
    {
        $totalHours = 0;
        $totalMinutes = 0;

        // Define work time ranges
        $workTimes = [
            ['start' => '07:30', 'end' => '09:00'],
            ['start' => '09:15', 'end' => '11:00'],
            ['start' => '11:15', 'end' => '12:30'],
            ['start' => '13:00', 'end' => '15:00'],
            ['start' => '15:10', 'end' => '16:30'],
        ];

        foreach ($clockEntries as $entry) {
            $clockIn = Carbon::parse($entry->Clock_In);
            $clockOut = Carbon::parse($entry->Clock_Out);

            // Initialize variables to track total worked time for this entry
            $entryHours = 0;
            $entryMinutes = 0;

            // Iterate through each work time range
            foreach ($workTimes as $workTime) {
                $workStart = Carbon::parse($workTime['start']);
                $workEnd = Carbon::parse($workTime['end']);

                // Determine the overlap between clock-in and clock-out times and work time range
                $overlapStart = $clockIn->max($workStart);
                $overlapEnd = $clockOut->min($workEnd);

                // Check if there is a valid overlap
                if ($overlapStart->lt($overlapEnd)) {
                    $overlapMinutes = $overlapStart->diffInMinutes($overlapEnd);
                    $entryHours += floor($overlapMinutes / 60);
                    $entryMinutes += $overlapMinutes % 60;
                }
            }

            // Subtract break times if the clock-in time is within a work time range
            $clockInWithinWorkHours = false;
            foreach ($workTimes as $workTime) {
                $workStart = Carbon::parse($workTime['start']);
                $workEnd = Carbon::parse($workTime['end']);

                if ($clockIn->between($workStart, $workEnd, true)) {
                    $clockInWithinWorkHours = true;
                    break;
                }
            }

            if ($clockInWithinWorkHours) {
                // Define break times
                $breakTimes = [
                    ['start' => '09:00', 'end' => '09:15'],
                    ['start' => '11:00', 'end' => '11:15'],
                    ['start' => '12:30', 'end' => '13:00'],
                    ['start' => '15:00', 'end' => '15:10'],
                ];

                foreach ($breakTimes as $breakTime) {
                    $breakStart = Carbon::parse($breakTime['start']);
                    $breakEnd = Carbon::parse($breakTime['end']);

                    // Subtract break time from the entry's worked hours and minutes
                    if ($clockIn->between($breakStart, $breakEnd, true)) {
                        $breakMinutes = $clockIn->diffInMinutes($breakEnd);
                        $entryHours -= floor($breakMinutes / 60);
                        $entryMinutes -= $breakMinutes % 60;
                    }
                }
            }

            // Add entry's worked hours and minutes to the running total
            $totalHours += $entryHours;
            $totalMinutes += $entryMinutes;
        }

        // Convert excess minutes to hours
        $totalHours += floor($totalMinutes / 60);
        $totalMinutes %= 60;

        // Convert total hours and minutes to a more human-readable format
        $totalTime = "$totalHours hours $totalMinutes minutes";

        // Separate hours and minutes for further processing if needed
        $totalTimeParts = explode(' ', $totalTime);
        $totalHours = (int) $totalTimeParts[0];
        $totalMinutes = (int) $totalTimeParts[2];

        return $totalTime;
    }

    public function calculateTotalWorkDays($clockEntries)
    {
        $totalDays = 0;

        foreach ($clockEntries as $entry) {
            // Check if the entry has a clock-in and clock-out time
            if ($entry->Clock_In && $entry->Clock_Out) {
                $totalDays++;
            }
        }

        return $totalDays;
    }

    public function calculateDailyWorkHours($clockEntries)
    {
        $dailyMinutes = [];

        $workTimes = [
            ['start' => '07:30', 'end' => '09:00'],
            ['start' => '09:15', 'end' => '11:00'],
            ['start' => '11:15', 'end' => '12:30'],
            ['start' => '13:00', 'end' => '15:00'],
            ['start' => '15:10', 'end' => '16:30'],
        ];

        $breakTimes = [
            ['start' => '09:00', 'end' => '09:15'],
            ['start' => '11:00', 'end' => '11:15'],
            ['start' => '12:30', 'end' => '13:00'],
            ['start' => '15:00', 'end' => '15:10'],
        ];

        foreach ($clockEntries as $entry) {
            // Check if the entry has a clock-in and clock-out time
            if ($entry->Clock_In && $entry->Clock_Out) {
                $date = Carbon::parse($entry->Date)->format('Y-m-d');
                $clockIn = Carbon::parse($entry->Clock_In);
                $clockOut = Carbon::parse($entry->Clock_Out);

                $totalMinutes = $clockOut->diffInMinutes($clockIn);

                // Subtract break times
                foreach ($breakTimes as $breakTime) {
                    $breakStart = Carbon::parse($breakTime['start']);
                    $breakEnd = Carbon::parse($breakTime['end']);

                    // Check if the break time overlaps with work time
                    if ($breakStart->between($clockIn, $clockOut) || $breakEnd->between($clockIn, $clockOut)) {
                        $totalMinutes -= $breakEnd->diffInMinutes($breakStart);
                    }
                }

                if (!isset($dailyMinutes[$date])) {
                    $dailyMinutes[$date] = 0;
                }
                $dailyMinutes[$date] += $totalMinutes;
            }
        }

        $dailyHours = [];
        foreach ($dailyMinutes as $date => $minutes) {
            $hours = floor($minutes / 60);
            $minutes = $minutes % 60;
            $time = $hours . ' hours ' . str_pad($minutes, 2, '0', STR_PAD_LEFT) . ' minutes';
            $dailyHours[$date] = $time;
        }

        return $dailyHours;
    }

    public function calculateWeeklyWorkHours($clockEntries)
    {
        $weeklyMinutes = [];

        $workTimes = [
            ['start' => '07:30', 'end' => '09:00'],
            ['start' => '09:15', 'end' => '11:00'],
            ['start' => '11:15', 'end' => '12:30'],
            ['start' => '13:00', 'end' => '15:00'],
            ['start' => '15:10', 'end' => '16:30'],
        ];

        $breakTimes = [
            ['start' => '09:00', 'end' => '09:15'],
            ['start' => '11:00', 'end' => '11:15'],
            ['start' => '12:30', 'end' => '13:00'],
            ['start' => '15:00', 'end' => '15:10'],
        ];

        foreach ($clockEntries as $entry) {
            // Check if the entry has a clock-in and clock-out time
            if ($entry->Clock_In && $entry->Clock_Out) {
                $date = Carbon::parse($entry->Date);
                $weekStartDate = $date->startOfWeek();
                $weekEndDate = $date->copy()->endOfWeek();

                $clockIn = Carbon::parse($entry->Clock_In);
                $clockOut = Carbon::parse($entry->Clock_Out);

                $totalMinutes = $clockOut->diffInMinutes($clockIn);

                // Subtract break times
                foreach ($breakTimes as $breakTime) {
                    $breakStart = Carbon::parse($breakTime['start']);
                    $breakEnd = Carbon::parse($breakTime['end']);

                    // Check if the break time overlaps with work time
                    if ($breakStart->between($clockIn, $clockOut) || $breakEnd->between($clockIn, $clockOut)) {
                        $totalMinutes -= $breakEnd->diffInMinutes($breakStart);
                    }
                }

                $weekKey = $weekStartDate->format('Y-m-d') . ' to ' . $weekEndDate->format('Y-m-d');
                if (!isset($weeklyMinutes[$weekKey])) {
                    $weeklyMinutes[$weekKey] = 0;
                }
                $weeklyMinutes[$weekKey] += $totalMinutes;
            }
        }

        return $weeklyMinutes;
    }

    //show each user's profile with the right id
    public function showProfile(Request $request, $id)
    {
        $user = User::find($id);
        $userId = auth()->user()->id;
        $allClockEntries = Clock::where('User_id', $userId)->get();
        $totalHoursWorked = $this->calculateTotalWorkHours($allClockEntries);
        // Calculate total work days

        $totalWorkDays = $this->calculateTotalWorkDays($allClockEntries);
        $start_date = $request->input('start_date');
        $end_date = $request->input('end_date');

        // Filter clock entries based on the chosen date range
        $clockEntries = $allClockEntries->filter(function ($entry) use ($start_date, $end_date) {
            $entryDate = Carbon::parse($entry->Date);
            return $entryDate->gte($start_date) && $entryDate->lte($end_date);
        });

        $weeklyWorkHours = $this->calculateWeeklyWorkHours($clockEntries, $start_date, $end_date);
        $dailyWorkHours = $this->calculateDailyWorkHours($clockEntries, $start_date, $end_date);

        return view('users.show', ['clockEntries' => $clockEntries, 'totalHoursWorked' => $totalHoursWorked, 'totalWorkDays' => $totalWorkDays, 'dailyWorkHours' => $dailyWorkHours, 'weeklyWorkHours' => $weeklyWorkHours, 'user' => $user]);

    }

    /**
     * Update the user's profile information.
     */
    public function update(Request $request, $id): RedirectResponse
    {
        $user = User::find($id);

        $user->update([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'nfc_card_data' => $request->nfc_card_data,
            'role' => $request->role,
            'update_at' => Carbon::now(),
        ]);

        return redirect('/profile');
    }

    /**
     * Delete the user's account.
     */
    public function destroy(string $id)
    {
        $user = User::find($id);
        $user->delete();

        return Redirect('/profile');
    }

    //create user
    public function create()
    {
        return view('users.create');
    }

    //store user
    public function store(Request $request)
{
    // Validate request data
    $request->validate([
        'name' => 'required',
        'email' => 'required|email|unique:users', // Add unique validation
        'password' => 'required',
        'nfc_card_data' => 'required',
        'role' => ['required', 'in:admin,user'],
    ]);

    // Create user
    $user = User::create([
        'name' => $request->name,
        'email' => $request->email,
        'password' => bcrypt($request->password),
        'nfc_card_data' => $request->nfc_card_data,
        'role' => $request->role,
    ]);

    // Redirect to profile page
    return redirect('/profile');
}
}