<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\VacationRequest;
use App\Mail\VacationRequestMail;
use App\Mail\VacationApprovedMail;
use App\Mail\VacationDeclinedMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class VacationRequestController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        $vacationRequests = $user->vacationRequests;
    
        return view('vacation.index', compact('vacationRequests'));
    }    

    public function store(Request $request)
    {
        $request->validate([
            'start_date' => [
                'required',
                'date',
                Rule::unique('vacation_requests')->where(function ($query) {
                    return $query
                        ->where('user_id', Auth::id())
                        ->where(function ($subQuery) {
                            $subQuery
                                ->whereBetween('start_date', [request('start_date'), request('end_date')])
                                ->orWhereBetween('end_date', [request('start_date'), request('end_date')])
                                ->orWhere(function ($dateQuery) {
                                    $dateQuery
                                        ->where('start_date', '<=', request('start_date'))
                                        ->where('end_date', '>=', request('start_date'));
                                });
                        });
                }),
            ],
            'end_date' => [
                'required',
                'date',
                'after_or_equal:start_date',
                Rule::unique('vacation_requests')->where(function ($query) {
                    return $query
                        ->where('user_id', Auth::id())
                        ->where(function ($subQuery) {
                            $subQuery
                                ->whereBetween('start_date', [request('start_date'), request('end_date')])
                                ->orWhereBetween('end_date', [request('start_date'), request('end_date')])
                                ->orWhere(function ($dateQuery) {
                                    $dateQuery
                                        ->where('start_date', '<=', request('end_date'))
                                        ->where('end_date', '>=', request('end_date'));
                                });
                        });
                }),
            ],
        ]);
    
        $user = Auth::user();
    
        // Check if the user has already requested the selected date range
        $existingRequests = $user->vacationRequests()
            ->where(function ($query) use ($request) {
                $query
                    ->whereBetween('start_date', [$request->start_date, $request->end_date])
                    ->orWhereBetween('end_date', [$request->start_date, $request->end_date])
                    ->orWhere(function ($dateQuery) use ($request) {
                        $dateQuery
                            ->where('start_date', '<=', $request->start_date)
                            ->where('end_date', '>=', $request->start_date);
                    });
            })
            ->exists();
    
        if ($existingRequests) {
            return redirect()->route('vacation.index')->with('error', 'You have already requested this date range.');
        }
    
        $vacationRequest = $user->vacationRequests()->create($request->all());
    
        // Send email to admin
        $adminEmail = 'r.zande@beginstation.nl'; // Replace with actual admin email
        Mail::to($adminEmail)->send(new VacationRequestMail($vacationRequest));
    
        return redirect()->route('vacation.index')->with('success', 'Vacation request submitted successfully.');
    } 

    public function approve($id)
    {
        $vacationRequest = VacationRequest::find($id);
        if ($vacationRequest->status !== 'pending') {
            return redirect()->route('vacation.index')->with('error', 'This request has already been processed.');
        }
        else{
        $vacationRequest->update(['status' => 'approved']);

        // Send approval email to user
        Mail::to($vacationRequest->user->email)->send(new VacationApprovedMail($vacationRequest));

        return redirect()->route('vacation.index')->with('success', 'Vacation request approved.');
        }
    }

    public function decline($id)
    {
        $vacationRequest = VacationRequest::find($id);
        if ($vacationRequest->status !== 'pending') {
            return redirect()->route('vacation.index')->with('error', 'This request has already been processed.');
        }
        else{
        $vacationRequest->update(['status' => 'declined']);
        // Send decline email to user
        Mail::to($vacationRequest->user->email)->send(new VacationDeclinedMail($vacationRequest));

        return redirect()->route('vacation.index')->with('success', 'Vacation request declined.');
        }
    }
}
