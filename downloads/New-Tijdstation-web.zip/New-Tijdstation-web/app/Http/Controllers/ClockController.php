<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Clock;
use App\Models\User;
use Illuminate\Support\Facades\Mail;
use App\Mail\ClockoutReminder;
use Carbon\Carbon;

class ClockController extends Controller
{
    public function index()
    {
        $users = User::all();
        $user = Auth::user();
    
        // Find the latest clock-in entry for the user
        $clockedInEntry = Clock::where('User_id', $user->id)
            ->whereNull('Clock_Out')
            ->orderByDesc('Clock_In')
            ->first();
    
        if ($clockedInEntry) {
            // Calculate the duration
            $now = Carbon::now();
            $clockInTime = Carbon::parse($clockedInEntry->Clock_In);
            $duration = $now->diff($clockInTime);
    
            // Format the duration
            $formattedDuration = sprintf(
                '%02d:%02d:%02d',
                $duration->h,
                $duration->i,
                $duration->s
            );
    
            return view('Clock.index', [
                'clockedIn' => true,
                'clockInTime' => $formattedDuration,
                'users' => $users,
            ]);
        }
    
        return view('Clock.index', [
            'clockedIn' => false,
            'clockInTime' => null,
            'users' => $users,
        ]);
    }

    public function getClockInTime()
{
    $user = Auth::user();
    $clockedInEntry = Clock::where('User_id', $user->id)
        ->whereNull('Clock_Out')
        ->orderByDesc('Clock_In')
        ->first();

    if ($clockedInEntry) {
        $now = Carbon::now();
        $clockInTime = Carbon::parse($clockedInEntry->Clock_In);
        $duration = $now->diff($clockInTime);

        return response()->json(['clockInTime' => $duration->format('%H:%I:%S')]);
    }

    return response()->json(['clockInTime' => '']);
}

public function clockIn(Request $request)
{
    $userId = $request->input('userSelect');
    $user = User::find($userId);

    // Ensure the user exists
    if (!$user) {
        return redirect()->route('Clock.index')->with('error', 'Selected user not found.');
    }

    // Make sure the user is not already clocked in
    $existingClockIn = Clock::where('User_id', $user->id)
        ->whereNull('Clock_Out')
        ->first();

    if ($existingClockIn) {
        return redirect()->route('Clock.index')->with('error', 'Selected user is already clocked in.');
    }

    Clock::create([
        'Date' => Carbon::today(),
        'Clock_In' => Carbon::now(),
        'User_id' => $user->id,
        'Timestamps' => Carbon::now(),
    ]);

    return redirect()->route('Clock.index')->with('success', 'Clocked in successfully.');
}


    public function clockOut()
    {
        $user = Auth::user();

        // Find the latest clock-in entry for the user
        $clockedInEntry = Clock::where('User_id', $user->id)
            ->whereNull('Clock_Out')
            ->orderByDesc('Clock_In') 
            ->latest('Timestamps');

        if (!$clockedInEntry) {
            return redirect()->route('clock')->with('error', 'You are not currently clocked in.');
        }

        // Update the clock-out time
        $clockedInEntry->update([
            'Clock_Out' => Carbon::now(),
            'Timestamps' => Carbon::now(),
        ]);

        return redirect()->route('Clock.index')->with('success', 'Clocked out successfully.');
    }
    public function delete($id){
        $entry=Clock::findOrFail($id);
        // Check that this is a valid clocking record belonging to the authenticated user
        if ($entry->User_id != Auth::user()->id) {
            return redirect('/home')->with('error','Unauthorized Page');
            }
            return view ('Clocks.delete',['Clock'=>$entry]);
            }
            public function destroy($id){
                $entry=Clock::findOrFail($id);
                // Delete the log entry
                $entry->delete();
                // Redirect back to the dashboard with a success message
                return redirect('/dashboard')->with('success',"Log deleted");
                }
}
