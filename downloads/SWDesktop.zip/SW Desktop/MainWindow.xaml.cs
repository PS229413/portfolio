﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using SnelleWiel.Models;
using SnelleWiel.Services.API;
using SnelleWiel.Views;

namespace SnelleWiel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private async void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            tbErrorMessage.Text = "";

            if(tbEmail.Text == "")
            {
                tbErrorMessage.Text = "Vul aub iets in bij het email adres";
                return;
            }
            if(tbPassword.Password == "")
            {
                tbErrorMessage.Text = "Vul aub iets in bij het wachtwoord";
                return;
            }
            if(!IsValidEmail(tbEmail.Text))
            {
                tbErrorMessage.Text = "De email is niet geldig";
                return;
            }
            (Driver driver, string methodResult) = await Auth.LoginAsync(tbEmail.Text, tbPassword.Password);
            if(methodResult != "OK")
            {
                tbErrorMessage.Text = "Helaas ging er iets mis met onze servers. Neem contact op met de service desk voor hulp!\n" + methodResult;
                return;
            }
            if(driver != null)
            {
                if(driver.Role == "Admin")
                {
                    new KeuzeWindow(true, driver).Show();
                }
                else
                {
                    new KeuzeWindow(false, driver).Show();
                }

                this.Close();
            }
            else
            {
                tbErrorMessage.Text = "Ongeldige combinatie gebruikersnaam en wachtwoord";
                return;
            }
        }
        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                // Normalize the domain
                email = Regex.Replace(email, @"(@)(.+)$", DomainMapper,
                                      RegexOptions.None, TimeSpan.FromMilliseconds(200));

                // Examines the domain part of the email and normalizes it.
                string DomainMapper(Match match)
                {
                    // Use IdnMapping class to convert Unicode domain names.
                    var idn = new IdnMapping();

                    // Pull out and process domain name (throws ArgumentException on invalid)
                    string domainName = idn.GetAscii(match.Groups[2].Value);

                    return match.Groups[1].Value + domainName;
                }
            }
            catch (RegexMatchTimeoutException e)
            {
                Console.WriteLine(e);
                return false;
            }
            catch (ArgumentException e)
            {
                Console.WriteLine($"{e.Message}");
                return false;
            }

            try
            {
                return Regex.IsMatch(email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }

        private void btnGast_Click(object sender, RoutedEventArgs e)
        {
            // Clear any previous error messages
            tbErrorMessage.Text = "";

            // Create a guest driver object with limited permissions
            Driver guestDriver = new Driver
            {
                Fullname = "Gast",
                Role = "Guest"
            };

            // Open a new window for the guest user, similar to the choice window for logged-in users
            // Here we pass 'false' since guests should not have admin access, and we pass the guestDriver object
            new KeuzeWindow(false, guestDriver).Show();

            // Optionally close the current window
            this.Close();
        }

    }
}