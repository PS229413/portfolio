﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnelleWiel.Models
{
    internal class DeliveredInfo
    {
        public int Id { get; set; }
        public string Address { get; set; }
        public string Postcode { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string Status { get; set; }
        public DateOnly Delivery_date { get; set; }
        public TimeSpan? Delivery_time_a { get; set; }
        public TimeSpan? Delivery_time_b { get; set; }
    }
}
