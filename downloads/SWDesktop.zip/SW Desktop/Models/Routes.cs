﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnelleWiel.Models
{
    public class Routes
    {
        public int RouteId { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string OptimalRoute { get; set; }
        public string RealTimeUpdates { get; set; }
        public DateTime LastUpdated { get; set; }
    }

}
