﻿using SnelleWiel.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnelleWiel.ViewModels
{
    public class ProfitViewModel : ViewModelBase
    {
        public ObservableCollection<ProfitData> Profits { get; set; }

        private DateTime _startDate;
        public DateTime StartDate
        {
            get => _startDate;
            set => SetProperty(ref _startDate, value);
        }

        private DateTime _endDate;
        public DateTime EndDate
        {
            get => _endDate;
            set => SetProperty(ref _endDate, value);
        }

        public ProfitViewModel()
        {
            Profits = new ObservableCollection<ProfitData>();
            StartDate = DateTime.Now.Date;
            EndDate = DateTime.Now.Date;
        }

        public void FilterData(string filterType)
        {
            var now = DateTime.Now;
            switch (filterType.ToLower())
            {
                case "day":
                    StartDate = now.Date;
                    EndDate = now.Date.AddDays(1).AddTicks(-1);
                    break;
                case "week":
                    StartDate = now.Date.AddDays(-(int)now.DayOfWeek);
                    EndDate = StartDate.AddDays(7).AddTicks(-1);
                    break;
                case "month":
                    StartDate = new DateTime(now.Year, now.Month, 1);
                    EndDate = StartDate.AddMonths(1).AddTicks(-1);
                    break;
                case "year":
                    StartDate = new DateTime(now.Year, 1, 1);
                    EndDate = StartDate.AddYears(1).AddTicks(-1);
                    break;
                default:
                    throw new ArgumentException("Invalid filter type");
            }
        }
    }
}
