﻿using System.Windows;
using Orders = SnelleWiel.Views.DeliveredInformation.Index;
using SnelleWiel.Views.Drivers;
using SnelleWiel.Models;
using Index = SnelleWiel.Views.Drivers.Index;
using Roosters = SnelleWiel.Views.ScheduleAdmin.Index;
using System.ComponentModel;

namespace SnelleWiel.Views;

/// <summary>
/// Interaction logic for KeuzeWindow.xaml
/// </summary>
public partial class KeuzeWindow : Window
{
    Driver _driver;
    bool _isadmin;
    public KeuzeWindow(bool admin, Driver driver)
    {
        InitializeComponent();
        tbIntrotekst.Text = "Hallo " + driver.Fullname + ", waar wil je naar toe";
        if(driver.Role == "Admin")
        {
            _isadmin = true;
        }
        else
        {
            _isadmin = false;
        }
        _isadmin = admin;
        _driver = driver;
    }
    protected override void OnClosing(CancelEventArgs e)
    {
        base.OnClosing(e);
        new MainWindow().Show();
    }
    private void btnOrders_Click(object sender, RoutedEventArgs e)
    {
        new Orders(_isadmin, _driver).Show();
    }

    private void btnDrivers_Click(object sender, RoutedEventArgs e)
    {
        new Index(_isadmin, _driver).Show();
    }

    private void btnRoosters_Click(object sender, RoutedEventArgs e)
    {
        new Roosters(_isadmin, _driver).Show();
    }

    private void btnDocumenten_Click(object sender, RoutedEventArgs e)
    {
        new Documenten.Documenten().Show();
    }

    private void btnWinst_Click(object sender, RoutedEventArgs e)
    {
        new Winst.Index().Show();
    }
}
