﻿using Microsoft.Win32;
using SnelleWiel.Services;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace SnelleWiel.Views.Documenten
{
    /// <summary>
    /// Interaction logic for Documenten.xaml
    /// </summary>
    public partial class Documenten : Window
    {
        private DocumentService _documentService;
        public Documenten()
        {
            InitializeComponent();
            _documentService = new DocumentService();
            DocumentsListBox.ItemsSource = _documentService.Documents;
        }

        private void AddDocumentButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                _documentService.AddDocument(Path.GetFileName(openFileDialog.FileName), openFileDialog.FileName);
            }
        }

        private void OpenDocumentButton_Click(object sender, RoutedEventArgs e)
        {
            if (DocumentsListBox.SelectedItem is Document selectedDocument)
            {
                OpenDocument(selectedDocument.Path);
            }
        }

        private void DeleteDocumentButton_Click(object sender, RoutedEventArgs e)
        {
            if (DocumentsListBox.SelectedItem is Document selectedDocument)
            {
                _documentService.DeleteDocument(selectedDocument);
                DocumentContentTextBox.Clear();
            }
        }

        private void DocumentsListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DocumentsListBox.SelectedItem is Document selectedDocument)
            {
                OpenDocument(selectedDocument.Path);
            }
            else
            {
                DocumentContentTextBox.Clear();
            }
        }

        private void OpenDocument(string path)
        {
            var extension = Path.GetExtension(path).ToLower();
            if (extension == ".txt")
            {
                DocumentContentTextBox.Text = File.ReadAllText(path);
            }
            else
            {
                // Open the file with the default associated program
                Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
            }
        }
    }
}
