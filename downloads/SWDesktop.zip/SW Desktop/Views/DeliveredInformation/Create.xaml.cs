﻿using Newtonsoft.Json;
using RestSharp;
using SnelleWiel.Models;
using SnelleWiel.Services.API;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace SnelleWiel.Views.DeliveredInformation
{
    /// <summary>
    /// Interaction logic for Create.xaml
    /// </summary>
    public partial class Create : Window
    {
        private const string myAPIKey = "4e299181c30a4bc19b8b499388eec86d"; // Replace with your actual API key
        Driver _driver;
        public Create(Driver driver)
        {
            InitializeComponent();
            _driver = driver;
        }
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            new Index(true, _driver).Show();
        }

        private async void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            if(tbAdres.Text == "")
            {
                MessageBox.Show("Vul aub een adres in");
                return;
            }
            if(tbAdres.Text.Length > 70)
            {
                MessageBox.Show("Het ingevulde adres is te lang, het mag maximaal 70 karakters bevatten");
                return;
            }
            if(tbPostcode.Text == "")
            {
                MessageBox.Show("Vul aub een postcode in");
                return;
            }
            if(tbPostcode.Text.Length > 10)
            {
                MessageBox.Show("De ingevulde postcode is te lang, die mag maximaal 10 karakters bevatten");
                return;
            }
            if(tbPlaats.Text == "")
            {
                MessageBox.Show("Vul aub een plaats in");
                return;
            }
            if(tbPlaats.Text.Length > 70)
            {
                MessageBox.Show("De ingevulde plaats is te lang, die mag maximaal 70 karakters bevatten");
                return;
            }
            if(string.IsNullOrEmpty(cbxLanden.Text))
            {
                MessageBox.Show("Selecteer een land");
                return;
            }
            if(dpDate.SelectedDate < DateTime.Now)
            {
                MessageBox.Show("De datum mag niet eerder zijn dan vandaag. De datum van vandaag is " + DateTime.Now.Day + "-" + DateTime.Now.Month + "-" + DateTime.Now.Year);
                return;
            }
            TimeSpan? timeA = null;
            TimeSpan? timeB = null;
            if(tbUren1.Text != "" && tbUren2.Text != "" && tbMinuten1.Text != "" && tbMinuten2.Text != "")
            {
                int u1;
                int u2;
                int m1;
                int m2;
                try
                {
                    u1 = Int32.Parse(tbUren1.Text);
                    u2 = Int32.Parse(tbUren2.Text);
                    m1 = Int32.Parse(tbMinuten1.Text);
                    m2 = Int32.Parse(tbMinuten2.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Vul aub een getal in in ieder vak voor de tijd");
                    return;
                }
                if (u1 < 0 || u1 > 23 || u2 < 0 || u2 > 23 || m1 < 0 || m1 > 59 || m2 < 0 || m2 > 59)
                {
                    MessageBox.Show("Je hebt ergens een ongeldige waarde ingevuld bij de tijden");
                    return;
                }
                timeA = new TimeSpan(0, u1, m1, 0, 0, 0);
                timeB = new TimeSpan(0, u2, m2, 0, 0, 0);
            }
            else
            {
                if(tbUren1.Text == "" || tbUren2.Text == "" || tbMinuten1.Text == "" || tbMinuten2.Text == "")
                {
                    MessageBoxResult myResult = MessageBox.Show("Je hebt de tijden niet of niet geheel ingevuld. " +
                    "Wil je deze order opslaan zonder tijd?", "Tijden niet ingevuld", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (myResult == MessageBoxResult.No)
                    {
                        MessageBox.Show("Vul de tijden in");
                        return;
                    }
                }
            }
            bool check = ValidateAddress(tbAdres.Text, tbPostcode.Text, tbPlaats.Text, cbxLanden.Text);
            if(!check)
            {
                MessageBox.Show("Het adres is ongeldig");
                return;
            }
            DeliveredInfo deliveredinfo = new DeliveredInfo();
            deliveredinfo.Address = tbAdres.Text;
            deliveredinfo.Postcode = tbPostcode.Text;
            deliveredinfo.City = tbPlaats.Text;
            deliveredinfo.Country = cbxLanden.Text;
            deliveredinfo.Delivery_date = DateOnly.FromDateTime((DateTime)dpDate.SelectedDate!);
            if(timeA != null)
            {
                deliveredinfo.Delivery_time_a = timeA;
            }
            if(timeB != null)
            {
                deliveredinfo.Delivery_time_b = timeB;
            }
            deliveredinfo.Status = "Open";
            (DeliveredInfo deliveredinfoCreated, string statusCode, string methodResult) = await DeliveredInformationService.CreateDeliveredInformationAsync(deliveredinfo);
            if(statusCode == "Created" && methodResult == "OK")
            {
                MessageBoxResult myResult = MessageBox.Show("Creëren is gelukt! Druk op OK om naar het hoofdscherm te gaan, of op annuleer om op dit scherm te blijven.",
                    "Creëren gelukt", MessageBoxButton.OKCancel, MessageBoxImage.Question);
                if(myResult == MessageBoxResult.OK)
                {
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Er ging iets mis met het creëren van de order. Neem contact op met de service desk. Bericht voor hun:\n" + methodResult);
            }
        }
        private bool ValidateAddress(string address, string postcode, string city, string country)
        {
            // Construct the address string
            string fullAddress = $"{address}, {postcode} {city}, {country}";

            // Make a request to OpenStreetMap Nominatim API
            var client = new RestClient("https://nominatim.openstreetmap.org");
            var request = new RestRequest("search", Method.Get);
            request.AddParameter("format", "json");
            request.AddParameter("q", fullAddress);
            var response = client.Execute(request);

            // Check if the response is successful and contains valid results
            if (response.IsSuccessful && !string.IsNullOrWhiteSpace(response.Content) && response.Content.Contains("lat"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private async void FetchAddressSuggestions(string address, string postalCode)
        {
            var url = "https://api.geoapify.com/v1/geocode";
            var options = new RestClientOptions(url);
            var client = new RestClient(options);
            var request = new RestRequest("/autocomplete");

            if (!string.IsNullOrEmpty(address))
                request.AddParameter("text", address);

            if (!string.IsNullOrEmpty(postalCode))
                request.AddParameter("postcode", postalCode);

            request.AddParameter("apiKey", myAPIKey);

            var response = await client.GetAsync(request);

            if (response.IsSuccessful)
            {
                dynamic result = JsonConvert.DeserializeObject(response.Content);
                ProcessResponse(result);
            }
            else
            {
                MessageBox.Show($"Failed to fetch address suggestions. Error: {response.Content}");
            }
        }
        private void ProcessResponse(dynamic result)
        {
            List<string> formattedAddresses = new List<string>();

            foreach (var feature in result["features"])
            {
                string formattedAddress = feature["properties"]["formatted"];
                formattedAddresses.Add(formattedAddress);
            }

            MessageBox.Show($"Found {formattedAddresses.Count} address suggestions:\n{string.Join("\n", formattedAddresses)}");
        }
    }
}
