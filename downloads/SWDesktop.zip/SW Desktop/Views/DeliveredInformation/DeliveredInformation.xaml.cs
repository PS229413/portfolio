﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Diagnostics;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;

namespace SnelleWiel.Views.DeliveredInformation
{
    /// <summary>
    /// Interaction logic for DeliveredInformation.xaml
    /// </summary>
    public partial class DeliveredInformation : Window
    {
        private const string myAPIKey = "4e299181c30a4bc19b8b499388eec86d"; // Replace with your actual API key
        public DeliveredInformation()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string address = txtAddress.Text;
            string postcode = txtPostalCode.Text;
            string city = txtCity.Text;
            string country = txtCountry.Text;

            // Perform address validation
            bool isValidAddress = ValidateAddress(address, postcode, city, country);
            if (isValidAddress)
            {
                txtValidationResult.Text = "Address is valid.";
            }
            else
            {
                txtValidationResult.Text = "Address is invalid.";
            }
        }

        private bool ValidateAddress(string address, string postcode, string city, string country)
        {
            // Construct the address string
            string fullAddress = $"{address}, {postcode} {city}, {country}";

            // Make a request to OpenStreetMap Nominatim API
            var client = new RestClient("https://nominatim.openstreetmap.org");
            var request = new RestRequest("search", Method.Get);
            request.AddParameter("format", "json");
            request.AddParameter("q", fullAddress);
            var response = client.Execute(request);

            // Check if the response is successful and contains valid results
            if (response.IsSuccessful && !string.IsNullOrWhiteSpace(response.Content) && response.Content.Contains("lat"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private async void FetchAddressSuggestions(string address, string postalCode)
        {
            var url = "https://api.geoapify.com/v1/geocode";
            var options = new RestClientOptions(url);
            var client = new RestClient(options);
            var request = new RestRequest("/autocomplete");

            if (!string.IsNullOrEmpty(address))
                request.AddParameter("text", address);

            if (!string.IsNullOrEmpty(postalCode))
                request.AddParameter("postcode", postalCode);

            request.AddParameter("apiKey", myAPIKey);

            var response = await client.GetAsync(request);

            if (response.IsSuccessful)
            {
                dynamic result = JsonConvert.DeserializeObject(response.Content);
                ProcessResponse(result);
            }
            else
            {
                MessageBox.Show($"Failed to fetch address suggestions. Error: {response.Content}");
            }
        }


        private void ProcessResponse(dynamic result)
        {
            List<string> formattedAddresses = new List<string>();

            foreach (var feature in result["features"])
            {
                string formattedAddress = feature["properties"]["formatted"];
                formattedAddresses.Add(formattedAddress);
            }

            MessageBox.Show($"Found {formattedAddresses.Count} address suggestions:\n{string.Join("\n", formattedAddresses)}");
        }

        private void FetchSuggestions_Click(object sender, RoutedEventArgs e)
        {
            string address = txtAddress.Text;
            string postalCode = txtPostalCode.Text;

            FetchAddressSuggestions(address, postalCode);
        }


    }
}
