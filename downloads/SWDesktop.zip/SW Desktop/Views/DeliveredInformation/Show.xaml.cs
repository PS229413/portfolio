﻿using SnelleWiel.Models;
using SnelleWiel.Services.API;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SnelleWiel.Views.DeliveredInformation
{
    /// <summary>
    /// Interaction logic for Show.xaml
    /// </summary>
    public partial class Show : Window
    {
        bool _isadmin;
        Driver _driver;
        public Show(bool admin, Driver driver)
        {
            InitializeComponent();
            _isadmin = admin;
            _driver = driver;
            PopulateOrder(driver.Id);
        }
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            new Index(_isadmin, _driver).Show();
        }
        private async void PopulateOrder(int id)
        {
            (DeliveredInfo deliveredInfo, string methodResult) = await DeliveredInformationService.GetDeliveredInformationByIdAsync(id);
            if(methodResult != "OK")
            {
                MessageBox.Show("Er ging iets mis met het ophalen van de order. Neem contact op met de service desk. Bericht voor hun:\n" + methodResult);
                return;
            }
            tbStraatHuis.Text = deliveredInfo.Address;
            tbPostcode.Text = deliveredInfo.Postcode;
            tbPlaats.Text = deliveredInfo.City;
            tbLand.Text = deliveredInfo.Country;
            tbStatus.Text = "Status: " + deliveredInfo.Status;
            tbDatum.Text = deliveredInfo.Delivery_date.ToString("dd-MM-yyyy");

            string[] partsTimeA = deliveredInfo.Delivery_time_a.ToString()!.Split(':');
            string[] partsTimeB = deliveredInfo.Delivery_time_b.ToString()!.Split(':');

            tbTijd.Text = partsTimeA[0] + ":" + partsTimeA[1] + " - " + partsTimeB[0] + ":" + partsTimeB[1];
        }
    }
}
