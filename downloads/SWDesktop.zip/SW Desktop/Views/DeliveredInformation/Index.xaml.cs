﻿using SnelleWiel.Services.API;
using SnelleWiel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;

namespace SnelleWiel.Views.DeliveredInformation
{
    /// <summary>
    /// Interaction logic for Index.xaml
    /// </summary>
    public partial class Index : Window
    {
        Driver _driver;
        bool _isadmin;
        public Index(bool admin, Driver driver)
        {
            InitializeComponent();
            PopulateInformation();
            _isadmin = admin;
            if (!admin)
            {
                btnCreate.Visibility = Visibility.Hidden;
                dgDelete.Visibility = Visibility.Hidden;
                dgUpdate.Visibility = Visibility.Hidden;
            }
            _driver = driver;
        }
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            new KeuzeWindow(_isadmin, _driver).Show();
        }
        private async void PopulateInformation()
        {
            (List<DeliveredInfo> deliveredInformation, string methodResult) = await DeliveredInformationService.GetDeliveredInformationAsync();
            if(methodResult != "OK")
            {
                MessageBox.Show("Er ging iets mis met het ophalen van de orders. Neem contact op met de service desk. Bericht voor hun: \n" + methodResult);
                return;
            }
            dataGrid.ItemsSource = deliveredInformation;
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            new Update(_isadmin, _driver).Show();
            this.Close();
        }
        private async void Delete_Click(object sender, RoutedEventArgs e)
        {
            var selectedObject = dataGrid.SelectedItem as DeliveredInfo;
            int id = selectedObject!.Id;
            MessageBoxResult myresult = MessageBox.Show("Weet je zeker dat je deze order met id " + id + " wilt verwijderen?", "Order verwijderen", 
                MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (myresult == MessageBoxResult.Yes)
            {
                string statusCode = await DeliveredInformationService.DeleteDeliveredInformationAsync(id);
                if (statusCode != "OK")
                {
                    MessageBox.Show("Helaas ging er iets mis met het verwijderen. Neem contact op met de service desk");
                    return;
                }
                else
                {
                    MessageBox.Show("Verwijderen gelukt!");
                    PopulateInformation();
                    return;
                }
            }    
        }
        private void Create_Click(object sender, RoutedEventArgs e)
        {
            new Create(_driver).Show();
            this.Close();
        }
        private void Show_Click(object sender, RoutedEventArgs e)
        {
            var selectedObject = dataGrid.SelectedItem as DeliveredInfo;
            int id = selectedObject!.Id;
            new Show(_isadmin, _driver).Show();
            this.Close();
        }
    }
}
