﻿using SnelleWiel.Models;
using SnelleWiel.Services.API;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System;
using System.Text.Json;
using System.ComponentModel;

namespace SnelleWiel.Views.Drivers
{
    /// <summary>
    /// Interaction logic for Create.xaml
    /// </summary>
    public partial class Create : Window
    {
        Driver _driver;
        public Create(Driver driver)
        {
            InitializeComponent();
            PopulateTrucks();
            _driver = driver;
        }
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            new Index(true, _driver).Show();
        }
        private async void PopulateTrucks()
        {
            List<Truck> trucks = await TruckService.GetTrucksAsync();
            foreach (Truck truck in trucks)
            {
                TextBlock textblock = new TextBlock();
                textblock.FontSize = 13;
                textblock.Margin = new Thickness(2, 2, 0, 0);
                textblock.Text = "Nr. " + truck.Id.ToString() + " - Gewicht: " + truck.Weight.ToString() + " - Hoogte: " + truck.Height.ToString();
                textblock.MinWidth = 300;
                textblock.Height = 20;
                spTruckdsc.Children.Add(textblock);

                Button button = new Button();
                button.Content = "Koppelen";
                button.Click += Button_Click;
                button.Name = "B" + truck.Id.ToString();
                button.Margin = new Thickness(2, 2, 0, 0);
                button.Background = Brushes.LightGray;
                button.Width = 80;
                button.Height = 20;
                spButtons.Children.Add(button);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button? button = sender as Button;
            if(button!.Content.ToString() == "Koppelen")
            {
                button.Background = Brushes.LightGreen;
                button.Content = "Ontkoppelen";
            }
            else
            {
                button.Background = Brushes.LightGray;
                button.Content = "Koppelen";
            }
        }
        private async void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            if(tbName.Text == "")
            {
                MessageBox.Show("Er is geen naam ingevuld. Vul een naam in");
                return;
            }
            if(tbEmail.Text == "")
            {
                MessageBox.Show("Er is geen email ingevuld. Vul een email in");
                return;
            }
            if(tbPhone.Text == "")
            {
                MessageBox.Show("Er is geen telefoonnummer ingevuld");
                return;
            }
            if (cbRole.SelectedIndex == -1)
            {
                MessageBox.Show("Selecteer aub een rol!");
                return;
            }
            if (tbPassword.Password == "")
            {
                MessageBox.Show("Vul een wachtwoord in");
                return;
            }
            if (tbName.Text.Length > 70)
            {
                MessageBox.Show("Er is een te lange naam ingevuld, deze mag maximaal 70 karakters lang zijn");
                return;
            }
            if (tbEmail.Text.Length > 50)
            {
                MessageBox.Show("Er is een te lange email ingevuld, deze mag maximaal 50 karakters lang zijn");
                return;
            }
            if (tbPhone.Text.Length > 20)
            {
                MessageBox.Show("Er is een te lang telefoonnummer ingevuld, deze mag maximaal 20 karakters lang zijn");
                return;
            }
            if (tbPassword.Password != tbPasswordH.Password)
            {
                MessageBox.Show("De wachtwoorden komen niet overeen");
                return;
            }
            if(tbPassword.Password.Length < 8)
            {
                MessageBox.Show("Het wachtwoord dient minimaal 8 karakters te hebben");
                return;
            }
            bool check = false;
            int counter = 0;
            bool[] indexSelectedTrucks = new bool[spButtons.Children.Count];
            foreach (Button button in spButtons.Children.OfType<Button>())
            {
                if(button.Content.ToString() == "Ontkoppelen")
                {
                    check = true;
                    indexSelectedTrucks[counter] = true;
                }
                counter++;
            }
            if(!check)
            {
                MessageBox.Show("Je moet minimaal 1 truck selecteren die gekoppeld wordt aan de gebruiker");
                return;
            }

            List<Truck> trucks = new List<Truck>();
            int listIndexCounter = 0;
            counter = 0;
            foreach (TextBlock textblock in spTruckdsc.Children.OfType<TextBlock>())
            {
                string[] parts = textblock.Text.Split(' ');
                if (indexSelectedTrucks[counter])
                {
                    Truck truck = new Truck();
                    truck.Id = Convert.ToInt32(parts[1]);
                    truck.Weight = Convert.ToInt32(parts[4]);
                    truck.Height = Convert.ToInt32(parts[7]);
                    trucks.Add(truck);
                    listIndexCounter++;
                }
                counter++;
            }

            Driver driver = new Driver();
            driver.Email = tbEmail.Text;
            driver.Phone = tbPhone.Text;
            driver.Fullname = tbName.Text;
            driver.Role = "Admin";
            driver.Password = tbPassword.Password;

            (string createddriver, string statusCode, string methodResult) = await DriverService.CreateDriverAsync(driver);
            if (methodResult != "OK") 
            {
                MessageBox.Show("Er ging iets mis bij het creëren, wellicht heb je een email adres dan wel telefoonnummer ingevuld dat al wordt gebruikt?");
                return;
            }
            using (JsonDocument doc = JsonDocument.Parse(createddriver))
            {
                JsonElement root = doc.RootElement;
                JsonElement data = root.GetProperty("data");
                int id = data.GetProperty("id").GetInt32();
                foreach (Truck truck in trucks)
                {
                    string code = await DRTDservice.CreateDriverTruckAsync(id, truck.Id);
                    if(code != "Created")
                    {
                        MessageBox.Show("Er ging iets mis met het koppelen van de trucks");
                        return;
                    }
                    await Task.Delay(1000); // Wacht 1 seconde
                }
            }
            if (statusCode == "Created")
            {
                MessageBoxResult myResult = MessageBox.Show("Creëren is gelukt! Druk op OK om naar het hoofdscherm te gaan, of op annuleer om op dit scherm te blijven.",
                    "Creëren gelukt", MessageBoxButton.OKCancel, MessageBoxImage.Question);
                if (myResult == MessageBoxResult.OK)
                {
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Er ging iets mis met het creëren van de order. Neem contact op met de service desk");
            }
        }
    }
}
