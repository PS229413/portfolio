﻿using SnelleWiel.Models;
using SnelleWiel.Services.API;
using SnelleWiel.Views.DeliveredInformation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SnelleWiel.Views.Drivers
{
    /// <summary>
    /// Interaction logic for Index.xaml
    /// </summary>
    public partial class Index : Window
    {
        Driver _driver;
        bool _isadmin;
        public Index(bool admin, Driver driver)
        {
            InitializeComponent();
            PopulateDrivers();
            _isadmin = admin;
            _driver = driver;
            if (!admin)
            {
                btnCreate.Visibility = Visibility.Hidden;
                dgDelete.Visibility = Visibility.Hidden;
                dgUpdate.Visibility = Visibility.Hidden;
            }
        }
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            new KeuzeWindow(_isadmin, _driver).Show();
        }
        private async void PopulateDrivers()
        {
            (List<Driver> deliveredInformation, string methodResult) = await DriverService.GetDriversAsync();
            if(methodResult != "OK")
            {
                MessageBox.Show("Er ging iets mis met het ophalen van alle drivers. Neem contact op met de service desk.");
                return;
            }
            dataGrid.ItemsSource = deliveredInformation;
        }

        private void Create_Click(object sender, RoutedEventArgs e)
        {
            new Create(_driver).Show();
            this.Close();
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            new Update(_isadmin, _driver).Show();
            this.Close();
        }

        private async void Delete_Click(object sender, RoutedEventArgs e)
        {
            var selectedObject = dataGrid.SelectedItem as Driver;
            int id = selectedObject!.Id;
            MessageBoxResult myresult = MessageBox.Show("Weet je zeker dat je deze driver met id " + id + " wilt verwijderen?", "Driver verwijderen",
                MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (myresult == MessageBoxResult.Yes)
            {
                (string statusCode, string methodResult) = await DriverService.DeleteDriverAsync(id);
                if (statusCode != "OK" || methodResult != "OK")
                {
                    MessageBox.Show("Helaas ging er iets mis met het verwijderen. Neem contact op met de service desk");
                    return;
                }
                else
                {
                    MessageBox.Show("Verwijderen gelukt!");
                    PopulateDrivers();
                    return;
                }
            }
        }

        private void Show_Click(object sender, RoutedEventArgs e)
        {
            var selectedObject = dataGrid.SelectedItem as Driver;
            int id = selectedObject!.Id;
            new Show(_isadmin, _driver).Show();
            this.Close();
        }
    }
}
