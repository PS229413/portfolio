﻿using SnelleWiel.Models;
using SnelleWiel.Services.API;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SnelleWiel.Views.Drivers
{
    /// <summary>
    /// Interaction logic for Update.xaml
    /// </summary>
    public partial class Update : Window
    {
        Driver _driver = new Driver();
        string _email = "";
        List<int> _truckIdsAttachedBeforeUpdating = new List<int>();
        bool _isadmin;
        public Update(bool admin, Driver driver)
        {
            InitializeComponent();
            _isadmin = admin;
            _driver = driver;
            PopulateDriver(driver.Id);
        }
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            new Index(_isadmin, _driver).Show();
        }
        private async void PopulateDriver(int id)
        {
            (_driver, string json, string methodResult) = await DriverService.GetDriverByIdAsync(id);
            tbName.Text = _driver.Fullname;
            tbEmail.Text = _driver.Email;
            tbPhone.Text = _driver.Phone;
            cbRole.Text = _driver.Role;
            _email = _driver.Email;

            List<Truck> trucks = await TruckService.GetTrucksAsync();
            foreach (Truck truck in trucks)
            {
                TextBlock textblock = new TextBlock();
                textblock.FontSize = 13;
                textblock.Margin = new Thickness(2, 2, 0, 0);
                textblock.Text = "Nr. " + truck.Id.ToString() + " - Gewicht: " + truck.Weight.ToString() + " - Hoogte: " + truck.Height.ToString();
                textblock.MinWidth = 300;
                textblock.Height = 20;
                spTruckdsc.Children.Add(textblock);

                Button button = new Button();
                button.Content = "Koppelen";
                button.Click += Button_Click;
                button.Name = "B" + truck.Id.ToString();
                button.Margin = new Thickness(2, 2, 0, 0);
                button.Background = Brushes.LightGray;
                button.Width = 80;
                button.Height = 20;
                spButtons.Children.Add(button);
            }

            // Parse the JSON string
            var document = JsonDocument.Parse(json);
            var root = document.RootElement;

            // Check if the trucks property exists
            if (root.TryGetProperty("trucks", out JsonElement trucksElement))
            {
                // Iterate through the trucks array
                foreach (JsonElement truck in trucksElement.EnumerateArray())
                {
                    if (truck.TryGetProperty("truck_id", out JsonElement truckIdElement))
                    {
                        _truckIdsAttachedBeforeUpdating.Add(truckIdElement.GetInt32());
                    }
                }
                foreach (Button button in spButtons.Children)
                {
                    string[] splitted = button.Name.Split('B');
                    int btId = int.Parse(splitted[1]);
                    foreach (int truckId in _truckIdsAttachedBeforeUpdating)
                    {
                        if(truckId == btId)
                        {
                            button.Background = Brushes.LightGreen;
                            button.Content = "Ontkoppelen";
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("No trucks found in the JSON data.");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button? button = sender as Button;
            if (button!.Content.ToString() == "Koppelen")
            {
                button.Background = Brushes.LightGreen;
                button.Content = "Ontkoppelen";
            }
            else
            {
                button.Background = Brushes.LightGray;
                button.Content = "Koppelen";
            }
        }

        private async void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (tbName.Text == "")
            {
                MessageBox.Show("Er is geen naam ingevuld. Vul een naam in");
                return;
            }
            if (tbEmail.Text == "")
            {
                MessageBox.Show("Er is geen email ingevuld. Vul een email in");
                return;
            }
            if (tbPhone.Text == "")
            {
                MessageBox.Show("Er is geen telefoonnummer ingevuld");
                return;
            }
            if (tbPassword.Password == "")
            {
                MessageBox.Show("Vul een wachtwoord in");
                return;
            }
            if (tbName.Text.Length > 70)
            {
                MessageBox.Show("Er is een te lange naam ingevuld, deze mag maximaal 70 karakters lang zijn");
                return;
            }
            if (tbEmail.Text.Length > 50)
            {
                MessageBox.Show("Er is een te lange email ingevuld, deze mag maximaal 50 karakters lang zijn");
                return;
            }
            if (tbPhone.Text.Length > 20)
            {
                MessageBox.Show("Er is een te lang telefoonnummer ingevuld, deze mag maximaal 20 karakters lang zijn");
                return;
            }
            if (tbPassword.Password != tbPasswordH.Password)
            {
                MessageBox.Show("De wachtwoorden komen niet overeen");
                return;
            }
            if (cbRole.SelectedIndex == -1)
            {
                MessageBox.Show("Selecteer aub een rol!");
                return;
            }
            if (tbPassword.Password.Length < 8)
            {
                MessageBox.Show("Het wachtwoord dient minimaal 8 karakters te hebben");
                return;
            }
            bool check = false;
            int counter = 0;
            bool[] indexSelectedTrucks = new bool[spButtons.Children.Count];
            foreach (Button button in spButtons.Children.OfType<Button>())
            {
                if (button.Content.ToString() == "Ontkoppelen")
                {
                    check = true;
                    indexSelectedTrucks[counter] = true;
                }
                counter++;
            }
            if (!check)
            {
                MessageBox.Show("Je moet minimaal 1 truck selecteren die gekoppeld wordt aan de gebruiker");
                return;
            }

            List<Truck> trucks = new List<Truck>();
            int listIndexCounter = 0;
            counter = 0;
            foreach (TextBlock textblock in spTruckdsc.Children.OfType<TextBlock>())
            {
                string[] parts = textblock.Text.Split(' ');
                if (indexSelectedTrucks[counter])
                {
                    Truck truck = new Truck();
                    truck.Id = Convert.ToInt32(parts[1]);
                    truck.Weight = Convert.ToInt32(parts[4]);
                    truck.Height = Convert.ToInt32(parts[7]);
                    trucks.Add(truck);
                    listIndexCounter++;
                }
                counter++;
            }

            Driver driver = new Driver();
            driver.Email = tbEmail.Text;
            driver.Phone = tbPhone.Text;
            driver.Fullname = tbName.Text;
            driver.Role = "Admin";
            driver.Password = tbPassword.Password;

            (string updateddriver, string statusCode, string methodResult) = await DriverService.UpdateDriverAsync(_driver.Id, driver);
            using (JsonDocument doc = JsonDocument.Parse(updateddriver))
            {
                JsonElement root = doc.RootElement;
                JsonElement data = root.GetProperty("data");
                int id = data.GetProperty("id").GetInt32();

                string deletecode = await DRTDservice.DeleteDriverTruckAsync(id);
                if(deletecode != "OK")
                {
                    MessageBox.Show("Er ging iets mis met het verwijderen van de oude gekoppelde trucks");
                    return;
                }
                foreach (Truck truck in trucks)
                {
                    string code = await DRTDservice.CreateDriverTruckAsync(id, truck.Id);
                    if (code != "Created")
                    {
                        MessageBox.Show("Er ging iets mis met het koppelen van de trucks");
                        return;
                    }
                    await Task.Delay(1000); // Wacht 1 seconde
                }
            }
            if (statusCode == "Created")
            {
                MessageBoxResult myResult = MessageBox.Show("Creëren is gelukt! Druk op OK om naar het hoofdscherm te gaan, of op annuleer om op dit scherm te blijven.",
                    "Creëren gelukt", MessageBoxButton.OKCancel, MessageBoxImage.Question);
                if (myResult == MessageBoxResult.OK)
                {
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Er ging iets mis met het creëren van de order. Neem contact op met de service desk");
            }
        }
    }
}
