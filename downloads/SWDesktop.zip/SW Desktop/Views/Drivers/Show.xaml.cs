﻿using SnelleWiel.Models;
using SnelleWiel.Services.API;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SnelleWiel.Views.Drivers
{
    /// <summary>
    /// Interaction logic for Show.xaml
    /// </summary>
    public partial class Show : Window
    {
        bool _isadmin;
        Driver _driver;
        public Show(bool admin, Driver driver)
        {
            InitializeComponent();
            PopulateDriver(driver.Id);
            _isadmin = admin;
            _driver = driver;
        }
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            new Index(_isadmin, _driver).Show();
        }
        private async void PopulateDriver(int id)
        {
            (Driver driver, string json, string methodResult) = await DriverService.GetDriverByIdAsync(id);
            tbDriver.Text = "Driver: " + driver.Fullname;
            tbEmail.Text = "Email: " + driver.Email;
            tbRole.Text = "Rol: " + driver.Role;
            tbTel.Text = "Tel: " + driver.Phone;
            //Nieuwe route aanmaken voor de trucks op te halen
            /*foreach (Truck truck in driver.Trucks)
            {
                ListBoxItem item = new ListBoxItem();
                item.Margin = new Thickness(11, 0, 22, 0);
                item.FontSize = 24;
                item.Content = "Nummer: " + truck.Id.ToString();

                ListBoxItem item2 = new ListBoxItem();
                item2.Margin = new Thickness(11, 0, 22, 0);
                item2.FontSize = 24;
                item2.Content = "Hoogte: " + truck.Height.ToString();

                ListBoxItem item3 = new ListBoxItem();
                item3.Margin = new Thickness(11, 0, 22, 0);
                item3.FontSize = 24;
                item3.Content = "Gewicht: " + truck.Weight.ToString();

                lbTrucks.Items.Add(item);
                lbTrucks.Items.Add(item2);
                lbTrucks.Items.Add(item3);
            }*/
        }
    }
}
