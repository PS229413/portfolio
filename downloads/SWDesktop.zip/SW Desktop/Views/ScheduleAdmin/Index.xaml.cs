﻿using SnelleWiel.Models;
using SnelleWiel.Services.API;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SnelleWiel.Views.ScheduleAdmin
{
    /// <summary>
    /// Interaction logic for Index.xaml
    /// </summary>
    public partial class Index : Window
    {
        List<Schedule> _schedules = new();
        int _id = 0;
        int _currentyear = 0;
        int _currentweek = 0;
        string[] _months = { "januari", "februari", "maart", "april", "mei", "juni", "juli", "augustus", "september", "oktober", "november", "december" };

        public Index(bool admin, Driver driver)
        {
            InitializeComponent();
            if (!admin)
            {
                btnCreate.Visibility = Visibility.Hidden;
            }
            _id = driver.Id;
            tbHeader.Text = "Hallo " + driver.Fullname;
            _currentyear = DateTime.Now.Year;
            _currentweek = GetIso8601WeekOfYear(DateTime.Now);
            GetAllSchedules(_id);
            PopulateSchedules();
        }
        private async void GetAllSchedules(int id)
        {
            (List<Schedule> schedules, string methodResult) = await ScheduleService.GetSchedulesByDriverAsync(id);
            if (methodResult != "OK")
            {
                MessageBox.Show("Er ging helaas iets mis met het ophalen van de diensten:\n" + methodResult);
                return;
            }
            _schedules = schedules;
        }
        private void PopulateSchedules()
        {
            spDiensten.Children.Clear();
            DateTime jan1 = new DateTime(_currentyear, 1, 1);
            bool isJan1InFirstWeek = jan1.DayOfWeek == DayOfWeek.Monday ||
                                     jan1.DayOfWeek == DayOfWeek.Tuesday ||
                                     jan1.DayOfWeek == DayOfWeek.Wednesday ||
                                     jan1.DayOfWeek == DayOfWeek.Thursday;

            DateTime firstMonday;
            if (isJan1InFirstWeek)
            {
                int daysOffset = DayOfWeek.Monday - jan1.DayOfWeek;
                firstMonday = jan1.AddDays(daysOffset);
            }
            else
            {
                int daysOffset = (7 - (int)jan1.DayOfWeek + (int)DayOfWeek.Monday);
                firstMonday = jan1.AddDays(daysOffset);
            }

            DateOnly startOfWeek = DateOnly.FromDateTime(firstMonday.AddDays((_currentweek - 1) * 7));
            DateOnly endOfWeek = startOfWeek.AddDays(6);

            TextBlock header = new TextBlock();
            header.Margin = new Thickness(0, 10, 0, 0);
            header.FontSize = 20;
            header.FontWeight = FontWeights.UltraBold;
            header.FontFamily = new FontFamily("Arial");
            header.Foreground = Brushes.Black;
            header.TextDecorations = TextDecorations.Underline;
            header.TextAlignment = TextAlignment.Center;
            header.Text = "Week " + _currentweek.ToString() + " - " + _currentyear.ToString();
            spDiensten.Children.Add(header);

            foreach (Schedule schedule in _schedules)
            {
                if(schedule.Date >= startOfWeek && schedule.Date <= endOfWeek)
                {
                    TextBlock datum = new TextBlock();
                    datum.FontSize = 16;
                    datum.TextAlignment = TextAlignment.Center;
                    switch (schedule.Date.DayOfWeek)
                    {
                        case DayOfWeek.Sunday:
                            datum.Text = "Zondag ";
                            break;
                        case DayOfWeek.Monday:
                            datum.Text = "Maandag ";
                            break;
                        case DayOfWeek.Tuesday:
                            datum.Text = "Dinsdag ";
                            break;
                        case DayOfWeek.Wednesday:
                            datum.Text = "Woensdag "; 
                            break;
                        case DayOfWeek.Thursday:
                            datum.Text = "Donderdag";
                            break;
                        case DayOfWeek.Friday:
                            datum.Text = "Vrijdag ";
                            break;
                        case DayOfWeek.Saturday:
                            datum.Text = "Zaterdag ";
                            break;
                        default:
                            break;
                    }
                    datum.Text += schedule.Date.Day.ToString() + " " + _months[schedule.Date.Month - 1] + " " + _currentyear;
                    TextBlock tijd = new TextBlock();
                    tijd.FontSize = 16;
                    tijd.TextAlignment = TextAlignment.Center;
                    tijd.Text = schedule.Starttime.ToString() + " - " + schedule.Endtime.ToString();
                    spDiensten.Children.Add(datum);
                    spDiensten.Children.Add(tijd);
                }
            }
        }
        private void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            new Create().Show();
        }

        public static int GetIso8601WeekOfYear(DateTime time)
        {
            DayOfWeek day = CultureInfo.InvariantCulture.Calendar.GetDayOfWeek(time);
            if (day >= DayOfWeek.Monday && day <= DayOfWeek.Wednesday)
            {
                time = time.AddDays(3);
            }
            return CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(time, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
        }
        private void btPreviousWeek_Click(object sender, RoutedEventArgs e)
        {
            if (_currentweek == 1)
            {
                _currentyear--;
                _currentweek = GetWeeksInYear(_currentyear);
            }
            else
            {
                _currentweek--;
            }
            PopulateSchedules();
        }
        private void btNextWeek_Click(object sender, RoutedEventArgs e)
        {
            if(_currentweek == GetWeeksInYear(_currentyear))
            {
                _currentyear++;
                _currentweek = 1;
            }
            else
            {
                _currentweek++;
            }
            PopulateSchedules();
        }
        private int GetWeeksInYear(int year)
        {
            DateTime lastDayOfYear = new DateTime(year, 12, 31);
            System.Globalization.CultureInfo ci = System.Globalization.CultureInfo.CurrentCulture;
            int weekNumber = ci.Calendar.GetWeekOfYear(lastDayOfYear, System.Globalization.CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);

            return weekNumber;
        }

        private void btnShowSchedules_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int year = Convert.ToInt32(tbxJaar.Text);
                int week = Convert.ToInt32(tbxWeek.Text);
                if (year <= 0 || year > 9999)
                {
                    MessageBox.Show("Het jaar moet tussen 0001 en 9999 liggen");
                    return;
                }
                if(week <= 0 || week > 53)
                {
                    MessageBox.Show("De week moet tussen 1 en 53 liggen");
                    return;
                }
                _currentyear = year;
                _currentweek = week;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
