﻿using Google.Type;
using Grpc.Core;
using SnelleWiel.Models;
using SnelleWiel.Services.API;
using SnelleWiel.Views.DeliveredInformation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SnelleWiel.Views.ScheduleAdmin
{
    /// <summary>
    /// Interaction logic for Create.xaml
    /// </summary>
    public partial class Create : Window
    {
        public Create()
        {
            InitializeComponent();
            PopulateSchedules();
        }
        private async void PopulateSchedules()
        {
            (List<Schedule> schedules, string methodResult) = await ScheduleService.GetSchedulesAsync();
            if (methodResult != "OK")
            {
                MessageBox.Show("Er ging iets mis met het ophalen van de orders. Neem contact op met de service desk. Bericht voor hun: \n" + methodResult);
                return;
            }
            dataGrid.ItemsSource = schedules;
        }

        private async void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(dpDate.SelectedDate == null)
                {
                    MessageBox.Show("Selecteer een datum!");
                    return;
                }
                if(!IsValidTime(tbStarttime.Text))
                {
                    MessageBox.Show("Je hebt geen correcte starttijd ingevuld. Vul deze bijvoorbeeld zo in: 12:30 (Gebruik een : en geen . of iets dergelijks!)");
                    return;
                }
                if(!IsValidTime(tbEndtime.Text))
                {
                    MessageBox.Show("Je hebt geen correcte eindtijd ingevuld. Vul deze bijvoorbeeld zo in: 12:30 (Gebruik een : en geen . of iets dergelijks!)");
                    return;
                }

                string[] splittedStarttime = tbStarttime.Text.Split(':');
                string[] splittedEndtime = tbEndtime.Text.Split(':');

                Schedule schedule = new Schedule();

                System.DateTime selectedDate = dpDate.SelectedDate!.Value;
                DateOnly dateOnly = DateOnly.FromDateTime(selectedDate);

                TimeOnly starttime = new TimeOnly(Convert.ToInt32(splittedStarttime[0]), Convert.ToInt32(splittedStarttime[1]));
                TimeOnly endtime = new TimeOnly(Convert.ToInt32(splittedEndtime[0]), Convert.ToInt32(splittedEndtime[1]));

                schedule.Date = dateOnly;
                schedule.Starttime = starttime;
                schedule.Endtime = endtime;

                (string objectjson, string response, string methodResult) = await ScheduleService.CreateScheduleAsync(schedule);
                if (response == "Created" && methodResult == "OK")
                {
                    MessageBox.Show("Creëren is gelukt!");
                    PopulateSchedules();
                }
                else
                {
                    MessageBox.Show("Er ging helaas iets mis\n" + methodResult);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Heb je ergens een verkeerde waarde ingevuld bij de tijden? Let op dat je de tijd zo intypt: HH:MM. Gebruik een : tussen de uren en minuten!");
                Console.WriteLine(ex.Message);
                return;
            }
        }
        private bool IsValidTime(string input)
        {
            // Check the format using a regex
            Regex timeRegex = new Regex(@"^([01]?[0-9]|2[0-3]):[0-5][0-9]$");
            if (!timeRegex.IsMatch(input))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        private async void Delete_Click(object sender, RoutedEventArgs e)
        {
            var selectedObject = dataGrid.SelectedItem as Schedule;
            int id = selectedObject!.Id;
            MessageBoxResult myresult = MessageBox.Show("Weet je zeker dat je deze dienst met id " + id + " wilt verwijderen?", "Dienst verwijderen",
                MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (myresult == MessageBoxResult.Yes)
            {
                (string statusCode, string methodResult) = await ScheduleService.DeleteScheduleAsync(id);
                if (statusCode != "OK")
                {
                    MessageBox.Show("Helaas ging er iets mis met het verwijderen. Neem contact op met de service desk");
                    return;
                }
                else
                {
                    MessageBox.Show("Verwijderen gelukt!");
                    PopulateSchedules();
                    return;
                }
            }
        }
    }
}
