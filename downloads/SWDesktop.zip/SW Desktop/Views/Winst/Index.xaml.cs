﻿using SnelleWiel.Services.API;
using SnelleWiel.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;

namespace SnelleWiel.Views.Winst
{
    /// <summary>
    /// Interaction logic for Index.xaml
    /// </summary>
    public partial class Index : Window
    {
        private readonly WinstService _winstService;
        private readonly ProfitViewModel _viewModel;
        public Index()
        {
            InitializeComponent();
            _winstService = new WinstService();
            _viewModel = new ProfitViewModel();
            DataContext = _viewModel;
        }

        private async void LoadDataButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("LoadDataButton_Click triggered"); // Debugging message
            await LoadData();
        }

        private async Task LoadData()
        {
            try
            {
                MessageBox.Show("Fetching data from API..."); // Debugging message
                var profits = await _winstService.GetProfitsAsync(_viewModel.StartDate, _viewModel.EndDate);
                MessageBox.Show($"API returned {profits.Count} records"); // Debugging message
                _viewModel.Profits.Clear();
                foreach (var profit in profits)
                {
                    _viewModel.Profits.Add(profit);
                }
                PlotData();
            }
            catch (HttpRequestException httpRequestException)
            {
                MessageBox.Show($"Request error: {httpRequestException.Message}");
            }
            catch (JsonException jsonException)
            {
                MessageBox.Show($"JSON deserialization error: {jsonException.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void PlotData()
        {
            var data = _viewModel.Profits;
            if (data != null && data.Count > 0)
            {
                double[] xData = data.Select((p, index) => (double)index).ToArray();
                double[] yData = data.Select(p => (double)p.Profit).ToArray();

                MessageBox.Show($"xData: {string.Join(", ", xData)}"); // Debugging message
                MessageBox.Show($"yData: {string.Join(", ", yData)}"); // Debugging message

                WpfPlot1.Plot.Clear();
                WpfPlot1.Plot.Add.Scatter(xData, yData);
                WpfPlot1.Plot.Title("Profits Over Time");
                WpfPlot1.Plot.XLabel("Time");
                WpfPlot1.Plot.YLabel("Profit");
                WpfPlot1.Refresh();

                MessageBox.Show("Data plotted successfully."); // Debugging message
            }
            else
            {
                MessageBox.Show("No data to display");
            }
        }


        private async void FilterDay_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("FilterDay_Click triggered"); // Debugging message
            _viewModel.FilterData("day");
            await LoadData();
        }

        private async void FilterWeek_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("FilterWeek_Click triggered"); // Debugging message
            _viewModel.FilterData("week");
            await LoadData();
        }

        private async void FilterMonth_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("FilterMonth_Click triggered"); // Debugging message
            _viewModel.FilterData("month");
            await LoadData();
        }

        private async void FilterYear_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("FilterYear_Click triggered"); // Debugging message
            _viewModel.FilterData("year");
            await LoadData();
        }
    }
}
