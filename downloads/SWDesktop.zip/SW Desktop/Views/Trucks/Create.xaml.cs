﻿using SnelleWiel.Models;
using SnelleWiel.Services.API;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SnelleWiel.Views.Trucks
{
    /// <summary>
    /// Interaction logic for Create.xaml
    /// </summary>
    public partial class Create : Window
    {
        public Create()
        {
            InitializeComponent();
        }

        private async void Create_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Retrieve height and width values from text boxes
                if (double.TryParse(txtHeight.Text, out double height) && double.TryParse(txtWidth.Text, out double weight))
                {
                    // Create new truck object
                    var newTruck = new Truck { Height = (int)height, Weight = (int)weight };

                    // Call backend service to create truck
                    //var createdTruck = await TrucksService.CreateTruckAsync(newTruck);

                    // Optionally, show success message or navigate to index page
                    MessageBox.Show("Truck created successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Please enter valid height and width values.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error creating truck: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
