﻿using Newtonsoft.Json;
using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows; // If using MessageBox for error display

namespace SnelleWiel.Services
{
    public class DocumentService
    {
        private readonly string saveFilePath = @"C:\SW Desktop\Resources\document.json";
        public ObservableCollection<Document> Documents { get; private set; } = new ObservableCollection<Document>();

        public DocumentService()
        {
            LoadDocuments();
        }

        public void AddDocument(string name, string path)
        {
            var document = new Document
            {
                Name = name,
                Path = path
            };
            Documents.Add(document);
            SaveDocuments();
        }

        public void DeleteDocument(Document document)
        {
            if (Documents.Contains(document))
            {
                Documents.Remove(document);
                SaveDocuments();
            }
        }

        public void LoadDocuments()
        {
            if (File.Exists(saveFilePath))
            {
                try
                {
                    var json = File.ReadAllText(saveFilePath);

                    // Ensure the JSON is in an array format before deserialization
                    if (!json.Trim().StartsWith("["))
                    {
                        // If JSON is not in array format, attempt to correct it or log the error
                        MessageBox.Show("The JSON data is not in the correct format. Please ensure it's an array.",
                                        "Invalid JSON Format",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Error);
                        return;
                    }

                    // Deserialize JSON into ObservableCollection<Document>
                    var documents = JsonConvert.DeserializeObject<ObservableCollection<Document>>(json);

                    if (documents != null)
                    {
                        Documents = documents;
                    }
                }
                catch (JsonSerializationException ex)
                {
                    // Handle deserialization errors with user feedback
                    MessageBox.Show($"Error deserializing JSON data: {ex.Message}",
                                    "Deserialization Error",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Error);
                }
                catch (Exception ex)
                {
                    // Catch any other exceptions
                    MessageBox.Show($"An error occurred while loading documents: {ex.Message}",
                                    "Error",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Error);
                }
            }
            else
            {
                // Create an empty JSON file if it doesn't exist
                SaveDocuments();
            }
        }

        public void SaveDocuments()
        {
            try
            {
                var json = JsonConvert.SerializeObject(Documents, Formatting.Indented);
                File.WriteAllText(saveFilePath, json);
            }
            catch (Exception ex)
            {
                // Handle any exceptions during the saving process
                MessageBox.Show($"An error occurred while saving documents: {ex.Message}",
                                "Save Error",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
            }
        }
    }

    public class Document
    {
        public string Name { get; set; }
        public string Path { get; set; }
    }
}
