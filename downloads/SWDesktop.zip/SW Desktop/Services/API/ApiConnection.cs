﻿namespace SnelleWiel.Services.API
{
    internal static class ApiConnection
    {
        internal static readonly string BaseUrl = "http://127.0.0.1:8000/api";
    }
}