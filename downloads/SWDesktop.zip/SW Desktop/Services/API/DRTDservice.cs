﻿using SnelleWiel.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Windows;

namespace SnelleWiel.Services.API
{
    internal class DRTDservice
    {
        private static readonly HttpClient client = new HttpClient();
        public static async Task<string> CreateDriverTruckAsync(int driverid, int truckid)
        {
            var response = await client.GetAsync($"{ApiConnection.BaseUrl}/driver/" + driverid + "/truck/" + truckid);
            response.EnsureSuccessStatusCode();
            return response.StatusCode.ToString();
        }
        public static async Task<string> DeleteDriverTruckAsync(int driverid)
        {
            var response = await client.DeleteAsync($"{ApiConnection.BaseUrl}/driver/deletetrucks/" + driverid);
            response.EnsureSuccessStatusCode();
            return response.StatusCode.ToString();
        }
    }
}
