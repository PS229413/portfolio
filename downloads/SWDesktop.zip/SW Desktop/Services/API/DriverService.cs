﻿using SnelleWiel.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using System.Windows;

namespace SnelleWiel.Services.API
{
    internal class DriverService
    {
        private static readonly HttpClient client = new HttpClient();

        public static async Task<(List<Driver>, string)> GetDriversAsync()
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.GetAsync($"{ApiConnection.BaseUrl}/drivers");
                response.EnsureSuccessStatusCode();
                methodResult = "OK";
                return (await response.Content.ReadFromJsonAsync<List<Driver>>(), methodResult);
            }
            catch ( Exception ex )
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(GetDriversAsync));
                Console.Error.WriteLine(ex.Message.ToString());
                return (null!, methodResult);
            }
        }
        
        public static async Task<(Driver, string, string)> GetDriverByIdAsync(int id)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.GetAsync($"{ApiConnection.BaseUrl}/drivers/{id}");
                response.EnsureSuccessStatusCode();
                var responseBody = await response.Content.ReadAsStringAsync();
                var obj = JsonNode.Parse(responseBody);
                methodResult = "OK";
                return (await response.Content.ReadFromJsonAsync<Driver>(), obj.ToJsonString(), methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(GetDriverByIdAsync));
                Console.Error.WriteLine(ex.Message.ToString());
                return (null!, null!, methodResult);
            }
        }

        public static async Task<(string, string, string)> CreateDriverAsync(Driver driver)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var json = $"{{\n    \"fullname\": \"{driver.Fullname}\",\n    \"email\": \"{driver.Email}\"," +
$"\n    \"phone\": \"{driver.Phone}\",\n    \"password\": \"{driver.Password}\", \n    \"role\": \"{driver.Role}\"\n}}";
                var response = await client.PostAsync($"{ApiConnection.BaseUrl}/drivers", new StringContent(json, Encoding.UTF8, "application/json")).ConfigureAwait(false);
                response.EnsureSuccessStatusCode();
                var responseBody = await response.Content.ReadAsStringAsync();
                var obj = JsonNode.Parse(responseBody);
                methodResult = "OK";
                return (obj.ToJsonString(), response.StatusCode.ToString(), methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(CreateDriverAsync));
                Console.Error.WriteLine(ex.Message.ToString());
                return (null!, null!, methodResult);
                throw;
            }
        }

        public static async Task<(string, string, string)> UpdateDriverAsync(int id, Driver driver)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var json = $"{{\n    \"fullname\": \"{driver.Fullname}\",\n    \"email\": \"{driver.Email}\"," +
$"\n    \"phone\": \"{driver.Phone}\",\n    \"password\": \"{driver.Password}\", \n    \"role\": \"{driver.Role}\"\n}}";
                var response = await client.PutAsync($"{ApiConnection.BaseUrl}/drivers/{id}", new StringContent(json, Encoding.UTF8, "application/json")).ConfigureAwait(false);
                response.EnsureSuccessStatusCode();
                var responseBody = await response.Content.ReadAsStringAsync();
                var obj = JsonNode.Parse(responseBody);
                methodResult = "OK";
                return (obj.ToJsonString(), response.StatusCode.ToString(), methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(UpdateDriverAsync));
                Console.Error.WriteLine(ex.Message.ToString());
                return (null!, null!, methodResult);
            }
        }

        public static async Task<(string, string)> DeleteDriverAsync(int id)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.DeleteAsync($"{ApiConnection.BaseUrl}/drivers/{id}");
                response.EnsureSuccessStatusCode();
                methodResult = "OK";
                return (response.StatusCode.ToString(), methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(DeleteDriverAsync));
                Console.Error.WriteLine(ex.Message.ToString());
                return (null!, methodResult);
            }
        }
    }
}
