﻿using SnelleWiel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows;
using Newtonsoft.Json;


namespace SnelleWiel.Services.API
{
    internal class Auth
    {
        private static readonly HttpClient client = new HttpClient();
        public static async Task<(Driver, string)> LoginAsync(string email, string password)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.PostAsJsonAsync($"{ApiConnection.BaseUrl}/login", new { email, password });
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    methodResult = "Login failed";
                    return (null!, methodResult);
                }
                response.EnsureSuccessStatusCode();

                string responseBody = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<dynamic>(responseBody);
                var information = result!.driver;

                Driver driver = new Driver();
                driver.Id = information.id;
                driver.Fullname = information.fullname;
                driver.Email = information.email;
                driver.Phone = information.phone;
                driver.Role = information.role;

                methodResult = "OK";

                return (driver, methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(LoginAsync));
                Console.Error.WriteLine(ex.Message);
                return (null!, methodResult);
            }
        }
    }

}
