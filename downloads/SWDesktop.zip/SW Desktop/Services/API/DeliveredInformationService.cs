﻿using SnelleWiel.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Windows;

namespace SnelleWiel.Services.API
{
    internal class DeliveredInformationService
    {
        private static readonly HttpClient client = new HttpClient();

        public static async Task<(List<DeliveredInfo>, string)> GetDeliveredInformationAsync()
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.GetAsync($"{ApiConnection.BaseUrl}/deliveredinformation");
                response.EnsureSuccessStatusCode();
                methodResult = "OK";
                return (await response.Content.ReadFromJsonAsync<List<DeliveredInfo>>(), methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(GetDeliveredInformationAsync));
                Console.WriteLine(ex.Message.ToString());
                return (null!, methodResult);
            }
        }

        public static async Task<(DeliveredInfo, string)> GetDeliveredInformationByIdAsync(int id)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.GetAsync($"{ApiConnection.BaseUrl}/deliveredinformation/{id}");
                response.EnsureSuccessStatusCode();
                methodResult = "OK";
                return (await response.Content.ReadFromJsonAsync<DeliveredInfo>(), methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(GetDeliveredInformationByIdAsync));
                Console.WriteLine(ex.Message.ToString());
                return (null!, methodResult);
            }
        }

        public static async Task<(DeliveredInfo, string, string)> CreateDeliveredInformationAsync(DeliveredInfo deliveredInformation)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.PostAsJsonAsync($"{ApiConnection.BaseUrl}/deliveredinformation", deliveredInformation);
                response.EnsureSuccessStatusCode();
                var deliveredInfo = await response.Content.ReadFromJsonAsync<DeliveredInfo>();
                methodResult = "OK";
                return (deliveredInfo, response.StatusCode.ToString(), methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(CreateDeliveredInformationAsync));
                Console.WriteLine(ex.Message.ToString());
                return (null!, null!, methodResult);
            }
        }


        public static async Task<(DeliveredInfo, string, string)> UpdateDeliveredInformationAsync(int id, DeliveredInfo updatedDeliveredInformation)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.PutAsJsonAsync($"{ApiConnection.BaseUrl}/deliveredinformation/{id}", updatedDeliveredInformation);
                response.EnsureSuccessStatusCode();
                methodResult = "OK";
                return (await response.Content.ReadFromJsonAsync<DeliveredInfo>(), response.StatusCode.ToString(), methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(UpdateDeliveredInformationAsync));
                Console.WriteLine(ex.Message.ToString());
                return (null!, null!, methodResult);
            }
        }
        public static async Task<string> DeleteDeliveredInformationAsync(int id)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.DeleteAsync($"{ApiConnection.BaseUrl}/deliveredinformation/{id}");
                response.EnsureSuccessStatusCode();
                methodResult = "OK";
                return response.StatusCode.ToString();
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(DeleteDeliveredInformationAsync));
                Console.WriteLine(ex.Message.ToString());
                return null!;
            }
        }
    }
}
