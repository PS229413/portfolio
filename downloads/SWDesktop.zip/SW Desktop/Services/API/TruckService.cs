﻿using SnelleWiel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace SnelleWiel.Services.API
{
    class TruckService
    {
        private static readonly HttpClient client = new HttpClient();

        public static async Task<List<Truck>> GetTrucksAsync()
        {
            var response = await client.GetAsync($"{ApiConnection.BaseUrl}/trucks");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<Truck>>();
        }

        public static async Task<Truck> GetTruckByIdAsync(int id)
        {
            var response = await client.GetAsync($"{ApiConnection.BaseUrl}/trucks/{id}");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<Truck>();
        }

        public static async Task<Truck> CreateTruckAsync(Truck truck)
        {
            var response = await client.PostAsJsonAsync($"{ApiConnection.BaseUrl}/trucks", truck);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<Truck>();
        }

        public static async Task<Truck> UpdateTruckAsync(int id, Truck updatedTruck)
        {
            var response = await client.PutAsJsonAsync($"{ApiConnection.BaseUrl}/trucks/{id}", updatedTruck);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<Truck>();
        }

        public static async Task DeleteTruckAsync(int id)
        {
            var response = await client.DeleteAsync($"{ApiConnection.BaseUrl}/trucks/{id}");
            response.EnsureSuccessStatusCode();
        }
    }
}
