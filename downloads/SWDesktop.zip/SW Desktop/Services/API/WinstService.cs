﻿using System.Threading.Tasks;
using Newtonsoft.Json;
using SnelleWiel.Models;
using System.Windows;
using System.Net.Http;

namespace SnelleWiel.Services.API
{
    public class WinstService
    {
        private static readonly HttpClient client = new HttpClient();

        public async Task<List<ProfitData>> GetProfitsAsync(DateTime startDate, DateTime endDate)
        {
            string url = $"http://localhost:8001/api/profits?start_date={startDate:yyyy-MM-dd}&end_date={endDate:yyyy-MM-dd}";
            MessageBox.Show($"Requesting URL: {url}"); // Debugging message

            try
            {
                var response = await client.GetAsync(url);
                MessageBox.Show("Received response"); // Debugging message

                response.EnsureSuccessStatusCode(); // Throws an exception if the status code is not 2xx

                var jsonResponse = await response.Content.ReadAsStringAsync();
                MessageBox.Show($"Response JSON: {jsonResponse}"); // Debugging message

                var profitDataList = JsonConvert.DeserializeObject<List<ProfitData>>(jsonResponse);
                MessageBox.Show($"Deserialized {profitDataList.Count} items"); // Debugging message

                return profitDataList;
            }
            catch (HttpRequestException httpRequestException)
            {
                MessageBox.Show($"Request error: {httpRequestException.Message}");
                throw new Exception($"Request error: {httpRequestException.Message}");
            }
            catch (JsonException jsonException)
            {
                MessageBox.Show($"JSON deserialization error: {jsonException.Message}");
                throw new Exception($"JSON deserialization error: {jsonException.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
                throw new Exception($"An error occurred: {ex.Message}");
            }
        }
    }
}
