﻿using SnelleWiel.Models;
using SnelleWiel.Views.DeliveredInformation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace SnelleWiel.Services.API
{
    internal class ScheduleService
    {
        private static readonly HttpClient client = new HttpClient();
        public static async Task<(List<Schedule>, string)> GetSchedulesAsync()
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.GetAsync($"{ApiConnection.BaseUrl}/schedules");
                response.EnsureSuccessStatusCode();
                methodResult = "OK";
                return (await response.Content.ReadFromJsonAsync<List<Schedule>>(), methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(GetSchedulesAsync));
                Console.Error.WriteLine(ex.Message.ToString());
                return (null!, methodResult);
            }
        }
        public static async Task<(Driver, string, string)> GetScheduleByIdAsync(int id)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.GetAsync($"{ApiConnection.BaseUrl}/schedules/{id}");
                response.EnsureSuccessStatusCode();
                var responseBody = await response.Content.ReadAsStringAsync();
                var obj = JsonNode.Parse(responseBody);
                methodResult = "OK";
                return (await response.Content.ReadFromJsonAsync<Driver>(), obj.ToJsonString(), methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(GetScheduleByIdAsync));
                Console.Error.WriteLine(ex.Message.ToString());
                return (null!, null!, methodResult);
            }
        }
        public static async Task<(List<Schedule>, string)> GetSchedulesByDriverAsync(int id)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.GetAsync($"{ApiConnection.BaseUrl}/schedules/getbydriver/{id}");
                response.EnsureSuccessStatusCode();
                methodResult = "OK";
                return (await response.Content.ReadFromJsonAsync<List<Schedule>>(), methodResult);
            }
            catch(Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(GetSchedulesByDriverAsync));
                Console.Error.WriteLine(ex.Message.ToString());
                return (null!, methodResult);
            }
        }
        public static async Task<(string, string, string)> CreateScheduleAsync(Schedule schedule)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.PostAsJsonAsync($"{ApiConnection.BaseUrl}/schedules", schedule);
                response.EnsureSuccessStatusCode();
                var responseBody = await response.Content.ReadAsStringAsync();
                var obj = JsonNode.Parse(responseBody);
                methodResult = "OK";
                return (obj.ToJsonString(), response.StatusCode.ToString(), methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(CreateScheduleAsync));
                Console.Error.WriteLine(ex.Message.ToString());
                return (null!, null!, methodResult);
                throw;
            }
        }
        public static async Task<(string, string, string)> UpdateScheduleAsync(int id, Schedule schedule)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.PutAsJsonAsync($"{ApiConnection.BaseUrl}/schedules/{id}", schedule);
                response.EnsureSuccessStatusCode();
                var responseBody = await response.Content.ReadAsStringAsync();
                var obj = JsonNode.Parse(responseBody);
                methodResult = "OK";
                return (obj.ToJsonString(), response.StatusCode.ToString(), methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(UpdateScheduleAsync));
                Console.Error.WriteLine(ex.Message.ToString());
                return (null!, null!, methodResult);
                throw;
            }
        }
        public static async Task<(string, string)> DeleteScheduleAsync(int id)
        {
            string methodResult = "UNKNOWN";
            try
            {
                var response = await client.DeleteAsync($"{ApiConnection.BaseUrl}/schedules/{id}");
                response.EnsureSuccessStatusCode();
                methodResult = "OK";
                return (response.StatusCode.ToString(), methodResult);
            }
            catch (Exception ex)
            {
                methodResult = ex.Message;
                Console.Error.WriteLine(nameof(DeleteScheduleAsync));
                Console.Error.WriteLine(ex.Message.ToString());
                return (null!, methodResult);
            }
        }
    }
}
