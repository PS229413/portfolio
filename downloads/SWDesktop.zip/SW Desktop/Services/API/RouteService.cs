﻿using SnelleWiel.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using System.Windows;


namespace SnelleWiel.Services.API
{
    internal class RouteService
    {
        private static readonly HttpClient client = new HttpClient();
        public static async Task<List<Routes>> GetRoutesAsync()
        {
            var response = await client.GetAsync($"{ApiConnection.BaseUrl}/routes");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<Routes>>();
        }

        public static async Task<Routes> CreateRouteAsync(Routes newRoute)
        {
            var response = await client.PostAsJsonAsync($"{ApiConnection.BaseUrl}/routes", newRoute);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<Routes>();
        }

        public static async Task<Routes> UpdateRouteAsync(int routeId, Routes updatedRoute)
        {
            var response = await client.PutAsJsonAsync($"{ApiConnection.BaseUrl}/routes/{routeId}", updatedRoute);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<Routes>();
        }

        public static async Task DeleteRouteAsync(int routeId)
        {
            var response = await client.DeleteAsync($"{ApiConnection.BaseUrl}/routes/{routeId}");
            response.EnsureSuccessStatusCode();
        }
    }
}
