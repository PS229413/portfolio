﻿using AutoMapper;
using HetFietsenStationAPI;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPITests
{
    public class TestBase
    {
        internal MapperConfiguration mockAutoMapper;
        internal IMapper autoMapper;
        internal DbContextOptions<DataContext> options;
        internal DataContext MockContext;

        [SetUp]
        public void Setup()
        {
            mockAutoMapper = new MapperConfiguration(config =>
            {
                config.AddProfile(new AutoMapperProfile());
            });
            autoMapper = mockAutoMapper.CreateMapper();

            options = new DbContextOptionsBuilder<DataContext>()
                .UseInMemoryDatabase(databaseName: "MockDatabase")
                .Options;

            MockContext = new DataContext(options);

            MockContext.SideProducts.AddRange(
                new SideProduct { Id = 1, Name = "SideProduct 1", Description = "Test data", Stock = 1, Price = 10 },
                new SideProduct { Id = 2, Name = "SideProduct 2", Description = "Test data", Stock = 1, Price = 10 },
                new SideProduct { Id = 3, Name = "SideProduct 3", Description = "Test data", Stock = 1, Price = 10 }
            );

            MockContext.RepairSteps.AddRange(
                new RepairStep { Id = 1, Name = "RepairStep 1", Description = "Test data", required = true },
                new RepairStep { Id = 2, Name = "RepairStep 2", Description = "Test data", required = true },
                new RepairStep { Id = 3, Name = "RepairStep 3", Description = "Test data", required = false }
            );
            MockContext.Bikes.AddRange(
                new Bike { Id = 1, Brand = "Brand 1", Model = "M1", Note = "Note", FrameHeight = 100, FrameNumber = 1, Price = 100, RepairDate = DateTime.Today, RegistrationDate = DateTime.Today, BikeColorId = 1, BikeConditionId = 1, BikeSourceId = 1, BikeStatusId = 1, BikeTypeId = 1 },
                new Bike { Id = 2, Brand = "Brand 2", Model = "M1", Note = "Note", FrameHeight = 100, FrameNumber = 1, Price = 100, RepairDate = DateTime.Today, RegistrationDate = DateTime.Today, BikeColorId = 1, BikeConditionId = 1, BikeSourceId = 1, BikeStatusId = 1, BikeTypeId = 1 },
                new Bike { Id = 3, Brand = "Brand 3", Model = "M1", Note = "Note", FrameHeight = 100, FrameNumber = 1, Price = 100, RepairDate = DateTime.Today, RegistrationDate = DateTime.Today, BikeColorId = 1, BikeConditionId = 1, BikeSourceId = 1, BikeStatusId = 1, BikeTypeId = 1 },
                new Bike { Id = 4, Brand = "Brand 4", Model = "M1", Note = "Note", FrameHeight = 100, FrameNumber = 1, Price = 100, RepairDate = DateTime.Today, RegistrationDate = DateTime.Today, BikeColorId = 1, BikeConditionId = 1, BikeSourceId = 1, BikeStatusId = 3, BikeTypeId = 1 }
            );

            MockContext.BikeColors.AddRange(
                new BikeColor { Id = 1, Name = "BikeColor 1", Description = "Test data" },
                new BikeColor { Id = 2, Name = "BikeColor 2", Description = "Test data" },
                new BikeColor { Id = 3, Name = "BikeColor 3", Description = "Test data" }
            );

            MockContext.BikeConditions.AddRange(
                new BikeCondition { Id = 1, Name = "BikeCondition 1", Description = "Test data" },
                new BikeCondition { Id = 2, Name = "BikeCondition 2", Description = "Test data" },
                new BikeCondition { Id = 3, Name = "BikeCondition 3", Description = "Test data" }
            );

            MockContext.BikeSources.AddRange(
                new BikeSource { Id = 1, Name = "BikeSource 1", Description = "Test data" },
                new BikeSource { Id = 2, Name = "BikeSource 2", Description = "Test data" },
                new BikeSource { Id = 3, Name = "BikeSource 3", Description = "Test data" }
            );

            MockContext.BikeStatuses.AddRange(
                new BikeStatus { Id = 1, Name = "BikeStatus 1", Description = "Test data" },
                new BikeStatus { Id = 2, Name = "BikeStatus 2", Description = "Test data" },
                new BikeStatus { Id = 3, Name = "BikeStatus 3", Description = "Test data" }
            );

            MockContext.BikeTypes.AddRange(
                new BikeType { Id = 1, Name = "BikeType 1", Description = "Test data" },
                new BikeType { Id = 2, Name = "BikeType 2", Description = "Test data" },
                new BikeType { Id = 3, Name = "BikeType 3", Description = "Test data" }
            );

            MockContext.BikeRepairSteps.AddRange(
                new BikeRepairStep { BikeId = 1, RepairStepId = 1, Done = true },
                new BikeRepairStep { BikeId = 1, RepairStepId = 2, Done = true },
                new BikeRepairStep { BikeId = 2, RepairStepId = 1, Done = false }
            );

            MockContext.Users.AddRange(
                new User { Id = 1, Name = "User 1", Password = new byte[0], UserRoleId = 1 },
                new User { Id = 2, Name = "User 2", Password = new byte[0], UserRoleId = 1 },
                new User { Id = 3, Name = "User 3", Password = new byte[0], UserRoleId = 2 }
            );

            MockContext.UserRoles.AddRange(
                new UserRole { Id = 1, Name = "Admin", Description = "Test data" },
                new UserRole { Id = 2, Name = "Mechanic", Description = "Test data" }
            );

            MockContext.SaveChanges();
        }

        [TearDown]
        public void TearDown()
        {
            using (var context = new DataContext(options))
            {
                context.Database.EnsureDeleted();
            }
        }
    }
}
