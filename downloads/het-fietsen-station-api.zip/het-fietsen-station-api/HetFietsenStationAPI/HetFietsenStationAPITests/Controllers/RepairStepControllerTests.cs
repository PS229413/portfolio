﻿using HetFietsenStationAPI.Controllers;
using HetFietsenStationAPI.Services.RepairStep;
using Microsoft.AspNetCore.Mvc;

namespace HetFietsenStationAPITests.Controllers
{
    public class RepairStepControllerTests : TestBase
    {
        private readonly IRepairStepService _repairStepService;
        public RepairStepControllerTests()
        {
            _repairStepService = new RepairStepMockService();
        }

        [Test]
        public async Task GetAllRepairStepsFromBike_Should_Return_Status_Code_200()
        {
            //Arrange
            var controller = new RepairStepController(_repairStepService);
            
            //Act
            var output = await controller.GetAllRepairStepsFromBike(1);
            var okResult = output.Result as OkObjectResult;
            
            //Assert
            Assert.That(okResult, Is.Not.Null);
            Assert.That(okResult?.StatusCode, Is.EqualTo(200));
        }

        [Test]
        public async Task GetAllRepairStepsFromBike_Should_Return_Status_Code_404()
        {
            //Arrange
            var controller = new RepairStepController(_repairStepService);
            
            //Act
            var output = await controller.GetAllRepairStepsFromBike(3);
            var notFoundResult = output.Result as NotFoundObjectResult;
            
            //Assert
            Assert.That(notFoundResult, Is.Not.Null);
            Assert.That(notFoundResult?.StatusCode, Is.EqualTo(404));
        }
    }
}
