﻿using HetFietsenStationAPI.Controllers;
using HetFietsenStationAPI.Services.BikeColor;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace HetFietsenStationAPITests.Controllers
{
    public class BikeColorControllerTests : TestBase
    {
        private readonly IBikeColorService _bikeColorService;
        public BikeColorControllerTests()
        {
            _bikeColorService = new BikeColorMockService();
        }

        [Test]
        public async Task GetAllBikeColors_Should_Return_Status_Code_200()
        {
            //Arrange
            var controller = new BikeColorController(_bikeColorService);
            
            //Act
            var output = await controller.GetAllBikeColors();
            var okResult = output.Result as OkObjectResult;
            
            //Assert
            Assert.That(okResult, Is.Not.Null);
            Assert.That(okResult?.StatusCode, Is.EqualTo(200));
        }

        [Test]
        public async Task GetAllBikeColors_Should_Return_Status_Code_404()
        {
            //Arrange
            var bikeColorServiceMock = new Mock<IBikeColorService>();
            bikeColorServiceMock.Setup(x => x.GetAllBikeColors()).ThrowsAsync(new Exception("Not found"));
            var controller = new BikeColorController(bikeColorServiceMock.Object);
            
            //Act
            var output = await controller.GetAllBikeColors();
            var notFoundResult = output.Result as NotFoundObjectResult;
            
            //Assert
            Assert.That(notFoundResult, Is.Not.Null);
            Assert.That(notFoundResult?.StatusCode, Is.EqualTo(404));
        }
    }
}
