﻿using HetFietsenStationAPI.Controllers;
using HetFietsenStationAPI.Services.BikeSource;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace HetFietsenStationAPITests.Controllers
{
    public class BikeSourceControllerTests : TestBase
    {
        private readonly IBikeSourceService _bikeSourceService;

        public BikeSourceControllerTests()
        {
            _bikeSourceService = new BikeSourceMockService();
        }

        [Test]
        public async Task GetAllBikeSources_Should_Return_Status_Code_200()
        {
            //Arrange
            var controller = new BikeSourceController(_bikeSourceService);
            
            //Act
            var output = await controller.GetAllBikeSources();
            var okResult = output.Result as OkObjectResult;
            
            //Assert
            Assert.That(okResult, Is.Not.Null);
            Assert.That(okResult?.StatusCode, Is.EqualTo(200));
        }

        [Test]
        public async Task GetAllBikeSources_Should_Return_Status_Code_404()
        {
            //Arrange
            var bikeSourceServiceMock = new Mock<IBikeSourceService>();
            bikeSourceServiceMock.Setup(x => x.GetAllBikeSources()).ThrowsAsync(new Exception("Not found"));
            var controller = new BikeSourceController(bikeSourceServiceMock.Object);
            
            //Act
            var output = await controller.GetAllBikeSources();
            var notFoundResult = output.Result as NotFoundObjectResult;
            
            //Assert
            Assert.That(notFoundResult, Is.Not.Null);
            Assert.That(notFoundResult?.StatusCode, Is.EqualTo(404));
        }
    }
}
