using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.SideProduct;
using HetFietsenStationAPI.Services.SideProduct;
using HetFietsenStationAPI.Services;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using HetFietsenStationAPI;

namespace HetFietsenStationAPITests.Controllers
{
    internal class SideProductControllerTests : TestBase
    {
        [Test]
        public void GetAllSideProducts_Should_Get_All_Side_Products()
        {
            using (var context = new DataContext(options))
            {
                SideProductService sideProductService = new SideProductService(autoMapper, context);
                Task<ServiceResponse<List<GetSideProductDto>>> sideProducts = sideProductService.GetAllSideProducts();

                Assert.That(sideProducts?.Result?.Data?.Count, Is.EqualTo(3));
            }
        }

        [Test]
        public void GetSideProduct_Should_Get_Single_Side_Product()
        {
            using (var context = new DataContext(options))
            {
                SideProductService sideProductService = new SideProductService(autoMapper, context);
                Task<ServiceResponse<GetSideProductDto>> sideProduct = sideProductService.GetSingleSideProduct(1);

                Assert.That(sideProduct?.Result?.Data?.Id, Is.EqualTo(1));
            }
        }

        [Test]
        public async Task AddSideProduct_Should_Add_Side_Product()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<DataContext>()
                .UseInMemoryDatabase(databaseName: "AddSideProductTestDb")
                .Options;
            using (var context = new DataContext(options))
            {
                var mapperConfig = new MapperConfiguration(cfg => cfg.AddProfile(new AutoMapperProfile()));
                var mapper = mapperConfig.CreateMapper();
                var sideProductService = new SideProductService(mapper, context);

                var request = new AddSideProductDto
                {
                    Name = "Test Side Product",
                    Description = "Test Description",
                    Price = 10,
                    Stock = 5,
                    SideProductTypeId = 1
                };

                // Act
                var response = await sideProductService.AddSideProduct(request);

                // Assert
                Assert.Multiple(() =>
                {
                    Assert.That(response.Success, Is.True);
                    Assert.That(response.Message, Is.EqualTo(string.Empty));
                    Assert.That(response.Data, Is.Not.Null);
                    Assert.That(response?.Data?.Name, Is.EqualTo(request.Name));
                    Assert.That(response?.Data?.Description, Is.EqualTo(request.Description));
                    Assert.That(response?.Data?.Price, Is.EqualTo(request.Price));
                    Assert.That(response?.Data?.Stock, Is.EqualTo(request.Stock));
                    Assert.That(response?.Data?.SideProductTypeId, Is.EqualTo(request.SideProductTypeId));
                });
            }
        }

        [Test]
        public async Task DeleteSideProduct_Should_Delete_Side_Product()
        {
            using var context = new DataContext(options);
            SideProductService sideProductService = new SideProductService(autoMapper, context);
            await sideProductService.DeleteSideProduct(1);
            Task<ServiceResponse<List<GetSideProductDto>>> sideProducts = sideProductService.GetAllSideProducts();

            Assert.That(sideProducts?.Result?.Data?.Count, Is.EqualTo(2));
        }

        [Test]
        public async Task UpdateSideProduct_Should_Update_Side_Product()
        {
            using var context = new DataContext(options);
            SideProductService sideProductService = new(autoMapper, context);
            await sideProductService.UpdateSideProduct(new UpdateSideProductDto { Id = 1, Name = "SideProduct 1", Description = "Test data", Stock = 1, Price = 15 });
            Task<ServiceResponse<GetSideProductDto>> sideProduct = sideProductService.GetSingleSideProduct(1);

            Assert.That(sideProduct?.Result?.Data?.Price, Is.EqualTo(15));
        }
    }
}