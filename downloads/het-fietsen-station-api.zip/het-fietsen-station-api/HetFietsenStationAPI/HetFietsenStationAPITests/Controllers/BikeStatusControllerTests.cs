﻿using HetFietsenStationAPI.Controllers;
using HetFietsenStationAPI.Services.BikeStatus;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace HetFietsenStationAPITests.Controllers
{
    public class BikeStatusControllerTests : TestBase
    {
        private readonly IBikeStatusService _bikeStatusService;

        public BikeStatusControllerTests()
        {
            _bikeStatusService = new BikeStatusMockService();
        }

        [Test]
        public async Task GetAllBikeStatus_Should_Return_Status_Code_200()
        {
            //Arrange
            var controller = new BikeStatusController(_bikeStatusService);
            
            //Act
            var output = await controller.GetAllBikeStatus();
            var okResult = output.Result as OkObjectResult;
            
            //Assert
            Assert.That(okResult, Is.Not.Null);
            Assert.That(okResult?.StatusCode, Is.EqualTo(200));
        }

        [Test]
        public async Task GetAllBikeStatus_Should_Return_Status_Code_404()
        {
            //Arrange
            var bikeStatusServiceMock = new Mock<IBikeStatusService>();
            bikeStatusServiceMock.Setup(x => x.GetAllBikeStatus()).ThrowsAsync(new Exception("Not found"));
            var controller = new BikeStatusController(bikeStatusServiceMock.Object);
            
            //Act
            var output = await controller.GetAllBikeStatus();
            var notFoundResult = output.Result as NotFoundObjectResult;
            
            //Assert
            Assert.That(notFoundResult, Is.Not.Null);
            Assert.That(notFoundResult?.StatusCode, Is.EqualTo(404));
        }
    }
}
