﻿using HetFietsenStationAPI.Controllers;
using HetFietsenStationAPI.Services.BikeType;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace HetFietsenStationAPITests.Controllers
{
    public class BikeTypeControllerTests : TestBase
    {
        private readonly IBikeTypeService _bikeTypeService;

        public BikeTypeControllerTests()
        {
            _bikeTypeService = new BikeTypeMockService();
        }

        [Test]
        public async Task GetAllBikeTypes_Should_Return_Status_Code_200()
        {
            //Arrange
            var controller = new BikeTypeController(_bikeTypeService);
            
            //Act
            var output = await controller.GetAllBikeTypes();
            var okResult = output.Result as OkObjectResult;
            
            //Assert
            Assert.That(okResult, Is.Not.Null);
            Assert.That(okResult?.StatusCode, Is.EqualTo(200));
        }

        [Test]
        public async Task GetAllBikeTypes_Should_Return_Status_Code_404()
        {
            //Arrange
            var bikeTypeServiceMock = new Mock<IBikeTypeService>();
            bikeTypeServiceMock.Setup(x => x.GetAllBikeTypes()).ThrowsAsync(new Exception("Not found"));
            var controller = new BikeTypeController(bikeTypeServiceMock.Object);
            
            //Act
            var output = await controller.GetAllBikeTypes();
            var notFoundResult = output.Result as NotFoundObjectResult;
            
            //Assert
            Assert.That(notFoundResult, Is.Not.Null);
            Assert.That(notFoundResult?.StatusCode, Is.EqualTo(404));
        }
    }
}
