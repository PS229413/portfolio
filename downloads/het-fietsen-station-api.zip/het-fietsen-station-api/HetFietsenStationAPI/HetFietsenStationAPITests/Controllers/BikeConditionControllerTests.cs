﻿using HetFietsenStationAPI.Controllers;
using HetFietsenStationAPI.Services.BikeCondition;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace HetFietsenStationAPITests.Controllers
{
    public class BikeConditionControllerTests : TestBase
    {
        private readonly IBikeConditionService _bikeConditionService;

        public BikeConditionControllerTests()
        {
            _bikeConditionService = new BikeConditionMockService();
        }

        [Test]
        public async Task GetAllBikeConditions_Should_Return_Status_Code_200()
        {
            //Arrange
            BikeConditionController controller = new(_bikeConditionService);
            //Act
            var output = await controller.GetAllBikeConditions();
            var okResult = output.Result as OkObjectResult;
            //Assert
            Assert.NotNull(okResult);
            Assert.That(okResult.StatusCode, Is.EqualTo(200));
        }

        [Test]
        public async Task GetAllBikeConditions_Should_Return_Status_Code_404()
        {
            //Arrange
            var bikeConditionServiceMock = new Mock<IBikeConditionService>();
            bikeConditionServiceMock.Setup(x => x.GetAllBikeConditions()).ThrowsAsync(new Exception("Not found"));
            var controller = new BikeConditionController(bikeConditionServiceMock.Object);
            
            //Act
            var output = await controller.GetAllBikeConditions();
            var notFoundResult = output.Result as NotFoundObjectResult;
            
            //Assert
            Assert.That(notFoundResult, Is.Not.Null);
            Assert.That(notFoundResult?.StatusCode, Is.EqualTo(404));
        }
    }
}
