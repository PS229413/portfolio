﻿using HetFietsenStationAPI.Controllers;
using HetFietsenStationAPI.Dtos.Bike;
using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.Bike;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace HetFietsenStationAPITests.Controllers
{
    public class BikeControllerTests : TestBase
    {
        private readonly IBikeService _bikeService;
        public BikeControllerTests()
        {
            _bikeService = new BikeMockService();
        }

        [Test]
        public async Task GetAllBikes_Should_Return_Status_Code_200()
        {
            //Arrange
            BikeController controller = new BikeController(_bikeService, null);
            //Act
            var output = await controller.GetAllBikes();
            var okResult = output.Result as OkObjectResult;
            //Assert
            Assert.NotNull(okResult);
            Assert.That(okResult.StatusCode, Is.EqualTo(200));
        }

        [Test]
        public async Task GetAllBikes_Should_Return_Status_Code_404()
        {
            //Arrange
            var mockService = new Mock<IBikeService>();
            mockService.Setup(service => service.GetAllBikes()).ReturnsAsync(new ServiceResponse<List<GetBikeDto>> { Success = false });
            BikeController controller = new BikeController(mockService.Object, null);

            //Act
            var output = await controller.GetAllBikes();
            var notFoundResult = output.Result as NotFoundObjectResult;

            //Assert
            Assert.NotNull(notFoundResult);
            Assert.That(notFoundResult.StatusCode, Is.EqualTo(404));
        }
    }
}
