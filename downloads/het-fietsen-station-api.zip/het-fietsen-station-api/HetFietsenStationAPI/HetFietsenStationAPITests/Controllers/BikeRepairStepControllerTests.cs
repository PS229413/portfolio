﻿using HetFietsenStationAPI.Controllers;
using HetFietsenStationAPI.Dtos.BikeRepairStep;
using HetFietsenStationAPI.Services.BikeRepairStep;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace HetFietsenStationAPITests.Controllers
{
    public class BikeRepairStepControllerTests
    {
        private readonly IBikeRepairStepService _bikeBikeRepairStepService;

        public BikeRepairStepControllerTests()
        {
            _bikeBikeRepairStepService = new BikeRepairStepMockService();
        }

        [Test]
        public async Task GetAllBikeRepairSteps_Should_Return_Status_Code_200()
        {
            //Arrange
            var controller = new BikeRepairStepController(_bikeBikeRepairStepService);
            var data = new UpdateBikeRepairStepDto()
            {
                BikeId = 1,
                RepairStepId = 1,
                Done = true
            };
            //Act
            var output = await controller.UpdateBikeRepairStep(data);
            var okResult = output.Result as OkObjectResult;
            //Assert
            Assert.That(okResult, Is.Not.Null);
            Assert.That(okResult?.StatusCode, Is.EqualTo(200));
        }

        [Test]
        public async Task GetAllBikeRepairSteps_Should_Return_Status_Code_404()
        {
            //Arrange
            var bikeRepairStepServiceMock = new Mock<IBikeRepairStepService>();
            bikeRepairStepServiceMock.Setup(x => x.UpdateBikeRepairStep(null)).ThrowsAsync(new Exception("Not found"));
            var controller = new BikeRepairStepController(bikeRepairStepServiceMock.Object);
            
            //Act
            var output = await controller.UpdateBikeRepairStep(null);
            var notFoundResult = output.Result as NotFoundObjectResult;
            
            //Assert
            Assert.That(notFoundResult, Is.Not.Null);
            Assert.That(notFoundResult?.StatusCode, Is.EqualTo(404));
        }
    }
}
