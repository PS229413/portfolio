﻿using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.BikeType;
using HetFietsenStationAPI.Dtos.BikeType;

namespace HetFietsenStationAPITests.Services
{
    public class BikeTypeServiceTests : TestBase
    {

        [Test]
        public void GetAllBikeTypes_Should_Return_All_Bike_Types()
        {
            //Arrange
            BikeTypeService bikeTypeService = new(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<List<GetBikeTypeDto>>> bikeTypes = bikeTypeService.GetAllBikeTypes();
            //Assert
            Assert.That(bikeTypes?.Result?.Data?.Count, Is.EqualTo(3));
        }

        [Test]
        public void GetAllBikeTypes_Should_Return_Null_When_Error_Is_Given()
        {
            //Arrange
            BikeTypeService bikeTypeService = new(autoMapper, null);
            //Act
            Task<ServiceResponse<List<GetBikeTypeDto>>> bikeTypes = bikeTypeService.GetAllBikeTypes();
            //Assert
            Assert.That(bikeTypes.Result.Data, Is.EqualTo(null));
        }
    }
}
