﻿using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.User;
using HetFietsenStationAPI.Dtos.User;

namespace HetFietsenStationAPITests.Services
{
    public class UserServiceTests : TestBase
    {

        [Test]
        public void GetAllUsers_Should_Return_All_Users()
        {
            //Arrange
            UserService userService = new UserService(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<List<GetUserDto>>> users = userService.GetAllUsers();
            //Assert
            Assert.That(users.Result.Data, Has.Count.EqualTo(3));
        }

        [Test]
        public void GetAllUsers_Should_Return_Null_When_Error_Is_Given()
        {
            //Arrange
            UserService userService = new UserService(autoMapper, null);
            //Act
            Task<ServiceResponse<List<GetUserDto>>> users = userService.GetAllUsers();
            //Assert
            Assert.That(users.Result.Data, Is.Null);
        }

        [Test]
        public void GetAllMechanics_Should_Return_All_Mechanics()
        {
            //Arrange
            UserService userService = new UserService(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<List<GetUserDto>>> mechanics = userService.GetAllMechanics();
            //Assert
            Assert.That(mechanics.Result.Data, Has.Count.EqualTo(2));
        }

        [Test]
        public void GetAllMechanics_Should_Return_Null_When_Error_Is_Given()
        {
            //Arrange
            UserService userService = new UserService(autoMapper, null);
            //Act
            Task<ServiceResponse<List<GetUserDto>>> mechanics = userService.GetAllMechanics();
            //Assert
            Assert.That(mechanics.Result.Data, Is.EqualTo(null));
        }

        /* This does give error
        [Test]
        public async Task AddUser_ShouldAddNewUser()
        {
            //Arrange
            UserService userService = new UserService(autoMapper, MockContext);

            var newUser = new AddUserDto { Name = "John", Role = 2, Password = "password" };
            var passwordHash = Encoding.UTF8.GetBytes("password");

            // Act
            var result = await userService.AddUser(newUser, passwordHash);

            //Assert
            var allUsers = await userService.GetAllUsers(); // Get all users after adding new user
            Assert.IsTrue(result.Success);
            Assert.IsNotNull(result.Data);
            Assert.IsTrue(result.Success);
            Assert.AreEqual(newUser.Name, result.Data.Name);
            Assert.AreEqual(newUser.Role, result.Data.Role);
        }
        */

        [Test]
        public async Task AddUser_Should_Return_Null_When_Request_Null()
        {
            //Arrange
            UserService userService = new UserService(autoMapper, MockContext);

            //Act
            var result = await userService.AddUser(null, null);

            //Assert
            Assert.That(result.Data, Is.Null);
        }

        [Test]
        public void AddUser_Should_Return_Null_When_error_Is_Given()
        {
            //Arrange
            UserService userService = new UserService(autoMapper, null);
            //Act
            Task<ServiceResponse<AddUserDto>> users = userService.AddUser(new AddUserDto(), new byte[0]);
            //Assert
            Assert.That(users.Result.Data, Is.EqualTo(null));
        }

        [Test]
        public void VerifyUser_Should_Return_Repair_Bike_When_Succesfull()
        {
            //Arrange
            UserService userService = new UserService(autoMapper, MockContext);

            VerifyUserDto request = new VerifyUserDto()
            {
                Name = "User 1",
                Password = "password"
            };
            //Act
            Task<ServiceResponse<ValidationUser>> user = userService.VerifyUser(request);
            //Assert
            Assert.That(user.Result.Data, Is.Not.Null);
        }

        [Test]
        public void VerifyUser_Should_Return_Null_When_Reqyest_Null()
        {
            //Arrange
            UserService userService = new UserService(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<ValidationUser>> user = userService.VerifyUser(null);
            //Assert
            Assert.That(user.Result.Data, Is.EqualTo(null));
        }

        [Test]
        public void VerifyUser_Should_Return_Null_When_error_Is_Given()
        {
            //Arrange
            UserService userService = new UserService(autoMapper, null);
            //Act
            Task<ServiceResponse<ValidationUser>> user = userService.VerifyUser(new VerifyUserDto());
            //Assert
            Assert.That(user.Result.Data, Is.EqualTo(null));
        }
    }
}
