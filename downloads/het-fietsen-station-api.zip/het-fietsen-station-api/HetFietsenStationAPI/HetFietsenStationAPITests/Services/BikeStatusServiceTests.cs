﻿using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.BikeStatus;
using HetFietsenStationAPI.Dtos.BikeStatus;

namespace HetFietsenStationAPITests.Services
{
    public class BikeStatusServiceTests : TestBase
    {

        [Test]
        public void GetAllBikeStatuss_Should_Return_All_Bike_Statuss()
        {
            //Arrange
            BikeStatusService bikeStatusService = new BikeStatusService(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<List<GetBikeStatusDto>>> bikeStatuss = bikeStatusService.GetAllBikeStatus();
            //Assert
            Assert.That(bikeStatuss?.Result?.Data?.Count, Is.EqualTo(3));
        }

        [Test]
        public void GetAllBikeStatuss_Should_Return_Null_When_Error_Is_Given()
        {
            //Arrange
            BikeStatusService bikeStatusService = new BikeStatusService(autoMapper, null);
            //Act
            Task<ServiceResponse<List<GetBikeStatusDto>>> bikeStatuss = bikeStatusService.GetAllBikeStatus();
            //Assert
            Assert.That(bikeStatuss.Result.Data, Is.EqualTo(null));
        }
    }
}
