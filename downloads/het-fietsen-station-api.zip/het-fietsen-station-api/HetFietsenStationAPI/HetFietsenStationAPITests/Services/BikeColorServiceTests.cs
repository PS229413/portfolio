﻿using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.BikeColor;
using HetFietsenStationAPI.Dtos.BikeColor;

namespace HetFietsenStationAPITests.Services
{
    public class BikeColorServiceTests : TestBase
    {

        [Test]
        public void GetAllBikeColors_Should_Return_All_Bike_Colors()
        {
            //Arrange
            BikeColorService bikeColorService = new BikeColorService(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<List<GetBikeColorDto>>> bikeColors = bikeColorService.GetAllBikeColors();
            //Assert
            Assert.That(bikeColors?.Result?.Data?.Count, Is.EqualTo(3));
        }

        [Test]
        public void GetAllBikeColors_Should_Return_Null_When_Error_Is_Given()
        {
            //Arrange
            BikeColorService bikeColorService = new BikeColorService(autoMapper, null);
            //Act
            Task<ServiceResponse<List<GetBikeColorDto>>> bikeColors = bikeColorService.GetAllBikeColors();
            //Assert
            Assert.That(bikeColors.Result.Data, Is.EqualTo(null));
        }
    }
}
