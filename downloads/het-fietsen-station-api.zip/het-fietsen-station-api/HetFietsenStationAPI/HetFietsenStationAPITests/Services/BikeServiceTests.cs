﻿using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.Bike;
using HetFietsenStationAPI.Dtos.Bike;

namespace HetFietsenStationAPITests.Services
{
    public class BikeServiceTests : TestBase
    {

        [Test]
        public void GetAllBikes_Should_Return_All_Bikes()
        {
            //Arrange
            BikeService BikeService = new BikeService(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<List<GetBikeDto>>> Bikes = BikeService.GetAllBikes();
            //Assert
            Assert.That(Bikes?.Result?.Data?.Count, Is.EqualTo(4));
        }

        [Test]
        public void GetAllBikes_Should_Return_Null_When_Error_Is_Given()
        {
            //Arrange
            BikeService BikeService = new BikeService(autoMapper, null);
            //Act
            Task<ServiceResponse<List<GetBikeDto>>> Bikes = BikeService.GetAllBikes();
            //Assert
            Assert.That(Bikes.Result.Data, Is.EqualTo(null));
        }
    }
}
