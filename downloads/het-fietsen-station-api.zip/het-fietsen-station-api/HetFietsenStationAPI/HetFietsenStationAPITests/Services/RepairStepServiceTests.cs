﻿using HetFietsenStationAPI.Services.RepairStep;
using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Dtos.BikeRepairStep;

namespace HetFietsenStationAPITests.Services
{
    public class RepairStepServiceTests : TestBase
    {
        [Test]
        public void GetAllRepairStepsFromBike_Should_Return_Repair_Steps()
        {
            //Arrange
            RepairStepService repairStepService = new RepairStepService(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<List<GetBikeRepairStepDto>>> repairSteps = repairStepService.GetAllRepairStepsFromBike(1);
            //Assert
            Assert.That(repairSteps?.Result?.Data?.Count, Is.EqualTo(2));
        }

        [Test]
        public void GetAllRepairStepsFromBike_Should_Return_Null_When_Error_Is_Given()
        {
            //Arrange
            RepairStepService repairStepService = new RepairStepService(autoMapper, null);
            //Act
            Task<ServiceResponse<List<GetBikeRepairStepDto>>> repairSteps = repairStepService.GetAllRepairStepsFromBike(1);
            //Assert
            Assert.That(repairSteps.Result.Data, Is.EqualTo(null));
        }

        [Test]
        public void GetAllRepairStepsFromBike_Succes_Should_Be_True()
        {
            //Arrange
            RepairStepService repairStepService = new RepairStepService(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<List<GetBikeRepairStepDto>>> repairSteps = repairStepService.GetAllRepairStepsFromBike(1);
            //Assert
            Assert.That(repairSteps.Result.Success, Is.EqualTo(true));
        }

        [Test]
        public void GetAllRepairStepsFromBike_Succes_Should_Be_False()
        {
            //Arrange
            RepairStepService repairStepService = new RepairStepService(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<List<GetBikeRepairStepDto>>> repairSteps = repairStepService.GetAllRepairStepsFromBike(0);
            //Assert
            Assert.That(repairSteps.Result.Success, Is.EqualTo(false));
        }
    }
}
