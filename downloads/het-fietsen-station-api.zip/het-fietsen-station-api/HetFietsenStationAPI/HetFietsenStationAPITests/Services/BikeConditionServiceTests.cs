﻿using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.BikeCondition;
using HetFietsenStationAPI.Dtos.BikeCondition;

namespace HetFietsenStationAPITests.Services
{
    public class BikeConditionServiceTests : TestBase
    {

        [Test]
        public void GetAllBikeConditions_Should_Return_All_Bike_Conditions()
        {
            //Arrange
            BikeConditionService bikeConditionService = new BikeConditionService(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<List<GetBikeConditionDto>>> bikeConditions = bikeConditionService.GetAllBikeConditions();
            //Assert
            Assert.That(bikeConditions?.Result?.Data?.Count, Is.EqualTo(3));
        }

        [Test]
        public void GetAllBikeConditions_Should_Return_Null_When_Error_Is_Given()
        {
            //Arrange
            BikeConditionService bikeConditionService = new BikeConditionService(autoMapper, null);
            //Act
            Task<ServiceResponse<List<GetBikeConditionDto>>> bikeConditions = bikeConditionService.GetAllBikeConditions();
            //Assert
            Assert.That(bikeConditions.Result.Data, Is.EqualTo(null));
        }
    }
}
