﻿using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.BikeSource;
using HetFietsenStationAPI.Dtos.BikeSource;

namespace HetFietsenStationAPITests.Services
{
    public class BikeSourceServiceTests : TestBase
    {

        [Test]
        public void GetAllBikeSources_Should_Return_All_Bike_Sources()
        {
            //Arrange
            BikeSourceService bikeSourceService = new BikeSourceService(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<List<GetBikeSourceDto>>> bikeSources = bikeSourceService.GetAllBikeSources();
            //Assert
            Assert.That(bikeSources?.Result?.Data?.Count, Is.EqualTo(3));
        }

        [Test]
        public void GetAllBikeSources_Should_Return_Null_When_Error_Is_Given()
        {
            //Arrange
            BikeSourceService bikeSourceService = new BikeSourceService(autoMapper, null);
            //Act
            Task<ServiceResponse<List<GetBikeSourceDto>>> bikeSources = bikeSourceService.GetAllBikeSources();
            //Assert
            Assert.That(bikeSources.Result.Data, Is.EqualTo(null));
        }
    }
}
