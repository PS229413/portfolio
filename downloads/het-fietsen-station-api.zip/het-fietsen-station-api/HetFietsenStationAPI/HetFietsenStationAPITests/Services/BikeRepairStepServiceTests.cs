﻿using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.BikeRepairStep;
using HetFietsenStationAPI.Dtos.BikeRepairStep;

namespace HetFietsenStationAPITests.Services
{
    public class BikeRepairStepServiceTests : TestBase
    {

        [Test]
        public void AddBikeRepairSteps_Should_Return_Bike_Repair_Steps_When_Succesfull()
        {
            //Arrange
            BikeRepairStepService bikeRepairStepService = new BikeRepairStepService(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<List<GetBikeRepairStepDto>>> bikeRepairSteps = bikeRepairStepService.AddBikeRepairSteps(3);
            //Assert
            Assert.That(bikeRepairSteps?.Result?.Data?.Count, Is.EqualTo(3));
        }

        [Test]
        public void AddBikeRepairSteps_Should_Return_Null_When_error_Is_Given()
        {
            //Arrange
            BikeRepairStepService bikeRepairStepService = new BikeRepairStepService(autoMapper, null);
            //Act
            Task<ServiceResponse<List<GetBikeRepairStepDto>>> bikeRepairSteps = bikeRepairStepService.AddBikeRepairSteps(3);
            //Assert
            Assert.That(bikeRepairSteps.Result.Data, Is.EqualTo(null));
        }

        [Test]
        public void UpdateBikeRepairStep_Should_Return_Bike_Repair_Step_When_Succesfull()
        {
            //Arrange
            BikeRepairStepService bikeRepairStepService = new BikeRepairStepService(autoMapper, MockContext);

            UpdateBikeRepairStepDto request = new UpdateBikeRepairStepDto()
            {
                BikeId = 1,
                RepairStepId = 1,
                Done = false
            };
            //Act
            Task<ServiceResponse<GetBikeRepairStepDto>> bikeRepairSteps = bikeRepairStepService.UpdateBikeRepairStep(request);
            //Assert
            Assert.That(bikeRepairSteps?.Result?.Data?.Done, Is.EqualTo(false));
        }

        [Test]
        public void UUpdateBikeRepairStep_Should_Return_Null_When_Reqyest_Null()
        {//Arrange
            BikeRepairStepService bikeRepairStepService = new BikeRepairStepService(autoMapper, MockContext);
            //Act
            Task<ServiceResponse<GetBikeRepairStepDto>> bikeRepairSteps = bikeRepairStepService.UpdateBikeRepairStep(null);
            //Assert
            Assert.That(bikeRepairSteps.Result.Data, Is.EqualTo(null));
        }

        [Test]
        public void UpdateBikeRepairStep_Should_Return_Null_When_error_Is_Given()
        {//Arrange
            BikeRepairStepService bikeRepairStepService = new BikeRepairStepService(autoMapper, null);
            //Act
            Task<ServiceResponse<GetBikeRepairStepDto>> bikeRepairSteps = bikeRepairStepService.UpdateBikeRepairStep(new UpdateBikeRepairStepDto());
            //Assert
            Assert.That(bikeRepairSteps.Result.Data, Is.EqualTo(null));
        }
    }
}
