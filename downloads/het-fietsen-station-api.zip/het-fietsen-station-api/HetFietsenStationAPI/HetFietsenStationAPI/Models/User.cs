﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HetFietsenStationAPI.Models
{
    public class User
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; } = string.Empty;
        [Required]
        public byte[]? Password { get; set; } = null;
        [ForeignKey("UserRole")]
        public int? UserRoleId { get; set; } = null;
        public UserRole? Userrole { get; set; } = null;
    }
}
