﻿using System.ComponentModel.DataAnnotations;

namespace HetFietsenStationAPI.Models
{
    public class BikeColor
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; } = string.Empty;
        [Required]
        public string Description { get; set; } = string.Empty;
        [Required]
        public string HexCode { get; set; } = string.Empty;
        public List<Bike>? Bikes { get; set; } = null;
    }
}
