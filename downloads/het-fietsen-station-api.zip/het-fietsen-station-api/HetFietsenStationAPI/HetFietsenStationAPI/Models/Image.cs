﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace HetFietsenStationAPI.Models
{
    public class Image
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        public string Url { get; set; }
        [ForeignKey(nameof(ProductId))]
        public int? ProductId { get; set; }
        [JsonIgnore]
        public virtual SideProduct? SideProduct { get; set; }
        public int? BikeId { get; set; }
        [ForeignKey(nameof(BikeId))]
        [JsonIgnore]
        public virtual Bike? Bike { get; set; }
    }
}
