﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace HetFietsenStationAPI.Models
{
    public class SideProduct
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; } = string.Empty;
        [Required]
        public string Description { get; set; } = string.Empty;
        [Required]
        public ICollection<Image> Images { get; set; }
        [Required]
        public int Stock { get; set; } = 0;
        [Required]
        public int? Price { get; set; } = 0;
        [ForeignKey("SideProductType")]
        public int? SideProductTypeId { get; set; } = null;
        public SideProductType? SideproductType { get; set; } = null;
    }
}
