﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HetFietsenStationAPI.Models
{
    public class Bike
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Brand { get; set; } = string.Empty;
        [Required]
        public string Model { get; set; } = string.Empty;
        [Required]
        public string Note { get; set; } = string.Empty;
        [Required]
        public virtual ICollection<Image> Images { get; set; }
        [Required]
        public int FrameNumber { get; set; }
        [Required]
        public int FrameHeight { get; set; }
        public int? Price { get; set; }
        public DateTime? RepairDate { get; set; }
        public DateTime? RegistrationDate { get; set; }
        [ForeignKey("BikeType")]
        public int? BikeTypeId { get; set; } = null;
        public BikeType? BikeType { get; set; } = null;
        [ForeignKey("BikeColor")]
        public int? BikeColorId { get; set; } = null;
        public BikeColor? BikeColor { get; set; } = null;
        [ForeignKey("BikeCondition")]
        public int? BikeConditionId { get; set; } = null;
        public BikeCondition? BikeCondition { get; set; } = null;
        [ForeignKey("BikeStatus")]
        public int? BikeStatusId { get; set; } = null;
        public BikeStatus? BikeStatus { get; set; } = null;
        [ForeignKey("BikeSource")]
        public int? BikeSourceId { get; set; } = null;
        public BikeSource? BikeSource { get; set; } = null;
        public List<BikeRepairStep>? BikeRepairSteps { get; set; } = null;
        [ForeignKey("User")]
        public int? MechanicId { get; set; } = null;
        public User? User { get; set; } = null;
    }
}
