﻿namespace HetFietsenStationAPI.Models
{
    public class BikeRepairStep
    {
        public int BikeId { get; set; }
        public int RepairStepId { get; set; }
        public Bike? Bike { get; set; }
        public RepairStep? RepairStep { get; set; }
        public bool Done { get; set; } = false;
    }
}
