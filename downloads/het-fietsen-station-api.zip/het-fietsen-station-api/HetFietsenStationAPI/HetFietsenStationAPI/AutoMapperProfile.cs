﻿using AutoMapper;
using HetFietsenStationAPI.Dtos.RepairBike;
using HetFietsenStationAPI.Dtos.BikeRepairStep;
using HetFietsenStationAPI.Dtos.RepairStep;
using HetFietsenStationAPI.Dtos.SideProduct;
using HetFietsenStationAPI.Dtos.SideProductType;
using HetFietsenStationAPI.Models;
using HetFietsenStationAPI.Dtos.BikeType;
using HetFietsenStationAPI.Dtos.BikeColor;
using HetFietsenStationAPI.Dtos.BikeCondition;
using HetFietsenStationAPI.Dtos.BikeStatus;
using HetFietsenStationAPI.Dtos.BikeSource;
using HetFietsenStationAPI.Dtos.User;
using HetFietsenStationAPI.Dtos.PhotographBike;
using HetFietsenStationAPI.Dtos.Bike;
using HetFietsenStationAPI.Dtos.Role;
using HetFietsenStationAPI.Dtos.Images;

namespace HetFietsenStationAPI
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            //All "SideProduct" related mappings
            CreateMap<SideProduct, AddImageDto>();
            CreateMap<SideProduct, GetImageDto>();
            CreateMap<SideProduct, AddSideProductDto>();
            CreateMap<SideProduct, GetSideProductDto>();
            CreateMap<SideProduct, UpdateImageDto>();

            //All "SideProductType related mappings"
            CreateMap<SideProductType, GetSideProductTypeDto>();
            CreateMap<SideProductType, AddSideProductTypeDto>();
            CreateMap<SideProductType, UpdateSideProductTypeDto>();

            //All "RepairStep" related mappings
            CreateMap<RepairStep, GetRepairStepDto>();
            CreateMap<AddRepairStepDto, RepairStep>();

            //All "BikeRepairStep" related mappings
            CreateMap<BikeRepairStep, GetBikeRepairStepDto>();
            CreateMap<AddBikeRepairStepDto, BikeRepairStep>();

            //All "Bike" related mappings
            CreateMap<Bike, GetRepairBikeDto>()
                .ForMember(getRepairBikeDto => getRepairBikeDto.BikeType, getBikeTypeDto => getBikeTypeDto.MapFrom(bike => bike.BikeType))
                .ForMember(getRepairBikeDto => getRepairBikeDto.BikeColor, getBikeColorDto => getBikeColorDto.MapFrom(bike => bike.BikeColor))
                .ForMember(getRepairBikeDto => getRepairBikeDto.BikeCondition, getBikeConditionDto => getBikeConditionDto.MapFrom(bike => bike.BikeCondition))
                .ForMember(getRepairBikeDto => getRepairBikeDto.BikeStatus, getBikeStatusDto => getBikeStatusDto.MapFrom(bike => bike.BikeStatus))
                .ForMember(getRepairBikeDto => getRepairBikeDto.BikeSource, getBikeSourceDto => getBikeSourceDto.MapFrom(bike => bike.BikeSource));
            CreateMap<AddBikeDto, Bike>();
            CreateMap<UpdateRepairBikeDto, Bike>();
            CreateMap<Bike, AddPhotoDto>();
            CreateMap<Bike, UpdateBikeDto>();


            //All "BikeType" related mappings
            CreateMap<BikeType, GetBikeTypeDto>();

            //All "BikeColor" related mappings
            CreateMap<BikeColor, GetBikeColorDto>();

            //All "BikeCondition" related mappings
            CreateMap<BikeCondition, GetBikeConditionDto>();

            //All "BikeStatus" related mappings
            CreateMap<BikeStatus, GetBikeStatusDto>();

            //All "BikeSource" related mappings
            CreateMap<BikeSource, GetBikeSourceDto>();

            //All "User" related mappings
            CreateMap<User, GetUserDto>();
            CreateMap<User, ValidationUser>();
            CreateMap<User, AddUserDto>();
            CreateMap<User, UpdateUserDto>();

            //All "Role" related mappings
            CreateMap<UserRole, GetRoleDto>();

            // All "AddSideProductDto" related mappings
            CreateMap<AddSideProductDto, SideProduct>();

            //All "PhotographBike" related mappings
            CreateMap<Bike, GetPhotographBikeDto>();

            //All "Image" related mappings
            CreateMap<Image, GetImageDto>();
            CreateMap<Image, AddImageDto>();

            //All "Bike" related mappings
            CreateMap<Bike, GetBikeDto>()
                .ForMember(getBikeDto => getBikeDto.BikeType, getBikeTypeDto => getBikeTypeDto.MapFrom(bike => bike.BikeType))
                .ForMember(getBikeDto => getBikeDto.BikeColor, getBikeColorDto => getBikeColorDto.MapFrom(bike => bike.BikeColor))
                .ForMember(getBikeDto => getBikeDto.BikeCondition, getBikeConditionDto => getBikeConditionDto.MapFrom(bike => bike.BikeCondition))
                .ForMember(getBikeDto => getBikeDto.BikeStatus, getBikeStatusDto => getBikeStatusDto.MapFrom(bike => bike.BikeStatus))
                .ForMember(getBikeDto => getBikeDto.BikeSource, getBikeSourceDto => getBikeSourceDto.MapFrom(bike => bike.BikeSource))
                .ForMember(getBikeDto => getBikeDto.Mechanic, getUserDto => getUserDto.MapFrom(user => user.User));
            
            //All "AddImageDto" related mappings
            CreateMap<AddImageDto, Image>()
                .ForMember(dest => dest.Url, opt => opt.MapFrom(src => src.Url))
                .ForMember(dest => dest.BikeId, opt => opt.MapFrom(src => src.BikeId))
                .ForMember(dest => dest.ProductId, opt => opt.MapFrom(src => src.ProductId));
        }
    }
}
