﻿using HetFietsenStationAPI.Dtos.BikeType;
using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.BikeType;
using Microsoft.AspNetCore.Mvc;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BikeTypeController : BaseMethod
    {
        private readonly IBikeTypeService _bikeTypeService;
        public BikeTypeController(IBikeTypeService bikeTypeService)
        {
            _bikeTypeService = bikeTypeService;
        }

        [HttpGet]
        public async Task<ActionResult<ServiceResponse<List<GetBikeTypeDto>>>> GetAllBikeTypes()
        {
            // Retrieve the list of bike types and return the response
            return await ResponseListBase(_bikeTypeService.GetAllBikeTypes());
        }
    }
}
