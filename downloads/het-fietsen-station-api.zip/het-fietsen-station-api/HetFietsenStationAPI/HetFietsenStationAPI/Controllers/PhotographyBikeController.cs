﻿using HetFietsenStationAPI.Services;
using Microsoft.AspNetCore.Mvc;
using HetFietsenStationAPI.Dtos.PhotographBike;
using HetFietsenStationAPI.Services.PhotographyBike;
using HetFietsenStationAPI.Dtos.Images;
using Microsoft.AspNetCore.Authorization;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class PhotographyBikeController : BaseMethod
    {
        private readonly IPhotographyBikeService _photographyBikeService;

        public PhotographyBikeController(IPhotographyBikeService photographyBikeService)
        {
            _photographyBikeService = photographyBikeService;
        }

        [HttpPost("AddPhoto")]
        public async Task<ActionResult<ServiceResponse<AddPhotoDto>>> AddPhoto([FromForm] AddPhotoDto request)
        {
            // Get the base URL of the request
            string host = Request.Scheme + "://" + Request.Host.ToString(); // Messy solution.
            
            // Read the form data from the request
            var formCollection = await Request.ReadFormAsync();
            var files = formCollection.Files;
            var response = new ServiceResponse<AddPhotoDto>();

            // Process each uploaded file
            foreach (IFormFile file in files)
            {
                // Generate a unique file name
                string fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);

                // Save the file to the specified path
                var saveFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Uploads", fileName);
                using (var stream = new FileStream(saveFilePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                // Add the image URL to the request and call the service to add the photo
                var resp = await _photographyBikeService.AddImageURL(request, fileName, host);

                if (resp.Data == null)
                    return NotFound(resp);

                if (!resp.Success)
                {
                    response.Success = false;
                    response.Message = resp.Message;
                    break;
                }

            }
            
            if (response.Success)
            {
                Ok(response);
            }
            
            return NotFound(response);
        }

        [HttpPut("UpdatePhoto")]
        public async Task<ActionResult<ServiceResponse<AddImageDto>>> UpdatePhoto([FromForm] AddPhotoDto request)
        {
            // Read the form data from the request
            var formCollection = await Request.ReadFormAsync();
            var file = formCollection.Files.First();
            
            // Generate a unique file name
            string fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
            
            // Get the base URL of the request
            string host = Request.Scheme + "://" + Request.Host.ToString(); // Messy solution.

            // Save the file to the specified path
            var saveFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Uploads", fileName);
            using (var stream = new FileStream(saveFilePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            // Add the image URL to the request and update the photo
            return await ResponseSingleBase(_photographyBikeService.AddImageURL(request, fileName, host));
        }
    }
}