﻿using HetFietsenStationAPI.Dtos.BikeRepairStep;
using HetFietsenStationAPI.Services.BikeRepairStep;
using HetFietsenStationAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class BikeRepairStepController : BaseMethod
    {
        private readonly IBikeRepairStepService _bikeRepairStepService;

        public BikeRepairStepController(IBikeRepairStepService bikeRepairStepService)
        {
            _bikeRepairStepService = bikeRepairStepService;
        }

        [HttpPut, Authorize(Roles = "mechanic,admin")]
        public async Task<ActionResult<ServiceResponse<GetBikeRepairStepDto>>> UpdateBikeRepairStep(UpdateBikeRepairStepDto request)
        {
            // Update bike repair steps with the provided request data and return the response
            return await ResponseSingleBase(_bikeRepairStepService.UpdateBikeRepairStep(request));
        }
    }
}
