﻿using HetFietsenStationAPI.Dtos.User;
using HetFietsenStationAPI.Services.User;
using HetFietsenStationAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : BaseMethod
    {
        private readonly IUserService _userService;
        public UserController(IUserService bikeTypeService)
        {
            _userService = bikeTypeService;
        }

        [HttpGet]
        public async Task<ActionResult<ServiceResponse<List<GetUserDto>>>> GetAllUsers()
        {
            // Retrieve the list of users and return the response
            return await ResponseListBase(_userService.GetAllUsers());
        }

        [HttpGet("Mechanics"), Authorize(Roles = "mechanic,admin")]
        public async Task<ActionResult<ServiceResponse<List<GetUserDto>>>> GetAllMechanics()
        {
            // Retrieve the list of mechanics and return the response
            return await ResponseListBase(_userService.GetAllMechanics());
        }
    }
}
