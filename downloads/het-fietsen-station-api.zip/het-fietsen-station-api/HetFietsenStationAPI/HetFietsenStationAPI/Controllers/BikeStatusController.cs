﻿using HetFietsenStationAPI.Dtos.BikeStatus;
using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.BikeStatus;
using Microsoft.AspNetCore.Mvc;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BikeStatusController : BaseMethod
    {
        private readonly IBikeStatusService _bikeStatusService;

        public BikeStatusController(IBikeStatusService bikeStatusService)
        {
            _bikeStatusService = bikeStatusService;
        }

        [HttpGet]
        public async Task<ActionResult<ServiceResponse<List<GetBikeStatusDto>>>> GetAllBikeStatus()
        {
            // Retrieve the list of bike status and return the response
            return await ResponseListBase(_bikeStatusService.GetAllBikeStatus());
        }
    }
}
