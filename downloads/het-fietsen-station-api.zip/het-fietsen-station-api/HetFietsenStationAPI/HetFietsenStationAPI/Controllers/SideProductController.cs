﻿using HetFietsenStationAPI.Dtos.SideProduct;
using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.SideProduct;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class SideProductController : BaseMethod
    {
        private readonly ISideProductService _sideProductService;

        public SideProductController(ISideProductService sideProductService)
        {
            _sideProductService = sideProductService;
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult<ServiceResponse<List<GetSideProductDto>>>> GetAllSideProducts()
        {
            // Retrieve the list of side products and return the response
            return await ResponseListBase(_sideProductService.GetAllSideProducts());
        }

        [HttpPost]
        public async Task<ActionResult<ServiceResponse<AddSideProductDto>>> AddSideProduct(AddSideProductDto request)
        {
            // Add a side product with the provided request data and return the response
            return await ResponseSingleBase(_sideProductService.AddSideProduct(request));
        }

        [HttpPut]
        public async Task<ActionResult<ServiceResponse<UpdateSideProductDto>>> UpdateSideProduct(UpdateSideProductDto request)
        {
            // Update a side product with the provided request data and return the response
            return await ResponseSingleBase(_sideProductService.UpdateSideProduct(request));
        }
        
        [AllowAnonymous]
        [HttpGet("lastAdded")]
        public async Task<ActionResult<ServiceResponse<GetSideProductDto>>> GetLastAddedSideProduct(string? name)
        {
            // Retrieve the last added side product with the provided name (if any) and return the response
            return await ResponseSingleBase(_sideProductService.GetLastAddedSideProduct(name));
        }
        
        [AllowAnonymous]
        [HttpGet("{sideProductId}")]
        public async Task<ActionResult<ServiceResponse<GetSideProductDto>>> GetSingleSideProduct(int sideProductId)
        {
            // Retrieve a side product with the specified sideProductId and return the response
            return await ResponseSingleBase(_sideProductService.GetSingleSideProduct(sideProductId));
        }
    }
}
