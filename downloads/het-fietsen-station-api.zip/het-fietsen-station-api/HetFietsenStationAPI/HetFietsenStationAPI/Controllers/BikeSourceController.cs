﻿using HetFietsenStationAPI.Dtos.BikeSource;
using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.BikeSource;
using Microsoft.AspNetCore.Mvc;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BikeSourceController : BaseMethod
    {
        private readonly IBikeSourceService _bikeSourceService;

        public BikeSourceController(IBikeSourceService bikeSourceService)
        {
            _bikeSourceService = bikeSourceService;
        }

        [HttpGet]
        public async Task<ActionResult<ServiceResponse<List<GetBikeSourceDto>>>> GetAllBikeSources()
        {
            // Retrieve the list of bike sources and return the response
            return await ResponseListBase(_bikeSourceService.GetAllBikeSources());
        }
    }
}
