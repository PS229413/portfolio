﻿using HetFietsenStationAPI.Dtos.Role;
using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.Role;
using Microsoft.AspNetCore.Mvc;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : BaseMethod
    {
        private readonly IRoleService _roleService;
         
        public RoleController(IRoleService roleService)
        {
            _roleService = roleService;
        }
        
        [HttpGet]
        public async Task<ActionResult<ServiceResponse<List<GetRoleDto>>>> GetAllRoles()
        {
            // Retrieve the list of roles and return the response
            return await ResponseListBase(_roleService.GetAllRoles());
        }
    }
}
