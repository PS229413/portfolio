﻿using HetFietsenStationAPI.Dtos.Bike;
using HetFietsenStationAPI.Services.Bike;
using HetFietsenStationAPI.Services;
using Microsoft.AspNetCore.Mvc;
using HetFietsenStationAPI.Dtos.RepairBike;
using HetFietsenStationAPI.Services.BikeRepairStep;
using HetFietsenStationAPI.Dtos.PhotographBike;
using Microsoft.AspNetCore.Authorization;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class BikeController : BaseMethod
    {
        private readonly IBikeService _bikeService;
        private readonly IBikeRepairStepService _repairBikeStepService;

        public BikeController(IBikeService bikeService, IBikeRepairStepService repairBikeStepService)
        {
            _bikeService = bikeService;
            _repairBikeStepService = repairBikeStepService;
        }

        [AllowAnonymous]
        [HttpGet("Repaired")]
        public async Task<ActionResult<ServiceResponse<List<GetBikeDto>>>> GetRepairedBikes()
        {
            // Retrieve the list of repaired bikes and return the response
            return await ResponseListBase(_bikeService.GetRepairedBikes(2));
        }

        [HttpGet("Repair")]
        public async Task<ActionResult<ServiceResponse<List<GetBikeDto>>>> GetRepairBikes()
        {
            // Retrieve the list of repair bikes and return the response
            return await ResponseListBase(_bikeService.GetRepairedBikes(1));
        }

        [HttpPut]
        public async Task<ActionResult<ServiceResponse<UpdateBikeDto>>> UpdateBike(UpdateBikeDto request)
        {
            // Update the bike with the provided request data and return the response
            return await ResponseSingleBase(_bikeService.UpdateBike(request));
        }
        
        [HttpGet("lastAdded")]
        public async Task<ActionResult<ServiceResponse<GetBikeDto>>> GetLastAddedBike(string? name)
        {
            // Retrieve the last added bike with the provided name (if any) and return the response
            return await ResponseSingleBase(_bikeService.GetLastAddedBike(name));
        }
        
        [AllowAnonymous]
        [HttpGet("{bikeId}")]
        public async Task<ActionResult<ServiceResponse<GetBikeDto>>> GetSingleBike(int bikeId)
        {
            // Retrieve a bike with the specified bikeId and return the response
            return await ResponseSingleBase(_bikeService.GetSingleBike(bikeId));
        }

        [HttpGet("all")]
        public async Task<ActionResult<ServiceResponse<List<GetBikeDto>>>> GetAllBikes()
        {
            // Retrieve all bikes and return the response
            return await ResponseSingleBase(_bikeService.GetAllBikes());
        }

        [HttpPost]
        public async Task<ActionResult<ServiceResponse<GetBikeDto>>> AddBike(AddBikeDto request)
        {
            // Add a new bike with the provided request data and retrieve the response
            var bikeResponse = await _bikeService.AddBike(request);
            
            // Check if the bike response data is null
            if (bikeResponse.Data == null)
            {
                // If the data is null, return a 404 Not Found status code with the bike response
                return NotFound(bikeResponse);
            }

            // If the data is not null, add the bike repair steps to the bike and retrieve the response
            var bikeStepResponse = await _repairBikeStepService.AddBikeRepairSteps(bikeResponse.Data.Id);
            
            // Check if the bike step response was successful or not
            if (!bikeStepResponse.Success)
            {
                // If the response was not successful, return a 404 Not Found status code with the bike step response
                return NotFound(bikeStepResponse);
            }

            // If the response was successful, return a 200 OK status code with the bike response
            return Ok(bikeResponse);
        }

        [HttpPut("Photograph")]
        public async Task<ActionResult<ServiceResponse<GetPhotographBikeDto>>> RepairBikeToPhotographBike(RepairBikeToPhotographBikeDto request)
        {
            return await ResponseSingleBase(_bikeService.BikeToPhotographBike(request));
        }
    }
}