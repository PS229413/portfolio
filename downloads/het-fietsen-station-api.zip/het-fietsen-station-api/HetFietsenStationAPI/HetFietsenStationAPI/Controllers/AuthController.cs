﻿using HetFietsenStationAPI.Dtos.User;
using HetFietsenStationAPI.Services.User;
using HetFietsenStationAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class AuthController : BaseMethod
    {
        private readonly IConfiguration _configuration;
        private readonly IUserService _userService;

        public AuthController(IUserService userService, IConfiguration configuration)
        {
            _userService = userService;
            _configuration = configuration;
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult<string> GetMe()
        {
            // Retrieve the username from the authenticated user and return it
            var userName = User.Identity?.Name;
            return Ok(userName);
        }
        
        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<ActionResult<ValidationUser>> Register(AddUserDto request)
        {
            // Create a password hash using the provided password
            CreatePasswordHash(request.Password, out byte[] passwordHash);

            // Add the user with the password hash to the user service
            var user = await _userService.AddUser(request, passwordHash);

            return Ok(user);
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<ActionResult<ValidationUser>> Login(VerifyUserDto request)
        {
            // Verify the user's credentials and retrieve the user information
            var userResponse = await _userService.VerifyUser(request);
            var user = userResponse.Data;
            
            // Check if the user exists and the provided name matches
            if (user == null || user.Name != request.Name)
                return BadRequest("User not found.");

            // Verify the password hash
            if (user.Password == null || !VerifyPasswordHash(request.Password, user.Password))
                return BadRequest("");

            // Create a JWT token with the user's claims and return it
            string token = CreateToken(user);

            return Ok(new { Token = token });
        }

        [HttpPut("update")]
        public async Task<ActionResult<ServiceResponse<UpdateUserDto>>> UpdateUser(UpdateUserDto request)
        {
            // Create a password hash if the password is provided
            var passwordHash = Array.Empty<byte>();
            if (!string.IsNullOrEmpty(request.Password))
            {
                CreatePasswordHash(request.Password, out passwordHash);
            }

            // Update the user with the provided request data and return the response
            return await ResponseSingleBase(_userService.UpdateUser(request, passwordHash));
        }

        [HttpDelete("delete"), Authorize(Roles = "admin")]
        public async Task<ActionResult<ServiceResponse<DeleteUserDto>>> DeleteUser(DeleteUserDto request)
        {
            // Delete the user with the provided request data and return the response
            return await ResponseSingleBase(_userService.DeleteUser(request));
        }

        private string CreateToken(ValidationUser currentValidationUser)
        {
            // Create claims for the user's name and role
            List<Claim> claims = new();
            var role = GetUserRole(currentValidationUser.UserRoleId);
            
            if (!string.IsNullOrEmpty(role))
            {
                claims.Add(new Claim(ClaimTypes.Name, currentValidationUser.Name));
                claims.Add(new Claim(ClaimTypes.Role, role));
            }

            // Create a symmetric security key using the token secret from configuration
            SymmetricSecurityKey key = new(System.Text.Encoding.UTF8.GetBytes(
                    _configuration.GetSection("AppSettings:token").Value));

            // Create signing credentials with the key
            SigningCredentials cred = new(key, SecurityAlgorithms.HmacSha512Signature);

            // Create a JWT token with the claims and signing credentials
            JwtSecurityToken token = new(
                claims: claims,
                expires: DateTime.Now.AddDays(60),
                signingCredentials: cred);

            // Write the token as a string and return it
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private static void CreatePasswordHash(string password, out byte[] passwordHash)
        {
            // Create a password hash using HMACSHA512 algorithm
            using (var hmac = new HMACSHA512(new byte[0]))
            {
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }

        private static bool VerifyPasswordHash(string password, byte[] passwordHash)
        {
            // Verify the password by computing the hash and comparing it with the stored hash
            using (var hmac = new HMACSHA512(new byte[0]))
            {
                byte[] computedHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                return computedHash.SequenceEqual(passwordHash);
            }
        }
        
        private static string GetUserRole(int userRoleId)
        {
            // Return the user role based on the userRoleId
            return userRoleId switch
            {
                1 => "mechanic",
                2 => "admin",
                3 => "photographer",
                4 => "salesperson",
                _ => throw new InvalidOperationException("Invalid UserRoleId encountered.")
            };
        }
    }
}
