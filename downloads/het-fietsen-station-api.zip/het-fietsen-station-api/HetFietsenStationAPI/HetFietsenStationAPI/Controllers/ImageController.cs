using HetFietsenStationAPI.Services;
using Microsoft.AspNetCore.Mvc;
using HetFietsenStationAPI.Services.Images;
using HetFietsenStationAPI.Dtos.Images;
using Microsoft.AspNetCore.Authorization;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class ImageController : BaseMethod
    {
        private readonly IImageService _imageService;

        public ImageController(IImageService imageService)
        {
            _imageService = imageService;
        }

        [AllowAnonymous]
        [HttpGet("GetAllImages")]
        public async Task<ActionResult<ServiceResponse<List<GetImageDto>>>> GetAllImages()
        {
            // Retrieve the list of images types and return the response
            return await ResponseListBase(_imageService.GetAllImages());
        }

        [HttpPost]
        public async Task<ActionResult<ServiceResponse<AddImageDto>>> AddImage(AddImageDto request)
        {
            // Add a new image and return the response
            return await ResponseSingleBase(_imageService.AddImage(request));
        }

        [HttpDelete]
        public async Task<ActionResult<ServiceResponse<DeleteImageDto>>> DeleteImage(DeleteImageDto request)
        {
            // Delete an image and return the response
            return await ResponseSingleBase(_imageService.DeleteImage(request));
        }

        [AllowAnonymous]
        [HttpGet("Bike/{bikeId}")]
        public async Task<ActionResult<ServiceResponse<List<GetImageDto>>>> GetImagesForBike(int bikeId)
        {
            // Retrieve the list of images associated with a specific bike ID and return the response
            return await ResponseListBase(_imageService.GetImagesForBike(bikeId));
        }

        [AllowAnonymous]
        [HttpGet("SideProduct/{productId}")]
        public async Task<ActionResult<ServiceResponse<List<GetImageDto>>>> GetImagesForSideProduct(int productId)
        {
            // Retrieve the list of images associated with a specific side product ID and return the response
            return await ResponseListBase(_imageService.GetImagesForSideProduct(productId));
        }
    }
}