﻿using HetFietsenStationAPI.Dtos.BikeColor;
using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.BikeColor;
using Microsoft.AspNetCore.Mvc;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BikeColorController : BaseMethod
    {
        private readonly IBikeColorService _bikeColorService;

        public BikeColorController(IBikeColorService bikeColorService)
        {
            _bikeColorService = bikeColorService;
        }

        [HttpGet]
        public async Task<ActionResult<ServiceResponse<List<GetBikeColorDto>>>> GetAllBikeColors()
        {
            // Retrieve the list of bike colors and return the response
            return await ResponseListBase(_bikeColorService.GetAllBikeColors());
        }
    }
}
