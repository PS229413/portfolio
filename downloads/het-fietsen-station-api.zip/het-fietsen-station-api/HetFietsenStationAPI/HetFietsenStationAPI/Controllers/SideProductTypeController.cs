﻿using HetFietsenStationAPI.Dtos.SideProductType;
using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.SideProductType;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class SideProductTypeController : BaseMethod
    {
        private readonly ISideProductTypeService _sideProductTypeService;

        public SideProductTypeController(ISideProductTypeService sideProductTypeService)
        {
            _sideProductTypeService = sideProductTypeService;
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult<ServiceResponse<List<GetSideProductTypeDto>>>> GetSideProductType()
        {
            // Retrieve the list of side product types and return the response
            return await ResponseListBase(_sideProductTypeService.GetAllSideProductTypes());
        }

        [HttpPost]
        public async Task<ActionResult<ServiceResponse<AddSideProductTypeDto>>> AddSideProductType(AddSideProductTypeDto request)
        {
            // Add a side product type with the provided request data and return the response
            return await ResponseSingleBase(_sideProductTypeService.AddSideProductType(request));
        }

        [HttpPut]
        public async Task<ActionResult<ServiceResponse<UpdateSideProductTypeDto>>> UpdateSideProductType(UpdateSideProductTypeDto request)
        {
            // Update a side product type with the provided request data and return the response
            return await ResponseSingleBase(_sideProductTypeService.UpdateSideProductType(request));
        }

        [HttpDelete]
        public async Task<ActionResult<ServiceResponse<DeleteSideProductTypeDto>>> RemoveSideProductType(DeleteSideProductTypeDto request)
        {
            // Remove a side product type with the provided request data and return the response
            return await ResponseSingleBase(_sideProductTypeService.DeleteSideProductType(request));
        }
    }
}