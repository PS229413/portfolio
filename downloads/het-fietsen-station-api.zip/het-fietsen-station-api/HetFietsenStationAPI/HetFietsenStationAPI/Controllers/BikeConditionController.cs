﻿using HetFietsenStationAPI.Dtos.BikeCondition;
using HetFietsenStationAPI.Services;
using HetFietsenStationAPI.Services.BikeCondition;
using Microsoft.AspNetCore.Mvc;

namespace HetFietsenStationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BikeConditionController : BaseMethod
    {
        private readonly IBikeConditionService _bikeConditionService;
        
        public BikeConditionController(IBikeConditionService bikeConditionService)
        {
            _bikeConditionService = bikeConditionService;
        }

        [HttpGet]
        public async Task<ActionResult<ServiceResponse<List<GetBikeConditionDto>>>> GetAllBikeConditions()
        {
            // Retrieve the list of bike conditions and return the response
            return await ResponseListBase(_bikeConditionService.GetAllBikeConditions());
        }
    }
}
