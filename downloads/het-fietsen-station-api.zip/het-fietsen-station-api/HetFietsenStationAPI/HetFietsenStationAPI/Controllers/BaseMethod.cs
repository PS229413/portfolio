﻿using HetFietsenStationAPI.Services;
using Microsoft.AspNetCore.Mvc;

namespace HetFietsenStationAPI.Controllers
{
    public class BaseMethod : ControllerBase
    {
        // Handles the response for endpoints returning a list of DTOs
        protected async Task<ActionResult<ServiceResponse<List<TDto>>>> ResponseListBase<TDto>(Task<ServiceResponse<List<TDto>>> task) where TDto : class
        {
            return await HandleResponse(task);
        }
        
        // Handles the response for endpoints returning a single DTO
        protected async Task<ActionResult<ServiceResponse<TDto>>> ResponseSingleBase<TDto>(Task<ServiceResponse<TDto>> task) where TDto : class
        {
            return await HandleResponse(task);
        }
        
        // Handles the response logic for both list and single DTO endpoints
        private async Task<ActionResult<ServiceResponse<TDto>>> HandleResponse<TDto>(Task<ServiceResponse<TDto>> task) where TDto : class
        {
            try
            {
                // Await the completion of the task to get the service response
                var response = await task;

                // Check if the response data is null
                if (response.Data == null)
                {
                    // If the data is null, return a NotFound result with the response
                    return NotFound(response);
                }

                // If the response data is not null, return an Ok result with the response
                return Ok(response);
            }
            catch (Exception e)
            {
                // If an exception occurs, create a new service response with error details
                var response = new ServiceResponse<TDto>()
                {
                    Data = null,
                    Success = false,
                    Message = e.Message
                };

                // Return a NotFound result with the error response
                return NotFound(response);
            }
        }
    }
}