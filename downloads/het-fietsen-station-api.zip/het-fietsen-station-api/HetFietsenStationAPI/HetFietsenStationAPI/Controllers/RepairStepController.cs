﻿using HetFietsenStationAPI.Services.RepairStep;
using HetFietsenStationAPI.Services;
using Microsoft.AspNetCore.Mvc;
using HetFietsenStationAPI.Dtos.BikeRepairStep;

namespace HetFietsenStationAPI.Controllers
{
    //Sets the base route of the controller
    [Route("api/[controller]")]
    [ApiController]
    public class RepairStepController : BaseMethod
    {
        //Variable that will contain a object that implements the IRepairService interface
        private readonly IRepairStepService _repairStepService;

        //Injects a instance of a object that implements IRepairStepService
        public RepairStepController(IRepairStepService repairStepService)
        {
            _repairStepService = repairStepService;
        }
        
        [HttpGet("{bikeId}")]
        public async Task<ActionResult<ServiceResponse<List<GetBikeRepairStepDto>>>> GetAllRepairStepsFromBike(int bikeId)
        {
            // Retrieve the list of repair steps from the specified bikeId and return the response
            return await ResponseListBase(_repairStepService.GetAllRepairStepsFromBike(bikeId));
        }
    }
}
