﻿using HetFietsenStationAPI.Dtos.Images;

namespace HetFietsenStationAPI.Services.Images
{
    public interface IImageService
    {
        public Task<ServiceResponse<AddImageDto>> AddImage(AddImageDto request);
        public Task<ServiceResponse<List<GetImageDto>>> GetAllImages();
        public Task<ServiceResponse<UpdateImageDto>> UpdateImage(UpdateImageDto request);
        public Task<ServiceResponse<DeleteImageDto>> DeleteImage(DeleteImageDto request);
        public Task<ServiceResponse<List<GetImageDto>>> GetImagesForBike(int bikeId);
        public Task<ServiceResponse<List<GetImageDto>>> GetImagesForSideProduct(int productId);
    }
}