﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.Images;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Services.Images
{
    public class ImageService : IImageService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public ImageService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }
        public async Task<ServiceResponse<AddImageDto>> AddImage(AddImageDto request)
        {
            ServiceResponse<AddImageDto> response = new ServiceResponse<AddImageDto>();

            try
            {
                Models.Image images = _mapper.Map<Models.Image>(request);

                if (request.ProductId != 0)
                {
                    images = new Models.Image() { Url = request.Url, BikeId = null, ProductId = request.ProductId };
                }
                else if (request.BikeId != 0)
                {
                    images = new Models.Image() { Url = request.Url, BikeId = request.BikeId, ProductId = null };
                }

                _context.Image.Add(images);

                await _context.SaveChangesAsync();

                response.Data = _mapper.Map<AddImageDto>(images);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<DeleteImageDto>> DeleteImage(DeleteImageDto request)
        {
            ServiceResponse<DeleteImageDto> response = new ServiceResponse<DeleteImageDto>();

            try
            {
                try
                {
                    Models.Image? image = _context.Find<Models.Image>(request.Id);
                    string filePath = Path.Combine(Directory.GetCurrentDirectory(), "Uploads", image.Url);
                    if (File.Exists(filePath))
                    {
                        File.Delete(filePath);
                    }
                    _context.Remove(image);

                    await _context.SaveChangesAsync();
                    response.Message = $"Deleted image with ID {request.Id}";
                }
                catch (Exception ex)
                {
                    response.Success = false;
                    response.Message = ex.Message;
                }
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<UpdateImageDto>> UpdateImage(UpdateImageDto request)
        {
            ServiceResponse<UpdateImageDto> response = new ServiceResponse<UpdateImageDto>();

            try
            {
                Models.Image? image = _context.Find<Models.Image>(request.Id);
                image.Url = request.Url;
                image.ProductId = null;
                image.BikeId = null;
                if (request.ProductId != 0)
                {
                    image.ProductId = request.ProductId;
                }
                if (request.BikeId != 0)
                {
                    image.BikeId = request.BikeId;
                }

                await _context.SaveChangesAsync();

                response.Data = _mapper.Map<UpdateImageDto>(image);
            }
            catch (Exception ex)
            {   
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }
        
        public async Task<ServiceResponse<List<GetImageDto>>> GetImagesForBike(int bikeId)
        {
            ServiceResponse<List<GetImageDto>> response = new ServiceResponse<List<GetImageDto>>();
            try
            {
                List<Models.Image> images = await _context.Image.Where(img => img.BikeId == bikeId).ToListAsync();

                if (images.Count > 0)
                {
                    response.Data = images.Select(u => new GetImageDto { Url = u.Url, Id = u.Id, BikeId = u.BikeId, ProductId = u.ProductId }).ToList();
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }

        public async Task<ServiceResponse<List<GetImageDto>>> GetImagesForSideProduct(int productId)
        {
            ServiceResponse<List<GetImageDto>> response = new ServiceResponse<List<GetImageDto>>();
            try
            {
                List<Models.Image> images = await _context.Image.Where(img => img.ProductId == productId).ToListAsync();

                if (images.Count > 0)
                {
                    response.Data = images.Select(u => new GetImageDto { Url = u.Url, Id = u.Id, BikeId = u.BikeId, ProductId = u.ProductId }).ToList();
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }

        public async Task<ServiceResponse<List<GetImageDto>>> GetAllImages()
        {

            ServiceResponse<List<GetImageDto>> response = new ServiceResponse<List<GetImageDto>>();
            try
            {
                List<Models.Image> images = await _context.Image.ToListAsync();

                if (images.Count > 0)
                {
                    response.Data = images.Select(u => new GetImageDto { Url = u.Url, Id = u.Id, BikeId = u.BikeId, ProductId = u.ProductId }).ToList();
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }
    }
}
