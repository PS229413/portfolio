﻿using HetFietsenStationAPI.Dtos.BikeType;

namespace HetFietsenStationAPI.Services.BikeType
{
    public class BikeTypeMockService : IBikeTypeService
    {
        private readonly List<GetBikeTypeDto> _mockBikeTypes = new List<GetBikeTypeDto>()
        {
            new()
            { 
                Id = 1,
                Name = "type 1",
                Description = "description"
            },
            new()
            {
                Id = 2,
                Name = "type 2",
                Description = "description"
            },
            new()
            {
                Id = 3,
                Name = "type 3",
                Description = "description"
            }
        };
        public async Task<ServiceResponse<List<GetBikeTypeDto>>> GetAllBikeTypes()
        {
            ServiceResponse<List<GetBikeTypeDto>> mockResponse = new ServiceResponse<List<GetBikeTypeDto>>();

            try
            {
                await Task.Delay(10);

                mockResponse.Data = _mockBikeTypes;
                mockResponse.Success = true;
                mockResponse.Message = "";

                return mockResponse;
            }
            catch
            {
                mockResponse.Data = null;
                mockResponse.Success = false;
                mockResponse.Message = "error";
            }

            return mockResponse;
        }
    }
}
