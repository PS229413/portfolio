﻿using HetFietsenStationAPI.Dtos.BikeType;

namespace HetFietsenStationAPI.Services.BikeType
{
    public interface IBikeTypeService
    {
        public Task<ServiceResponse<List<GetBikeTypeDto>>> GetAllBikeTypes();
    }
}
