﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.BikeType;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Services.BikeType
{
    public class BikeTypeService : IBikeTypeService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public BikeTypeService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        public async Task<ServiceResponse<List<GetBikeTypeDto>>> GetAllBikeTypes()
        {
            ServiceResponse<List<GetBikeTypeDto>> response = new ServiceResponse<List<GetBikeTypeDto>>();
            try
            {
                List<Models.BikeType> bikeTypes = await _context.BikeTypes.ToListAsync();

                if (bikeTypes.Count > 0)
                {
                    response.Data = bikeTypes.Select(bt => _mapper.Map<Models.BikeType, GetBikeTypeDto>(bt)).ToList();
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }
    }
}
