﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.SideProduct;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Services.SideProduct
{
    public class SideProductService : ISideProductService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public SideProductService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        public async Task<ServiceResponse<AddSideProductDto>> AddSideProduct(AddSideProductDto request)
        {
            ServiceResponse<AddSideProductDto> response = new ServiceResponse<AddSideProductDto>();

            try
            {
                Models.SideProduct sideProduct = new Models.SideProduct() { Name = request.Name, Description = request.Description, Price = request.Price, Stock = request.Stock, SideProductTypeId = request.SideProductTypeId };

                //List<Models.Image> images = new List<Image>();
                //sideProduct.Images = images;
                _context.SideProducts.Add(sideProduct);

                await _context.SaveChangesAsync();

                response.Data = _mapper.Map<AddSideProductDto>(sideProduct);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<GetSideProductDto>> GetLastAddedSideProduct(string withName = null)
        {
            ServiceResponse<GetSideProductDto> response = new ServiceResponse<GetSideProductDto>();

            try
            {
                // Get the latest added sideproduct, if withName is not null, get the latest added sideproduct with the given name
                Models.SideProduct? sideProduct = (withName == null) ? await _context.SideProducts.OrderByDescending(sp => sp.Id).FirstOrDefaultAsync() : await _context.SideProducts.OrderByDescending(sp => sp.Id).FirstOrDefaultAsync(sp => sp.Name == withName);

                if (sideProduct != null)
                {
                    response.Data = _mapper.Map<GetSideProductDto>(sideProduct);
                }
                else
                {
                    response.Success = false;
                    response.Message = "Sideproduct not found";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<UpdateSideProductDto>> UpdateSideProduct(UpdateSideProductDto request)
        {
            ServiceResponse<UpdateSideProductDto> response = new ServiceResponse<UpdateSideProductDto>();

            try
            {
                Models.SideProduct? sideProduct = _context.Find<Models.SideProduct>(request.Id);
                if (sideProduct == null)
                {
                    response.Success = false;
                    response.Message = "Side product not found.";
                    return response;
                }

                sideProduct.Name = request.Name;
                sideProduct.Description = request.Description;
                sideProduct.Images = request.Images;
                sideProduct.Price = (request.Price >= 0) ? request.Price : 0;
                sideProduct.Stock = (request.Stock >= 0) ? request.Stock : 0;
                sideProduct.SideProductTypeId = request.SideProductTypeId;

                await _context.SaveChangesAsync();

                response.Data = _mapper.Map<UpdateSideProductDto>(sideProduct);
            }
            catch (Exception ex)
            {

                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<List<UpdateSideProductDto>>> DeleteSideProduct(int id)
        {
            ServiceResponse<List<UpdateSideProductDto>> response = new ServiceResponse<List<UpdateSideProductDto>>();

            try
            {
                Models.SideProduct? sideProduct = await _context.SideProducts.FirstOrDefaultAsync(sp => sp.Id == id);
                if (sideProduct != null)
                {
                    _context.SideProducts.Remove(sideProduct);
                    await _context.SaveChangesAsync();
                    response.Data = _context.SideProducts.Select(sp => _mapper.Map<UpdateSideProductDto>(sp)).ToList();
                }
                else
                {
                    response.Success = false;
                    response.Message = "Sideproduct not found";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<List<GetSideProductDto>>> GetAllSideProducts()
        {
            ServiceResponse<List<GetSideProductDto>> response = new ServiceResponse<List<GetSideProductDto>>();
            List<Models.SideProduct> superHeroes = await _context.SideProducts.Include(sp => sp.SideproductType).Include(img => img.Images).ToListAsync();
            response.Data = superHeroes.Select(sp => _mapper.Map<GetSideProductDto>(sp)).ToList();
            return response;
        }

        public async Task<ServiceResponse<GetSideProductDto>> GetSingleSideProduct(int id)
        {
            ServiceResponse<GetSideProductDto> response = new ServiceResponse<GetSideProductDto>();
            try
            {
                Models.SideProduct? sideProduct = await _context.SideProducts
                    .Include(sp => sp.SideproductType)
                    .Include(img => img.Images)
                    .Where(sp => sp.Id == id)
                    .FirstAsync();

                if (sideProduct != null)
                {
                    response.Data = _mapper.Map<Models.SideProduct, GetSideProductDto>(sideProduct);
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message ?? "An error occurred while processing your request.";
            }
            return response;
        }
    }
}