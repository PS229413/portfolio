﻿using HetFietsenStationAPI.Dtos.SideProduct;

namespace HetFietsenStationAPI.Services.SideProduct
{
    public interface ISideProductService
    {
        public Task<ServiceResponse<GetSideProductDto>> GetSingleSideProduct(int id);
        public Task<ServiceResponse<List<GetSideProductDto>>> GetAllSideProducts();
        public Task<ServiceResponse<AddSideProductDto>> AddSideProduct(AddSideProductDto request);
        public Task<ServiceResponse<GetSideProductDto>> GetLastAddedSideProduct(string withName);
        public Task<ServiceResponse<UpdateSideProductDto>> UpdateSideProduct(UpdateSideProductDto request);
        public Task<ServiceResponse<List<UpdateSideProductDto>>> DeleteSideProduct(int id);
    }
}
