﻿using HetFietsenStationAPI.Dtos.Role;

namespace HetFietsenStationAPI.Services.Role
{
    public interface IRoleService
    {
        public Task<ServiceResponse<List<GetRoleDto>>> GetAllRoles();
    }
}
