﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.Role;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Services.Role
{
    public class RoleService : IRoleService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public RoleService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        public async Task<ServiceResponse<List<GetRoleDto>>> GetAllRoles()
        {
            ServiceResponse<List<GetRoleDto>> response = new ServiceResponse<List<GetRoleDto>>();
            try
            {
                List<Models.UserRole> userRoles = await _context.UserRoles.ToListAsync();

                if (userRoles.Count > 0)
                {
                    response.Data = userRoles.Select(u => _mapper.Map<GetRoleDto>(u)).ToList();
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }
    }
}
