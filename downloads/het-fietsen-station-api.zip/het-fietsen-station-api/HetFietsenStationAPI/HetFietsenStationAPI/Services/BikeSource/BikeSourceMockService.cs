﻿using HetFietsenStationAPI.Dtos.BikeSource;

namespace HetFietsenStationAPI.Services.BikeSource
{
    public class BikeSourceMockService : IBikeSourceService
    {
        private readonly List<GetBikeSourceDto> _mockBikeSources = new List<GetBikeSourceDto>()
        {
            new()
            { 
                Id = 1,
                Name = "source 1",
                Description = "description"
            },
            new()
            {
                Id = 2,
                Name = "source 2",
                Description = "description"
            },
            new()
            {
                Id = 3,
                Name = "source 3",
                Description = "description"
            }
        };
        public async Task<ServiceResponse<List<GetBikeSourceDto>>> GetAllBikeSources()
        {
            ServiceResponse<List<GetBikeSourceDto>> mockResponse = new ServiceResponse<List<GetBikeSourceDto>>();

            try
            {
                await Task.Delay(10);

                mockResponse.Data = _mockBikeSources;
                mockResponse.Success = true;
                mockResponse.Message = "";

                return mockResponse;
            }
            catch
            {
                mockResponse.Data = null;
                mockResponse.Success = false;
                mockResponse.Message = "error";
            }

            return mockResponse;
        }
    }
}
