﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.BikeSource;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Services.BikeSource
{
    public class BikeSourceService : IBikeSourceService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public BikeSourceService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        public async Task<ServiceResponse<List<GetBikeSourceDto>>> GetAllBikeSources()
        {
            ServiceResponse<List<GetBikeSourceDto>> response = new ServiceResponse<List<GetBikeSourceDto>>();
            try
            {
                List<Models.BikeSource> bikeSources = await _context.BikeSources.ToListAsync();

                if (bikeSources.Count > 0)
                {
                    response.Data = bikeSources.Select(bs => _mapper.Map<Models.BikeSource, GetBikeSourceDto>(bs)).ToList();
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }
    }
}
