﻿using HetFietsenStationAPI.Dtos.BikeSource;

namespace HetFietsenStationAPI.Services.BikeSource
{
    public interface IBikeSourceService
    {
        public Task<ServiceResponse<List<GetBikeSourceDto>>> GetAllBikeSources();
    }
}
