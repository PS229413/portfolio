﻿using HetFietsenStationAPI.Dtos.BikeRepairStep;
using HetFietsenStationAPI.Dtos.RepairStep;

namespace HetFietsenStationAPI.Services.RepairStep
{
    public class RepairStepMockService : IRepairStepService
    {
        private readonly List<ServiceResponse<List<GetBikeRepairStepDto>>> _mockBikeRepairStep = new List<ServiceResponse<List<GetBikeRepairStepDto>>>()
        {
            new()
            {
                Data = new List<GetBikeRepairStepDto>()
                {
                    new GetBikeRepairStepDto() { RepairStep = new GetRepairStepDto() { Id = 1, Name = "Test 1", Description = "Test 1" }, Done = true },
                    new GetBikeRepairStepDto() { RepairStep = new GetRepairStepDto() { Id = 2, Name = "Test 2", Description = "Test 2" }, Done = false }
                },
                Success = true,
                Message = ""
            },
            new()
            {
                Data = new List<GetBikeRepairStepDto>()
                {
                    new GetBikeRepairStepDto() { RepairStep = new GetRepairStepDto() { Id = 1, Name = "Test 1", Description = "Test 1" }, Done = true },
                    new GetBikeRepairStepDto() { RepairStep = new GetRepairStepDto() { Id = 2, Name = "Test 2", Description = "Test 2" }, Done = false }
                },
                Success = true,
                Message = ""
            }
        };

        public async Task<ServiceResponse<List<GetBikeRepairStepDto>>> GetAllRepairStepsFromBike(int id)
        {
            try
            {
                await Task.Delay(10);

                return _mockBikeRepairStep[id];
            }
            catch
            {
                return new ServiceResponse<List<GetBikeRepairStepDto>>() { Success = false };
            }
        }
    }
}
