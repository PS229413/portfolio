﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.BikeRepairStep;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Services.RepairStep
{
    public class RepairStepService : IRepairStepService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public RepairStepService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        public async Task<ServiceResponse<List<GetBikeRepairStepDto>>> GetAllRepairStepsFromBike(int id)
        {
            ServiceResponse<List<GetBikeRepairStepDto>> response = new ServiceResponse<List<GetBikeRepairStepDto>>();
            try 
            {
                List<Models.BikeRepairStep> repairSteps = await _context.BikeRepairSteps
                    .Include(brs => brs.RepairStep)
                    .Where(brs => brs.BikeId == id)
                    .ToListAsync();

                if (repairSteps.Count > 0)
                {
                    response.Data = repairSteps.Select(rp => _mapper.Map<GetBikeRepairStepDto>(rp)).ToList();
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }
    }
}
