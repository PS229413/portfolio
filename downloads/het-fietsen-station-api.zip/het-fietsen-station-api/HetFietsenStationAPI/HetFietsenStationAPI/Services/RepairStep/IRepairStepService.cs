﻿using HetFietsenStationAPI.Dtos.BikeRepairStep;

namespace HetFietsenStationAPI.Services.RepairStep
{
    //Interface which defines what each RepairStepService has to have
    public interface IRepairStepService
    {
        //Defines that each RepairStepService has to have a GetAllRepairStepsFromBike function
        public Task<ServiceResponse<List<GetBikeRepairStepDto>>> GetAllRepairStepsFromBike(int id);
    }
}
