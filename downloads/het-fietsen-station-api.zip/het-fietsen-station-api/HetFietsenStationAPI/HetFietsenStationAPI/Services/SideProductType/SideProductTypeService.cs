﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.SideProductType;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Services.SideProductType
{
    public class SideProductTypeService : ISideProductTypeService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public SideProductTypeService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        public async Task<ServiceResponse<List<GetSideProductTypeDto>>> GetAllSideProductTypes()
        {
            ServiceResponse<List<GetSideProductTypeDto>> response = new ServiceResponse<List<GetSideProductTypeDto>>();
            List<Models.SideProductType> superHeroes = await _context.SideProductTypes.Include(sp => sp.SideProduct).ToListAsync();
            response.Data = superHeroes.Select(sp => _mapper.Map<GetSideProductTypeDto>(sp)).ToList();
            return response;
        }

        public async Task<ServiceResponse<AddSideProductTypeDto>> AddSideProductType(AddSideProductTypeDto request)
        {
            ServiceResponse<AddSideProductTypeDto> response = new ServiceResponse<AddSideProductTypeDto>();

            try
            {
                Models.SideProductType sideProductType = new Models.SideProductType() { Name = request.Name, Description = request.Description };

                _context.SideProductTypes.Add(sideProductType);

                await _context.SaveChangesAsync();

                response.Data = _mapper.Map<AddSideProductTypeDto>(sideProductType);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<UpdateSideProductTypeDto>> UpdateSideProductType(UpdateSideProductTypeDto request)
        {
            ServiceResponse<UpdateSideProductTypeDto> response = new ServiceResponse<UpdateSideProductTypeDto>();

            try
            {
                Models.SideProductType? sideProductType = _context.Find<Models.SideProductType>(request.Id);
                if (sideProductType != null)
                {
                    sideProductType.Name = request.Name;
                    sideProductType.Description = request.Description;

                    await _context.SaveChangesAsync();

                    response.Data = _mapper.Map<UpdateSideProductTypeDto>(sideProductType);
                }
                else
                {
                    response.Success = false;
                    response.Message = $"Side product type with ID {request.Id} not found";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<DeleteSideProductTypeDto>> DeleteSideProductType(DeleteSideProductTypeDto request)
        {
            ServiceResponse<DeleteSideProductTypeDto> response = new ServiceResponse<DeleteSideProductTypeDto>();

            try
            {
                Models.SideProductType sideProductType = _context.Find<Models.SideProductType>(request.Id) ?? throw new ArgumentNullException(nameof(sideProductType));
                _context.Remove(sideProductType);

                await _context.SaveChangesAsync();
                response.Message = $"Deleted side product type with ID {request.Id}";

            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }
    }
}
