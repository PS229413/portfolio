﻿using HetFietsenStationAPI.Dtos.SideProductType;

namespace HetFietsenStationAPI.Services.SideProductType
{
    public interface ISideProductTypeService
    {
        public Task<ServiceResponse<List<GetSideProductTypeDto>>> GetAllSideProductTypes();
        public Task<ServiceResponse<AddSideProductTypeDto>> AddSideProductType(AddSideProductTypeDto request);
        public Task<ServiceResponse<UpdateSideProductTypeDto>> UpdateSideProductType(UpdateSideProductTypeDto request);
        public Task<ServiceResponse<DeleteSideProductTypeDto>> DeleteSideProductType(DeleteSideProductTypeDto request);
    }
}
