﻿using HetFietsenStationAPI.Dtos.BikeColor;

namespace HetFietsenStationAPI.Services.BikeColor
{
    public interface IBikeColorService
    {
        public Task<ServiceResponse<List<GetBikeColorDto>>> GetAllBikeColors();
    }
}
