﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.BikeColor;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Services.BikeColor
{
    public class BikeColorService : IBikeColorService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public BikeColorService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        public async Task<ServiceResponse<List<GetBikeColorDto>>> GetAllBikeColors()
        {
            ServiceResponse<List<GetBikeColorDto>> response = new ServiceResponse<List<GetBikeColorDto>>();
            try
            {
                List<Models.BikeColor> bikeColors = await _context.BikeColors.ToListAsync();

                if (bikeColors.Count > 0)
                {
                    response.Data = bikeColors.Select(bc => _mapper.Map<Models.BikeColor, GetBikeColorDto>(bc)).ToList();
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }
    }
}
