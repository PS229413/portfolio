﻿using HetFietsenStationAPI.Dtos.BikeColor;

namespace HetFietsenStationAPI.Services.BikeColor
{
    public class BikeColorMockService : IBikeColorService
    {
        private readonly List<GetBikeColorDto> _mockBikeColors = new List<GetBikeColorDto>()
        {
            new()
            { 
                Id = 1,
                Name = "color 1",
                Description = "description",
                HexCode = "#FFFFFF"
            },
            new()
            {
                Id = 2,
                Name = "color 2",
                Description = "description",
                HexCode = "#FFFFFF"
            },
            new()
            {
                Id = 3,
                Name = "color 3",
                Description = "description",
                HexCode = "#FFFFFF"
            }
        };
        public async Task<ServiceResponse<List<GetBikeColorDto>>> GetAllBikeColors()
        {
            ServiceResponse<List<GetBikeColorDto>> mockResponse = new ServiceResponse<List<GetBikeColorDto>>();

            try
            {
                await Task.Delay(10);

                mockResponse.Data = _mockBikeColors;
                mockResponse.Success = true;
                mockResponse.Message = "";

                return mockResponse;
            }
            catch
            {
                mockResponse.Data = null;
                mockResponse.Success = false;
                mockResponse.Message = "error";
            }

            return mockResponse;
        }
    }
}
