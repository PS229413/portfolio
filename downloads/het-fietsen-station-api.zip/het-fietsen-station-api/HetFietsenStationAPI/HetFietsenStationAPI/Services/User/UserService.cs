﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.User;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Services.User
{
    public class UserService : IUserService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public UserService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        public async Task<ServiceResponse<List<GetUserDto>>> GetAllUsers()
        {
            ServiceResponse<List<GetUserDto>> response = new ServiceResponse<List<GetUserDto>>();
            try
            {
                List<Models.User> users = await _context.Users.ToListAsync();

                if (users.Count > 0)
                {
                    response.Data = users.Select(u => _mapper.Map<GetUserDto>(u)).ToList();
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }

        public async Task<ServiceResponse<List<GetUserDto>>> GetAllMechanics()
        {
            ServiceResponse<List<GetUserDto>> response = new ServiceResponse<List<GetUserDto>>();
            try
            {
                List<Models.User> repairSteps = await _context.Users.Where(u => u.UserRoleId == 1).ToListAsync();

                if (repairSteps.Count > 0)
                {
                    response.Data = repairSteps.Select(u => _mapper.Map<GetUserDto>(u)).ToList();
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<AddUserDto>> AddUser(AddUserDto request, byte[] passwordHash)
        {
            ServiceResponse<AddUserDto> response = new ServiceResponse<AddUserDto>();

            try
            {
                Models.User user = new Models.User() { Name = request.Name, Password = passwordHash, UserRoleId = request.Role};
                _context.Users.Add(user);

                await _context.SaveChangesAsync();

                response.Data = _mapper.Map<AddUserDto>(user);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<UpdateUserDto>> UpdateUser(UpdateUserDto request, byte[] passwordHash)
        {
            ServiceResponse<UpdateUserDto> response = new ServiceResponse<UpdateUserDto>();

            try
            {
                Models.User? user = _context.Find<Models.User>(request.Id);
                if (user != null)
                {
                    user.Name = request.Name;
                    if (passwordHash != null)
                    {
                        user.Password = passwordHash;
                    }
                    user.UserRoleId = request.UserRole;

                    await _context.SaveChangesAsync();

                    response.Data = _mapper.Map<UpdateUserDto>(user);
                }
                else
                {
                    response.Success = false;
                    response.Message = "User not found";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<DeleteUserDto>> DeleteUser(DeleteUserDto request)
        {
            ServiceResponse<DeleteUserDto> response = new ServiceResponse<DeleteUserDto>();

            try
            {
                Models.User? user = _context.Find<Models.User>(request.Id);
                if (user != null)
                {
                    _context.Remove(user!);

                    await _context.SaveChangesAsync();
                    response.Message = $"Deleted user with ID {request.Id}";
                }
                else
                {
                    response.Success = false;
                    response.Message = $"User with ID {request.Id} not found";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<ValidationUser>> VerifyUser(VerifyUserDto request)
        {
            ServiceResponse<ValidationUser> response = new ServiceResponse<ValidationUser>();
            try
            {
                Models.User user = await _context.Users.Where(u => u.Name == request.Name).FirstAsync();
                user.UserRoleId = _context.UserRoles.Where(ur => ur.Id == user.UserRoleId).FirstAsync().Result.Id;

                if (user != null)
                {
                    response.Data = _mapper.Map<ValidationUser>(user);
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }
    }
}
