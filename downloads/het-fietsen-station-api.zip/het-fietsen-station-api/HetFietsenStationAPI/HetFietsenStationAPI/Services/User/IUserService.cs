﻿using HetFietsenStationAPI.Dtos.User;

namespace HetFietsenStationAPI.Services.User
{
    public interface IUserService
    {
        public Task<ServiceResponse<List<GetUserDto>>> GetAllUsers();
        public Task<ServiceResponse<List<GetUserDto>>> GetAllMechanics();
        public Task<ServiceResponse<AddUserDto>> AddUser(AddUserDto request, byte[] passwordHash);
        public Task<ServiceResponse<UpdateUserDto>> UpdateUser(UpdateUserDto request, byte[] passwordHash);
        public Task<ServiceResponse<DeleteUserDto>> DeleteUser(DeleteUserDto request);
        public Task<ServiceResponse<ValidationUser>> VerifyUser(VerifyUserDto request);
    }
}
