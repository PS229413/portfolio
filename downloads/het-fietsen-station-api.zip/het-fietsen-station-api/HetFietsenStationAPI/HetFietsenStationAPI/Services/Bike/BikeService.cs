﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.Bike;
using HetFietsenStationAPI.Dtos.PhotographBike;
using HetFietsenStationAPI.Dtos.RepairBike;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Services.Bike
{
    public class BikeService : IBikeService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public BikeService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        //This function is only used for bikes who are ready to be sold
        public async Task<ServiceResponse<List<GetBikeDto>>> GetRepairedBikes(int statusId)
        {
            ServiceResponse<List<GetBikeDto>> response = new ServiceResponse<List<GetBikeDto>>();
            try
            {
                List<Models.Bike> bikes = await _context.Bikes
                    .Include(b => b.BikeType)
                    .Include(b => b.BikeColor)
                    .Include(b => b.BikeCondition)
                    .Include(b => b.BikeStatus)
                    .Include(b => b.BikeSource)
                    .Include(b => b.User)
                    .Where(b => b.BikeStatus != null && b.BikeStatus.Id == statusId)
                    .ToListAsync();

                if (bikes.Count > 0)
                {
                    var data = bikes.Select(rb => _mapper.Map<Models.Bike, GetBikeDto>(rb)).ToList();

                    // Fetch and add the Images for each bike
                    foreach (GetBikeDto bike in data)
                    {
                        List<Models.Image> images = await _context.Image
                            .Where(img => img.BikeId == bike.Id)
                            .ToListAsync();
                        

                        bike.Images = images;
                    }

                    response.Data = data;
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }

        public async Task<ServiceResponse<UpdateBikeDto>> UpdateBike(UpdateBikeDto request)
        {
            ServiceResponse<UpdateBikeDto> response = new ServiceResponse<UpdateBikeDto>();

            try
            {
                Models.Bike? bike = _context.Find<Models.Bike>(request.Id);

                if (bike != null)
                {
                    bike.Brand = request.Brand;
                    bike.Model = request.Model;
                    bike.Note = request.Note;
                    bike.FrameNumber = request.FrameNumber;
                    bike.FrameHeight = request.FrameHeight;
                    bike.Price = request.Price;
                    bike.BikeTypeId = request.BikeTypeId;
                    bike.BikeColorId = request.BikeColorId;
                    bike.BikeConditionId = request.BikeConditionId;
                    bike.BikeSourceId = request.BikeSourceId;
                    bike.MechanicId = request.MechanicId;

                    await _context.SaveChangesAsync();

                    response.Data = _mapper.Map<UpdateBikeDto>(bike);
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }

        public async Task<ServiceResponse<GetBikeDto>> GetSingleBike(int bikeId)
        {
            ServiceResponse<GetBikeDto> response = new ServiceResponse<GetBikeDto>();
            try
            {
                Models.Bike? bike = await _context.Bikes
                    .Include(b => b.BikeType)
                    .Include(b => b.BikeColor)
                    .Include(b => b.BikeCondition)
                    .Include(b => b.BikeStatus)
                    .Include(b => b.BikeSource)
                    .Include(b => b.User)
                    .FirstOrDefaultAsync(b => b.Id == bikeId);
                if (bike != null)
                {
                    response.Data = _mapper.Map<Models.Bike, GetBikeDto>(bike);
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }

        public async Task<ServiceResponse<List<GetBikeDto>>> GetAllBikes()
        {
            ServiceResponse<List<GetBikeDto>> response = new ServiceResponse<List<GetBikeDto>>();
            try
            {
                List<Models.Bike> bikes = await _context.Bikes
                    .Include(b => b.BikeType)
                    .Include(b => b.BikeColor)
                    .Include(b => b.BikeCondition)
                    .Include(b => b.BikeStatus)
                    .Include(b => b.BikeSource)
                    .Include(b => b.User)
                    .Include(b => b.Images)
                    .ToListAsync();

                if (bikes.Count > 0)
                {
                    response.Data = bikes.Select(rb => _mapper.Map<Models.Bike, GetBikeDto>(rb)).ToList();
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }

        public async Task<ServiceResponse<GetBikeDto>> GetLastAddedBike(string withModel = null)
        {
            ServiceResponse<GetBikeDto> response = new ServiceResponse<GetBikeDto>();

            try
            {
                // Get the latest added sideproduct, if withName is not null, get the latest added sideproduct with the given model
                Models.Bike? bike = (withModel == null) ? await _context.Bikes.OrderByDescending(sp => sp.Id).FirstOrDefaultAsync() : await _context.Bikes.OrderByDescending(sp => sp.Id).FirstOrDefaultAsync(sp => sp.Model == withModel);

                if (bike != null)
                {
                    response.Data = _mapper.Map<GetBikeDto>(bike);
                }
                else
                {
                    response.Success = false;
                    response.Message = "Bike not found";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<GetBikeDto>> AddBike(AddBikeDto request)
        {
            ServiceResponse<GetBikeDto> response = new ServiceResponse<GetBikeDto>();

            try
            {
                Models.Bike bike = _mapper.Map<Models.Bike>(request);
                _context.Bikes.Add(bike);
                await _context.SaveChangesAsync();

                response.Data = _mapper.Map<GetBikeDto>(bike);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<GetPhotographBikeDto>> BikeToPhotographBike(RepairBikeToPhotographBikeDto request)
        {
            ServiceResponse<GetPhotographBikeDto> response = new ServiceResponse<GetPhotographBikeDto>();

            try
            {
                Models.Bike? bike = _context.Find<Models.Bike>(request.Id);

                if (bike == null)
                {
                    response.Success = false;
                    response.Message = "Bike not found";
                    return response;
                }

                bike.Note = request.Note;
                bike.RepairDate = request.RepairDate;
                bike.Price = request.Price;
                bike.BikeStatusId = request.BikeStatusId;
                bike.MechanicId = request.MechanicId;

                await _context.SaveChangesAsync();

                response.Data = _mapper.Map<GetPhotographBikeDto>(bike);
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }
    }
}