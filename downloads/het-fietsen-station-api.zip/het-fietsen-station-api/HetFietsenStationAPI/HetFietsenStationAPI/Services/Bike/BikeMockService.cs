﻿using HetFietsenStationAPI.Dtos.Bike;
using HetFietsenStationAPI.Dtos.BikeColor;
using HetFietsenStationAPI.Dtos.BikeCondition;
using HetFietsenStationAPI.Dtos.BikeSource;
using HetFietsenStationAPI.Dtos.BikeStatus;
using HetFietsenStationAPI.Dtos.BikeType;
using HetFietsenStationAPI.Dtos.PhotographBike;
using HetFietsenStationAPI.Dtos.RepairBike;

namespace HetFietsenStationAPI.Services.Bike
{
    public class BikeMockService : IBikeService
    {
        private readonly List<GetBikeDto> _mockBikes = new List<GetBikeDto>()
        {
                new()
                {
                    Id = 1, Brand = "Brand 1", Model = "M1", Note = "Note", FrameHeight = 100, FrameNumber = 1, Price = 100, RepairDate = DateTime.Today, RegistrationDate = DateTime.Today,
                    BikeColor = new GetBikeColorDto {Id = 1, Name = "BikeColor 1", Description = "Test data", HexCode = "#FFFFFF"},
                    BikeCondition = new GetBikeConditionDto {Id = 1, Name = "BikeCondition 1", Description = "Test data" },
                    BikeSource = new GetBikeSourceDto { Id = 1, Name = "BikeSource 1", Description = "Test data" },
                    BikeStatus = new GetBikeStatusDto { Id = 3, Name = "BikeStatus 3", Description = "Test data" },
                    BikeType = new GetBikeTypeDto { Id = 1, Name = "BikeType 1", Description = "Test data" }
                },
                new()
                {
                    Id = 1, Brand = "Brand 1", Model = "M1", Note = "Note", FrameHeight = 100, FrameNumber = 1, Price = 100, RepairDate = DateTime.Today, RegistrationDate = DateTime.Today,
                    BikeColor = new GetBikeColorDto {Id = 1, Name = "BikeColor 1", Description = "Test data", HexCode = "#FFFFFF"},
                    BikeCondition = new GetBikeConditionDto {Id = 1, Name = "BikeCondition 1", Description = "Test data" },
                    BikeSource = new GetBikeSourceDto { Id = 1, Name = "BikeSource 1", Description = "Test data" },
                    BikeStatus = new GetBikeStatusDto { Id = 3, Name = "BikeStatus 3", Description = "Test data" },
                    BikeType = new GetBikeTypeDto { Id = 1, Name = "BikeType 1", Description = "Test data" }
                },
                new()
                {
                    Id = 1, Brand = "Brand 1", Model = "M1", Note = "Note", FrameHeight = 100, FrameNumber = 1, Price = 100, RepairDate = DateTime.Today, RegistrationDate = DateTime.Today,
                    BikeColor = new GetBikeColorDto {Id = 1, Name = "BikeColor 1", Description = "Test data", HexCode = "#FFFFFF"},
                    BikeCondition = new GetBikeConditionDto {Id = 1, Name = "BikeCondition 1", Description = "Test data" },
                    BikeSource = new GetBikeSourceDto { Id = 1, Name = "BikeSource 1", Description = "Test data" },
                    BikeStatus = new GetBikeStatusDto { Id = 3, Name = "BikeStatus 3", Description = "Test data" },
                    BikeType = new GetBikeTypeDto { Id = 1, Name = "BikeType 1", Description = "Test data" }
                }
        };
        public async Task<ServiceResponse<List<GetBikeDto>>> GetRepairedBikes(int statusId)
        {
            var mockResponse = new ServiceResponse<List<GetBikeDto>>();

            try
            {
                await Task.Delay(10);

                mockResponse.Data = _mockBikes;
                mockResponse.Success = true;
                mockResponse.Message = "";

                return mockResponse;
            }
            catch
            {
                mockResponse.Data = null;
                mockResponse.Success = false;
                mockResponse.Message = "error";
            }

            return mockResponse;
        }

        public async Task<ServiceResponse<UpdateBikeDto>> UpdateBike(UpdateBikeDto updateBikeDto)
        {
            var mockResponse = new ServiceResponse<UpdateBikeDto>();

            try
            {
                await Task.Delay(10);

                mockResponse.Data = null;
                mockResponse.Success = true;
                mockResponse.Message = "";
                return mockResponse;
            }
            catch
            {
                mockResponse.Data = null;
                mockResponse.Success = false;
                mockResponse.Message = "error";
            }
            return mockResponse;
        }

        public async Task<ServiceResponse<GetBikeDto>> GetSingleBike(int id)
        {
            var mockResponse = new ServiceResponse<GetBikeDto>();

            try
            {
                await Task.Delay(10);
                mockResponse.Data = _mockBikes.FirstOrDefault(b => b.Id == id);
                mockResponse.Success = true;
                mockResponse.Message = "";
                return mockResponse;
            }
            catch
            {
                mockResponse.Data = null;
                mockResponse.Success = false;
                mockResponse.Message = "error";
            }
            return mockResponse;
        }

        public async Task<ServiceResponse<List<GetBikeDto>>> GetAllBikes()
        {
            var mockResponse = new ServiceResponse<List<GetBikeDto>>();

            try
            {
                await Task.Delay(10);

                mockResponse.Data = _mockBikes;
                mockResponse.Success = true;
                mockResponse.Message = "";

                return mockResponse;
            }
            catch
            {
                mockResponse.Data = null;
                mockResponse.Success = false;
                mockResponse.Message = "error";
            }

            return mockResponse;
        }

        public async Task<ServiceResponse<GetBikeDto>> AddBike(AddBikeDto bikeDto)
        {
            await Task.Delay(0);
            var mockResponse = new ServiceResponse<GetBikeDto>();
            return mockResponse;
        }


        public async Task<ServiceResponse<GetPhotographBikeDto>> BikeToPhotographBike(RepairBikeToPhotographBikeDto request)
        {
            await Task.Delay(0);
            var mockResponse = new ServiceResponse<GetPhotographBikeDto>();
            // Set the properties of the mockResponse object here
            return mockResponse;
        }

        public async Task<ServiceResponse<GetBikeDto>> GetLastAddedBike(string withModel = null)
        {
            await Task.Delay(0);
            var mockResponse = new ServiceResponse<GetBikeDto>();
            // Set the properties of the mockResponse object here
            return mockResponse;
        }
    }
}
