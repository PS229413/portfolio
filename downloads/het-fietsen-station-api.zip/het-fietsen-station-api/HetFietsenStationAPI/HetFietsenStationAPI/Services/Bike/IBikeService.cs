﻿using HetFietsenStationAPI.Dtos.Bike;
using HetFietsenStationAPI.Dtos.PhotographBike;
using HetFietsenStationAPI.Dtos.RepairBike;

namespace HetFietsenStationAPI.Services.Bike
{
    public interface IBikeService
    {
        public Task<ServiceResponse<List<GetBikeDto>>> GetRepairedBikes(int statusId);
        public Task<ServiceResponse<UpdateBikeDto>> UpdateBike(UpdateBikeDto updateBikeDto);
        public Task<ServiceResponse<GetBikeDto>> GetSingleBike(int id);
        public Task<ServiceResponse<GetBikeDto>> GetLastAddedBike(string withName);
        public Task<ServiceResponse<List<GetBikeDto>>> GetAllBikes();
        public Task<ServiceResponse<GetBikeDto>> AddBike(AddBikeDto request);
        public Task<ServiceResponse<GetPhotographBikeDto>> BikeToPhotographBike(RepairBikeToPhotographBikeDto request);
    }
}
