﻿using HetFietsenStationAPI.Dtos.BikeStatus;

namespace HetFietsenStationAPI.Services.BikeStatus
{
    public interface IBikeStatusService
    {
        public Task<ServiceResponse<List<GetBikeStatusDto>>> GetAllBikeStatus();
    }
}
