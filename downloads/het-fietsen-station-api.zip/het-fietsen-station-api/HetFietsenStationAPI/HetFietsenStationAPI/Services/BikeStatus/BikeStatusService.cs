﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.BikeStatus;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Services.BikeStatus
{
    public class BikeStatusService : IBikeStatusService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public BikeStatusService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        public async Task<ServiceResponse<List<GetBikeStatusDto>>> GetAllBikeStatus()
        {
            ServiceResponse<List<GetBikeStatusDto>> response = new ServiceResponse<List<GetBikeStatusDto>>();
            try
            {
                List<Models.BikeStatus> bikeStatus = await _context.BikeStatuses.ToListAsync();

                if (bikeStatus.Count > 0)
                {
                    response.Data = bikeStatus.Select(bs => _mapper.Map<Models.BikeStatus, GetBikeStatusDto>(bs)).ToList();
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }
    }
}
