﻿using HetFietsenStationAPI.Dtos.BikeStatus;

namespace HetFietsenStationAPI.Services.BikeStatus
{
    public class BikeStatusMockService : IBikeStatusService
    {
        private readonly List<GetBikeStatusDto> _mockBikeStatuses = new List<GetBikeStatusDto>()
        {
            new()
            { 
                Id = 1,
                Name = "status 1",
                Description = "description"
            },
            new()
            {
                Id = 2,
                Name = "status 2",
                Description = "description"
            },
            new()
            {
                Id = 3,
                Name = "status 3",
                Description = "description"
            }
        };
        public async Task<ServiceResponse<List<GetBikeStatusDto>>> GetAllBikeStatus()
        {
            ServiceResponse<List<GetBikeStatusDto>> mockResponse = new ServiceResponse<List<GetBikeStatusDto>>();

            try
            {
                await Task.Delay(10);

                mockResponse.Data = _mockBikeStatuses;
                mockResponse.Success = true;
                mockResponse.Message = "";

                return mockResponse;
            }
            catch
            {
                mockResponse.Data = null;
                mockResponse.Success = false;
                mockResponse.Message = "error";
            }

            return mockResponse;
        }
    }
}
