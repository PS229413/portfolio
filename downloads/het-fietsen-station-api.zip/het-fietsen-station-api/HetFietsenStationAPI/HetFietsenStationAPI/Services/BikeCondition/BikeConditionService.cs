﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.BikeCondition;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Services.BikeCondition
{
    public class BikeConditionService : IBikeConditionService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public BikeConditionService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        public async Task<ServiceResponse<List<GetBikeConditionDto>>> GetAllBikeConditions()
        {
            ServiceResponse<List<GetBikeConditionDto>> response = new ServiceResponse<List<GetBikeConditionDto>>();
            try
            {
                List<Models.BikeCondition> bikeConditions = await _context.BikeConditions.ToListAsync();

                if (bikeConditions.Count > 0)
                {
                    response.Data = bikeConditions.Select(bc => _mapper.Map<Models.BikeCondition, GetBikeConditionDto>(bc)).ToList();
                }
                else
                {
                    response.Success = false;
                    response.Message = "Nothing was found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }
            return response;
        }
    }
}
