﻿using HetFietsenStationAPI.Dtos.BikeCondition;

namespace HetFietsenStationAPI.Services.BikeCondition
{
    public class BikeConditionMockService : IBikeConditionService
    {
        private List<GetBikeConditionDto> MockBikeConditions = new List<GetBikeConditionDto>()
        {
            new GetBikeConditionDto()
            { 
                Id = 1,
                Name = "condition 1",
                Description = "description"
            },
            new GetBikeConditionDto()
            {
                Id = 2,
                Name = "condition 2",
                Description = "description"
            },
            new GetBikeConditionDto()
            {
                Id = 3,
                Name = "condition 3",
                Description = "description"
            }
        };
        public async Task<ServiceResponse<List<GetBikeConditionDto>>> GetAllBikeConditions()
        {
            ServiceResponse<List<GetBikeConditionDto>> mockResponse = new ServiceResponse<List<GetBikeConditionDto>>();

            try
            {
                await Task.Delay(10);

                mockResponse.Data = MockBikeConditions;
                mockResponse.Success = true;
                mockResponse.Message = "";

                return mockResponse;
            }
            catch
            {
                mockResponse.Data = null;
                mockResponse.Success = false;
                mockResponse.Message = "error";
            }

            return mockResponse;
        }
    }
}
