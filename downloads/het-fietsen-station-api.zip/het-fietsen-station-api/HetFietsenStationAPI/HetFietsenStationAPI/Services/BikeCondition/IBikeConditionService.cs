﻿using HetFietsenStationAPI.Dtos.BikeCondition;

namespace HetFietsenStationAPI.Services.BikeCondition
{
    public interface IBikeConditionService
    {
        public Task<ServiceResponse<List<GetBikeConditionDto>>> GetAllBikeConditions();
    }
}
