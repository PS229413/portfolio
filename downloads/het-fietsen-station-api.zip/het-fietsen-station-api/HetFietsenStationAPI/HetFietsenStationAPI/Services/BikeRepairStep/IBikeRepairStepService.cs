﻿using HetFietsenStationAPI.Dtos.BikeRepairStep;

namespace HetFietsenStationAPI.Services.BikeRepairStep
{
    public interface IBikeRepairStepService
    {
        public Task<ServiceResponse<List<GetBikeRepairStepDto>>> AddBikeRepairSteps(int bikeId);
        public Task<ServiceResponse<GetBikeRepairStepDto>> UpdateBikeRepairStep(UpdateBikeRepairStepDto request);
    }
}
