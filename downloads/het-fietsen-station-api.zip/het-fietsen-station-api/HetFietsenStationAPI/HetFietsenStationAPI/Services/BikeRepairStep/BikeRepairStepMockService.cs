﻿using HetFietsenStationAPI.Dtos.BikeRepairStep;
using HetFietsenStationAPI.Dtos.RepairStep;

namespace HetFietsenStationAPI.Services.BikeRepairStep
{
    public class BikeRepairStepMockService : IBikeRepairStepService
    {
        private readonly List<GetBikeRepairStepDto> _mockBikeRepairsSteps = new List<GetBikeRepairStepDto>()
        {
            new()
            { 
                RepairStep = new GetRepairStepDto()
                { 
                    Id = 1,
                    Name = "`repair step 1",
                    Description = "description",
                    Required = true,
                },
                Done = false
            },
            new()
            {
                RepairStep = new GetRepairStepDto()
                {
                    Id = 2,
                    Name = "`repair step 2",
                    Description = "description",
                    Required = true,
                },
                Done = true
            },
            new()
            {
                RepairStep = new GetRepairStepDto()
                {
                    Id = 3,
                    Name = "`repair step 3",
                    Description = "description",
                    Required = false,
                },
                Done = false
            },
        };

        public async Task<ServiceResponse<List<GetBikeRepairStepDto>>> AddBikeRepairSteps(int bikeId)
        {
            ServiceResponse<List<GetBikeRepairStepDto>> mockResponse = new ServiceResponse<List<GetBikeRepairStepDto>>();
            try
            {
                await Task.Delay(10);

                if(bikeId != 1)
                {
                    mockResponse.Data = _mockBikeRepairsSteps;
                    mockResponse.Success = true;
                    mockResponse.Message = "";
                }

                mockResponse.Data = null;
                mockResponse.Success = false;
                mockResponse.Message = "bike does not exist";

            }
            catch (Exception ex)
            {
                mockResponse.Data = null;
                mockResponse.Success = false;
                mockResponse.Message = ex.Message;
            }
            return mockResponse;
        }

        public async Task<ServiceResponse<GetBikeRepairStepDto>> UpdateBikeRepairStep(UpdateBikeRepairStepDto request)
        {
            ServiceResponse<GetBikeRepairStepDto> response = new ServiceResponse<GetBikeRepairStepDto>();
            try
            {
                await Task.Delay(10);

                GetBikeRepairStepDto? bikeRepairStep = _mockBikeRepairsSteps.FirstOrDefault(mockBikeRepairsSteps => mockBikeRepairsSteps.RepairStep?.Id == request.RepairStepId);
                if (bikeRepairStep != null)
                {
                    bikeRepairStep.Done = request.Done;
                    response.Data = bikeRepairStep;
                    response.Success = true;
                    response.Message = "";
                }
                else
                {
                    response.Success = false;
                    response.Message = "No matching bike repair step found!";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }
    }
}
