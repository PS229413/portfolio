﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.BikeRepairStep;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Services.BikeRepairStep
{
    public class BikeRepairStepService : IBikeRepairStepService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public BikeRepairStepService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        public async Task<ServiceResponse<List<GetBikeRepairStepDto>>> AddBikeRepairSteps(int bikeId)
        {
            ServiceResponse<List<GetBikeRepairStepDto>> response = new ServiceResponse<List<GetBikeRepairStepDto>>();

            try
            {
                List<GetBikeRepairStepDto> bikeRepairSteps = new List<GetBikeRepairStepDto>();

                List<Models.RepairStep> repairSteps = await _context.RepairSteps.ToListAsync();

                foreach (Models.RepairStep repairStep in repairSteps)
                {
                    Models.BikeRepairStep bikeRepairStep = _mapper.Map<Models.BikeRepairStep>(new AddBikeRepairStepDto(bikeId, repairStep.Id));

                    _context.BikeRepairSteps.Add(bikeRepairStep);

                    bikeRepairSteps.Add(_mapper.Map<GetBikeRepairStepDto>(bikeRepairStep));
                }

                await _context.SaveChangesAsync();

                response.Data = bikeRepairSteps;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<ServiceResponse<GetBikeRepairStepDto>> UpdateBikeRepairStep(UpdateBikeRepairStepDto request)
        {
            ServiceResponse<GetBikeRepairStepDto> response = new ServiceResponse<GetBikeRepairStepDto>();

            try
            {
                Models.BikeRepairStep? bikeRepairStep = _context.Find<Models.BikeRepairStep>(request.BikeId, request.RepairStepId);
                if (bikeRepairStep != null)
                {
                    bikeRepairStep.Done = request.Done;

                    await _context.SaveChangesAsync();

                    response.Data = _mapper.Map<GetBikeRepairStepDto>(bikeRepairStep);
                }
                else
                {
                    response.Success = false;
                    response.Message = "Bike repair step not found";
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;
            }

            return response;
        }
    }
}
