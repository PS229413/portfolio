﻿using AutoMapper;
using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Dtos.Images;
using HetFietsenStationAPI.Dtos.PhotographBike;


namespace HetFietsenStationAPI.Services.PhotographyBike
{
    public class PhotographyBikeService : IPhotographyBikeService
    {
        private readonly IMapper _mapper;
        private readonly DataContext _context;

        public PhotographyBikeService(IMapper mapper, DataContext context)
        {
            _mapper = mapper;
            _context = context;
        }

        public async Task<ServiceResponse<AddImageDto>> AddImageURL(AddPhotoDto request, string fileName, string host)
        {
            ServiceResponse<AddImageDto> response = new ServiceResponse<AddImageDto>();

            try
            {
                if (request.Type == "Bike")
                {
                    Models.Image image = new Models.Image() { Url = fileName, BikeId = request.Id };

                    _context.Image.Add(image);

                    await _context.SaveChangesAsync();

                    response.Data = _mapper.Map<AddImageDto>(image);
                }
                else if (request.Type == "Product")
                {
                    Models.Image image = new Models.Image() { Url = fileName, ProductId = request.Id };

                    _context.Image.Add(image);

                    await _context.SaveChangesAsync();

                    response.Data = _mapper.Map<AddImageDto>(image);
                }
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = ex.Message;

                string filePath = Path.Combine(Directory.GetCurrentDirectory(), "Uploads", fileName);
                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                }
            }

            return response;
        }
    }
}
