﻿using HetFietsenStationAPI.Dtos.Images;
using HetFietsenStationAPI.Dtos.PhotographBike;

namespace HetFietsenStationAPI.Services.PhotographyBike
{
    public interface IPhotographyBikeService
    {
        public Task<ServiceResponse<AddImageDto>> AddImageURL(AddPhotoDto request, string fileName, string host);
    }
}
