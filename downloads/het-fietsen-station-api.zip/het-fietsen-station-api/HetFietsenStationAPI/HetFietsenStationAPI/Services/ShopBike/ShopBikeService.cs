﻿namespace HetFietsenStationAPI.Services.ShopBike
{
    public class ShopBikeService
    {
    }
}
