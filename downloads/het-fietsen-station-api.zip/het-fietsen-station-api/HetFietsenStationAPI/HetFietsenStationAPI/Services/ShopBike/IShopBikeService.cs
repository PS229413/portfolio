﻿namespace HetFietsenStationAPI.Services.ShopBike
{
    public interface IRepairBikeService
    {
    }
}
