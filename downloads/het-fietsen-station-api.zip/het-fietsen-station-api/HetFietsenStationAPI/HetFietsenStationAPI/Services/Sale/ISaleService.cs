﻿namespace HetFietsenStationAPI.Services.Sale
{
    public interface ISaleService
    {
    }
}
