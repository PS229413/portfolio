﻿namespace HetFietsenStationAPI.Services.Sale
{
    public class SaleService
    {
    }
}
