﻿namespace HetFietsenStationAPI.Dtos.BikeRepairStep
{
    public class AddBikeRepairStepDto
    {
        public int BikeId { get; set; } = 0;
        public int RepairStepId { get; set; } = 0;
        public bool Done { get; set; } = false;

        public AddBikeRepairStepDto(int bikeId, int bikeRepairStepId, bool done = false) 
        {
            BikeId = bikeId;
            RepairStepId = bikeRepairStepId;
            Done = done;
        }
    }
}
