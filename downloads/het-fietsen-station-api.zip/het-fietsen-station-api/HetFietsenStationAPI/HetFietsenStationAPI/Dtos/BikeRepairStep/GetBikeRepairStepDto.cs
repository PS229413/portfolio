﻿using HetFietsenStationAPI.Dtos.RepairStep;

namespace HetFietsenStationAPI.Dtos.BikeRepairStep
{
    public class GetBikeRepairStepDto
    {
        public GetRepairStepDto? RepairStep { get; set; }
        public bool Done { get; set; } = false;
    }
}
