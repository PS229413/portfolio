﻿namespace HetFietsenStationAPI.Dtos.BikeRepairStep
{
    public class UpdateBikeRepairStepDto
    {
        public int BikeId { get; set; } = 0;
        public int RepairStepId { get; set; } = 0;
        public bool Done { get; set; } = false;
    }
}
