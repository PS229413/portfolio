﻿using HetFietsenStationAPI.Models;

namespace HetFietsenStationAPI.Dtos.SideProduct
{
    public class UpdateSideProductDto
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public List<Image> Images { get; set; } = null;
        public int Stock { get; set; } = 0;
        public int Price { get; set; } = 0;
        public int SideProductTypeId { get; set; } = 0;
    }
}
