﻿using HetFietsenStationAPI.Models;
using HetFietsenStationAPI.Dtos.SideProductType;

namespace HetFietsenStationAPI.Dtos.SideProduct
{
    public class GetSideProductDto
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public List<Image> Images { get; set; } = null;
        public int Stock { get; set; } = 0;
        public int Price { get; set; } = 0;
        public GetSideProductTypeDto? SideProductType { get; set; } = null;
    }
}
