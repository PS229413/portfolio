﻿namespace HetFietsenStationAPI.Dtos.SideProductType
{
    public class DeleteSideProductTypeDto
    {
        public int Id { get; set; }
    }
}
