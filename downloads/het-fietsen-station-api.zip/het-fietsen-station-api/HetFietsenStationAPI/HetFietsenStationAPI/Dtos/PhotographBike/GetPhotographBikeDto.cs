﻿using HetFietsenStationAPI.Dtos.BikeColor;
using HetFietsenStationAPI.Dtos.BikeCondition;
using HetFietsenStationAPI.Dtos.BikeSource;
using HetFietsenStationAPI.Dtos.BikeStatus;
using HetFietsenStationAPI.Dtos.BikeType;
using HetFietsenStationAPI.Dtos.User;
using HetFietsenStationAPI.Models;

namespace HetFietsenStationAPI.Dtos.PhotographBike
{
    public class GetPhotographBikeDto
    {
        public int Id { get; set; } = 0;
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string Note { get; set; } = string.Empty;
        public List<Image> Images { get; set; } = null;
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public int Price { get; set; } = 0;
        public DateTime RegistrationDate { get; set; }
        public DateTime RepairDate { get; set; }
        public GetBikeTypeDto? BikeType { get; set; } = null;
        public GetBikeColorDto? BikeColor { get; set; } = null;
        public GetBikeConditionDto? BikeCondition { get; set; } = null;
        public GetBikeStatusDto? BikeStatus { get; set; } = null;
        public GetBikeSourceDto? BikeSource { get; set; } = null;
        public GetUserDto? Mechanic { get; set; } = null;
    }
}
