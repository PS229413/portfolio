﻿namespace HetFietsenStationAPI.Dtos.PhotographBike
{
    public class AddPhotoDto
    {
        public int Id { get; set; }
        public List<IFormFile> Files { get; set; }
        public string? Type { get; set; }
    }
}