﻿namespace HetFietsenStationAPI.Dtos.RepairStep
{
    public class AddRepairStepDto
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public bool Required { get; set; } = false;
    }
}
