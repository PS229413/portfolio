﻿namespace HetFietsenStationAPI.Dtos.BikeType
{
    public class GetBikeTypeDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
    }
}
