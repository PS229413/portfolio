﻿namespace HetFietsenStationAPI.Dtos.Images
{
    public class UpdateImageDto
    {
        public int Id { get; set; } = 0;
        public string Url { get; set; } = string.Empty;
        public int? BikeId { get; set; } = 0;
        public int? ProductId { get; set; } = 0;
    }
}
