﻿namespace HetFietsenStationAPI.Dtos.Images
{
    public class DeleteImageDto
    {
        public int Id { get; set; }
    }
}
