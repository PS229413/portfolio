﻿namespace HetFietsenStationAPI.Dtos.Images
{
    public class AddImageDto
    {
        public string Url { get; set; } = string.Empty;
        public int? BikeId { get; set; } = 0;
        public int? ProductId { get; set; } = 0;
    }
}
