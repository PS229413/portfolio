﻿namespace HetFietsenStationAPI.Dtos.User
{
    public class GetUserDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int UserRoleId { get; set; }
    }
}
