﻿namespace HetFietsenStationAPI.Dtos.User
{
    public class DeleteUserDto
    {
        public int Id { get; set; }
    }
}
