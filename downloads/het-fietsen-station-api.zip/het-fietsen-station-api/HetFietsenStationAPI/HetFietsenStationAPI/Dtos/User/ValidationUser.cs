﻿namespace HetFietsenStationAPI.Dtos.User
{
    public class ValidationUser
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public byte[]? Password { get; set; }
        public int UserRoleId { get; set; }
    }
}
