﻿namespace HetFietsenStationAPI.Dtos.User
{
    public class AddUserDto
    {
        public string Name { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public int Role { get; set; } = 0;
    }
}
