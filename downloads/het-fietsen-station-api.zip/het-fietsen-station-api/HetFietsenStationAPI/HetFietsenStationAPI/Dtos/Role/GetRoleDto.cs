﻿namespace HetFietsenStationAPI.Dtos.Role
{
    public class GetRoleDto
    { 
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
    }
}
