﻿using HetFietsenStationAPI.Models;

namespace HetFietsenStationAPI.Dtos.RepairBike
{
    public class AddRepairBikeDto
    {
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public List<Image> Images { get; set; } = null;
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public DateTime? RegistrationDate { get; set; }
        public int BikeTypeId { get; set; }
        public int BikeColorId { get; set; }
        public int BikeConditionId { get; set; }
        public int BikeStatusId { get; set; }
        public int BikeSourceId { get; set; }
    }
}
