﻿using HetFietsenStationAPI.Models;

namespace HetFietsenStationAPI.Dtos.RepairBike
{
    public class RepairBikeToPhotographBikeDto
    {
        public int Id { get; set; } = 0;
        public string Note { get; set; } = string.Empty;
        public List<Image> Images { get; set; } = null;
        public int Price { get; set; } = 0;
        public DateTime RepairDate { get; set; }
        public int BikeStatusId { get; set; } = 0;
        public int MechanicId { get; set; } = 0;
    }
}
