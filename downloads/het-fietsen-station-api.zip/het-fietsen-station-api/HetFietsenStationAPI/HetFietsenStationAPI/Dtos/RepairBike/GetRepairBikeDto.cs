﻿using HetFietsenStationAPI.Models;
using HetFietsenStationAPI.Dtos.BikeColor;
using HetFietsenStationAPI.Dtos.BikeType;
using HetFietsenStationAPI.Dtos.BikeStatus;
using HetFietsenStationAPI.Dtos.BikeSource;
using HetFietsenStationAPI.Dtos.BikeCondition;

namespace HetFietsenStationAPI.Dtos.RepairBike
{
    public class GetRepairBikeDto
    {
        public int Id { get; set; } = 0;
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public List<Image> Images { get; set; }
        public DateTime? RegistrationDate { get; set; }
        public GetBikeTypeDto? BikeType { get; set; } = null;
        public GetBikeColorDto? BikeColor { get; set; } = null;
        public GetBikeConditionDto? BikeCondition { get; set; } = null;
        public GetBikeStatusDto? BikeStatus { get; set; } = null;
        public GetBikeSourceDto? BikeSource { get; set; } = null;
    }
}
