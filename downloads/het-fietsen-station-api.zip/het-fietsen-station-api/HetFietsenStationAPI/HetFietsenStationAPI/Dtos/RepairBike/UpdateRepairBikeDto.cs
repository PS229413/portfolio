﻿using HetFietsenStationAPI.Models;

namespace HetFietsenStationAPI.Dtos.RepairBike
{
    public class UpdateRepairBikeDto
    {
        public int Id { get; set; } = 0;
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public List<Image> Images { get; set; } = null;
        public int FrameNumber { get; set; } = 0;
        public int FrameHeight { get; set; } = 0;
        public int BikeTypeId { get; set; } = 0;
        public int BikeColorId { get; set; } = 0;
        public int BikeConditionId { get; set; } = 0;
        public int BikeSourceId { get; set; } = 0;
    }
}
