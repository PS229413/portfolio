﻿namespace HetFietsenStationAPI.Enums
{
    public enum UserRole
    {
        Admin = 1,
        Mechanic = 2,
        Photographer = 3,
        SalesPerson = 4
    }
}
