using HetFietsenStationAPI.Data;
using HetFietsenStationAPI.Services.Bike;
using HetFietsenStationAPI.Services.BikeColor;
using HetFietsenStationAPI.Services.BikeCondition;
using HetFietsenStationAPI.Services.BikeRepairStep;
using HetFietsenStationAPI.Services.BikeSource;
using HetFietsenStationAPI.Services.BikeStatus;
using HetFietsenStationAPI.Services.BikeType;
using HetFietsenStationAPI.Services.RepairStep;
using HetFietsenStationAPI.Services.Role;
using HetFietsenStationAPI.Services.SideProduct;
using HetFietsenStationAPI.Services.SideProductType;
using HetFietsenStationAPI.Services.User;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.Filters;
using System.Text;
using HetFietsenStationAPI.Controllers;
using Microsoft.Extensions.FileProviders;
using HetFietsenStationAPI.Services.PhotographyBike;
using HetFietsenStationAPI.Services.Images;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

// Creates the MySql database connection
builder.Services.AddDbContext<DataContext>(options =>
{
    options.UseMySql(builder.Configuration.GetConnectionString("DefaultConnection"), new MySqlServerVersion(new Version(8, 0, 28)));
});

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
    {
        Description = "Standard Authorization header using the Bearer scheme (\"bearer {token}\")",
        In = ParameterLocation.Header,
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey
    });

    options.OperationFilter<SecurityRequirementsOperationFilter>();
});

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8
            .GetBytes(builder.Configuration.GetSection("AppSettings:Token").Value)),
            ValidateIssuer = false,
            ValidateAudience = false,
            ValidateLifetime = true,
            ClockSkew = TimeSpan.Zero
        };
    });

builder.Services.AddAutoMapper(typeof(Program).Assembly);
builder.Services.AddScoped<ISideProductService, SideProductService>();
builder.Services.AddScoped<ISideProductTypeService, SideProductTypeService>();
builder.Services.AddScoped<IRepairStepService, RepairStepService>();
builder.Services.AddScoped<IBikeRepairStepService, BikeRepairStepService>();
builder.Services.AddScoped<IBikeTypeService, BikeTypeService>();
builder.Services.AddScoped<IBikeColorService, BikeColorService>();
builder.Services.AddScoped<IBikeConditionService, BikeConditionService>();
builder.Services.AddScoped<IBikeStatusService, BikeStatusService>();
builder.Services.AddScoped<IBikeSourceService, BikeSourceService>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IBikeService, BikeService>();
builder.Services.AddScoped<IRoleService, RoleService>();
builder.Services.AddScoped<IPhotographyBikeService, PhotographyBikeService>();
builder.Services.AddScoped<IImageService, ImageService>();

builder.Services.AddScoped<BaseMethod>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

//app.UseHttpsRedirection();

app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(
           Path.Combine(builder.Environment.ContentRootPath, "Uploads")),
    RequestPath = "/Uploads"
});

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();
