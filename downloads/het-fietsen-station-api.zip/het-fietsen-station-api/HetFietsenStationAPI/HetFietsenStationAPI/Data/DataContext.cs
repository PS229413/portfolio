﻿using HetFietsenStationAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace HetFietsenStationAPI.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder) 
        {
            modelBuilder.Entity<BikeRepairStep>()
                .HasKey(brs => new { brs.BikeId, brs.RepairStepId});

            modelBuilder.Entity<BikeRepairStep>()
                .HasOne(brs => brs.Bike)
                .WithMany(b => b.BikeRepairSteps)
                .HasForeignKey(b => b.BikeId);

            modelBuilder.Entity<BikeRepairStep>()
                .HasOne(brs => brs.RepairStep)
                .WithMany(rs => rs.BikeRepairSteps)
                .HasForeignKey(b => b.RepairStepId);

            modelBuilder.Entity<Image>()
                .HasOne(i => i.SideProduct)
                .WithMany(sp => sp.Images) // Add the inverse navigation property here
                .HasForeignKey(i => i.ProductId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Image>()
                .HasOne(i => i.Bike)
                .WithMany(b => b.Images) // Add the inverse navigation property here
                .HasForeignKey(i => i.BikeId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Image>()
                .Property(i => i.ProductId)
                .HasColumnName("productId");

            modelBuilder.Entity<Image>()
                .Property(i => i.BikeId)
                .HasColumnName("bikeId");
        }

        public DbSet<Bike> Bikes { get; set; }
        public DbSet<BikeType> BikeTypes { get; set; }
        public DbSet<BikeColor> BikeColors { get; set; }
        public DbSet<BikeCondition> BikeConditions { get; set; }
        public DbSet<BikeStatus> BikeStatuses { get; set; }
        public DbSet<BikeSource> BikeSources { get; set; }
        public DbSet<SideProduct> SideProducts { get; set; }
        public DbSet<SideProductType> SideProductTypes { get; set; }
        public DbSet<RepairStep> RepairSteps { get; set; }
        public DbSet<BikeRepairStep> BikeRepairSteps { get; set; }
        public DbSet<Image> Image { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
    }
}
