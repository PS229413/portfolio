#include <iostream>
#include <thread>
#include "../include/core/NetworkManager.h"
#include "../include/core/SpamFilter.h"
#include "../include/core/AdBlocker.h"
#include "../include/core/IDS.h"
#include "../include/core/Logger.h"
#include "../include/system/UpdateManager.h"
#include "../include/system/ProcessManager.h"
#include "../include/utils/SignalHandler.h"

using namespace std;

// Initialize components
NetworkManager networkManager;
SpamFilter spamFilter;
AdBlocker adBlocker;
IDS ids;
Logger logger;
UpdateManager updateManager;
ProcessManager processManager;

void initializeSystem() {
    // Initialize logger
    logger.init("logs/pishield.log","logs/pishield.log");

    // Load configurations
    networkManager.loadConfig("config/network_config.yaml");
    spamFilter.loadRules("config/spam_rules.yaml");
    adBlocker.loadRules("config/adblock_rules.yaml");
    ids.loadRules("config/ids_rules.yaml");

    // Print initialization logs
    logger.log("PiShield system initialized", Logger::INFO);
    logger.log("Potential issue detected", Logger::WARNING);
    logger.log("Critical failure encountered!", Logger::ERROR);
    logger.log("Loading network, spam, adblock, and IDS configurations...", Logger::INFO);
}

// Main loop function to run PiShield as a continuous service
void runPiShield() {
    while (true) {
        // Capture and analyze network traffic
        networkManager.captureTraffic();

        // Apply spam filtering
        //networkManager.filterTraffic(spamFilter);

        // Apply ad blocking
        //networkManager.filterTraffic(adBlocker);

        // Monitor for security threats
        //ids.monitorTraffic(networkManager.getTraffic());

        // Sleep for a short while before the next iteration
        this_thread::sleep_for(chrono::seconds(10));
    }
}

// Signal handling for clean shutdown
void handleShutdown(int signal) {
    //logger.log("Shutdown signal received. Stopping PiShield...", Logger::INFO);

    // Stop processes and clean up
    //processManager.stopAll();
    //networkManager.shutdown();
    //logger.shutdown();

    exit(0); // Exit cleanly
}

int main(int argc, char* argv[]) {
    // Register signal handler for graceful shutdown
    //SignalHandler::registerSignalHandler(SIGINT, handleShutdown);

    // Initialize the system
    initializeSystem();

    // Start update and log management services in background threads
    //thread updateThread(&UpdateManager::run, &updateManager);
    //thread logThread(&Logger::runLogRotation, &logger);

    // Main PiShield operation loop
    runPiShield();

    // Join threads before exiting (this point will not be reached until shutdown)
    //updateThread.join();
    //logThread.join();

    return 0;
}
