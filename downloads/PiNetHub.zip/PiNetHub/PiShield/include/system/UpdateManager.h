//
// Created by raulv on 17-9-2024.
//

#ifndef UPDATEMANAGER_H
#define UPDATEMANAGER_H

class UpdateManager{

};

#endif //UPDATEMANAGER_H
