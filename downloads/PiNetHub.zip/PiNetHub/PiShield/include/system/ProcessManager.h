//
// Created by raulv on 17-9-2024.
//

#ifndef PROCESSMANAGER_H
#define PROCESSMANAGER_H

class ProcessManager {

};

#endif //PROCESSMANAGER_H
