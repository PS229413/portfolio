//
// Created by raulv on 17-9-2024.
//

#ifndef MLSPAMDETECTION_H
#define MLSPAMDETECTION_H



class MLSpamDetection {

};



#endif //MLSPAMDETECTION_H
