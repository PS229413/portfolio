//
// Created by raulv on 17-9-2024.
//

#ifndef ANOMALYDETECTION_H
#define ANOMALYDETECTION_H



class AnomalyDetection {

};



#endif //ANOMALYDETECTION_H
