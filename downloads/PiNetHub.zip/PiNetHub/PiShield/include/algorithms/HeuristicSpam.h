//
// Created by raulv on 17-9-2024.
//

#ifndef HEURISTICSPAM_H
#define HEURISTICSPAM_H



class HeuristicSpam {

};



#endif //HEURISTICSPAM_H
