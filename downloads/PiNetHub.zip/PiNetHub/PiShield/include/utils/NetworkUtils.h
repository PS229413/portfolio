//
// Created by raulv on 17-9-2024.
//

#ifndef NETWORKUTILS_H
#define NETWORKUTILS_H



class NetworkUtils {

};



#endif //NETWORKUTILS_H
