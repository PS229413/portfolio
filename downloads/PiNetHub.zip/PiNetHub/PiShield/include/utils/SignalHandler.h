//
// Created by raulv on 17-9-2024.
//

#ifndef SIGNALHANDLER_H
#define SIGNALHANDLER_H



class SignalHandler {

};



#endif //SIGNALHANDLER_H
