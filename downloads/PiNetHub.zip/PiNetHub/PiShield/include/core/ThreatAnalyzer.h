//
// Created by raulv on 17-9-2024.
//

#ifndef THREATANALYZER_H
#define THREATANALYZER_H



class ThreatAnalyzer {

};



#endif //THREATANALYZER_H
