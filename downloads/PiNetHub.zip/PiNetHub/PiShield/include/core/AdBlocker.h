//
// Created by raulv on 17-9-2024.
//

#ifndef ADBLOCKER_H
#define ADBLOCKER_H

class AdBlocker {
private:
    std::ofstream rulesFile;  // This should be for writing, but we will use ifstream for loading/reading
public:
    // Method to load the configuration file
    void loadRules(const char* rulesFilePath) {
        std::ifstream rulesFile(rulesFilePath);  // Use ifstream for reading the config file

        if (!rulesFile.is_open()) {
            std::cerr << "Failed to open configuration file: " << rulesFilePath << std::endl;
            return;
        }

        std::string line;
        while (std::getline(rulesFile, line)) {
            // Here you can process each line of the config file
            std::cout << "Read line: " << line << std::endl;
        }

        rulesFile.close();  // Close the file after reading
    }
};

#endif //ADBLOCKER_H
