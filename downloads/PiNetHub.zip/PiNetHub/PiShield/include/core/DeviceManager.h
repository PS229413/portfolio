//
// Created by raulv on 17-9-2024.
//

#ifndef DEVICEMANAGER_H
#define DEVICEMANAGER_H



class DeviceManager {

};



#endif //DEVICEMANAGER_H
