//
// Created by raulv on 17-9-2024.
//

#ifndef NETWORKMANAGER_H
#define NETWORKMANAGER_H
#include <fstream>
#include <iostream>


class NetworkManager {
private:
    std::ofstream configFile;  // This should be for writing, but we will use ifstream for loading/reading
public:
    // Method to load the configuration file
    void loadConfig(const char* configFilePath) {
        std::ifstream configFile(configFilePath);  // Use ifstream for reading the config file

        if (!configFile.is_open()) {
            std::cerr << "Failed to open configuration file: " << configFilePath << std::endl;
            return;
        }

        std::string line;
        while (std::getline(configFile, line)) {
            // Here you can process each line of the config file
            std::cout << "Read line: " << line << std::endl;
        }

        configFile.close();  // Close the file after reading
    }
public:void captureTraffic() {

}
};



#endif //NETWORKMANAGER_H
