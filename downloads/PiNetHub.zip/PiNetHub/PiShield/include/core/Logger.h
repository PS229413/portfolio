//
// Created by raulv on 17-9-2024.
//

#ifndef LOGGER_H
#define LOGGER_H
#include <fstream>
#include <functional>
#include <iostream>


class Logger {
public:
    enum LogLevel { INFO, WARNING, ERROR };

private:
    std::ofstream logFile;
    std::ofstream errorFile;

    // Helper function to get current timestamp
    std::string getTimestamp() {
        time_t now = time(0);
        char buf[80];
        strftime(buf, sizeof(buf), "%Y-%m-%d %X", localtime(&now));
        return std::string(buf);
    }

    // Helper function to get string representation of log level
    std::string logLevelToString(LogLevel level) {
        switch (level) {
            case INFO: return "INFO";
            case WARNING: return "WARNING";
            case ERROR: return "ERROR";
            default: return "UNKNOWN";
        }
    }

public:
    // Initialization function
    void init(const char* logFilePath, const char* errorFilePath) {
        logFile.open(logFilePath, std::ios::app);
        errorFile.open(errorFilePath, std::ios::app);

        if (!logFile.is_open() || !errorFile.is_open()) {
            std::cerr << "Failed to open log files!" << std::endl;
            return;
        }

        // Log initialization messages
        log("Logger initialized.", INFO);
        log("Errors will be logged to error file.", INFO);
    }

    // Log function with severity level
    void log(const std::string& message, LogLevel level) {
        std::string timestamp = getTimestamp();
        std::string logMessage = timestamp + " [" + logLevelToString(level) + "] " + message + "\n";

        // Log to appropriate file based on log level
        if (level == ERROR) {
            errorFile << logMessage;
        } else {
            logFile << logMessage;
        }
    }

    // Destructor to close the log files
    ~Logger() {
        if (logFile.is_open()) {
            logFile.close();
        }
        if (errorFile.is_open()) {
            errorFile.close();
        }
    }
};



#endif //LOGGER_H
