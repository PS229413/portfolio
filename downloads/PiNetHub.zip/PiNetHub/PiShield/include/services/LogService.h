//
// Created by raulv on 17-9-2024.
//

#ifndef LOGSERVICE_H
#define LOGSERVICE_H



class LogService {

};



#endif //LOGSERVICE_H
